<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Tymon\JWTAuth\Contracts\JWTSubject;

class VetCare extends Authenticatable implements JWTSubject
{
    //

    protected $table = 'vet_care';

    protected $fillable = ['name','clinic_name','email','password','phone_no','address','other'];

    protected $hidden = ['password'];

    protected $appends = ['app','IsEnableHandshake'];

    protected $casts = [
        'other' => 'object'
    ];

    public function getJWTIdentifier()
    {
        return $this->getKey();
    }

    public function getJWTCustomClaims()
    {
        return [];
    }

    public function app(){
        return $this->morphOne(App::class, 'model');
    }

    public function getAppAttribute(){
        return $this->app()->pluck('name');
    }

    public function getIsEnableHandshakeAttribute(){
        return ($this->app()->first() && is_handshake_enabled($this->app()->first()->id)) ? 1 : 0 ;
    }

    public function loadVetCareUser(){
        return $this->app()->with('vetCareUsers');
    }

    public function appSettings()
    {
        return $this->belongsTo(AppSetting::class, 'id', 'clinic_id');
    }

    public function vetCareCoupon(){
        return $this->morphMany(VetCareCoupon::class, 'model');
    }
}
