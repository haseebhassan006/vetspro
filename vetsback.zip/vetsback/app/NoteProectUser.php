<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class NoteProectUser extends Model
{
    //
    protected $table = 'notes_protect_users';

    protected $fillable = ['user_id','emergency_id','paid','amount','note','attachment','pet_name','clinic_arrival_time','app_id','pet_species','pet_age','pet_sex','clinic_name','clinic_phone_no','paid_by'];

    public $timestamps = false;

    protected $casts = ['attachment'=>'array'];

}
