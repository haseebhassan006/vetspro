<?php

namespace App;

use App\Traits\CustomSearch;
use Illuminate\Database\Eloquent\Model;

class WebAppUsersExtra extends Model
{
    //
    use CustomSearch;
    protected $table = 'webapps_users_extra';
    protected $guarded = [];
    protected $searchable = [
        'protected','type'
    ];

    public function webappuser(){
        return $this->belongsTo(WebappUser::class,'user_id','id');
    }
    public function vetData(){
        return $this->hasMany(Vet::class,'id','vet_id');
    }


}
