<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AppointmentPayment extends Model
{
    protected $guarded = [];

    protected $casts = [
        'stripe_response' => 'array',
    ];

    public function model(){
        return $this->morphTo();
    }


    public function appointmentBookings(){
        return $this->hasMany(AppointmentBooking::class);
    }
}
