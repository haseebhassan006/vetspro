<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class ReviewNameTrainerReview extends Model
{
    protected $table = 'review_name_trainer_review';

    protected $fillable = ['review_name_id','trainer_review_id','rate'];

    public $timestamps = false;

    public function reviewName(){
        return $this->belongsTo(ReviewName::class);
    }


    public function trainerReview(){
        return $this->belongsTo(TrainerReview::class);
    }
}
