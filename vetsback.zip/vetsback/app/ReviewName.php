<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class ReviewName extends Model
{

    use SoftDeletes;

    protected $fillable = ['title'];

    protected $hidden = ['updated_at','deleted_at'];

    public function ratings(){
        return $this->hasMany(ReviewNameTrainerReview::class);
    }

}
