<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class VetCarePackageMetaData extends Model
{
    //
    protected $fillable = ['package_id','commission','faqs','rules_and_regulations'];
}
