<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class StaffQueue extends Model
{
    use SoftDeletes;
    protected $guarded = [];

    public function queue(): \Illuminate\Database\Eloquent\Relations\HasMany
    {
        return $this->hasMany(SubAdmin::class,'id','staff_id');
    }
}
