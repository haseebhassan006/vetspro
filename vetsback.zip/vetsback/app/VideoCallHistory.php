<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class VideoCallHistory extends Model
{
    //
    protected $guarded = [];
    public function video()
    {
        return $this->belongsTo(VideoCall::class,'video_call_id','id');
    }
}
