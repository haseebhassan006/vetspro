<?php

namespace App;
use App\Traits\CustomSearch;
use Illuminate\Database\Eloquent\Model;

class ExtraPet extends Model
{
    //
    use CustomSearch;
    protected $guarded =[];
    protected $softCascade = ['petVeterians','petMedicals','petInsurnaces'];
    protected $searchable = [
        'name','species','age','breed','color','sex','weight','sex_type'
    ];
    protected $appends = ['veterians','medicals','insurnaces'];

    public function webappUser()
    {
        return $this->hasONe(User::class, 'id', 'user_id');
    }

    public function petVeterians(){
        return $this->hasMany(PetVeterinarian::class,'pet_id');
    }
    public function getVeteriansAttribute()
    {
        $this->load('petVeterians');
    }
    public function petMedicals(){
        return $this->hasMany(PetMedical::class,'pet_id');
    }
    public function getMedicalsAttribute()
    {
        $this->load('petMedicals');
    }
    public function petInsurnaces(){
        return $this->hasMany(PetInsurance::class,'pet_id');
    }
    public function getInsurnacesAttribute()
    {
        $this->load('petInsurnaces');
    }
}
