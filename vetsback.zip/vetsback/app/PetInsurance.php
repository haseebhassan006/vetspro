<?php

namespace App;

use App\Traits\CustomSearch;
use App\Traits\FullTextSearch;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class PetInsurance extends Model
{
    //
    //use FullTextSearch;
    use CustomSearch;
    use SoftDeletes;

    protected $guarded = [];

    protected $searchable = [
        'is_insured','policy_number','company'
    ];

    public function pets(){
        return $this->belongsTo(Pet::class);
    }
}
