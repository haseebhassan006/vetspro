<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AppointmentBooking extends Model
{
    protected $guarded = [];

    public function model(){
         return $this->morphTo();
     }
     public function user()
     {
         return $this->belongsTo(VetCareUser::class,'model_id','id');
     }
     public function schedule()
     {
         return $this->belongsTo(TrainerSchedule::class,'schedule_id','id');
     }

     public function appointmentPayment()
     {
         return $this->belongsTo(AppointmentPayment::class,'appointment_payment_id','id');
     }

     public function app()
     {
         return $this->belongsTo(App::class,'app_id','id');
     }

     public function trainer()
     {
         return $this->belongsTo(Trainer::class,'trainer_id','id');
     }

     public function reviews()
    {
        return $this->morphMany(TrainerReview::class, 'reviewable','model_type','model_id');
    }
    public function pet()
    {
        return $this->belongsTo(Pet::class,'pet_id','id');
    }
}
