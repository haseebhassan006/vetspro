<?php

namespace App;

use App\Traits\CustomSearch;
use App\Traits\FullTextSearch;
use Illuminate\Database\Eloquent\Model;

class ChatDetail extends Model
{
    //
    use CustomSearch;
//    use FullTextSearch;
    protected $guarded = [];
    protected $casts = ['body'=>'json','attributes'=>'array'];
    protected $searchable = ['body','attributes'];

    public function chat(){
        return $this->hasOne(Chat::class,'id','chat_id')->latest();
    }

    public function getChatByApp($app_id){
        return $this->chat()->where('app_id','=', $app_id);
    }

    public function getColumnNameAttribute($value) {
        return json_decode($value);
    }
}
