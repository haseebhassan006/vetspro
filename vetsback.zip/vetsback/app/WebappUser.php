<?php

namespace App;

use App\Traits\CustomSearch;
use App\Traits\WhereAppType;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;


class WebappUser extends Model
{
    //
    use SoftDeletes;
    use CustomSearch;
    use WhereAppType;
    protected $guarded = [];
    protected $fillable = ['app_id','first_name','last_name','email','twilio_user_id','dev_type','your_registration_date','phone_no','next_emergency_activation_date'];
    protected $appends = ['app','activedays'];

    protected $searchable = [
        'first_name','last_name','email'
    ];
    public function getAppAttribute(){
        return $this->apps()->pluck('name');
    }

    public function getActiveDaysAttribute()
    {
        $last_date = date('Y-m-d');
        $dataset = UserAppStatus::where('user_id', $this->attributes['id'])->orderBy('id', 'DESC')->get();
        foreach ($dataset as $data) {
            if ($data->status == 'cancelled') {
                break;
            } else {
                $last_date = $data->created_at;
            }
        }
        $to = Carbon::createFromFormat('Y-m-d', date('Y-m-d'));
        $from = Carbon::createFromFormat('Y-m-d', date('Y-m-d', strtotime($last_date)));
        $diff_in_days = $to->diffInDays($from);
        return $diff_in_days;
    }

    public function emergency(){
        return $this->hasMany(WebAppUsersExtra::class,'user_id','id');
    }

    public function emergencyLastestProtect(){
        return $this->hasOne(WebAppUsersExtra::class,'user_id','id')->orderBy('id', 'desc');
    }

    public function emergencyLatest(){

        return $this->hasOne(WebAppUsersExtra::class,'user_id','id')->where('type','video')->latest();
//                ->whereRaw("(select max(`id`) from webapps_users_extra)");
    }

    public function apps(){
        return $this->hasMany(App::class,'id','app_id');
    }

    public function pets()
    {
        return $this->belongsTo(ExtraPet::class, 'id', 'user_id');
    }

    public function user_status(){
        return $this->hasMany(UserAppStatus::class,'user_id','id');
    }

    public function user_status_latest(){
        return $this->hasOne(UserAppStatus::class,'user_id','id')->latest();
    }

//    public function flagsEmergency(){
//        return $this->hasOne(FlagProtectUser::class,'user_id','id');
//    }
//
//    public function notesEmergency(){
//        return $this->hasOne(NoteProectUser::class,'user_id','id');
//    }

    public function userStatusType()
    {
        return $this->hasOne(ReportUserTypeStatus::class,'user_id','id')
                    ->whereIn('app_id',$this->whereAppIdArray(['webapp']));
    }

    public function userExtraData(){
        return $this->hasOne(WebappUserExtraInformation::class,'user_id','id');
    }




//    public function packageUsage(){
//        return $this->hasMany(PackageUsage::class,'user_id','id');
//
//    }

}
