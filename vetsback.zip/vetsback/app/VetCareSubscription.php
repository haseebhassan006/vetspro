<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class VetCareSubscription extends Model
{
    //
    use SoftDeletes;

    protected $fillable = ['user_id','subscription_id','start_date','end_date','status','others'];

    protected $casts = [
        'others' => 'object'
    ];

    public function subscriptonsData(){
        return $this->belongsTo(VetCareUser::class,'user_id','id');
    }
    
}
