<?php

namespace App;

use App\Traits\FullTextSearch;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class VetCareCoupon extends Model
{
    use FullTextSearch;
    use SoftDeletes;

    protected $fillable = ['other','model_id','model_type','package_id','created_by','created_model','updated_by','updated_model','deleted_by','deleted_model'];

    protected $casts = ['other'=>'json'];

    protected $searchable = ['other'];

    protected $hidden = ['updated_at','model_id','model_type'];

    public function model()
    {
        return $this->morphTo();
    }

    public function vetCarePackage(){
        return $this->belongsTo(VetCarePackage::class,'package_id');
    }

    public function vetCareCouponCodes()
    {
        return $this->morphMany(VetCareCouponCode::class, 'model');
    }
    public function vetCareCouponCode()
    {
        return $this->morphOne(VetCareCouponCode::class, 'model');
    }


}
