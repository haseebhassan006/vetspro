<?php

namespace App;

use App\Traits\CustomSearch;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Tymon\JWTAuth\Contracts\JWTSubject;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Spatie\Permission\Traits\HasRoles;
use JWTAuth;

class Vet extends Authenticatable implements JWTSubject
{
    //
    use Notifiable;
    use HasRoles;
    use SoftDeletes;
    use CustomSearch;

    protected $fillable = ['first_name','last_name','is_online','status','email','password','is_call'];
    protected $guard_name = 'vets';
    protected $appends = ['role_names','queue'];
    protected $searchable = ['first_name','last_name','email'];


    protected $hidden = [
        'password'
    ];
    /**
     * Get the identifier that will be stored in the subject claim of the JWT.
     *
     * @return mixed
     */
    public function getJWTIdentifier()
    {
        return $this->getKey();
    }

    /**
     * Return a key value array, containing any custom claims to be added to the JWT.
     *
     * @return array
     */
    public function getJWTCustomClaims()
    {
        return [];
    }

    public function chats()
    {
        return $this->morphMany(Chat::class, 'sender');
    }

    public function apps(){
        return $this->belongsTo(App::class);
    }
    public function appsMorph(){
        return $this->belongsTo(App::class);
    }

    public function devices(){
        return $this->morphOne(Device::class, 'model');
    }

    public function devicesThrashed(){
        return $this->morphOne(Device::class, 'model')->latest()->withTrashed();
    }

    public function vetDetails(){
        return $this->hasOne(VetDetail::class);
    }

    public function getRoleNamesAttribute()
    {
        return $this->getRoleNames();
    }

    public function vetAuthenticationHistory()
    {
        return $this->morphMany(AuthenticationHistory::class, 'model');
    }

    public function lastVetHistory()
    {
        return $this->morphMany(AuthenticationHistory::class, 'model')->where('type','login')->latest();
    }

    public function vet()
    {
        return $this->belongsTo(VideoCall::class,'id','vet_id');
    }
    public function coupon(){
        return $this->morphMany(Coupon::class, 'model');
    }
    public function vetCareCoupon(){
        return $this->morphMany(VetCareCoupon::class, 'model');
    }
    public function package(){
        return $this->hasOne(Package::class);
    }
    public function videoCall(){
        return $this->belongsTo(VideoCall::class,'id','vet_id');
    }
    public function queue(){
        return $this->hasMany(Queue::class);
    }
    public function webAppUser(){
        return $this->belongsTo(WebAppUsersExtra::class);
    }
    public function notification(){
        return $this->belongsTo(Notification::class,'id','user_to_notify');
    }
    public function end_chat(){
        return $this->hasMany(Chat::class,'vet_id','id');
    }

    public function attachments()
    {
        return $this->morphMany(TemplateAttachment::class, 'attachmentable');
    }

    public function notable()
    {
        return $this->morphMany(StaffNote::class, 'notable');
    }

    public function getQueueAttribute()
    {
        return count($this->queue()->where('status',0)->get()) > 0 ? true : false ; 
    }

    public function userFeedback(){
        return $this->morphMany(VetCareUserFeedback::class, 'model');
    }

    public function video(){
        return $this->morphMany(VideoCall::class, 'model');
    }
}
