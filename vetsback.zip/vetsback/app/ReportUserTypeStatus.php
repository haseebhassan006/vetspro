<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ReportUserTypeStatus extends Model
{
    protected $fillable = ['user_id','app_id','role','date_time'];
}
