<?php

use App\App;
use Carbon\Carbon;
use App\AppSetting;
use App\WebappUser;
use PhpOption\Option;
use Illuminate\Support\Arr;
use Illuminate\Support\Str;
use Illuminate\Support\Optional;
use Illuminate\Support\Collection;
use Dotenv\Environment\DotenvFactory;
use Illuminate\Contracts\Support\Htmlable;
use Illuminate\Support\HigherOrderTapProxy;
use Dotenv\Environment\Adapter\PutenvAdapter;
use Dotenv\Environment\Adapter\EnvConstAdapter;
use Dotenv\Environment\Adapter\ServerConstAdapter;

function get_sql($model)
{
    $sql = $model->toSql();
    $bindings = $model->getBindings();
    $sql_with_bindings = preg_replace_callback('/\?/', function ($match) use ($sql, &$bindings) {
        return json_encode(array_shift($bindings));
    }, $sql);
    return dd($sql_with_bindings);
}

if (! function_exists('suspend_app')) {
    /**
     * Assign high numeric IDs to a config item to force appending.
     *
     * @param  array  $array
     * @return array
     */
    function suspend_app($appId=null)
    {
        $status = true;

        $app = App::find($appId);
        if ($app && $app->is_suspended == 1) {
            $status = false;
        }
        return $status;

    }

}

if (! function_exists('appname_by_appid')) {
    /**
     * Assign high numeric IDs to a config item to force appending.
     *
     * @param  array  $array
     * @return array
     */
    function appname_by_appid($appId=null)
    {
        $app = App::find($appId);
        if ($app) {
            return $app->name;
        }
        return 'Not Found';

    }

}

if (! function_exists('apptype_by_appid')) {
    /**
     * Assign high numeric IDs to a config item to force appending.
     *
     * @param  array  $array
     * @return array
     */
    function apptype_by_appid($appId=null)
    {
        $app = App::find($appId);
        if ($app) {
            return $app->app_type;
        }
        return 'Not Found';

    }

}

if (! function_exists('appId_by_key')) {
    /**
     * function to get app id by key.
     *
     * @param  array  $array
     * @return array
     */
    function appId_by_key($key=null)
    {
        $app = App::where('api_key',$key)->first();
        if ($app) {
            return $app->id;
        }
        return null;
    }

}

function errorResponse($error, $code = 401,$errorMessages = []){

    $statusCode = $code == 0 ? 401 : $code;
    $response = [
        'success' => false,
        'status_code' =>$statusCode,
        'message' => is_array($error) == TRUE ? $error : [$error],
        'data'    => []
    ];

    return response()->json($response, $statusCode);
}

// Function to get vet busy dynamic text from DB
if (! function_exists('get_vet_busy_text')) {
    /**
     * Assign high numeric IDs to a config item to force appending.
     *
     * @param  array  $array
     * @return array
     */
    function get_vet_busy_text($appId=null)
    {
        $message = 'Vets are busy at the moment. Try again later';
        if($appId){
            $appSetting = AppSetting::where('app_id',$appId)->first();
            // $app = App::find($appId);
            if($appSetting){
                if(isset(json_decode($appSetting->other)->chat_error)){
                    $message = json_decode($appSetting->other)->chat_error;
                }
            }
        }
        return $message;

    }

}

// Function to know if app is handshake or not
if (! function_exists('is_handshake_enabled')) {
    /**
     *
     * @param  id  $id
     * @return bool
     */
    function is_handshake_enabled($appId=null)
    {
        $status = false;

        if($appId){
            $appSetting = AppSetting::where('app_id',$appId)->first();
            if($appSetting){
                if(isset(json_decode($appSetting->other)->enable_handshake)){
                   if(json_decode($appSetting->other)->enable_handshake == 1){
                          $status = true;
                   }
                }
            }
        }

        return $status;
    }

}

// Function to know if app Environment is local or not
if (! function_exists('is_local_env')) {
    /**
     *
     * @param  id  $id
     * @return bool
     */
    function is_local_env()
    {
        $status = false;

        if(env('APP_ENV') == 'local'){
            $status = true;
        }

        return $status;
    }

}

// Function to check webappuser Emergency Status
if (! function_exists('webappuserEmergencyStatus')) {
    /**
     *
     * @param  user_id  $userId
     * @return bool
     */
    function webappuserEmergencyStatus($userId=null, $appId)
    {
        //  Initialize variables
        $result = array();
        $now = Carbon::now();
        $userType = 'users';
        $trialPeriodCount = 0;
        $trialPeriodStartDate = null;
        $trialPeriodEndDate = null;
        $remainingTrialPeriodDays = null;
        $lastEmergencyActivationDate = null;
        $nextEmergencyActivationDate = null;
        $emergencyFund = 0;
        $canActivateEmergency = false;

        $user = WebappUser::where('id', $userId)->first();

        if ($user && $appId) {

            // Set User Type
            $userType = isset($user->emergencyLastestProtect) ? $user->emergencyLastestProtect->protected : 'users';

            // Get App Trial Period Count
            $trialPeriodCount = App::find($appId)->trial_period;

            // Trial Period Start Date
            $trialPeriodStartDate = $user->created_at;

            // Trial Period End Date
            $trialPeriodEndDate = ($user->created_at)->addDays($trialPeriodCount);

            // Remaining Trial Period Days
            $trialPeriodEndDate < $now ;
            $remainingTrialPeriodDays = $trialPeriodEndDate < $now ? 0 : $trialPeriodEndDate->diffInDays(Carbon::now());

            // Next Emergency Activation Date
            $nextEmergencyActivationDate = $user->next_emergency_activation_date;

            // Last Emergency Activation Date
            $lastEmergencyActivationDate = ($nextEmergencyActivationDate != null) ? Carbon::parse($user->next_emergency_activation_date)->subYear(1) : null;

            // Emergency Funds
            $emergencyFund = $user->emergency_fund;

            // Can Activate Emergency
            if ($userType == 'protect_users') { // If user type is protected
                if ($remainingTrialPeriodDays <= 0) {
                    $canActivateEmergency = true;
                    if ($lastEmergencyActivationDate && $nextEmergencyActivationDate > $now) {
                        $canActivateEmergency = false;
                    }
                }
            }
        }

        $result = [
            'user_type' => $userType,
            'trial_period_count' => $trialPeriodCount,
            'trial_period_start_date' => $trialPeriodStartDate ? date_format($trialPeriodStartDate,"Y-m-d H:i:s") : null,
            'trial_period_end_date' => $trialPeriodEndDate ? date_format($trialPeriodEndDate,"Y-m-d H:i:s") : null,
            'remaining_trial_period_days' => $remainingTrialPeriodDays,
            'last_emergency_activation_date' => $lastEmergencyActivationDate ? date_format($lastEmergencyActivationDate,"Y-m-d H:i:s") : null,
            'next_emergency_activation_date' => $nextEmergencyActivationDate,
            'emergency_fund' => $emergencyFund,
            'can_activate_Emergency' => $canActivateEmergency
        ];

        return $result;
    }
}
