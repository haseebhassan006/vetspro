<?php

namespace App;

use App\Traits\CustomSearch;
use App\Traits\FullTextSearch;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class PetMedical extends Model
{
    //
    //use FullTextSearch;
    use CustomSearch;
    use SoftDeletes;
    protected $guarded = [];
    protected $searchable = [
        'history','allergies','diet','is_vaccinated'
    ];
    public function pets(){
        return $this->belongsTo(Pet::class);
    }
}
