<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FeedbackEmail extends Model
{
    protected $fillable = ['email'];
    protected $appends = ['app_name']; 

    public function getAppNameAttribute(){
        return $this->app()->first() ? $this->app()->first()->name : '';
    }

    public function app(){
        return $this->hasOne(App::class,'id','app_id');
    }

}

