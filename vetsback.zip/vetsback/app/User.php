<?php

namespace App;

use App\App;
use App\Traits\CustomSearch;
use App\Traits\WhereAppType;
use Carbon\Carbon;
use Spatie\Permission\Traits\HasRoles;
use Tymon\JWTAuth\Contracts\JWTSubject;
use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;


class User extends Authenticatable implements JWTSubject
{
    use Notifiable;
    use SoftDeletes;
    use HasRoles;
    use CustomSearch;
    use WhereAppType;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $guard_name = 'users';

    protected $appends = ['role_names','app','activedays'];

    protected $fillable = [
        'first_name', 'last_name', 'email', 'password', 'app_id', 'is_online', 'status', 'stripe_id', 'card_id', 'trail_ends_at','next_emergency_activation_date'
    ];

    protected $searchable = ['first_name', 'last_name', 'email'];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token'
    ];
    //protected $guarded = [];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];
    //protected $appends = ['user_details'];

    // Rest omitted for brevity

    /**
     * Get the identifier that will be stored in the subject claim of the JWT.
     *
     * @return mixed
     */
    public function getJWTIdentifier()
    {
        return $this->getKey();
    }

    /**
     * Return a key value array, containing any custom claims to be added to the JWT.
     *
     * @return array
     */
    public function getJWTCustomClaims()
    {
        return [];
    }

    public function getRoleNamesAttribute(){
        return $this->getRoleNames();
    }

    public function getAppNameAttribute(){
        return $this->getAppAttribute();
    }

    public function userDetails(){
        return $this->hasOne(UserDetail::class);
    }

    public function apps(){
        return $this->hasMany(App::class,'id','app_id');
    }

    public function pets(){
        return $this->morphMany(Pet::class, 'model');
    }

    public function devices(){
        return $this->morphMany(Device::class, 'model');
    }

    public function chats(){
        return $this->belongsTo(Chat::class);
    }

    public function getAppAttribute(){
        return $this->apps()->pluck('name');
    }

    public function getActiveDaysAttribute()
    {
        $last_date = date('Y-m-d');
        foreach ($this->usageLatest as $data) {
            if ($data->deleted_at != '') {
                break;
            } else {
                $last_date = $data->created_at;
            }
        }
        $to = Carbon::createFromFormat('Y-m-d', date('Y-m-d'));
        $from = Carbon::createFromFormat('Y-m-d', date('Y-m-d', strtotime($last_date)));
        $diff_in_days = $to->diffInDays($from);
        return $diff_in_days;
    }

    public function getUserDetails($id){
        return User::find($id);
    }

    public function updateAppId($value){
        return $this->load('apps')->update(['app_id'=>$value]);
    }

    public function userDetailData(){
        return $this->load('user_details');
    }

    public function userAuthenticationHistory(){
        return $this->morphMany(AuthenticationHistory::class, 'model');
    }

    public function videoCall(){
        return $this->belongsTo(VideoCall::class,'id','user_id');
    }

    public function couponRedeem(){
        return $this->morphMany(CouponUsage::class, 'model');
    }

    public function coupon(){
        return $this->morphMany(Coupon::class, 'model');
    }

    public function usage(){
        return $this->hasMany(PackageUsage::class,'user_id','id');
    }

    public function usageLatest(){
        return $this->hasMany(PackageUsage::class,'user_id','id')->orderBy('id', 'DESC');
    }

    public function trashUsage(){
        return $this->hasMany(PackageUsage::class,'user_id','id')->withTrashed();
    }

    public function packages(){
        return $this->hasMany(Package::class,'user_id','id');
    }

    public function payment(){
        return $this->hasMany(Payment::class,'user_id','id');
    }

    public function latestPayment(){
        return $this->hasOne(Payment::class,'user_id','id')->latest();
    }

    public function latestPaymentHasMany(){
        if (request()->has('date_from') && request()->has('date_to')) {
            $input = request()->only('date_from','date_to');
            return
            $this->hasMany(Payment::class,'user_id','id')
                ->whereBetween('date', [$input['date_from'] . " 00:00:00", $input['date_to'] . " 23:59:00"])
                ->latest();
        }
        return $this->hasMany(Payment::class,'user_id','id')->latest();
    }


    public function emergency(){
        return $this->hasMany(EmergencyVetClient::class,'user_id','id');
    }

    public function coupon_usage(){
        return $this->hasOne(CouponUsage::class,'user_id','id')->latest();
    }

    public function usageByPackage(){
        return $this->hasMany(PackageUsage::class,'user_id','id');
    }

    public function payProtectUser(){
        return $this->hasOne(PaymentProtectUser::class,'user_id','id');
    }


    public function coupon_user()
    {
        return $this->hasOne(CouponUsage::class,'user_id','id');
    }

    public function userStatusType()
    {
        return $this->hasOne(ReportUserTypeStatus::class,'user_id','id')
                    ->whereIn('app_id',$this->whereAppIdArray(['whitelabel','sdk']));
    }

}
