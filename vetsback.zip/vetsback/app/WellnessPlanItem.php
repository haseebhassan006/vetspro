<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class WellnessPlanItem extends Model
{
    //
}
