<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TChatMessage extends Model
{
    //
    protected $guarded = [];
}
