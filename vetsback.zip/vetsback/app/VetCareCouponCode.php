<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class VetCareCouponCode extends Model
{
    use SoftDeletes;

    protected $fillable = ['code'];

    protected $casts = [
        'created_at' => 'datetime:Y-m-d',
    ];

    protected $hidden = ['updated_at','deleted_at','model_id','model_type'];

    public function model()
    {
        return $this->morphTo()->withTrashed();
    }

    public function vetCareCouponUsages()
    {
        return $this->hasMany(VetCareCouponUsage::class);
    }

    public function vetCarePackageUsages()
    {
        return $this->hasMany(VetCarePackageUsage::class);
    }
}
