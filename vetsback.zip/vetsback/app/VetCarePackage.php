<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class VetCarePackage extends Model
{
    use SoftDeletes;

    protected $fillable = ['app_id','vet_care_id','type','name','is_recurring','price','currency','is_card','interval','interval_count','product_id','price_id','emergency_fund','is_default','plan_items'];

    protected $casts = ['plan_items'=>'json'];

    protected $appends = ['benefit','vet_care_app_name'];

    public $hidden = ['app_id'];

    public function apps(){
        return $this->hasOne(App::class,'id','app_id');
    }

    public function benefit(){
        return $this->belongsToMany(VetCarePackageBenefit::class, 'package_benefit_pivot', 'vet_care_package_id' , 'vet_care_benefit_id');
    }

    public function getBenefitAttribute()
    {
        return $this->benefit()->get();
    }

    public function metadata(){
        return $this->hasOne(VetCarePackageMetaData::class,'package_id','id');
    }

    public function getVetCareAppNameAttribute(){
        return $this->hasOne(App::class,'id','vet_care_id')->pluck('name')->first();
    }

    public function app(){
        return $this->hasOne(App::class,'id','vet_care_id');
    }
}
