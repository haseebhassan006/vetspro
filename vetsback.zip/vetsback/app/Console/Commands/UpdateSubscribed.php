<?php

namespace App\Console\Commands;

use App\UserAppStatus;
use App\WebappUser;
use Carbon\Carbon;
use DateTime;
use Illuminate\Console\Command;

class UpdateSubscribed extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'webusers:subscribed';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Update Webusers Subscribed on Users App Status table every month';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        \Log::alert('Cron Start');
        $users = WebappUser::with(['user_status_latest']);
        $current_date = date('Y-m-d h:i:s');
        $current_year_month = date('Ym');
        $users->whereHas('user_status_latest', function ($q) use ($current_date)  {
            $q->where('status', 'subscribed');
        });
        $users = $users->get();
        $updatedCount = 0;

        foreach ($users as $user) {

            $user_stamp = $user->user_status_latest->date_time;
            if ($user_stamp == '') {
                $user_stamp = $user->user_status_latest->created_at;
            }

            $month = strtotime($user_stamp);
            $end = strtotime(date('Y-m-d'));

            while($month < $end) {
                //Restrict from future date on current month
                $month = strtotime("+1 month", $month);
                if (date('Ymd', $month) <= date('Ymd')) {
                    $create = UserAppStatus::create([
                        'user_id' => $user->id,
                        'app_id' => $user->app_id,
                        'status' => 'subscribed',
                        'type' => 'monthly',
                        'created_at' => date('Y-m-d H:i:s', $month),
                        'date_time' => date('Y-m-d H:i:s', $month)
                    ]);
                    $updatedCount++;
                }
            }
        }

        \Log::alert($updatedCount. ' records updated');
        \Log::alert('Cron End');
    }
}
