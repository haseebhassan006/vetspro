<?php

namespace App\Console;

use App\Console\Commands\EndChatAutomatically;
use App\Console\Commands\EndChatByAdmin;
use App\Console\Commands\UpdateSubscribed;
use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Foundation\Console\Kernel as ConsoleKernel;

class Kernel extends ConsoleKernel
{
    /**
     * The Artisan commands provided by your application.
     *
     * @var array
     */
    protected $commands = [
        //
        EndChatByAdmin::class,
        UpdateSubscribed::class,
        EndChatAutomatically::class,
        'App\Console\Commands\CallRoute'

    ];

    /**
     * Define the application's command schedule.
     *
     * @param Schedule $schedule
     * @return void
     */
    protected function schedule(Schedule $schedule)
    {
        // $schedule->command('inspire')
        //          ->hourly();
//        $schedule->command('telescope:prune --hours=48')->daily();
        //$schedule->command('vpm:endchat')->weekly();
        // $schedule->command('telescope:prune --hours=168')->daily();
        // cron at every five minutes for testing
        $schedule->command('webusers:subscribed')->everyFiveMinutes();


//        $schedule->exec('./vendor/bin/phpunit ./tests/OnePetTest')->everyFiveMinutes();



    }

    /**
     * Register the commands for the application.
     *
     * @return void
     */
    protected function commands()
    {
        $this->load(__DIR__.'/Commands');

        require base_path('routes/console.php');
    }
}
