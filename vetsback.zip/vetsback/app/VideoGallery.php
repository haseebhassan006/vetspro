<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class VideoGallery extends Model
{
    use SoftDeletes;

    protected $fillable = ['title','is_visible','video_url','category_id'];
    public function videoGalleryCategory()
    {
        return $this->belongsTo(VideoGalleryCategory::class,'category_id','id');
    }
}
