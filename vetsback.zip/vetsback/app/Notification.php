<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Notification extends Model
{
    //
    protected $guarded = [];

    public function vets()
    {
        return $this->hasMany(Vet::class,'user_to_notify','id');

    }


    public function staffs()
    {
        return $this->hasMany(SubAdmin::class,'user_to_notify','id');

    }
}
