<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Queue extends Model
{
    use SoftDeletes;
    protected $guarded = [];

    public function queue(): \Illuminate\Database\Eloquent\Relations\HasMany
    {
        return $this->hasMany(Vet::class,'id','vet_id');
    }
}
