<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Feedback extends Model
{
    //
    protected $guarded = [];

    public function video()
    {
        return $this->hasOne(VideoCall::class, 'id', 'table_id')->with(['vcUser','vet']);
    }

    public function video_expend()
    {
        return $this->hasOne(VideoCall::class, 'id', 'table_id')->with(['whitelabelUser', 'webapps', 'vcUser','vet']);
    }

    public function chat()
    {
        return $this->hasOne(Chat::class, 'id', 'table_id')->with(['vcUser','vet']);
    }

    public function chat_expend()
    {
        return $this->hasOne(Chat::class, 'id', 'table_id')->with(['whitelabelUser', 'webappUser', 'vcUser', 'vet']);
    }

    public function recommendation()
    {
        return $this->hasOne(Recommendation::class, 'id', 'recommendation_id');
    }

    public function reason()
    {
        return $this->hasOne(Reason::class, 'id', 'reason_id');
    }

}
