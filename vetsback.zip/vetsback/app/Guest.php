<?php

namespace App;

use App\Traits\CustomSearch;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Notifications\Notifiable;
use Spatie\Permission\Traits\HasRoles;
use Tymon\JWTAuth\Contracts\JWTSubject;
use Illuminate\Foundation\Auth\User as Authenticatable;


class Guest extends Authenticatable implements JWTSubject
{
    //
    use Notifiable;
    use SoftDeletes;
    use HasRoles;
    use CustomSearch;

    protected $guard_name = 'guests';

    protected $appends = ['role_names', 'app'];

    protected $fillable = ['first_name','last_name','email','app_id','password'];

    protected $searchable = ['first_name', 'last_name', 'email'];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token'
    ];
    //protected $guarded = [];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];
    //protected $appends = ['user_details'];

    // Rest omitted for brevity

    /**
     * Get the identifier that will be stored in the subject claim of the JWT.
     *
     * @return mixed
     */
    public function getJWTIdentifier()
    {
        return $this->getKey();
    }

    /**
     * Return a key value array, containing any custom claims to be added to the JWT.
     *
     * @return array
     */
    public function getJWTCustomClaims()
    {
        return [];
    }

    public function getRoleNamesAttribute()
    {
        return $this->getRoleNames();
    }

    public function apps()
    {
        return $this->belongsTo(App::class, 'app_id');
    }
    public function pets()
    {
        //return $this->hasMany(Pet::class,'user_id','id');
        return $this->morphMany(Pet::class, 'model');
    }
    public function devices()
    {
        return $this->morphMany(Device::class, 'model');
    }
    public function chats()
    {
        return $this->belongsTo(Chat::class);
    }
    public function getAppAttribute()
    {
        return $this->apps()->pluck('name');
    }
    public function guest()
    {
        return $this->morphMany(VideoCall::class, 'model');
    }
}
