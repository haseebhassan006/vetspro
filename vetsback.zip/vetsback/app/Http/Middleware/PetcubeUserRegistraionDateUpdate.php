<?php

namespace App\Http\Middleware;

use Closure;
use App\App;
class PetcubeUserRegistraionDateUpdate
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $msg  = 'Method not allowed';
        if($request->api_key!='Qd8umOvTtoBtX2MH' && $request->app_id !='5'){
            return $this->errorResponse($msg, 403);
        }
        return $next($request);
    }
    public function errorResponse($error, $code = 401,$errorMessages = []){

        $statusCode = $code == 0 ? 401 : $code;
        $response = [
            'success' => false,
            'status_code' =>$statusCode,
            'message' => is_array($error) == TRUE ? $error : [$error],
            //'message' => $error,
            //'data'    => $errorMessages
            'data'    => []
        ];

        return response()->json($response, $statusCode);
    }
}
