<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\App;

class goodCharlieMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if (App::environment(['production'])) {
            $AUTH_USER = 'good_charlie';
            $AUTH_PASS = 'zeG2wkcrhzI9E7fB';
        }
        if (App::environment(['local','staging'])) {
            $AUTH_USER = 'good_charlie';
            $AUTH_PASS = 'zeG2wkcrhzI9E7fB';
        }
        header('Cache-Control: no-cache, must-revalidate, max-age=0');
        $has_supplied_credentials = !(empty($_SERVER['PHP_AUTH_USER']) && empty($_SERVER['PHP_AUTH_PW']));
        $is_not_authenticated = (
            !$has_supplied_credentials ||
            $_SERVER['PHP_AUTH_USER'] != $AUTH_USER ||
            $_SERVER['PHP_AUTH_PW']   != $AUTH_PASS
        );
        if ($is_not_authenticated) {
            header('HTTP/1.1 401 Authorization Required');
            header('WWW-Authenticate: Basic realm="Access denied"');
            $error = ['Authorization Required','Access denied'];
            $response = [
                'success' => false,
                'status_code' =>401,
                'message' => is_array($error) == true ? $error : [$error],
                'data'    => []
            ];
            return response()->json($response, 401);

            //exit;
        }

        //Find app name from client provided url
        $find_app = \App\App::where('name', 'goodcharlie')->first();
        if (!$find_app) {
            $error = ['App Not Found'];
            $response = [
                'success' => false,
                'status_code' =>404,
                'message' => is_array($error) == true ? $error : [$error],
                'data'    => []
            ];
            return response()->json($response, 404);
        }
        if(!suspend_app($find_app->id)){
            return errorResponse('This App is suspended', 401);
        }
        $request->merge([
            'no_payment'=>true,
            'api_key'=>$find_app->api_key
        ]);

        return $next($request);
    }
}
