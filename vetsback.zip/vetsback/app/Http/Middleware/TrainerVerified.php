<?php

namespace App\Http\Middleware;

use Closure;

class TrainerVerified
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $user = auth()->guard('trainer')->user();
        $msg  = 'Your email is not verifed please verify your email';
        if($user->verification_token != NULL ||  $user->email_verified_at==NULL){
            return $this->errorResponse($msg, 403);
        }

        return $next($request);
    }
    public function errorResponse($error, $code = 401,$errorMessages = []){

        $statusCode = $code == 0 ? 401 : $code;
        $response = [
            'success' => false,
            'status_code' =>$statusCode,
            'message' => is_array($error) == TRUE ? $error : [$error],
            //'message' => $error,
            //'data'    => $errorMessages
            'data'    => []
        ];

        return response()->json($response, $statusCode);
    }
}
