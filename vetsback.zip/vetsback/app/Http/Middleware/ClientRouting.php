<?php

namespace App\Http\Middleware;

use App\App;
use Closure;
use http\Exception\BadMethodCallException;

class ClientRouting
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        //Find app name from client provided url
        $url = $request->url();
        $re = '/((\w* ){0,5})(user)(( \w*){0,5})/i';
        $index = strpos($url, 'user') + strlen('user');
        $result = substr($url, $index);
        $result = explode('/',$result);
        $find_app = App::where('name',$result[1])->first();
        if(!$find_app){
            return $this->errorResponse('Route invalid', 400);
        }
        if(!suspend_app($find_app->id)){
            return $this->errorResponse('This App is suspended', 401);
        }
        $request->merge([
            'api_key'=>$find_app->api_key
        ]);
        $response = $next($request);

        //if any custom handler exception
        //write here

        return $response;
    }

    public function errorResponse($error, $code = 401,$errorMessages = []){

        $statusCode = $code == 0 ? 401 : $code;
        $response = [
            'success' => false,
            'status_code' =>$statusCode,
            'message' => is_array($error) == TRUE ? $error : [$error],
            //'message' => $error,
            //'data'    => $errorMessages
            'data'    => []
        ];

        return response()->json($response, $statusCode);
    }

}
