<?php

namespace App\Http\Middleware;

use App\UnauthenticatedUsers;
use Closure;
use Illuminate\Support\Facades\DB;

class IpMiddleware
{
    //public $restrictedIp = ['192.168.0.1', '202.173.125.72', '192.168.0.3', '202.173.125.71','127.0.0.1'];

    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $restrictedIp = array();
        $get_restricted_ips = DB::table('unauthenticated_users')->selectRaw('INET_NTOA(ip) as ip')
            ->get();
        foreach ($get_restricted_ips as $restricted_ip){
            $restrictedIp[] = $restricted_ip->ip;
        }
        if (in_array($this->getIp(), $restrictedIp)) {
            return response()->json(['message' => "You don't have permission to access this website."]);
        }

        return $next($request);
    }

    public function getIp(){
        foreach (array('HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_FORWARDED', 'HTTP_X_CLUSTER_CLIENT_IP', 'HTTP_FORWARDED_FOR', 'HTTP_FORWARDED', 'REMOTE_ADDR') as $key){
            if (array_key_exists($key, $_SERVER) === true){
                foreach (explode(',', $_SERVER[$key]) as $ip){
                    $ip = trim($ip); // just to be safe
                    if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false){
                        return $ip;
                    }
                }
            }
        }
        //return request()->ip(); // it will return server ip when no client ip found
    }
}
