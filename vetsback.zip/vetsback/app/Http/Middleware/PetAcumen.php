<?php

namespace App\Http\Middleware;

use App\Mail\InformClientErrorEmail;
use Carbon\Carbon;
use Closure;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Mail;

class PetAcumen
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if (App::environment(['production'])) {
            $AUTH_USER = 'petacumen_admin';
            $AUTH_PASS = '93Enc76BbUzD9GdH';
        }
        if (App::environment(['local','staging'])) {
            $AUTH_USER = 'petacumen';
            $AUTH_PASS = 'petacumen##';
        }
        header('Cache-Control: no-cache, must-revalidate, max-age=0');
        $has_supplied_credentials = !(empty($_SERVER['PHP_AUTH_USER']) && empty($_SERVER['PHP_AUTH_PW']));
        $is_not_authenticated = (
            !$has_supplied_credentials ||
            $_SERVER['PHP_AUTH_USER'] != $AUTH_USER ||
            $_SERVER['PHP_AUTH_PW']   != $AUTH_PASS
        );
        if ($is_not_authenticated) {
            header('HTTP/1.1 401 Authorization Required');
            header('WWW-Authenticate: Basic realm="Access denied"');
            $error = ['Authorization Required','Access denied'];
            $response = [
                'success' => false,
                'status_code' =>401,
                'message' => is_array($error) == TRUE ? $error : [$error],
                'data'    => []
            ];
           // $this->statusErrorCodes(401,'petacumen','Authorization Required');
            return response()->json($response,401);
        }
        $find_app = \App\App::where('name', 'petacumen')->first();
        if ($find_app) {
            if(!suspend_app($find_app->id)){
                return errorResponse('This App is suspended', 401);
            }    
        }
        return $next($request);
    }

    public function statusErrorCodes($code,$app,$body){
        $date = Carbon::now()->toDateTimeString();
        $app = strtolower($app);
        switch ($code){
            case 401:
            case 406:
            case 500:
                switch ($app){
                    case 'vidaah':
                    case 'petacumen':
                    case 'vetsplsumore':
                        Mail::to('ali.raza@invisionsolutions.ca')->send(new InformClientErrorEmail($date,$app,$body,$code));
                        break;
                }
                break;

        }

    }
}
