<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\App;

class NimbleAuth
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {

        if (App::environment(['production'])) {
            $AUTH_USER = 'nimble_admin';
            $AUTH_PASS = 'wD@78t,&Fkz&H^pe';
        }
        if (App::environment(['local','staging'])) {
            $AUTH_USER = 'nimble';
            $AUTH_PASS = 'nimble##';
        }
        $has_supplied_credentials = !(empty($_SERVER['PHP_AUTH_USER']) && empty($_SERVER['PHP_AUTH_PW']));
        $is_not_authenticated = (
            !$has_supplied_credentials ||
            $_SERVER['PHP_AUTH_USER'] != $AUTH_USER ||
            $_SERVER['PHP_AUTH_PW']   != $AUTH_PASS
        );
        if ($is_not_authenticated) {
            header('HTTP/1.1 401 Authorization Required');
            header('WWW-Authenticate: Basic realm="Access denied"');
            $error = ['Authorization Required','Access denied'];
            $response = [
                'success' => false,
                'status_code' =>401,
                'message' => is_array($error) == TRUE ? $error : [$error],
                'data'    => []
            ];
            //return $this->errorResponse($exception->getMessage(), $exception->getCode());
            return response()->json($response,401);

            //exit;
        }
        $find_app = \App\App::where('name', 'Nimble')->first();
        if ($find_app) {
            if(!suspend_app($find_app->id)){
                return errorResponse('This App is suspended', 401);
            }    
        }
        return $next($request);
    }
}
