<?php

namespace App\Http\Middleware;

use Closure;

class handshakeAppsMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        //Find app name from client provided url
        $url = $request->url();
        $re = '/((\w* ){0,5})(user)(( \w*){0,5})/i';
        $index = strpos($url, 'user') + strlen('user');
        $result = substr($url, $index);
        $result = explode('/',$result);
        $find_app = \App\App::where('name',$result[1])->first();


        // App not found error
        if (!$find_app) {
            return errorResponse('App Not Found', 404);
        }

        // Only Allow Handshake Apps
        if(!is_handshake_enabled($find_app->id)){
            return errorResponse('Handshake is not enabled for this app.', 406);
        }

        // check whether App is not suspended 
        if(!suspend_app($find_app->id)){
            return errorResponse('This App is suspended', 401);
        }

        // Adding app name to request
        $request->merge([
            'no_payment'=>true,
            'api_key'=>$find_app->api_key,
            'app_id' => $find_app->id,
            'isHandshakeApp' => true
        ]);

        header('Cache-Control: no-cache, must-revalidate, max-age=0');
        $has_supplied_credentials = !(empty($_SERVER['PHP_AUTH_USER']) || empty($_SERVER['PHP_AUTH_PW']));
        if(!$has_supplied_credentials){
            return errorResponse('Authorization Required', 401);
        }

        $username = strtolower($_SERVER['PHP_AUTH_USER']);
        $password = $_SERVER['PHP_AUTH_PW'];

        // Get array form config/services.php
        $CredsArray = config('services.hand-shake-app-creds');
        $appCreds = isset($CredsArray[$find_app->name]) ? $CredsArray[$find_app->name] : null;
        if($appCreds){
            if(!isset($appCreds[$username]) || $appCreds[$username] != $password){
                header('HTTP/1.1 401 Authorization Required');
                header('WWW-Authenticate: Basic realm="Access denied"');
                return errorResponse('Authorization Required, Access denied', 401);
            }
        }else{
            return errorResponse('App Credentials missing. Contact Admin', 404);
        }

        return $next($request);
    }
}
