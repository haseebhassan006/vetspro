<?php

namespace App\Http\Middleware;

use Closure;

class Staff
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $user = auth()->guard('staff')->user();
        $msg  = 'You are not authorised for this access';
        if($user->hasRole('staff') === false){
            return $this->errorResponse($msg, 403);
        }

        return $next($request);
    }
    public function errorResponse($error, $code = 401,$errorMessages = []){

        $statusCode = $code == 0 ? 401 : $code;
        $response = [
            'success' => false,
            'status_code' =>$statusCode,
            'message' => is_array($error) == TRUE ? $error : [$error],
            //'message' => $error,
            //'data'    => $errorMessages
            'data'    => []
        ];

        return response()->json($response, $statusCode);
    }
}
