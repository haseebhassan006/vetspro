<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\App;

class handshakeAppsV2Middleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        //Find app name from client provided url
        $url = $request->url();
        $re = '/((\w* ){0,5})(v2)(( \w*){0,5})/i';
        $index = strpos($url, 'v2') + strlen('v2');
        $result = substr($url, $index);
        $result = explode('/',$result);
        $find_app = \App\App::where('name',$result[1])->first();

        // App not found error
        if (!$find_app) {
            return errorResponse('App Not Found', 404);
        }

        // check whether App is not suspended
        if(!suspend_app($find_app->id)){
            return errorResponse('This App is suspended', 401);
        }

        // Adding app name to request
        $request->merge([
            'app_id' => $find_app->id,
            'api_key'=>$find_app->api_key,
            'app_id' => $find_app->id,
            'isHandshakeApp' => true
        ]);

        header('Cache-Control: no-cache, must-revalidate, max-age=0');
        $has_supplied_credentials = !(empty($_SERVER['PHP_AUTH_USER']) || empty($_SERVER['PHP_AUTH_PW']));
        if(!$has_supplied_credentials){
            return errorResponse('Authorization Required', 401);
        }

        $username = strtolower($_SERVER['PHP_AUTH_USER']);
        $password = $_SERVER['PHP_AUTH_PW'];

        // Get array form config/services.php
        if (App::environment(['production'])) {
            $CredsArray = config('services.vpm-app-creds-production');
        } elseif (App::environment(['local','staging'])) {
            $CredsArray = config('services.vpm-app-creds');
        }
        $appCreds = isset($CredsArray[$find_app->name]) ? $CredsArray[$find_app->name] : null;

        if($appCreds){
            if(!isset($appCreds[$username]) || $appCreds[$username] != $password){
                header('HTTP/1.1 401 Authorization Required');
                header('WWW-Authenticate: Basic realm="Access denied"');
                return errorResponse('Authorization Required, Access denied', 401);
            }
        }else{
            return errorResponse('App Credentials missing. Contact Admin', 404);
        }

        return $next($request);
    }
}
