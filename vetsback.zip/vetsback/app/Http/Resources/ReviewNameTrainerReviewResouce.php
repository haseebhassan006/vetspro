<?php

namespace App\Http\Resources;

use App\ReviewName;
use Illuminate\Http\Resources\Json\JsonResource;

class ReviewNameTrainerReviewResouce extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return
        [
            'rate' => $this->rate,
            'review_name' => $this->whenLoaded($this->reviewName,function(){
                return  new ReviewName($this->reviewName);
            })
        ];
    }
}
