<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class UserSubscriptionStatusResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        parent::toArray($request);
        $status = $this->user_status->pluck('status');
        return [
            'email'=>$this->email,
            'registration'=>$this->your_registration_date,
            'status'=>$status
        ];
    }
}
