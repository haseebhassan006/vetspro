<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class ExternalPaymentApiResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        parent::toArray($request);
        $arr = array();
        $arr = [
            'payment_id' => $this->id,
            'amount' => $this->amount,
            'user_id' => $this->user ? $this->user->id : '',
            'status' => $this->status,
            'email' => $this->user ? $this->user->email : '',
            'first_name' => $this->user ? $this->user->first_name : '',
            'last_name' => $this->user ? $this->user->first_name : '',
            'next_emergency_activation_date' => $this->user->next_emergency_activation_date,
            'payment_initiated_time' => $this->created_at,
            'role' => $this->user ? $this->user->roles()->latest()->first()->name : '',
            'package_name' => $this->user->usage()->first() ? ($this->user->usage()->latest()->first()->package()->latest()->first() ? $this->user->usage()->latest()->first()->package()->latest()->first()->name : '') : '',
            'package_type' => $this->user->usage()->first() ? ($this->user->usage()->latest()->first()->package()->latest()->first() ? $this->user->usage()->latest()->first()->package()->latest()->first()->type : '') : '',
        ];

        return $arr;
    }
}
