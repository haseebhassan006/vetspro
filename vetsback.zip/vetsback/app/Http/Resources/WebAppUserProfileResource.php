<?php

namespace App\Http\Resources;

use App\App;
use App\EmergencyVetClient;
use Carbon\Carbon;
use Illuminate\Http\Resources\Json\JsonResource;

class WebAppUserProfileResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        parent::toArray($request);
        $arr = [];

           $arr = [
               'first_name'                     =>  $this->first_name,
               'last_name'                      =>  $this->last_name,
               'email'                          =>  $this->email,
               'phone_no'                       =>  $this->phone_no,
               'your_registration_date'         =>  $this->your_registration_date,
               'emergency_fund'                 =>  $this->emergency_fund,
               'next_emergency_activation_date' =>  $this->next_emergency_activation_date,
            //    'user_status'                    =>  $this->user_status,
               'activedays'                     =>  $this->activedays,
               'protect_type'                 =>  isset($this->emergencyLastestProtect)?$this->emergencyLastestProtect->protected:null,
               'package_type'                   =>  isset($this->user_status_latest)?$this->user_status_latest->type:null,
               'subscription_status'            =>  isset($this->user_status_latest)?$this->user_status_latest->status:null,

            ];
        return $arr;
    }
}
