<?php

namespace App\Http\Resources;
use Illuminate\Http\Resources\Json\JsonResource;

class AppointmentResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        parent::toArray($request);

        $data = [];
        $data = [
            'id'=>$this->id,
            'booking_note'=>$this->booking_note,
            'contact_no'=>$this->contact_no,
            'status'=>$this->status,
            'created_at'=>(string) $this->created_at,
            'updated_at'=>(string) $this->updated_at,
            'trainer'=>
            [
                'id'=>$this->trainer->first_name,
                'first_name'=>$this->trainer->first_name,
                'last_name'=>$this->trainer->last_name,
                'email'=>$this->trainer->email,
                'experience'=>$this->trainer->experience,
                'specialties'=>$this->trainer->specialties,
                'profile_image'=>$this->trainer->profile_image,
                'is_online'=>$this->trainer->is_online
            ],
            'app'=>[
                'name'=>$this->app->name,
                'type'=>$this->app->app_type
            ], 
            'user'=>[
                'id'=>$this->user->id,
                'first_name'=>$this->user->first_name,
                'last_name'=>$this->user->last_name,
                'email'=>$this->user->last_name,
            ], 
            'schedule'=>
            [
                'id'=> $this->schedule->id,
                'trainer_id'=> $this->schedule->trainer_id,
                'slot_from_time'=> $this->schedule->slot_from_timeid,
                'slot_to_time'=> $this->schedule->slot_to_time,
                'date'=> $this->schedule->date,
                'day'=> $this->schedule->day,
                'charges'=> $this->schedule->charges,
                'booking_status'=> $this->schedule->booking_status,
            ],
            'appointment_pet'=>
            [
                'id'=> $this->pet->id,
                'name'=> $this->pet->name,
                'species'=> $this->pet->species,
                'age'=> $this->pet->age,
                'breed'=>$this->pet->breed,
                'color'=> $this->pet->color,
                'weight'=> $this->pet->weight,
                'sex'=> $this->pet->sex,
                'sex_type'=> $this->pet->sex_type,
            ],
            'appointment_payment'=>[
                'id'=> $this->appointmentPayment->id,
                'charge_id'=> $this->appointmentPayment->charge_id,
                'amount'=> $this->appointmentPayment->amount,
                'date'=>$this->appointmentPayment->date,
                'status'=> $this->appointmentPayment->status,
                'stripe_response'=> $this->appointmentPayment->stripe_response, 
            ],
            
        ];
        return $data ;
    }
}
