<?php

namespace App\Http\Resources;

use Carbon\Carbon;
use Illuminate\Http\Resources\Json\JsonResource;

class CouponUsageResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
         parent::toArray($request);
            $arr = [
                'id'=>$this->id,
                'use_datetime' => $this->use_datetime,
                'is_subscribe'=> $this->is_subscribe,
                'left_days' => $this->left_days,
                'user'=>$this->user,
                'coupon'=>$this->coupon
            ];
        return $arr;
    }
}
