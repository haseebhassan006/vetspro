<?php

namespace App\Http\Resources;

use Carbon\Carbon;
use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Http\Resources\Json\ResourceCollection;

class VpmCallCollection extends JsonResource
{
    /**
     * Transform the resource collection into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
         parent::toArray($request);
         if($this->user->isNotEmpty()){
             $user = $this->user;
         }
         elseif($this->guest->isNotEmpty()){
             $user = $this->guest;
         }
         elseif($this->webapps->isNotEmpty()){
             $user = $this->webapps;
         }
        $duration = '0 minutes';
        if($this->end_time != null){
            $startTime = Carbon::parse($this->start_time);
            $endTime = Carbon::parse($this->end_time);
            $duration = $startTime->diff($endTime)->format('%H:%I:%S');;
        }


            return [
                'id'=>$this->id,
                'to'=>$this->vet,
                //'to_profile'=>$this->toProfile,
                'from'=>$user,
                //'from_profile'=>$this->fromProfile,
                'start_time'=>$this->start_time,
                'end_time'=>$this->end_time,
                'history'=>$this->history,
                'duration'=>$duration,
//                'status'=>$this->history->status
                //'duration'=>$duration,
                //'status'=>$this->status,
            ];
    }
}
