<?php

namespace App\Http\Resources;

use Carbon\Carbon;
use Illuminate\Http\Resources\Json\JsonResource;

class VetFeedbackResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
         parent::toArray($request);
         if($this->type == 'chat'){
            $arr = [
                'id'=>$this->id,
                'app_id'=>$this->app_id,
                'app_name'=>appname_by_appid($this->app_id),
                'type'=>$this->type,
                'recommendation' => $this->recommendation->name,
                'reason' => $this->reason->reasons,
                'feedback_date' => $this->created_at,
                'vet_id' =>  $this->chat->vet ?  $this->chat->vet->id : '',
                'vet_first_name' =>  $this->chat->vet ?  $this->chat->vet->first_name : '',
                'vet_last_name' =>  $this->chat->vet ?  $this->chat->vet->last_name : '',
                'vet_email' =>  $this->chat->vet ?  $this->chat->vet->email : '',
                'user_id' =>  $this->chat->vcUser ?  $this->chat->vcUser->id : '',
                'user_first_name' =>  $this->chat->vcUser ?  $this->chat->vcUser->first_name : '',
                'user_last_name' =>  $this->chat->vcUser ?  $this->chat->vcUser->last_name : '',
                'user_email' =>  $this->chat->vcUser ?  $this->chat->vcUser->email : '',
            ];
         }else{
            $arr = [
                'id'=>$this->id,
                'app_id'=>$this->app_id,
                'app_name'=>appname_by_appid($this->app_id),
                'type'=>$this->type,
                'recommendation' => $this->recommendation->name,
                'reason' => $this->reason->reasons,
                'feedback_date' => $this->created_at,
                'vet_id' => $this->video->vet[0] ?  $this->video->vet[0]->id : '',
                'vet_first_name' => $this->video->vet[0] ?  $this->video->vet[0]->first_name : '',
                'vet_last_name' => $this->video->vet[0] ?  $this->video->vet[0]->last_name : '',
                'vet_email' => $this->video->vet[0] ?  $this->video->vet[0]->email : '',
                'user_id' => $this->video->vcUser ?  $this->video->vcUser->id : '',
                'user_first_name' => $this->video->vcUser ?  $this->video->vcUser->first_name : '',
                'user_last_name' => $this->video->vcUser ?  $this->video->vcUser->last_name : '',
                'user_email' => $this->video->vcUser ?  $this->video->vcUser->email : '',
            ];
         }
            
        return $arr;
    }
}
