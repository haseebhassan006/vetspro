<?php

namespace App\Http\Resources;

use Carbon\Carbon;
use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Support\Facades\App;

class UserPaymentResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param \Illuminate\Http\Request $request
     * @return array
     */
    public function toArray($request)
    {
        parent::toArray($request);
        $now = Carbon::now('UTC');
        $interval = 0.0;

        if (isset($this->pay_protect_user)) {
            $interval = $now->diffInDays($this->pay_protect_user->subscription_timestamp);
        }
        $coupon = null;
        if (isset($this->coupon_usage->coupon)) {
            $coupon = $this->coupon_usage->coupon->other['code'];
        }

        return [
            'user_id' => $this->id,
            'first_name' => $this->first_name,
            'last_name' => $this->last_name,
            'email' => $this->email,
            'user_details' => $this->userDetails,
            'app' => $this->app[0],
            'payment'=>$this->latestPaymentHasMany,
            'days_left' => $interval,
            'coupon' => $coupon,
            'is_vet_protect' => $this->emergency,
            'usage' => $this->usage,


        ];

    }
}
