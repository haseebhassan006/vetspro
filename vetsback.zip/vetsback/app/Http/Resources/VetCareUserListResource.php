<?php

namespace App\Http\Resources;

use App\App;
use Carbon\Carbon;
use DateTime;
use Illuminate\Http\Resources\Json\JsonResource;

class VetCareUserListResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
         $arr = parent::toArray($request);
         $arr = [
             'id'=>$this->id,
             'first_name'=>$this->first_name,
             'last_name'=>$this->last_name,
             'pet_tracking_code'=>$this->pet_tracking_code,
             'created_at'=>date($this->created_at),
             'deleted_at'=>date($this->deleted_at),
             'email'=>$this->email,
             'default_pet'=>$this->defaultPet()->latest()->first(),
             'role_names'=>$this->role_names?$this->role_names:[],
             'usage' => $this->usage,
             'usage_subscription' => $this->usageSubscription,
             'emergency_latest_filter'=>$this->emergencyLatestFilter,
             'emergency_latest'=>$this->emergencyLatest ? $this->emergencyLatest : [],
             'vet_care_user_feedbacks'=>$this->vetCareUserFeedbacks ? $this->vetCareUserFeedbacks :[],
             'usage_with_thrashed'=>$this->usageWithThrashed ? $this->usageWithThrashed : [],
             'pets'=>$this->pets ?$this->pets:[],
         ];

        //  $vetCareApp = Apps::where('app_type','whitelabel-webapp')->where('name',$validatedData['app_name'])->first();
         $app = App::where('id',$this->app_id)->first();

         $userType = 0;

        //  userType = 0 means user status can be calculated from the package usage
        //  userType = 1 means user status can be calculated from the user_status


         if($app->app_type == 'whitelabel-webapp'){
            $appSetting = $app->appSettings()->first();
            $otherAttribute = json_decode($appSetting->other);
            if(isset($otherAttribute->enable_handshake) && $otherAttribute->enable_handshake == 1){
                $userType = 1 ;
            }
         }

         if($app->app_type == 'webapp'){
             $userType = 1 ;
         }

         $userSubscriptionStatus = 'cancelled';

         if ($userType == 0) {
             if ($this->usage()->count() > 0) {
                 $userSubscriptionStatus = 'subscribed';
                if (isset($this->usageSubscription) && count($this->usageSubscription) > 0) {
                    if($this->usageSubscription->last()->status == 'active'){
                        $userSubscriptionStatus = 'subscribed';
                    }else{
                        $userSubscriptionStatus = $this->usageSubscription->last()->status;
                    }
                 }
             }
             else{
                if($this->usageSubscription->last() && $this->usageSubscription->last()->status == 'active'){
                     $userSubscriptionStatus = 'subscribed';
                }else{
                    $userSubscriptionStatus = $this->usageSubscription->last() ? $this->usageSubscription->last()->status : 'cancelled' ;
                }

             }
         }else{
                if (count($this->user_status_latest) > 0) {
                    $userSubscriptionStatus = $this->user_status_latest[0]->status;
                }
        }

         if ($userSubscriptionStatus == 'upgrade') {
             $userSubscriptionStatus = 'upgraded';
         } elseif ($userSubscriptionStatus == 'cancelled') {
             $userSubscriptionStatus = 'canceled';
         }

        $arr['user_subscription_status'] = $userSubscriptionStatus;


        //  user activation status check
        $arr['user_activation_status'] = !empty($this->next_emergency_activation_date) && sizeof($this->usageSubscription)>0? 'activated' :'-' ;
        if(empty($this->next_emergency_activation_date)){
            $appSetting = $app->appSettings()->first();
            $otherAttribute = json_decode($appSetting->other);

            $fdate = $this->created_at;
            $tdate = Carbon::now();
            $datetime1 = new DateTime($fdate);
            $datetime2 = new DateTime($tdate);
            $interval = $datetime1->diff($datetime2);
            $days = $interval->format('%a'); //returning days
            $arr['user_activation_status'] = 'activated'; //activated
            if(isset($otherAttribute->trial_period) && (int)$days < $otherAttribute->trial_period){
                $arr['user_activation_status'] = $otherAttribute->trial_period - $days." day(s) left";
            }
        }

        return $arr;
    }

}
