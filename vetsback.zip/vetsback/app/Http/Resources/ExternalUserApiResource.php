<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class ExternalUserApiResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        parent::toArray($request);
        $arr = array();
        $arr = [
            'user_id' => $this->id,
            'email' => $this->email,
            'first_name' => $this->first_name,
            'last_name' => $this->last_name,
            'user_details' => $this->userDetails ? $this->userDetails->other : '',
            'extra' => $this->extra,
            'package_name' => $this->usage()->first() ? ($this->usage()->latest()->first()->package()->latest()->first() ? $this->usage()->latest()->first()->package()->latest()->first()->name : '') : '',
            'package_type' => $this->usage()->first() ? ($this->usage()->latest()->first()->package()->latest()->first() ? $this->usage()->latest()->first()->package()->latest()->first()->type : '') : '',
            'role' => $this->roles()->latest()->first() ? $this->roles()->latest()->first()->name : '',
            'default_pet' => $this->defaultPet()->latest()->first(),
            'all_pets' => $this->pets,
            'usage_subscription' => $this->usageSubscription,
            'user_subscription_status' => isset($this->user_status_latest)?$this->user_status_latest[0]->status:'',
            'joining_date' => $this->created_at,
        ];

        return $arr;
    }
}
