<?php

namespace App\Http\Resources;

use Carbon\Carbon;
use Illuminate\Http\Resources\Json\JsonResource;

class VetVpmFeedbackResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        parent::toArray($request);
        $arr = [
            'type'=>$this->type,
            'vet_first_name' =>  $this->vet ?  $this->vet->first_name : '',
            'vet_last_name' =>  $this->vet ?  $this->vet->last_name : '',
            'recommendation' => $this->recommendation->name,
            'reason' => $this->reason->reasons,
            'feedback_date' => $this->created_at,
        ];
            
        return $arr;
    }
}
