<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class VideoCallLog extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        parent::toArray($request);
        $arr = array();
        if($this->app->app_type == 'webapp'){
            $arr = [
                'id' => $this->id,
                'app' => $this->app->name,
                'from' =>$this->webapps,
                // 'to'=> $this->vet,
                'to'=>$this->model,
                'room_sid' => $this->room_sid,
                'start_time' => $this->start_time,
                'end_time' => $this->end_time,
                'status' => $this->status,
                'media_url' => $this->mediaUrl,
            ];
        }
        if($this->app->app_type == 'whitelabel'){
            $arr = [
                'id' => $this->id,
                'app' => $this->app->name,
                'from' =>$this->user,
                // 'to'=> $this->vet,
                'to'=>$this->model,
                'room_sid' => $this->room_sid,
                'start_time' => $this->start_time,
                'end_time' => $this->end_time,
                'status' => $this->status,
                'media_url' => $this->mediaUrl,
            ];
        }
        if ($this->app->app_type == 'whitelabel-webapp') {
            $vcUser[] = $this->vcUser;
            $arr = [
                'id' => $this->id,
                'app' => $this->app->name,
                // 'from' =>$this->vcUser,
                'from' =>$vcUser,
                // 'to'=> $this->vet,
                'to'=>$this->model,
                'room_sid' => $this->room_sid,
                'start_time' => $this->start_time,
                'end_time' => $this->end_time,
                'status' => $this->status,
                'media_url' => $this->mediaUrl,
            ];
        }
        if($this->app->app_type == 'sdk'){
            $arr = [
                'id' => $this->id,
                'app' => $this->app->name,
                'from' =>$this->user,
                // 'to'=> $this->vet,
                'to'=>$this->model,
                'room_sid' => $this->room_sid,
                'start_time' => $this->start_time,
                'end_time' => $this->end_time,
                'status' => $this->status,
                'media_url' => $this->mediaUrl,
            ];
        }
        return $arr;
    }
}
