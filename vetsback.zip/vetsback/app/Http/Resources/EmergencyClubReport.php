<?php

namespace App\Http\Resources;

use App\App;
use App\EmergencyVetClient;
use Carbon\Carbon;
use Illuminate\Http\Resources\Json\JsonResource;

class EmergencyClubReport extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        parent::toArray($request);
        $arr = [];

        $find_app = App::find($this->app_id);

        if($find_app->app_type == 'whitelabel'){
            $arr = [
                'id'        =>  $this->id,
                'app'       =>  $this->appData,
                'is_protect'=>  $this->is_protect,
                'requested' =>  $this->userData,
                'accepted'  =>  $this->vetData,
                'type'      =>  $this->type,
                'time'      =>  $this->created_at,
                'flags'     =>  $this->flagsEmergency,
                'notes'     =>  $this->notesEmergency
            ];
        }

        if($find_app->app_type === 'webapp'){
            $arr = [
                'id'        =>  $this->id,
                'app'       =>  $this->appData,
                'is_protect'=>  $this->is_protect,
                'requested' =>  $this->webappData,
                'accepted'  =>  $this->vetData,
                'type'      =>  $this->type,
                'time'      =>  $this->created_at,
                'flags'     =>  $this->flagsEmergency,
                'notes'     =>  $this->notesEmergency
            ];
        }

        if($find_app->app_type == 'sdk'){

            $arr = [
                'id'        =>  $this->id,
                'app'       =>  $this->appData,
                'is_protect'=>  $this->is_protect,
                'requested' =>  $this->webappData,
                'accepted'  =>  $this->vetData,
                'type'      =>  $this->type,
                'time'      =>  $this->created_at,
                'flags'     =>  $this->flagsEmergency,
                'notes'     =>  $this->notesEmergency
            ];
        }
        if ($request->has('app_type') != 'whitelabel-webapp') {
            if ($find_app->app_type === 'whitelabel-webapp') {
                $arr = [
                    'id' => $this->id,
                    'app' => $this->appData,
                    'is_protect' => $this->is_protect,
                    'requested' => $this->vetCareUserData,
                    'accepted' => $this->vetData,
                    'type' => $this->type,
                    'time' => $this->created_at,
                    'flags' => $this->flagsEmergency,
                    'notes' => $this->notesEmergency
                ];
            }
        }

        return $arr;
    }
}
