<?php

namespace App\Http\Resources;

use App\App;
use App\EmergencyVetClient;
use Carbon\Carbon;
use Illuminate\Http\Resources\Json\JsonResource;

class PetListResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        parent::toArray($request);
        $arr = [];

           $arr = [
               'id'                     =>  $this->id,
               'user_id'                =>  $this->user_id,
               'name'                   =>  $this->name,
               'species'                =>  $this->species,
               'age'                    =>  $this->age,
               'breed'                  =>  $this->breed,
               'color'                  =>  $this->color,
               'weight'                 =>  $this->weight,
               'sex'                    =>  $this->sex,
               'sex_type'               =>  $this->sex_type,
               'profile'                =>  $this->profile,
               'updated_at'             =>  ($this->updated_at)->toDateTimeString(),
               'deleted_at'             =>  !empty($this->deleted_at)?($this->deleted_at)->toDateTimeString():$this->deleted_at,
               'created_at'             =>  ($this->created_at)->toDateTimeString(),
               'user'                   =>  $this->model,
               'petVeterians'           =>  $this->petVeterians,
               'petMedicals'            =>  $this->petMedicals,
               'petInsurnaces'          =>  $this->petInsurnaces,
               'app_type'               =>request()->app_type,
            ];
        return $arr;
    }
}
