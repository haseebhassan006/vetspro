<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Http\Resources\Json\ResourceCollection;
use Carbon\Carbon;
use DateTime;
class ChatArchiveCollection extends JsonResource
{
    /**
     * Transform the resource collection into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        parent::toArray($request);
         if($this->chat->app->app_type == 'webapp'){
            $user_activedays = $this->chat->webappUser->activedays;
         }elseif($this->chat->app->app_type =='whitelabel'){
            $user_activedays = $this->chat->whitelabelUser->activedays;
         }
         elseif($this->chat->app->app_type !='whitelabel' && $this->chat->app->app_type != 'webapp' && $this->chat->app->app_type =='whitelabel-webapp'){
            $otherAttribute = json_decode($this->chat->app->app_setting->other);
            if(!$this->chat->vcUser){
                $user_activedays = "User record has been deleted ";

            }else{
                $fdate =  $this->chat->vcUser->created_at ;

                $tdate = Carbon::now();
                $datetime1 = new DateTime($fdate);
                $datetime2 = new DateTime($tdate);
                $interval = $datetime1->diff($datetime2);
                $days = $interval->format('%a'); //returning days
                $user_activedays = 'activated'; //activated
                if(isset($otherAttribute->trial_period) && (int)$days < $otherAttribute->trial_period){
                    $user_activedays = $otherAttribute->trial_period - $days." day(s) left";
                }
            }
            
         }else{
            //calculation needs to be recalculate once approved from client 
            if(!$this->chat->sdkUser){ 
                $user_activedays = "User record has been deleted";
            }else{
                $fdate =  $this->chat->sdkUser->created_at ;
                $tdate = Carbon::now();
                $datetime1 = new DateTime($fdate);
                $datetime2 = new DateTime($tdate);
                $interval = $datetime1->diff($datetime2);
                $days = $interval->format('%a'); //returning days
                $user_activedays = 'activated'; //activated
                if(isset($this->chat->app->trial_period) && (int)$days < $this->chat->app->trial_period){
                    $user_activedays = $this->chat->app->trial_period - $days;
                }
            }
         }
           $attributes = json_decode($this->attributes);
           $attributes->user_activedays = $user_activedays;
        return [
            'id'=>$this->id,
            'chat_id'=>$this->chat_id,
            'body'=>$this->body,
            // 'attributes'=>$this->attributes,
            'attributes'=>json_encode($attributes),
           
            'created_at'=>$this->created_at->toDateTimeString(),
            'updated_at'=>$this->updated_at->toDateTimeString(),
            'deleted_at'=>$this->deleted_at ? $this->deleted_at->toDateTimeString() : null,
            'chat'=>$this->chat,
            // 'active_days'=>$user_activedays,


            // 'channel_sid'=>$this->chat->channel_sid,
            // 'id'=>$this->id,
            // //'vet_id'=>$this->chat->vet_id,
            // 'vet'=>[
            //     'name'=>$this->chat->vet->first_name.' '.$this->chat->vet->last_name
            // ],

            // 'user_id'=>$this->chat->user_id,
            // 'user'=>$this->chat->whitelabelUser,
            // 'pet_id'=>$this->chat->pet_id,
            // 'pet'=>$this->chat->pet,
            // 'body'=>$this->body,
            // 'index'=>$this->index
        ];
    }
}
