<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class ProtectUserDataReport extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        parent::toArray($request);
        $arr = [];
        $arr = [
            'id'         => $this->id,
            'app_id'     => $this->app_id,
            'first_name' => $this->first_name,
            'last_name'  => $this->last_name,
            'email'      => $this->email,
            'app'        => $this->app,
            'created_at' => $this->created_at
        ];

        return $arr;
    }
}
