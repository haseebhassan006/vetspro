<?php

namespace App\Http\Resources;

use Carbon\Carbon;
use Illuminate\Http\Resources\Json\JsonResource;

class AppointmentReviewResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        $arr = [

            'rating'=> $this->whenLoaded('raviewRatings',function(){
                return  ReviewRatingResouce::collection($this->raviewRatings);
            }),
            'review_content' => $this->review_text,
            'updated_at'=>date($this->updated_at),
            'created_at'=>date($this->created_at),
            // 'app' => $this->app->name,
            'user' => $this->users,
            'trainer'=>$this->trainers,

        ];

        return $arr;
    }
}
