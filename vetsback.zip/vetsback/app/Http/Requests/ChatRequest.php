<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class ChatRequest extends BaseRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
                'pet_id'=>'required|sometimes',
                'api_key'=>'required',
                'pet_info'=>[
                    'name'=>'sometimes',
                    'species'=>'sometimes',
                    'age'=>'sometimes',
                    'breed'=>'sometimes',
                    'sex'=>'sometimes',
                    'sex_type'=>'sometimes',
                ],
                'vet_id'=>'required|sometimes',
                'room_sid'=>'required|sometimes',
                'user_id'=>'required|sometimes',
                'type'=>'required|sometimes',
                'status'=>'required|sometimes'
         ];
    }
}
