<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class CreatePetDetailRequest extends BaseRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            //
            'pet_veterians'=>[
                'is_veterinarian'=>'sometimes',
                'name'=>'sometimes',
                'phone_no'=>'sometimes',
            ],
            'pet_medicals'=>[
                'history'=>'sometimes',
                'allergies'=>'sometimes',
                'diet'=>'sometimes',
                'is_vaccinated'=>'sometimes',
            ],
//            'pet_insurnaces'=>[
//                'is_insured'=>'sometimes|required',
//                'allegies'=>'sometimes|required',
//                'company'=>'sometimes|required',
//                'policy_number'=>'sometimes|required',
//            ],
        ];
    }
}
