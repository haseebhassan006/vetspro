<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class FeatureUserRequest extends BaseRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'first_name'=>'sometimes|required',
            'last_name'=>'sometimes|required',
            'email' => 'sometimes|required|email|unique:users,email',
            'password' => 'sometimes|required',
            'phone'=>'sometimes|required',
            'dob'=>'sometimes|required',
            'device_token'=> 'sometimes|required',
            'api_key' => 'required',
            'dev_type'=>'sometimes|required',
            'country_id'=>'sometimes|required',
            'city'=>'sometimes|required',
            'zip_code'=>'sometimes|required',
            'other'=>'sometimes|required',
            'profile'=>'sometimes|required',
            'status'=>'sometimes|required',
            'is_online'=>'sometimes|required',
            'role'=> 'sometimes|required',
            'id' => 'sometimes|required',
            'type'=>'sometimes|required'
        ];
    }
}
