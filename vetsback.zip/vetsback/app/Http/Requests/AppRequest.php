<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class AppRequest extends BaseRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

//    protected function prepareForValidation()
//    {
//        $this->merge(['id'=>$this->id]);
//    }
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            "name" => ["required", "sometimes", Rule::unique('apps')->ignore($this->id)],
            "android_link" => "sometimes|required",
            "ios_link" => "sometimes|required",
            "fcm_server_key"=> "sometimes|required",
            "app_type"=>'required|sometimes',
            "logo"=>'sometimes',
            "primary_color"=>'sometimes',
            "secondary_color"=>'sometimes',
            "clinic_id"=>'sometimes',
            "app_settings"=>'sometimes',
            "emergency_fund"=>'sometimes',
            "is_payment_required"=>'sometimes',
            'zipcode_validation' => 'sometimes',
            'is_suspended' => 'sometimes',
            "extra_image"=>'sometimes',
            "other"=>'sometimes',
            "trial_period"=>'sometimes',
            "send_chat_on_email" => "boolean|required"
        ];
    }
}
