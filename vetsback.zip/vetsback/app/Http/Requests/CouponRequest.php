<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class CouponRequest extends BaseRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
           // 'other'=>'sometimes|required',
            'name'=>'sometimes|required',
            'code'=>'sometimes|required',
            'expiry'=>'sometimes|required',
            'access_days'=>'sometimes|required',
            'off_type'=>'sometimes|required',
            'price_off'=>'sometimes|required',
            'one_time'=>'sometimes|required',
            'package_id'=>'sometimes|required',
            'enable_pet_tracking'=>'sometimes|required',
            'has_expiry'=>'required|boolean',
        ];
    }
}
