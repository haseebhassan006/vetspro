<?php

namespace App\Http\Requests\Trainer;

use App\Http\Requests\BaseRequest;


class TrainerUpdateRequest extends BaseRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'first_name' => 'sometimes',
            'last_name' => 'sometimes',
            'experience' => 'sometimes',
            'specialties' => "sometimes",
            'about' => "sometimes",
            'phone_number' => "sometimes",
            'sex' => "sometimes|in:M,F",
            'profile_image' => "sometimes",
            'is_active'=>"sometimes"
        ];
    }
}
