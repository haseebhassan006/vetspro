<?php

namespace App\Http\Requests\Trainer;

use App\Http\Requests\BaseRequest;


class TrainerScheduleEditRequest extends BaseRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    protected function prepareForValidation() 
    {
        $this->merge(['id' => $this->route('id')]);
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'id' => 'required|exists:trainer_schedules',
            'slot_from_time' => 'required|date|before:slot_to_time',
            'slot_to_time' => 'required|date|after:slot_from_time',
            'date' => 'required|date',
            'charges' => 'required',
            'booking_status' => 'sometimes|in:Available,Booked'
        ];
    }
}
