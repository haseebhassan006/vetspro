<?php

namespace App\Http\Requests\Trainer;

use App\Http\Requests\BaseRequest;


class TrainerCreateFeebackRequest extends BaseRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'trainer_id' => 'required|exists:trainers,id',
            // 'user_id' => 'required',
            'booking_id' => 'required|exists:appointment_bookings,id',
            'booking_pet_id' => "sometimes",
            'review_text' => "sometimes",
            // 'status' => "sometimes",
            'ratings' => "required|array",
            'ratings.*.review_name_id' => 'required|exists:review_names,id',
            'ratings.*.rate' => 'required|gt:0'
        ];
    }
}
