<?php

namespace App\Http\Requests\Trainer;

use App\Http\Requests\BaseRequest;


class TrainerScheduleCreateRequest extends BaseRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            '*.slot_from_time' => 'required|date|before:*.slot_to_time|after_or_equal:now',
            '*.slot_to_time' => 'required|date|after:slot_from_time',
            '*.date' => 'required|date|after_or_equal:now',
            '*.charges' => 'required',
            '*.booking_status' => 'sometimes|in:Available,Booked'
        ];
    }
}
