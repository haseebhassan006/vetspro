<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class CreatePetRequest extends BaseRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            //
            'name'=>'required',
            'species'=>'required',
            'age'=>'sometimes|required',
            'breed'=>'required',
            'color'=>'sometimes|required',
            'weight'=>'sometimes|required',
            'sex'=>'required',
            'sex_type'=>'sometimes',
        ];
    }
}
