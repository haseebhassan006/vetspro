<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class VetRequest extends BaseRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
//    protected function prepareForValidation()
//    {
//        $this->merge(['id'=>$this->id]);
//    }

    public function rules()
    {
//        $rules = [];
//        if($this->segment(4) == "login"){
//            $rules = [
//                'email' => 'required|email|exists:vets,email',
//                'password' => 'required',
//            ];
//        }else if($this->segment(4) == "create"){
//            $rules = [
//                'first_name' => 'required',
//                'last_name' => 'required',
//                'email' => 'required|email|unique:vets,email',
//                'password' => 'required',
//                'role' => 'required|exists:roles,name',
//            ];
//        }else if($this->segment(4) == "update"){
//            $rules = [
//                'id' => 'required|exists:vets,id',
//                'first_name' => 'required',
//                'last_name' => 'required',
//                'profile' => 'sometimes|required',
//            ];
//        }else if($this->segment(4) == "get" || $this->segment(4) == "delete"){
//            $rules = [
//                "id" => "required|exists:vets,id",
//            ];
//        }
//        return $rules;


        return [

            'email'=>'sometimes|required|email|unique:users,email',
            'password'=>'sometimes|required',
            'first_name' => 'sometimes|required',
            'last_name' => 'sometimes|required',
            'role'=> 'sometimes|required',
            'id' => 'sometimes|required',
            'profile'=>'sometimes|required',
            'device_token'=>'sometimes|required',
            'udid'=>'sometimes|required',
            'api_key'=>'sometimes|required',
            'dev_type'=>'sometimes|required',
            'is_online'=>'sometimes|required',
            'status'=>'sometimes|required',
            'app_version'=>'sometimes|required'
        ];
    }
}
