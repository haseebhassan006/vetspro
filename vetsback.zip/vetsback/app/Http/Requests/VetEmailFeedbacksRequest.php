<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Support\Facades\Validator;

class VetEmailFeedbacksRequest extends BaseRequest
{
    public function __construct() {
        Validator::extend("emails", function($attribute, $value, $parameters) {
            $rules = [
                'email' => 'required|email',
            ];
            $value = str_replace(' ', '', $value);
            if (str_contains($value, ',') || str_contains($value, ';')) {
                if (str_contains($value, ',')) {
                    $value = explode(',', $value);
                } elseif (str_contains($value, ';')) {
                    $value = explode(';', $value);
                }
                foreach ($value as $email) {
                    $data = [
                        'email' => $email
                    ];
                    $validator = Validator::make($data, $rules);
                    if ($validator->fails()) {
                        return false;
                    }
                }
            } else {
                $data = [
                    'email' => $value
                ];
                $validator = Validator::make($data, $rules);
                if ($validator->fails()) {
                    return false;
                }
            }
            return true;
        }, 'Please enter a valid email address');
    }

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */

    public function rules()
    {
        return [

            'email'=>'required|emails',
            'date_from'=>'sometimes',
            'date_to'=>'sometimes',
            'export' => 'required',
            'app_id' => 'sometimes',
        ];
    }
}
