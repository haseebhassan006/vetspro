<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class VetCareRegisterUserRequest extends BaseRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool 
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            // Vet Care User Model
            'first_name'=>'required',
            'last_name'=>'required',
            'email'=>'required|email|unique:vet_care_users,email,NULL,id,deleted_at,NULL',
            'password' => 'sometimes|required',
            'phone_no'=>'sometimes',
            'dob'=>'sometimes',
            'device_token'=> 'sometimes|required',
            'api_key' => 'required',
            'dev_type'=>'sometimes|required',
            'country'=>'sometimes',
            'city'=>'sometimes',
            'zip_code'=>'sometimes',
            'other'=>'sometimes|required',
            'profile'=>'sometimes|required',
            'status'=>'sometimes|required|in:subscribed,cancelled,upgrade',
            'type'=>'sometimes|required|in:monthly,yearly',
            'gender'=>'sometimes|required',

            // Pet Model
            'name'=>'required',
            'species'=>'required',
            'age'=>'required',
            'breed'=>'required',
            'color'=>'sometimes|required',
            'weight'=>'required',
            'sex'=>'required',
            'sex_type'=>'',

            // Stripe Card
            'number'=>'sometimes|required',
            'exp_month'=>'sometimes|required',
            'exp_year'=>'sometimes|required',
            'cvc'=>'sometimes|required',
            'code'=>'sometimes',
            'package_id'=>'sometimes|required',
            'price'=>'sometimes|required',
            'is_addOn'=>'sometimes|required',
            'addOn_package_id'=>'sometimes|required',
            'addOn_price'=>'sometimes|required',

        ];
    }
}
