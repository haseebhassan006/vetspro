<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class ProtectClientAdminRequest extends BaseRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            //
            'app_id'=>'required',
            'paid'=>'sometimes',
            'amount'=>'sometimes',
            'attachment'=>'sometimes',
            'note'=>'sometimes',
            'flag'=>'sometimes',
            'notes'=>'sometimes',
            'pet_name'=>'sometimes',
            'clinic_arrival_time'=>'sometimes',
            'pet_age'=>'sometimes',
            'pet_species'=>'sometimes',
            'pet_sex'=>'sometimes',
            'clinic_name'=>'sometimes',
            'clinic_phone_no'=>'sometimes',
            'paid_by'=>'sometimes'
        ];
    }
}
