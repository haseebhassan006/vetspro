<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class TwilioApiRequest extends BaseRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            //
            'first_name'=>'required|sometimes',
            'last_name'=>'sometimes',
            'email'=>'required|sometimes',
            'conversation_request'=>'required',
            'pet'=>[
                'id'=>'sometimes',
                'weight'=>'sometimes',
                'age'=>'sometimes',
                'color'=>'sometimes',
                'name'=>'required',
                'species'=>'required',
                'sex'=>'required',
                'breed'=>'required',
                'sex_type'=>'sometimes'
            ],
            'api_key'=>'required',
            'is_protect'=>'required',
            'your_registration_date'=>'required',
            'dev_type'=>'required|sometimes',
            'phone_no'=>'sometimes',
            //For pawp only
            'identity'=>'required|sometimes',
            'twilio_user_sid'=>'sometimes',
            'channel_sid'=>'sometimes',
            'room_sid'=>'required|sometimes',
            'db_user_id'=>'sometimes',


        ];
    }
}
