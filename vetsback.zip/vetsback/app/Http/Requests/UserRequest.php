<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class UserRequest extends BaseRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true; // this is false by default which means unauthorized 403
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'first_name'=>'sometimes|required',
            'last_name'=>'sometimes|required',
            //'email' => 'sometimes|required|email|unique:users,email',
            'email'=>'sometimes|required|email|unique:users,email,NULL,id,deleted_at,NULL',
            'password' => 'sometimes|required',
            'phone_no'=>'sometimes',
            'dob'=>'sometimes',
            'device_token'=> 'sometimes|required',
            'api_key' => 'required',
            'dev_type'=>'sometimes|required',
            'country'=>'sometimes',
            'city'=>'sometimes',
            'zip_code'=>'sometimes',
            'other'=>'sometimes|required',
            'profile'=>'sometimes|required',
            'status'=>'sometimes|required',
            'gender'=>'sometimes|required'
        ];
    }
    /**
     * Get the error messages for the defined validation rules.
     *
     * @return array
     */
    public function messages()
    {
        return [
            'app_id.required' => 'App ID is required!',
        ];
    }
}
