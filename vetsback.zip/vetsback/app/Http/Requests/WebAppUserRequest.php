<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Support\Facades\Request;

class WebAppUserRequest extends BaseRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true; // this is false by default which means unauthorized 403
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $request = Request::all();
        if (array_key_exists('pet', $request)) {
            return [
                'first_name'=>'required',
                'last_name'=>'sometimes',
                'email'=>'required|email|unique:webapp_users,email',
                'emergency_fund'=>'sometimes|integer',
                    'pet.id'=>'sometimes',
                    'pet.weight'=>'required',
                    'pet.age'=>'required',
                    'pet.color'=>'sometimes',
                    'pet.name'=>'required',
                    'pet.species'=>'required',
                    'pet.sex'=>'required',
                    'pet.breed'=>'required',
                    'pet.sex_type'=>'sometimes',
                'role'=>'required',
                'dev_type'=>'required',
                'phone_no'=>'sometimes',
            ];
        } else {
            return [
                'first_name'=>'required',
                'last_name'=>'sometimes',
                'email'=>'required|email|unique:webapp_users,email',
                'emergency_fund'=>'sometimes|integer',
                'role'=>'required',
                'dev_type'=>'required',
                'phone_no'=>'sometimes',
            ];
        }

    }
    /**
     * Get the error messages for the defined validation rules.
     *
     * @return array
     */
    public function messages()
    {
        return [
            'app_id.required' => 'App ID is required!',
            'first_name.required' => 'The first name field is required.',
            'pet.weight.required' => 'The pet weight field is required.',
            'pet.age.required' => 'The pet age field is required.',
            'pet.name.required' => 'The pet name field is required.',
            'pet.species.required' => 'The pet species field is required.',
            'pet.sex.required' => 'The pet sex field is required.',
            'pet.breed.required' => 'The pet breed field is required.',
            'role.required' => 'The role field is required, should be "users" or "protect_users".',
        ];
    }
}
