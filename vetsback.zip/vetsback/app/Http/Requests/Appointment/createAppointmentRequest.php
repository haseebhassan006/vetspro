<?php

namespace App\Http\Requests\Appointment;

use App\Http\Requests\BaseRequest;
use Illuminate\Foundation\Http\FormRequest;

class createAppointmentRequest extends BaseRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'trainer_id' => 'required|exists:trainers,id',
            'schedule_id' => 'required|exists:trainer_schedules,id',
            'booking_note' => 'sometimes',
            'contact_no' => 'sometimes',

            // 'pet' => [
            //     'name' => 'required',
            //     'species' => 'required',
            //     'age' => 'required',
            //     'breed' => 'required',
            //     'color' => 'required',
            //     'sex' => 'required',
            //     'sex_type' => 'required',
            //     'weight' => 'required',
            // ],
            'pet_id'=>'required',
            'payment' => "required|array",
            'payment.number' => 'required',
            'payment.exp_month' => 'required',
            'payment.exp_year' => 'required',
            'payment.cvc' => 'required',
            'payment.amount' => 'required',
        ];
    }
}
