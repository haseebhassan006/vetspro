<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class RoleRequest extends BaseRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }
    
    protected function prepareForValidation()
    {
        $this->merge(['id'=>$this->id]);
    }
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $rules = [];
        if($this->segment(4) == "create"){
            $rules = [
                "name" => "required|unique:roles,name",
                "guard_name" => "required",
            ];
        }else if($this->segment(4) == "update"){
            $rules = [
                "id" => "required|exists:roles,id",
                "name" => "required|unique:roles,name," . $this->id . ",id",
                "guard_name" => "required",
            ];
        }else if($this->segment(4) == "get" || $this->segment(4) == "delete"){
            $rules = [
                "id" => "required|exists:roles,id",
            ];
        }
        return $rules;
    }
}
