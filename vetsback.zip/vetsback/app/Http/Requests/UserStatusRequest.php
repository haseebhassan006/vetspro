<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class UserStatusRequest extends BaseRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'api_key'=>'required',
            'email'=>'required',
            'first_name'=>'sometimes',
            'last_name'=>'sometimes',
            'status'=>'required',
            'your_registration_date'=>'sometimes',
            'phone_no'=>'sometimes',
            'role'=>'sometimes',
            'type'=>'sometimes'
        ];
    }
}
