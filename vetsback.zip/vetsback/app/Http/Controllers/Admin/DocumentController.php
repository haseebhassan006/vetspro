<?php

namespace App\Http\Controllers\Admin;

use App\Document;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\DocumentRequest;

class DocumentController extends Controller
{
    private $noOfRecordPerPage = 10;
    private $paginate = false;

    /**
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request){
        try{

            $name = '';
          
            if ($request->hasfile('document')) {

                $file = $request->file('document')->getClientOriginalName();
                $filename = pathinfo($file, PATHINFO_FILENAME);
                $name = Str::slug($filename, '-')  . "-" . time() . '.' . $request->document->extension();
                $request->document->move(public_path('docs/file'), $name);
            }
            $data = Document::create([
                'file_path' => $name,
                'title' => $request->title,
                'category_id' => $request->category
            ]);
            return $this->successResponse($data, 'Document Added');
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(),$e->getCode());
        }
    }

    public function index(Request $request){
       
        try{
           
            $data = Document::with('documentCategory');
           
            

            if($request->has('id') && !empty($request->id))
            {
                $data = $data->where('id',$request->id);
            }

            if($request->has('category') && !empty($request->category))
            {
                $category=$request->category;
                $data = $data->whereHas('documentCategory',function($q) use ($category){
                    $q->where('id','=',$category);
                });
            }
            if($request->has('search') && !empty($request->search)){
                $data = $data->where('title', 'LIKE', '%' . $request->search . '%');
            }

           
            if (isset($request['pagination']) && $request['pagination'] != "") {
                if($request->has('limit') && !empty($request->limit)){
                    $this->noOfRecordPerPage = $request->limit;
                }
                $this->paginate = true;
                $data = $data->paginate($this->noOfRecordPerPage);
            }else{
                $data = $data->get();
            }
            
            return $this->successResponse($data, 'Documents',$this->paginate);
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(),$e->getCode());
        }
    }

    public function edit(Request $request, $id){
        try{
           

            $name = '';
          
            if ($request->hasfile('document')) {

                $file = $request->file('document')->getClientOriginalName();
                $filename = pathinfo($file, PATHINFO_FILENAME);
                $name = Str::slug($filename, '-')  . "-" . time() . '.' . $request->document->extension();
                $request->document->move(public_path('docs/file'), $name);
            }

            $data = Document::updateOrCreate(['id'=>$id]);
        
            return $this->successResponse($data, 'Document Edited');
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(),$e->getCode());
        }
    }

    public function delete(Request $request,$id){
        try{
            $data = Document::find($id)->Delete();

            return $this->successResponse($data, 'Document Deleted');
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(),$e->getCode());
        }
    }

    public function documentList(Request $request){
        try{
            // Only Visible 
            $data = Document::with('documentCategory');
          
            if($request->has('id') && !empty($request->id))
            {
                $data = $data->where('id',$request->id);
            }

            if (isset($request['pagination']) && $request['pagination'] != "") {
                if($request->has('limit') && !empty($request->limit)){
                    $this->noOfRecordPerPage = $request->limit;
                }
                $this->paginate = true;
                $data = $data->paginate($this->noOfRecordPerPage);
            }else{
                $data = $data->get();
            }
            return $this->successResponse($data, 'Documents ',$this->paginate);
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(),$e->getCode());
        }
    }
}
