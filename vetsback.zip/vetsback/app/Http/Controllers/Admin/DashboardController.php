<?php

namespace App\Http\Controllers\Admin;

use App\Reason;
use App\Recommendation;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class DashboardController extends Controller
{
    //
    private $noOfRecordPerPage = 10;
    private $paginate = false;

    public function getRecoomendationsResons(Request $request){
        $input = $request->only('search_value', 'search_by', 'page', 'pagination', 'perPage');

        try{
            if (isset($input['perPage']) && $input['perPage'] != "" && is_int($input['perPage'])) {
                $this->noOfRecordPerPage = $input['perPage'];
            }

            $res = [
                'recommendation'=>Recommendation::all(),
                'reasons'=>Reason::all()
            ];
            return $this->successResponse($res, 'List',$this->paginate);

        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(),$e->getCode());
        }
    }

}
