<?php

namespace App\Http\Controllers\Admin;

use App\Faq;
use JWTAuth;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\CreateFaqRequest;

class FaqController extends Controller
{
    private $noOfRecordPerPage = 10;
    private $paginate = false;

    public function create(CreateFaqRequest $request){
        $validatedData = $request->validated();
        try {
            $faq = Faq::create($validatedData);
            return $this->successResponse($faq, 'FAQs Created Successfully');
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    public function list(Request $request)
    {
        $input = $request->only('search_value', 'search_by', 'page', 'pagination', 'perPage',  'date_from', 'date_to','faq_id');
        try {

            $faq = new Faq();
            if (isset($input['pagination']) && $input['pagination'] != "") {
                $perPage=isset($input['perPage'])?$input['perPage']:$this->noOfRecordPerPage;
                $this->paginate = true;
                $faq = $faq::paginate($perPage);
            } else {
                $trainer_id = $request['faq_id'];
                $faq = $faq::find($trainer_id);
            }
           
            return $this->successResponse($faq, 'Successfully Fetch FAQs List.',$this->paginate);
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    public function update($id, CreateFaqRequest $request)
    {
        $validatedData = $request->validated();
        try {
            $faq = Faq::findOrfail($id);
            $faq->update($validatedData);
            return $this->successResponse($faq, 'Successfully Record Updated.');
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    public function deleted($id, Request $request)
    {
        try {
            $faq = Faq::findOrfail($id);
            $faq->delete();
    
            return $this->successResponse($faq, 'Successfully Record Deleted.');
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

}
