<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\VideoGalleryCategory;
use App\Http\Requests\VideoGalleryCategoryRequest;

class VideoGallerCategoryController extends Controller
{
    private $noOfRecordPerPage = 10;
    private $paginate = false;
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        try{
            $data = new VideoGalleryCategory();
            // Only status 
            if(request()->has('status')  )
            {
                request()->status = request()->status === true || request()->status == 'true' ? 1 :0;
                
                $data = $data->where('status',request()->status);
            }
            if($request->has('id') && !empty($request->id))
            {
                $data = $data->where('id',$request->id);
            }
           
            if($request->has('search') && !empty($request->search)){
                $data = $data->where('category_name', 'LIKE', '%' . $request->search . '%');
            }
            if (isset($request['pagination']) && $request['pagination'] != "" ) {
                if($request->has('limit') && !empty($request->limit)){
                    $this->noOfRecordPerPage = $request->limit;
                }
                $this->paginate = true;
                $data = $data->paginate($this->noOfRecordPerPage);
            }else{
                $data = $data->get();
            }
            return $this->successResponse($data, 'Category List of Video Gallery Category Fetched',$this->paginate);
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(),$e->getCode());
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(VideoGalleryCategoryRequest $request)
    {
        //
        try{
            $validated = $request->validated();
            $data = VideoGalleryCategory::create($validated);
            return $this->successResponse($data, 'Category Added to Video Gallery Category ');
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(),$e->getCode());
        }
       
    }


    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(VideoGalleryCategoryRequest $request, $id)
    {
        try{
            $validated = $request->validated();
            $data = VideoGalleryCategory::updateOrCreate(['id'=>$id],$validated);
            return $this->successResponse($data, 'Category Added to Video Gallery Category');
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(),$e->getCode());
        }

    }


    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        try{
            $data = VideoGalleryCategory::find($id)->Delete();
            return $this->successResponse($data, 'Category Added to Video Gallery Category');
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(),$e->getCode());
        }

    }
}
