<?php

namespace App\Http\Controllers\Admin;

use App\Coupon;
use Carbon\Carbon;
use App\VetCareCoupon;
use App\VetCarePackage;
use App\VetCareCouponUsage;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\CouponRequest;
use App\Traits\CouponGenerateTrait;
use App\VetCareCouponCode;
use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\DB;

class VetCareCouponController extends Controller
{
    use CouponGenerateTrait;

    private $noOfRecordPerPage = 10;

    private $paginate = false;

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $input = $request->only('search_value', 'search_by', 'page', 'pagination', 'perPage','package_id','coupon_id');
        $value = isset($input['search_value'])?$input['search_value']:'';
        try{
            $model = VetCareCoupon::withCount('vetCareCouponCodes')->with(['vetCarePackage'])->orderBy('id','desc');
            if($request->has('package_id') && !empty($input['package_id'])){
                $model->where('package_id',$request->package_id);
                }
            if(isset($value) && !empty($value)){
                    $model = $model->whereRaw(" (other) like '%$value%'");

                }
            if (isset($input['pagination']) && $input['pagination'] != "") {
                $this->paginate = true;
                $data = $model->orderBy('id','desc')->paginate($this->noOfRecordPerPage);
            } else {
                $model = $model->where('id',$input['coupon_id'])->with('vetCareCouponCodes');
                $data = $model->get();
            }
            return $this->successResponse($data, 'list', $this->paginate);
        }
        catch (Exception $e){
            return $this->errorResponse('List error');
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(CouponRequest $request)
    {
        $validate = $request->validated();
        $user = auth()->user();
        try{
            $model = VetCareCoupon::whereHas('vetCareCouponCodes',function($q) use($request){
                $q->where('code',$request->code);
            })->first();
            if(!$model){
                $package_id = $validate['package_id'];
                if( $validate['has_expiry']==false ){

                    $validate['expiry']="null";
                    $validate['access_days']="null";
                }
                unset($validate['package_id'],$validate['code']);
                $validate['enable_pet_tracking'] = isset($validate['enable_pet_tracking']) ? $validate['enable_pet_tracking'] : 0;
                $data = ['other'=>$validate,'package_id'=>$package_id];
                $data['created_by'] = $user->id;
                $data['created_model'] = get_class($user);
                $data = $user->vetCareCoupon()->create($data);
                $data->vetCareCouponCodes()->create(['code' => $request->code]);
                return $this->successResponse($data, 'coupon added');
            }
            else{
                return $this->errorResponse('Coupon with same code already exists',403);
            }
        }
        catch (QueryException $e){
            return $this->errorResponse($e->getMessage(),404);
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\VetCareCoupon  $vetCareCoupon
     * @return \Illuminate\Http\Response
     */
    public function edit($id,CouponRequest $request)
    {
        $user = auth()->user();
        $validatedData = $request->validated();
        try {
            $package_id = $validatedData['package_id'];
            unset($validatedData['package_id'],$validatedData['code']);

            $model =  VetCareCoupon::findOrFail($id);

            if($model->vetCareCouponCodes()->count() > 1 && ( $model->vetCareCouponCodes()->has('vetCareCouponUsages')->count() ||
            $model->vetCareCouponCodes()->has('vetCarePackageUsages')->count() )
            ){
                return $this->errorResponse("Coupon codes are in used, unable to update",403);
            }
            $model_enable_pet_tracking=isset($model->other['enable_pet_tracking'])?$model->other['enable_pet_tracking']:0;
            if( $validatedData['has_expiry']==false ){

                $validatedData['expiry']="null";
                $validatedData['access_days']="null";
            }
            $validatedData['enable_pet_tracking'] = isset($validatedData['enable_pet_tracking']) ? $validatedData['enable_pet_tracking'] : $model_enable_pet_tracking;
            $model->package_id  = $package_id;
            $model->other = $validatedData;
            $model->updated_by = $user->id;
            $model->updated_model = get_class($user);
            $model->save();
            // this codition ensure to update those coupon code which has only one coupon code.

            // if($request->has('code') && $model->vetCareCouponCodes()->withTrashed()->count() == 1)
            // {
            //     $model->vetCareCouponCodes()->update(['code'=>$request->code]);

            // }

            $model->load('vetCareCouponCodes');
            return $this->successResponse($model, 'Successfully Record Updated.');
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\VetCareCoupon  $vetCareCoupon
     * @return \Illuminate\Http\Response
     */
    public function destroy($id,VetCareCoupon $request)
    {
        $user = auth()->user();
        try {
            $vetCareCoupon = VetCareCoupon::findOrfail($id);
            if( $vetCareCoupon && ($vetCareCoupon->vetCareCouponCodes()->has('vetCareCouponUsages')->count()
            || $vetCareCoupon->vetCareCouponCodes()->has('vetCarePackageUsages')->count()) )
            {
                return $this->errorResponse("Coupon codes are in used, unable to delete",403);
            }
            $vetCareCoupon->deleted_by =  $user->id;
            $vetCareCoupon->deleted_model = get_class($user);
            $vetCareCoupon->vetCareCouponCodes()->delete();
            $vetCareCoupon->deleted_at = Carbon::now();
            $vetCareCoupon->save();

            return $this->successResponse($vetCareCoupon, 'Successfully Deleted.');
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    public function redeem(Request $request)
    {

        try{
            $user = auth()->user();
            $code = $request->code;
            $date = Carbon::now()->toDateString();
            $history = null;
            $packageId = $request->package_id;

            $model = VetCareCoupon::where("package_id",$packageId)->with('vetCarePackage','vetCareCouponCodes')->whereHas("vetCareCouponCodes",function($q) use($code){
                $q->where('code',$code);
            })->first();

            if(!$model){
                return $this->errorResponse('Code Not Valid',404);
            }
            $json_to_var = json_decode($model);
            if($json_to_var->other->has_expiry=='false'){
                $json_to_var->other->expiry = isset($json_to_var->other->expiry) && $json_to_var->other->expiry!= "null" ? $json_to_var->other->expiry : $date;
            }

            //$expiry = $json_to_var['expiry'];
            //dd($json_to_var->other->expiry,$date);
            if($request->package_id == $model->package_id){

                if($json_to_var->other->expiry >= $date  ){
                    $get_payment = $model->vetCarePackage;
                    $code = $model->vetCareCouponCodes->where('code',$code)->first();
                    if($user){
                        $history = VetCareCouponUsage::where(['vet_care_coupon_code_id'=>$code->id,'user_id'=>$user->id])->first();
                    }

                    if($history){
                        if($json_to_var->other->one_time == 1){
                            return $this->errorResponse('Code one time use only  contact admin',406);
                        }
                        // $used_days = strtotime($history->use_datetime);
                        // $datediff = date_diff($date - $used_days);

                        if($history->left_days != "unlimited" && $history->left_days < 1 && ($json_to_var->other->expiry < $date)){
                            return $this->errorResponse('Code expired  contact admin',406);
                        }

                    }
                    //Response to show user
                    $old_price = $get_payment->price;
                    if(isset($json_to_var->other) && $json_to_var->other->off_type == 'percent_off'){
                        $off  = $json_to_var->other->price_off;
                        $calculation = ($off/100)*$old_price;
                    }elseif(isset($json_to_var->other) && $json_to_var->other->off_type == 'price_off'){
                        $off  = $json_to_var->other->price_off;
                        $calculation = $off ;
                    }else{
                        $off  = 0;
                        $calculation = $off ;
                    }
                    if((float)$old_price < (float)$calculation){
                        $calculation = $old_price ;

                        // return $this->errorResponse('wrong package price',406);

                    }
                    //else{
                        $new_price = $old_price - $calculation;
                    //}
                }
                else{
                    //$resp['message'] = 'Code expired or invalid code, contact admin';
                    //$resp['coupon_id'] = $model->id;
                    return $this->errorResponse('Code expired',406);
                }
            }
            else{
                //$resp['message'] = 'Code expired or invalid code, contact admin';
                //$resp['coupon_id'] = $model->id;
                return $this->errorResponse('Redeem code does not belong to your selected package',403);
            }

            $resp['message'] = 'Code accepted';
            $resp['coupon_id'] = $model->id;
            $resp['coupon_code_id'] = $code->id ?? 0;
            $resp['old_price'] = $old_price;
            $resp['new_price'] = round($new_price,2);
            $resp['discount'] = round($calculation,2);
            $resp['package_id'] = $request->package_id;
            $resp['currency'] = $get_payment->currency;
            $resp['enable_pet_tracking'] = isset($json_to_var->other->enable_pet_tracking)?$json_to_var->other->enable_pet_tracking:0; // enable_pet_tracking key added

            return $this->successResponse($resp, 'Redeeem Success');
        }
        catch (ModelNotFoundException $e){
            return $this->errorResponse('Incorrect code! Contact Admin');
        }
        catch (QueryException $e){
            return $this->errorResponse($e->getMessage(),404);
        }
        catch (Exception $e){
            return $this->errorResponse('Warning! Contact Admin',400);
        }
    }

    public function multiCoupon(CouponRequest $request)
    {
        $user = auth()->user();
        $only = $request->only('name','expiry','access_days','off_type','price_off','one_time','enable_pet_tracking','has_expiry');
        $only['enable_pet_tracking'] = isset($only['enable_pet_tracking']) ? $only['enable_pet_tracking'] : 0;
        if( $only['has_expiry']==false ){
            $only['expiry']="null";
            $only['access_days']="null";
        }
        $data = [
            'package_id' => $request->package_id,
            'other' => $only
        ];
        $model = null;
        try{

            $model = $user->vetCareCoupon()->create($data);

            for($i=0; $i<$request->coupon_count;$i++)
            {
                $model->vetCareCouponCodes()->create(['code'=>$this->generateCoupon()]);
            }
            $model->load('vetCareCouponCodes');

        } catch (\Exception $e) {

            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
        return $this->successResponse($model, 'coupon added');

    }

    public function show(VetCareCoupon $vetCareCoupon)
    {
         $vetCareCoupon->load(['vetCareCouponCodes'=>function($q){
            $q->withCount(['vetCareCouponUsages','vetCarePackageUsages'])->orderBy('id','desc');
         }]);
         return $this->successResponse($vetCareCoupon, 'show coupon');
    }

}
