<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\UserRequest;
use App\Traits\PushNotification;
use App\User;
use stdClass;

class NotificationController extends Controller
{
    use PushNotification;

    private $noOfRecordPerPage = 10;
    private $paginate = false;
    
    public function list(Request $request)
    {
        $input = $request->only('search_value', 'search_by', 'page', 'pagination', 'perPage', 'user_id');
        //dd($input);
        try {
            $user = User::whereHas('devices');
            if (isset($input['pagination']) && $input['pagination'] != "") {
                $this->paginate = true;
                $user = $user->paginate($this->noOfRecordPerPage);
            } else {
                $user_id = $input['user_id'];
                $user = $user->find($user_id);
            }
            $data = array(
                "user" => $user
            );
            return $this->successResponse($data, 'Successfully Fetch List User.');
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    public function sendNotification(Request $request)
    {
        try {
            $data = new stdClass;
            $notification = [
                'title' => "Ali Haider",
                'body' => "Ali Haider",
                'data' => "Ali Haider",
                'token' => "Ali Haider"
            ];
            $notificationResult = $this->PushNotification($notification);
            dd($notificationResult);
            return $this->successResponse($data, 'Successfully Send Notification.');
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }
}
