<?php

namespace App\Http\Controllers\Admin;

use JWTAuth;
use stdClass;
use Validator;
use App\Trainer;
use App\SubAdmin;
use Carbon\Carbon;
use Illuminate\Http\Request;
use App\AdminNotificableUser;
use App\Traits\TwilioSDKTrait;
use Illuminate\Support\Facades\DB;
use App\Traits\OtherTwilioSDKTrait;
use Illuminate\Support\Facades\App;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use App\Http\Requests\AdminUserRequest;
use Illuminate\Database\QueryException;
use App\Http\Requests\subAdminUpdateRequest;
use Carbon\Exceptions\UnknownGetterException;
use App\Http\Requests\SubAdminRegisterRequest;
use App\Http\Requests\Trainer\TrainerUpdateRequest;
use App\Http\Requests\Trainer\TrainerCreateRequest;
use App\Http\Requests\Trainer\TrainerLoginRequest;
use App\Http\Requests\Trainer\TrainerChangePasswordRequest;
use Illuminate\Support\Facades\Mail;

class TrainerCRUDController extends Controller
{
    protected $user;
    use TwilioSDKTrait;
    use OtherTwilioSDKTrait;
    private $noOfRecordPerPage = 10;
    private $paginate = false;

    public function __construct()
    {
        $this->generic();
        $this->construct();
    }

    /**
    * Get the guard to be used during authentication.
    *
    * @return \Illuminate\Contracts\Auth\Guard
    */
    public function guard()
    {
        return Auth::guard('trainer');
    }

    /**
     * register API
     *
     * @param TrainerRegisterRequest $request
     * @return \Illuminate\Http\Response
     */
    public function create(TrainerCreateRequest $request)
    {
        $validatedData = $request->except('udid','app_version','dev_type','device_token','password_confirmation','schedule');
        \DB::beginTransaction();
        try{
            $trainer = new Trainer;
            //check for profile_image 
            if($request->hasFile('profile_image')) {
                $validatedData['profile_image'] = $this->uploadFilePublicRepo($request->profile_image, 's3','vet_care_app');
            }
            if(array_key_exists('password',$validatedData)){
                $pwd = $validatedData['password'] ?$validatedData['password'] :'password' ;
                $validatedData['password'] = bcrypt($validatedData['password']);
            }
            
            $token = str_random(64);
            $validatedData['verification_token'] =$token;
            $data = $trainer->create($validatedData); // Saving Trainer to DB

            $data->assignRole('trainer'); // Assigning Role
            //Add trainer to twilio account as well
            $attributes = ["trainer_id"=>$data->id,"role"=>'trainer',"email"=>$data->email];
            $identity = 'trainer-'.$data->id;
            $identity = is_local_env() ? 'local-' . $identity : $identity;

            $dataToTwilio = [
                'attributes' => json_encode($attributes),
                'friendlyName' => $data->first_name.' '.$data->last_name,
                'identity'=> $identity
            ];
            $createUser = $this->createUser($dataToTwilio); // To Twilio Trait

            //Response
             // Setting URL for email
             $url = url('/trainer') . "/verify-email/" . $token . '?email=' . $data->email;

            //  Mail::send('customauth.trainer_verify', ['token' => $token, 'url' => $url], function ($message) use ($request) {
            //      $message->to($request->email);
            //      $message->subject('Verify Email Notification');
            //  });
            $success['trainer'] = $data;
            $success['verification_link'] =$url ;
            \DB::commit();
            return $this->successResponse($success, 'Successfully Created Trainer.');
        }catch (RestException $e) {
            \DB::rollback();
            return $this->errorResponse($e->getMessage(),$e->getCode());
        }
        catch (QueryException $e) {
            \DB::rollback();
            switch ($e->getCode()) {
                case 23000:
                    $message = "Email already exists";
                break;
                default:
                    $message = "Try again. Query Error";
            }
            return $this->errorResponse($message,405);
        }
        catch (\Exception $e) {
            \DB::rollback();
            return $this->errorResponse($e->getMessage(),$e->getCode());
        }
    }

    /**
     * Trainer Update and validating through Request Class
     * @param TrainerUpdateRequest $request
     * @return \Illuminate\Http\Response
     */
    public function update($id,TrainerUpdateRequest $request)
    {
        $data = $request->validated();
        try{
            $trainer = Trainer::with('schedules','appointments')->findOrfail($id);
            if(isset($request->is_active) && $request->is_active==0 && sizeof($trainer->appointments)>0){
                return $this->errorResponse('Can not deactivate the trainer who has appointment(s)', 200);
            }
            $data['profile_image'] = ($request->hasFile('profile_image'))  ?  $this->uploadFilePublicRepo($data['profile_image'], 's3','vet_care_app') : null;
            $trainer->update($data);
                return $this->successResponse($trainer, 'Trainer Succesfully Updated.');
            } catch (\Exception $e) {
                return $this->errorResponse($e->getMessage(), $e->getCode());
            }
    }
    /**
     * Delete
     * @param id $id
     * @return \Illuminate\Http\Response
     */
    public function deleted($id)
    {
        try {
            $trainer = Trainer::with('schedules','appointments')->findOrfail($id);
            if(sizeof($trainer->appointments)>0){
                return $this->errorResponse('Can not delete trainer who has appointment(s)', 200);
            }
            $trainer->delete();
            $data = array(
                "trainer" => $trainer
            );
            return $this->successResponse($data, 'Trainer Record Deleted.');
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }
    
    public function list(Request $request)
    {
        $input = $request->only('search_value', 'search_by', 'page', 'pagination', 'perPage',  'date_from', 'date_to','trainer_id');
        try {
            $trainer = new Trainer();
            if (isset($input['pagination']) && $input['pagination'] != "") {
                $this->paginate = true;
                $trainer = $trainer::with('schedules','appointments')->paginate($this->noOfRecordPerPage);
            } else {
                $trainer_id = $request['trainer_id'];
                $trainer = $trainer::with('schedules','appointments')->find($trainer_id);
            }
           
            return $this->successResponse($trainer, 'Successfully Fetch Trainer List.',$this->paginate);
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }
   
}
