<?php

namespace App\Http\Controllers\Admin;

use Carbon\Carbon;
use App\TrainerSchedule;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\Http\Requests\Appointment\createAppointmentRequest;
use App\Http\Resources\AppointmentResource;
use Illuminate\Support\Facades\DB;
use App\AppointmentBooking;
use App\Traits\SearchFullNameWithSpacesTrait;

class TrainerAppointmentController extends Controller
{
    private $noOfRecordPerPage = 10;
    private $paginate = false;
    use SearchFullNameWithSpacesTrait;

    public function list(Request $request){
        $input = $request->only( 'page', 'pagination', 'perPage',  'date_from', 'date_to','trainer_id','user_id');
       
        try {
            $value = isset($input['search_value']) ? $input['search_value'] : '';
            $appointments = new AppointmentBooking();
            $appointments = $appointments->with(['trainer','user','pet','app','schedule','appointmentPayment']);


            if(isset( $request['trainer_id']) && !empty( $request['trainer_id'])){
                $trainer_id = $request['trainer_id'];
                $appointments = $appointments->where('trainer_id',$trainer_id);
            }

            if(isset( $request['user_id']) && !empty( $request['user_id'])){
                $user_id = $request['user_id'];
                $appointments = $appointments->where('model_id',$user_id);

            }

            if(isset( $request['app_id']) && !empty( $request['app_id'])){
                $app_id = $request['app_id'];
                $appointments = $appointments->where('app_id',$app_id);

            }

            if ($request->has('date_from') && $request->has('date_to')) {
                $appointments = $appointments->whereBetween('created_at',
                    [$input['date_from'] . " 00:00:00", $input['date_to'] . " 23:59:00"]
                );
            }

            if (isset($input['pagination']) && $input['pagination'] != "") {
                $this->paginate = true;
                $appointments = $appointments->paginate($this->noOfRecordPerPage);
            } else {
                $appointments = $appointments->get();
            }
           
            return $this->successResponse($appointments, 'Successfully Fetch Trainer List.',$this->paginate);
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }
    
}
