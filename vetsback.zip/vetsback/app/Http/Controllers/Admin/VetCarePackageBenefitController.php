<?php

namespace App\Http\Controllers\Admin;

use Validator;
use Carbon\Carbon;
use App\VetCarePackage;
use Illuminate\Http\Request;
use App\VetCarePackageBenefit;
use App\Http\Controllers\Controller;



class VetCarePackageBenefitController extends Controller
{

    public function getBenefit(Request $request){

      try{
        $data = new VetCarePackageBenefit;
        if($request->has('id') && !empty($request->id))
        {
            $data = $data->where('id',$request->id);
        }
        $data = $data->latest()->get();
        return $this->successResponse($data, 'Vet Care Package Benefits');
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(),$e->getCode());
        }

    }

    public function createBenefit(Request $request)
    {
        $validator = Validator::make($request->only('benefit_title','features'), [
            'benefit_title' => 'required|max:255',
            'features' => 'sometimes',
            ]);

        try {
            $benefitResponse = array ();
            $benefits = $request->benefits;
            foreach ($benefits as $benefit) {
                array_push($benefitResponse , VetCarePackageBenefit::create([
                    'benefit_title' => $benefit['benefit_title'],
                    'features' => isset($benefit['features']) ? $benefit['features'] : '',
                    'created_at' => Carbon::now(),
                    'updated_at' => Carbon::now(),
                    ])
                );
            }            
            return $this->successResponse($benefitResponse, 'Vet Care Benefit Saved');
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    public function editBenefit(Request $request)
    {
        $validator = Validator::make($request->only('benefit_title','id'), [
          'id' => 'required|exists:vet_care_package_benefits',
          'benefit_title' => 'required|max:255',
          'features' => 'sometimes',
          ]);
        if ($validator->fails()) {
            $errors[] = $validator->errors();
            return $this->errorResponse($validator->errors()->all(), 422);
        }
        try {
            $input = $request->only('benefit_title','id','features');
            $data =  VetCarePackageBenefit::updateOrCreate(['id'=>$request->id],$input);
            return $this->successResponse($data, 'Vet Care Benefit Edited');
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    public function deleteBenefit($id)
    {
      try{
        $data = VetCarePackageBenefit::find($id)->delete();
        return $this->successResponse($data, 'Vet Care Benefit Deleted');
      }
      catch (\Exception $e){
          return $this->errorResponse($e->getMessage(),$e->getCode());
      }
    }

    public function assignBenefitToPackages(Request $request){
      
      // try {
          
      //     dd(4);
      //     $package = VetCarePackage::find(50);
      //     $package->benefit()->sync([1,2,4]);
      //     // return $this->successResponse($data, 'Vet Care Benefit Saved');
      // } catch (\Exception $e) {
      //     return $this->errorResponse($e->getMessage(), $e->getCode());
      // }
    }

}