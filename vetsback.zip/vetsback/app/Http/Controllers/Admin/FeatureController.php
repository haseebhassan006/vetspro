<?php

namespace App\Http\Controllers\Admin;

use App\SubAdmin;
use App\Pet;
use App\UserAppStatus;
use App\Vet;
use App\User;
use App\VetCarePet;
use App\Guest;
use App\Queue;
use App\ExtraPet;
use App\GuestPet;
use App\VetCare;
use App\VetCareUser;
use Carbon\Carbon;
use App\WebappUser;
use App\Subscriptions;
use App\NoteProectUser;
use App\FailedHandshake;
use App\FlagProtectUser;
use Barryvdh\DomPDF\PDF;
use App\EmergencyVetClient;
use Illuminate\Http\Request;
use App\Traits\StripePayment;
use App\AuthenticationHistory;
use App\Traits\FullTextSearch;
use App\Traits\TwilioSDKTrait;
use App\Http\Requests\VetRequest;
use App\Http\Requests\UserRequest;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\Traits\CollectionMethodsTrait;
use App\Http\Requests\GuestAuthRequest;
use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\Storage;
use App\Http\Requests\FeatureUserRequest;
use Illuminate\Support\Facades\Validator;
use App\Traits\SearchFullNameWithSpacesTrait;
use App\Http\Requests\ProtectClientAdminRequest;
use App\Http\Requests\GetPetListRequest;
use App\Http\Resources\PetListResource;

class FeatureController extends Controller
{
    private $noOfRecordPerPage = 100;
    private $paginate = false;
    use FullTextSearch;
    use StripePayment;
    use CollectionMethodsTrait;
    use SearchFullNameWithSpacesTrait;


    public function getVetOnline(Request $request)
    {
        $input = $request->only('search_value', 'search_by', 'page', 'pagination', 'perPage', 'vet_id');
        $value = isset($input['search_value'])?$input['search_value']:'';
        try {

            $vet_data = Vet::role('vets')->with(['devices','lastVetHistory'=> function($q){
                $q->whereRaw('id IN (select MAX(id) from authentication_histories GROUP BY model_id)');
            }])->where("is_online", 1);
            if ($value != ''){
                $vet_data = $this->SearchFullNameWithSpaces($vet_data,$value,'where');
                $vet_data =  $vet_data->latest();
            }
            if (isset($input['pagination']) && $input['pagination'] != "") {
                $this->paginate = true;
                $vet_data = $vet_data->paginate($this->noOfRecordPerPage);
            } else {
                $vet_id = $input['vet_id'];
                $vet_data = $vet_data->find($vet_id);
            }
            return $this->successResponse($vet_data, 'Successfully Get Online Doctor',$this->paginate);
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    public function getVetQueue(Request $request)
    {
        $input = $request->only('search_value', 'search_by', 'page', 'pagination', 'perPage', 'vet_id');
        try {
            $vet_data = Queue::with('queue')->where("status", 0);
            if (isset($input['pagination']) && $input['pagination'] != "") {
                $this->paginate = true;
                $vet_data = $vet_data->paginate($this->noOfRecordPerPage);
            } else {
                $vet_id = $input['vet_id'];
                $vet_data = $vet_data->find($vet_id);
            }

            return $this->successResponse($vet_data, 'Successfully Get Online Doctor',$this->paginate);
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    public function vetUpdate($id, VetRequest $request)
    {
        $validated = $request->validated();
        try {
            $vet = Vet::role('vets')->findOrfail($id);
            $vet->update($validated);
            $data = array(
                "vet" => $vet
            );
            $vet->vetAuthenticationHistory()->create([
                'dateTime' => Carbon::now(),
                'type' => 'logout'
            ]);
            $vet->devices()->delete();
            $vet->queue()->delete();
            return $this->successResponse($data, 'Successfully Record Updated.');
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    public function getVetList(Request $request)
    {
        $input = $request->only('search_value', 'search_by', 'page', 'pagination', 'perPage', 'vet_id');
        $value = isset($input['search_value'])?$input['search_value']:'';

        try{
            $vet_data = Vet::role('vets')->with(['devices','apps','vetDetails']);
            if ($value != ''){
                $vet_data = $this->SearchFullNameWithSpaces($vet_data,$value,'where')
                ->orwhere('email','like', $value);
                $vet_data =  $vet_data->latest();
            }
            if (isset($input['pagination']) && $input['pagination'] != "") {
                $this->paginate = true;
                $vet_data = $vet_data->paginate($this->noOfRecordPerPage);
            } else {
                $vet_id = $input['vet_id'];
                $vet_data = $vet_data->find($vet_id);
            }
            return $this->successResponse($vet_data, 'Successfully Get Vet Details.',$this->paginate);
        } catch (\Exception $e) {

            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    public function getUserList(Request $request)
    {
        $input = $request->only('search_value', 'search_by', 'page', 'pagination', 'perPage', 'user_id','app_name','key','email','export');
        $app_name = isset($input['app_name'])?$input['app_name']:'';
        $value = isset($input['search_value'])?$input['search_value']:'';
        $key = isset($input['key'])?$input['key']:'';
        $email = isset($input['email'])?$input['email']:'';
        $export = isset($input['export'])?$input['export']:false;
        try{
            $app = $this->findAppByName($input['app_name']);
            if($app_name != ''){
                switch ($app->app_type){
                    case 'whitelabel':
                        $user =  User::search($value)->with(['devices','apps','userDetails'])->where('app_id',$app->id)->latest();
                        if (isset($input['pagination']) && $input['pagination'] != "") {
                            $this->paginate = true;
                            $user = $user->paginate($this->noOfRecordPerPage);
                        } else {
                            $user_id = $input['user_id'];
                            $user = $user->find($user_id);
                        }
                        break;
                    case 'webapp':
                        $user = WebappUser::search($value)->with(['emergency','user_status'=>function($q){
                            $q->select('id','user_id','status','date_time')->latest();
                            //->whereRaw('id IN (select MAX(id) from user_app_statuses GROUP BY user_id)');
                        }])->where('app_id',$app->id)->latest();
                        if (isset($input['pagination']) && $input['pagination'] != "") {
                            $this->paginate = true;
                            $user = $user->paginate($this->noOfRecordPerPage);
                        } else {
                            $user_id = $input['user_id'];
                            $user = $user->find($user_id);
                        }
                        break;
                    case 'sdk':
                        $user = Guest::search($value)->where('app_id',$app->id)->latest();
                        if (isset($input['pagination']) && $input['pagination'] != "") {
                            $this->paginate = true;
                            $user = $user->paginate($this->noOfRecordPerPage);
                        } else {
                            $user_id = $input['user_id'];
                            $user = $user->find($user_id);
                        }
                        break;
                    case 'whitelabel-webapp':
                        $user = VetCareUser::search($value)->with(['emergency','user_status'=>function($q){
                            $q->select('id','user_id','status','date_time')->latest();
                            //->whereRaw('id IN (select MAX(id) from user_app_statuses GROUP BY user_id)');
                        }])->where('app_id',$app->id)->latest();
                        if (isset($input['pagination']) && $input['pagination'] != "") {
                            $this->paginate = true;
                            $user = $user->paginate($this->noOfRecordPerPage);
                        } else {
                            $user_id = $input['user_id'];
                            $user = $user->find($user_id);
                        }
                        break;
                }

//                if($app->app_type == 'whitelabel'){
//                    $user =  User::search($value)->with(['devices','apps','userDetails'])->where('app_id',$app->id)->latest();
//                }
//                elseif($app->app_type == 'webapp'){
//                    $user = WebappUser::search($value)->with(['emergency','user_status'=>function($q){
//                        $q->select('id','user_id','status','date_time')->latest();
//                        //->whereRaw('id IN (select MAX(id) from user_app_statuses GROUP BY user_id)');
//                    }])->where('app_id',$app->id)->latest();
//                }
//                elseif($app->app_type == 'sdk'){
//                    $user = Guest::search($value)->where('app_id',$app->id)->latest();
//                }
//                elseif($app->app_type == 'whitelabel-webapp'){
//                    $user = VetCareUser::search($value)->with(['emergency','user_status'=>function($q){
//                        $q->select('id','user_id','status','date_time')->latest();
//                        //->whereRaw('id IN (select MAX(id) from user_app_statuses GROUP BY user_id)');
//                    }])->where('app_id',$app->id)->latest();
//                }

            }
            elseif($key != '' && $email == ''){
                    $model1 = User::whereHas('apps',function($q) use ($key){
                        $q->select('id','name')->where('name',$key);
                    })->latest()->get();

                    $model2 = WebappUser::whereHas('apps',function($q) use ($key){
                        $q->select('id','name')->where('name',$key);
                    })->with(['user_status'=>function($q){
                    $q->select('id','user_id','status','date_time')->latest();
                        //->whereRaw('id IN (select MAX(id) from user_app_statuses GROUP BY user_id)');
                    }])->latest()->get();

                    $user = $model1->merge($model2);
                    $user->values()->all();
                    if (isset($input['pagination']) && $input['pagination'] != "") {
                        $this->paginate = true;
                        $user = $this->customPaginate($user,$this->noOfRecordPerPage);
                    }
                }
            elseif($email != ''){
                $check_app_type = $this->findAppByName($key);
                $email = htmlentities($email);
                $model1 = User::whereHas('apps',function($q) use ($key){
                    $q->select('id','name')->where('name',$key);
                });
                $model2 = WebappUser::whereHas('apps',function($q) use ($key){
                    $q->select('id','name')->where('name',$key);
                })->with(['user_status'=>function($q){
                    $q->select('id','user_id','status');
                    //->whereRaw('id IN (select MAX(id) from user_app_statuses GROUP BY user_id)');
                }]);
                if($check_app_type->app_type == 'whitelabel'){
                    $model1
                        ->where('email','LIKE',$email)
                        ->orWhere('first_name','LIKE','%'.$email.'%')
                        ->orWhere('last_name','LIKE','%'.$email.'%');
                        //->where('email',$email);
                }
                elseif($check_app_type->app_type == 'webapp'){
                   $model2
                        ->where('email','LIKE',$email)
                        ->orWhere('first_name','LIKE','%'.$email)
                        ->orWhere('last_name','LIKE',$email.'%');
                }
                $model1 = $model1->latest()->get();
                $model2 = $model2->latest()->get();
                $user = $model1->merge($model2);
                $user->values()->all();
                if (isset($input['pagination']) && $input['pagination'] != "") {
                    $this->paginate = true;
                    $user = $this->customPaginate($user,$this->noOfRecordPerPage);
                    $user->values();
                }
            }
            else{
                $model1 = User::search($value)->latest();
                $model2 = WebappUser::search($value)->latest();
                //$user = $model1->merge($model2);
                //$user->values()->all();
                if (isset($input['pagination']) && $input['pagination'] != "") {
                    $this->paginate = true;
                    $model1 = $model1->get();
                    $model2 = $model2->get();
                    $user = $model1->merge($model2);
                    $user = $this->customPaginate($user,$this->noOfRecordPerPage);
                }
            }
            return $this->successResponse($user, 'Successfully Get User Details.',$this->paginate);
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    public function getWhitelableUsersList(Request $request)
    {
        $input = $request->only('search_value', 'search_by', 'page', 'pagination', 'perPage', 'user_id','app_name','key','email');
        $app_name = isset($input['app_name'])?$input['app_name']:'';
        $value = isset($input['search_value'])?$input['search_value']:'';
        $key = isset($input['key'])?$input['key']:'';
        $email = isset($input['email'])?$input['email']:'';
        try{
            $user =  User::with(['devices','apps','userDetails']);
            if($app_name != ''){
                $app = $this->findAppByName($input['app_name']);
                if($app->app_type == 'whitelabel'){
                    $user =  $user->where('app_id',$app->id)->latest();
                }
            }
            elseif ($value != ''){
                $user =  $user->search($value)->latest();
            }
            if (isset($input['pagination']) && $input['pagination'] != "") {
                $this->paginate = true;
                $user = $user->paginate($this->noOfRecordPerPage);
            } else {
                $user_id = $input['user_id'];
                $user = $user->find($user_id);
            }
            return $this->successResponse($user, 'Successfully Get User Details.',$this->paginate);
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    public function getAllUserData(Request $request)
    {
        $input = $request->only('search_value', 'search_by', 'page', 'pagination', 'perPage', 'user_id','app_name','type','email','status','date_from','date_to','selectedProtect','is_subscribe_chk');
        $app_name = isset($input['app_name'])?$input['app_name']:'';
        $is_subscribe_chk = (isset($input['is_subscribe_chk']) && $input['is_subscribe_chk'] == 1) ? 1 : 0;
        $value = isset($input['search_value'])?$input['search_value']:'';
        $type = isset($input['type'])?$input['type']:'';
        $email = isset($input['email'])?$input['email']:'';
        $status = isset($input['status'])?$input['status']:'';
        $selectedProtect = isset($input['selectedProtect'])?$input['selectedProtect']:'';
        try{
            switch ($type){
                case 'whitelabel':
                    $user =  User::with(['devices','apps','userDetails','coupon_usage.coupon']);
                    $user = $user->whereHas('apps', function ($q) {
                        $q->where('app_type','whitelabel');
                    });

                    if (!$is_subscribe_chk) {
                        $user = $user->whereRaw('(SELECT "subscribed" FROM package_usages WHERE user_id = users.id ORDER BY id DESC LIMIT 1) = "subscribed"');
                    }


                    if($selectedProtect != '' && $selectedProtect == 'protect_users'){
                        $user = $user->whereRaw('(SELECT "protect_users" FROM model_has_roles WHERE role_id = "5" AND model_type = "App\\\User" AND model_id = users.id ORDER BY id DESC LIMIT 1) = "'. $selectedProtect . '"');
                    } elseif($selectedProtect != '' && $selectedProtect == 'users'){
                        $user = $user->whereRaw('(SELECT "users" FROM model_has_roles WHERE role_id = "4" AND model_type = "App\\\User" AND model_id = users.id ORDER BY id DESC LIMIT 1) = "'. $selectedProtect . '"');
                    }

//                    if ($request->has('date_from') && $request->has('date_to')) {
//                        $user = $user->whereBetween('created_at',
//                            [$input['date_from'] . " 00:00:00", $input['date_to'] . " 23:59:00"]
//                        );
//                    }
                    if ($request->has('date_from') && $request->has('date_to')) {
                        $date_from = date('Y-m-d', strtotime($input['date_from']));
                        $date_to = date('Y-m-d', strtotime($input['date_to']));
                        if ($is_subscribe_chk) {
                            $date_from = $date_from.' 00:00:00';
                            $date_to = $date_to.' 23:59:59';
                            $user = $user->whereRaw('(SELECT "subscribed" FROM package_usages WHERE user_id = users.id AND deleted_at <> "" AND created_at BETWEEN "'. $date_from . '"  AND "' . $date_to . '" ORDER BY id DESC LIMIT 1) = "subscribed"');

                        } else {
                            $user = $user->whereBetween('created_at',
                                [$input['date_from'] . " 00:00:00", $input['date_to'] . " 23:59:59"]
                            );
                        }
                    } else {
                        if ($is_subscribe_chk) {
                            $user = $user->whereRaw('(SELECT status FROM user_app_statuses WHERE user_id = webapp_users.id ORDER BY id DESC LIMIT 1) = "subscribed"');
                        }
                    }

                    $user = $user->latest();
                    break;
                case 'webapp':
                    $user =  WebappUser::with(['emergency','apps','user_status']);

                    if ($request->has('status')) {
                        $user = $user->whereRaw('(SELECT status FROM user_app_statuses WHERE user_id = webapp_users.id ORDER BY id DESC LIMIT 1) = "'. $request->status .'"');
                    } else {
                        if (!$is_subscribe_chk) {
                            $user = $user->whereRaw('(SELECT status FROM user_app_statuses WHERE user_id = webapp_users.id ORDER BY id DESC LIMIT 1) IN ("cancelled", "subscribed", "upgrade")');
                        }
                    }

                    if($selectedProtect != ''){
//                        $user->whereHas('emergency', function($q) use ($selectedProtect){
//                            $q = $q->where('protected',$selectedProtect);
//                        });
                        $user = $user->whereRaw('(SELECT protected FROM webapps_users_extra WHERE user_id = webapp_users.id ORDER BY id DESC LIMIT 1) = "'. $selectedProtect . '"');
                    }

                    if ($request->has('date_from') && $request->has('date_to')) {
                        $date_from = date('Y-m-d', strtotime($input['date_from']));
                        $date_to = date('Y-m-d', strtotime($input['date_to']));
                        if ($is_subscribe_chk) {
                            $date_from = $date_from.' 00:00:00';
                            $date_to = $date_to.' 23:59:59';
                            $user = $user->whereRaw('(SELECT status FROM user_app_statuses WHERE user_id = webapp_users.id AND created_at BETWEEN "'. $date_from . '"  AND "' . $date_to . '" ORDER BY id DESC LIMIT 1) = "subscribed"');

                        } else {
                            $user = $user->whereBetween('your_registration_date',
                                [$input['date_from'] . " 00:00:00", $input['date_to'] . " 23:59:59"]
                            );
                        }
                    } else {
                        if ($is_subscribe_chk) {
                            $user = $user->whereRaw('(SELECT status FROM user_app_statuses WHERE user_id = webapp_users.id ORDER BY id DESC LIMIT 1) = "subscribed"');
                        }
                    }

                    $user = $user->latest();
                    break;
                case 'sdk':
                    $user =  Guest::with(['devices','apps']);
                    if ($request->has('date_from') && $request->has('date_to')) {
                        $user = $user->whereBetween('created_at',
                            [$input['date_from'] . " 00:00:00", $input['date_to'] . " 23:59:00"]
                        );
                    }
                    break;
            }
           // $user =  WebappUser::with(['emergency','apps']);
            if ($value != ''){
                $user =  $user->where(function ($query) use ($value) {
                    $query->where('first_name', 'LIKE', '%' . $value . '%')
                        ->orWhere('last_name', 'LIKE', '%' . $value . '%')
                        ->orWhere('email', 'LIKE', '%' . $value . '%');
                });
//                $user =  $user->search($value);
//                $user = $this->SearchFullNameWithSpaces($user,$value);
                $user = $user->latest();
            }

            if($app_name != ''){
                $app = $this->findAppByName($input['app_name']);
                $user =  $user->where('app_id',$app->id)->latest();
            }

//            get_sql($user);

            if (isset($input['pagination']) && $input['pagination'] != "") {
                $this->paginate = true;
                $user = $user->paginate($this->noOfRecordPerPage);
            } else {

                $user = $user->get();

            }

            return $this->successResponse($user, 'Successfully Get User Details.',$this->paginate);
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    public function getSdkUsersList(Request $request)
    {
        $input = $request->only('search_value', 'search_by', 'page', 'pagination', 'perPage', 'user_id','app_name','key','email');
        $app_name = isset($input['app_name'])?$input['app_name']:'';
        $value = isset($input['search_value'])?$input['search_value']:'';
        $key = isset($input['key'])?$input['key']:'';
        $email = isset($input['email'])?$input['email']:'';
        try{
            $user =  Guest::with(['devices','apps','userDetails']);
            if($app_name != ''){
                $app = $this->findAppByName($input['app_name']);
                if($app->app_type == 'whitelabel'){
                    $user =  $user->where('app_id',$app->id)->latest();
                }
            }
            elseif ($value != ''){
                $user =  $user->search($value)->latest();
            }
            if (isset($input['pagination']) && $input['pagination'] != "") {
                $this->paginate = true;
                $user = $user->paginate($this->noOfRecordPerPage);
            } else {
                $user_id = $input['user_id'];
                $user = $user->find($user_id);
            }
            return $this->successResponse($user, 'Successfully Get User Details.',$this->paginate);
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    public function getProtectUserList(Request $request)
    {
        $input = $request->only('search_value', 'search_by', 'page', 'pagination', 'perPage', 'user_id');
        //dd($input);
        try{
            if (isset($input['pagination']) && $input['pagination'] != "") {
                $this->paginate = true;
                $user = User::role('protect users')->paginate($this->noOfRecordPerPage);
            } else {
                $user_id = $input['user_id'];
                $user = User::role('protect users')->find($user_id);
            }
            return $this->successResponse($user, 'Successfully Get Protect User Details.',$this->paginate);
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    public function getPetList(GetPetListRequest $request){
        $validatedData = $request->validated();
        $input = $request->only('search_value', 'search_by', 'page', 'pagination', 'perPage', 'pet_id','app_type');
        $app_type = isset($input['app_type'])?$input['app_type']:'';
        try{
            // $app = $this->findAppByName($input['app_name']);

            if($app_type != ''){
                switch ($app_type){
                    case 'whitelabel': case 'sdk':
                        $model = new Pet();
                        break;
                    case 'webapp':
                        $model = new ExtraPet();
                        break;
                    }

                    //            if (isset($input['search_by']) && $input['search_by'] != "" && isset($input['search_value']) && $input['search_value'] != "" ) {
                        //                $model = $model->where($input['search_by'],$input['search_value']);
                        //            }
                        $value = $input['search_value'];
                        //$term = $input['search_by'];
                        if ($request->has('search')) {
                            $model = $model::latest()->search($value)
                                ->orWhereHas('petInsurnaces', function ($query) use ($value){
                                //$query->whereRaw('*', 'like', '%'.$value.'%');
                                $query->search($value);
                            })->orWhereHas('petMedicals', function ($query) use ($value){
                                //$query->whereRaw('*', 'like', '%'.$value.'%');
                                $query->search($value);
                            })->orWhereHas('petVeterians', function ($query) use ($value){
                                $query->search($value);
                                //$query->search($value);
                            });
                            //$model = $model->whereHas('petInsurnaces')->whereHas('petMedicals')->whereHas('petVeterians')->search($value);
                        }
                      //dd($model);
                      if (isset($input['pagination']) && $input['pagination'] != "") {
                        $this->paginate = true;
                        $pet = $model->paginate($this->noOfRecordPerPage);
                    } else {
                        $pet_id = $input['pet_id'];
                        $pet = $model->where('id',$pet_id)->get();
                    }
                    $pet = PetListResource::collection($pet);
                    return $this->successResponse($pet, 'Pet Details.',$this->paginate);
            }


        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    public function getVetAuthenticationtHistory(Request $request)
    {
        $input = $request->only('search_value', 'search_by', 'page', 'pagination', 'perPage', 'vet_id', 'date_from', 'date_to');
        $value = isset($input['search_value'])?$input['search_value']:'';
        try{

            $model = new AuthenticationHistory();

            if ($request->has('date_from') && $request->has('date_to')) {
                $model = $model->whereBetween('created_at',
                    [$input['date_from'] . " 00:00:00", $input['date_to'] . " 23:59:00"]
                );
            }

            $user = $model->with(['vet'=>function($q){
                $q->with('devicesThrashed');
            }])->whereHas('vet', function ($q) use ($value) {
                $q->where('email',$value);
                $q = $this->SearchFullNameWithSpaces($q,$value);
            })->latest();
            if (isset($input['pagination']) && $input['pagination'] != "") {
                $this->paginate = true;
                $user = $user->paginate($this->noOfRecordPerPage);
            } else {
//                $vet_id = $input['vet_id'];
//                $user = $user->find($vet_id);
                $user = $user->get();
            }
            return $this->successResponse($user, 'Successfully Get Doctor Logout History Details.',$this->paginate);
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    public function vetDeleted($id, VetRequest $request)
    {
        try {
            $vet = Vet::role('vets')->findOrfail($id);
            $vet->delete();

            $data = array(
                "vet" => $vet
            );
            return $this->successResponse($data, 'Successfully Record Deleted.');
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    public function petDeleted($id)
    {
        try {
            $pet = Pet::findOrfail($id);
            $pet->delete();

            $data = array(
                "pet" => $pet
            );
            return $this->successResponse($data, 'Successfully Record Deleted.');
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    public function userUpdate($id, FeatureUserRequest $request)
    {
        $validatedData = $request->validated();
        try {
            $model = $this->find_app($request->api_key);
            if($model->app_type === 'vets'){
                $user = Vet::findOrfail($id);

                if($request->status == 0){
                    $user->removeRole('vets');
                }
                if($request->status == 1){
                    $user->assignRole('vets');
                }
            }
            else{
                $user = User::findOrfail($id);
                if($request->status == 0){
                    $user->removeRole('users');
                }
                if($request->status == 1){
                    $user->assignRole('users');
                }
            }
            unset($validatedData['status']);
            $user->update($validatedData);
            $data = array(
                "user" => $user
            );
            return $this->successResponse($data, 'Successfully Record Updated.');
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    public function userDeleted($id,Request $request)
    {
        try {
            $model = $this->find_app($request->api_key);
            if($model->app_type === 'vets'){
                $user = Vet::findOrfail($id);
            }else if($model->app_type === 'whitelabel-webapp'){
                $user = VetCareUser::findOrfail($id);
                if($user){
                    if(!empty($user->stripe_id)){
                        $this->init($user->app_id);
                        $this->deleteCustomer($user->stripe_id);
                    }
                }
            }
            else{
                $user = User::findOrfail($id);
                if($user){
                    if(!empty($user->stripe_id)){
                        $this->init($user->app_id);
                        $this->deleteCustomer($user->stripe_id);
                    }
                }
//                $data = Subscriptions::where('user_id',$user->id)->first();
//                if(isset($data)){
//                    $this->unsubscribe($data->subscription_id);
//                }

            }
            $user->delete();
            $data = array(
                "user" => $user
            );
            return $this->successResponse($data, 'Successfully Record Deleted.');
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    public function getFailedHandshakes(Request $request)
    {
        $input = $request->only('search_value', 'search_by', 'page', 'pagination', 'perPage', 'room_sid','chat_id','app_id');
        try {
            $data = FailedHandshake::with('apps')->latest();
            if($request->has('app_id') && !empty($request->app_id)){
                $data = $data->where('app_id', $request->app_id);
            }
            if (isset($input['pagination']) && $input['pagination'] != "") {
                if(isset($input['search_value']) && $input['search_value'] != ""){
                    $data->search($input['search_value']);
                }
                $this->paginate = true;
                $data = $data->paginate($this->noOfRecordPerPage);
            } else {
                $vet_id = $input['vet_id'];
                $vet_data = $vet_data->find($vet_id);
            }
            return $this->successResponse($data, 'Failed handshakes',$this->paginate);
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    public function updateAndGetProtectClientNotes(ProtectClientAdminRequest $request,$id){
        $validated = $request->validated();
//        $validated['user_id'] = $id;
        try{
            $emergencyVetClient=EmergencyVetClient::find($id);
            if(!$emergencyVetClient){
                return $this->errorResponse('No record found', 404);
            }
            $validated['emergency_id'] = $id;
            if($request->hasFile('attachment')){
                $temp = array();
                if(is_array($request->attachment)){
                    foreach ($request->attachment as $file) {
                        $temp[] = $this->uploadFileProtectRepo($file,'protect_attachments','app_'.$validated['app_id'].'-user_'.$id);

                    }
                }
                else{
                    $temp[] = $this->uploadFileProtectRepo($request->attachment,'protect_attachments','app_'.$validated['app_id'].'-user_'.$id);
                }
                $validated['attachment'] = $temp;
            }

//            $data = NoteProectUser::updateOrCreate(['user_id'=>$validated['user_id']],$validated);
            if ($request->isMethod('post')){
                $paid_by = isset($validated['paid_by']) &&  !empty($validated['paid_by']) ? $validated['paid_by'] : '';
                $emergencyVetClient->update(['status'=> $validated['paid']]);
                $validated['paid_by'] = $paid_by;
                $data = NoteProectUser::create($validated);
            }
            $response = NoteProectUser::where('emergency_id',$id)->latest()->first();

            return $this->successResponse($response, 'Notes data');
        }
        catch (\Exception $exception){
            return $this->errorResponse($exception->getMessage(), $exception->getCode());

        }
    }

    public function updateAndGetProtectClientFlag(ProtectClientAdminRequest $request,$id){
        $validated = $request->validated();
        try{
            $validated['emergency_id'] = $id;
            if ($request->isMethod('post')){
                $data = FlagProtectUser::create($validated);
            }
            $response = FlagProtectUser::where('emergency_id',$id)->get();
            return $this->successResponse($response, 'Flag data');
        }
        catch (\Exception $exception){
            return $this->errorResponse($exception->getMessage(), $exception->getCode());

        }
    }

    public function pdfview(Request $request,$id)
    {
        view()->share('items',$request->all());
        if($request->has('download')){
            $pdf = (new \Barryvdh\DomPDF\PDF)->loadView('pdfview');
            return $pdf->download('pdfview.pdf');
        }

        return view('protectClientPdfView');
    }

    public function getPetListByUser($id,Request $request){
        try{
            $app = $this->findAppById($request->app_id);
            switch ($app->app_type){
                case 'whitelabel':
                    $model = Pet::where('user_id',$id)->get();
                    break;
                case 'webapp':
                    $model = ExtraPet::where('user_id',$id)->get();
                    break;
                case 'sdk':
                    $model = GuestPet::where('user_id',$id)->get();
                    break;
            }
//
            return $this->successResponse($model, 'Pet Details.');
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    ########################## VetCare ##########################
    public function getClinicsList(Request $request){
        try{
            $clinicUsers = new VetCare;
            $clinicUsers = $clinicUsers->with('app');
            if($request->has('new') and $request->new == true){
                $clinicUsers = $clinicUsers->whereDoesntHave('app.appSettings');
            }

            $value = isset($input['search_value'])?$input['search_value']:'';

            if($request->has('search_value') && !empty($request->search_value)){
                $clinicUsers = $clinicUsers->where('clinic_name','LIKE','%'.$request->search_value.'%')
                ->orWhere('name','LIKE','%'.$request->search_value.'%');

            }

            if($request->has('id') && !empty($request->id)){
                $clinicUsers = $clinicUsers->where('id',$request->id);
                $clinicUsers =  $clinicUsers->get();
            }else{
                if($request->has('pagination') & !empty($request->pagination))
                {
                    $clinicUsers =  $clinicUsers->paginate(10);
                }else{
                    $clinicUsers =  $clinicUsers->get();
                }
            }
            return $this->successResponse($clinicUsers, 'Clinic List');
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }


    public function getStaffList(Request $request)
    {
        $input = $request->only('search_value', 'search_by', 'page', 'pagination', 'perPage', 'sub_admin_id');
        $value = isset($input['search_value'])?$input['search_value']:'';

        try{
            $sub_admin = SubAdmin::role('staff')->with(['AuthenticationHistory']);
            if ($value != ''){
                $sub_admin = $this->SearchFullNameWithSpaces($sub_admin,$value,'where')
                ->orwhere('email','like', $value);
                $sub_admin =  $sub_admin->latest();
            }
            if (isset($input['pagination']) && $input['pagination'] != "") {
                $this->paginate = true;
                $sub_admin = $sub_admin->paginate($this->noOfRecordPerPage);
            } else {
                $sub_admin_id = $input['sub_admin_id'];
                $sub_admin = $sub_admin->find($sub_admin_id);
            }
            return $this->successResponse($sub_admin, 'Successfully Get Vet Details.',$this->paginate);
        } catch (\Exception $e) {

            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    public function deleteVetCarepet(Request $request)
    {
        $input = $request->only('id');

        try {
            $pet = VetCarePet::findOrfail($input['id']);
            $defaultPet = VetCareUser::with(['defaultPet'])->where('id',$pet->user_id)->first();
            if($defaultPet->defaultPet[0]->pivot->pet_id == $input['id']){
                return $this->errorResponse("Cannot Delete Default pet",403);
            }else{
                $pet->delete();
                $data = array(
                    "pet" => $pet
                );
                return $this->successResponse($data, 'Successfully Record Deleted.');
            }

        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

}
