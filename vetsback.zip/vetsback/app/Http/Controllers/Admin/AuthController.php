<?php

namespace App\Http\Controllers\Admin;

use App\Http\Requests\AdminUserRequest;
use App\Traits\OtherTwilioSDKTrait;
use App\Traits\TwilioSDKTrait;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use JWTAuth;
use Mockery\Exception;
use stdClass;
use App\Vet;
use App\SubAdmin;


class AuthController extends Controller
{
    use TwilioSDKTrait;
    use OtherTwilioSDKTrait;
    protected $user;

    public function __construct()
    {
        $this->generic();
        $this->construct();
    }
    //
    /**
     * login API
     *
     * @return \Illuminate\Http\Response
     */
    public function login(AdminUserRequest $request)
    {
        $this->slackLog('admin login','info');
        $data = $request->validated();
        // credentials
        $credentials = $request->only(['email', 'password']);
        $dev_type = $request->dev_type;

        try {
            if($request->is_sub_admin === true || $request->is_sub_admin === 'true'){
                if ($token = auth('staff')->attempt($credentials)) {
                    $this->user = auth('staff')->user();
                    if ($this->user->hasRole('staff')) {
                        $this->user->update(['is_online'=>1]);
                        //Response
                        $success['token'] = $token;
                        // Hard coding 1 for staff and admin for now
                        $success['twilioToken'] = $this->init('staff-'.$this->user->id, $dev_type, 1);
                        //$success['pawpTwilioToken'] = $this->accessToken('staff-'.$this->user->id);
                        $success['admin'] = $this->user;
                        $dateTime =  Carbon::now(); //current date time
                        $this->user->AuthenticationHistory()->create([
                            'dateTime' => $dateTime,
                            'type' => 'login'
                        ]);

                        if($dev_type == 'android' || $dev_type == 'ios' || $dev_type == 'web'){
                            //Update or create new device
                            $device = $this->user->devices()->where(['rec_id'=>$this->user->id])->first();

                            if (isset($device) && !empty($device)) {
                                $device->update([
                                    'device_token'=>$request->device_token,
                                    'udid'=>$request->udid,
                                    'dev_type'=>$request->dev_type,
                                    'app_version'=>$request->app_version,
                                ]);
                            }
                            else {
                                $this->user->devices()->create([
                                    'rec_id'=>$this->user->id,
                                    'device_token'=>$request->device_token,
                                    'udid'=>$request->udid,
                                    'dev_type'=>$request->dev_type,
                                    'app_version'=>$request->app_version,
                                ]);
                            }
                        }
                         //Add staff id to staff queues table
                        $this->user->queue()->updateOrCreate(['staff_id'=>$this->user->id],['staff_id'=>$this->user->id,'status'=>false]);
                        return $this->successResponse($success, 'logged in');
                    }
                    else{
                        return $this->errorResponse('You dont have right to access. Contact admin');
                    }
                }
                else {
                    return $this->errorResponse('Wrong credentials or missing access rights to application.');
                }
            }
            else{
                if ($token = $this->guard()->attempt($credentials)) {
                    $this->user = $this->guard()->user();
                    if ($this->user->hasRole(['super admin', 'admin'])) {
                        $this->user->update(['is_online'=>1]);

                        $dev_type = $request->dev_type;

                        if($dev_type == 'android' || $dev_type == 'ios' || $dev_type == 'web'){
                            //Update or create new device
                            $device = $this->user->devices()->where(['rec_id'=>$this->user->id])->first();

                            if (isset($device) && !empty($device)) {
                                $device->update([
                                    'device_token'=>$request->device_token,
                                    'udid'=>$request->udid,
                                    'dev_type'=>$request->dev_type,
                                    'app_version'=>$request->app_version,
                                ]);
                            }
                            else {
                                $this->user->devices()->create([
                                    'rec_id'=>$this->user->id,
                                    'device_token'=>$request->device_token,
                                    'udid'=>$request->udid,
                                    'dev_type'=>$request->dev_type,
                                    'app_version'=>$request->app_version,
                                ]);
                            }
                        }
                        
                        //Response
                        $success['token'] = $token;
                        // Hard coding 1 for staff and admin for now
                        $success['twilioToken'] = $this->init('admin-'.$this->user->id, $dev_type, 1);
                        $success['twilio-admin-3'] = $this->init('admin-3');
                        $success['admin'] = $this->user;
                        return $this->successResponse($success, 'logged in');
                    }
                    else{
                        return $this->errorResponse('Wrong credentials or missing access rights to application.');
                    }
                }
                else {
                    return $this->errorResponse('Wrong credentials or missing access rights to application.');
                }
            }
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }
    /**
     * Logout user (Revoke the token)
     *
     * @return [string] message
     */
    public function logout(Request $request)
    {
        if(auth()->guard('staff')->user()){
            $user = $request->user('staff');
            $data = array(
                'is_online'=>0,
                'is_call'=>0
            );
            $user->devices()->delete();
            $user->queue()->delete();
            $user->update($data);

        }
        if(auth()->guard('vets')->user()){
            $user = $request->user('vets');
        }
        $user->update(['is_online'=> 0]);
        if ($user->hasRole('vets')) {
            $dateTime =  Carbon::now();
            $user->vetAuthenticationHistory()->create([
                'dateTime' => $dateTime,
                'type' => 'logout'
            ]);
        }
        if ($user->hasRole('staff')) {
            $dateTime =  Carbon::now();
            $user->AuthenticationHistory()->create([
                'dateTime' => $dateTime,
                'type' => 'logout'
            ]);
        }
        $this->guard()->logout();
        return $this->successResponse([], 'Successfully logged out');
    }

    /**
     * Refresh a token.
     *
     */
    public function refresh()
    {
        return $this->respondWithToken($this->guard()->refresh());
    }

    /**
     * Get the token array structure.
     *
     * @param string $token
     *
     * @return \Illuminate\Http\Response
     */
    protected function respondWithToken($token)
    {
        $a = [
            'access_token' => $token,
            'token_type' => 'bearer',
            'expires_in' => $this->guard()->factory()->getTTL() * 60
        ];

        return $this->successResponse($a, 'user data');
    }

    /**
     * Get the guard to be used during authentication.
     *
     * @return \Illuminate\Contracts\Auth\Guard
     */
    public function guard()
    {
        return Auth::guard('vets');
    }

    /**
     * Get the authenticated User.
     *
     */
    public function profile()
    {
        try {
            return $this->successResponse($this->guard()->user(), 'Successfully Get Profile');
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }
    public function deleteAdminChannels(){
        try {
            $this->deleteOLdChannels();
            return $this->successResponse(true, 'Successfully Removed');
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }

    }
    /**
     * Delete
     * @param Request $request
     * @return \Illuminate\Http\Response
     */
//    public function delete(Request $request){
//
//        try{
//            $id = User::find($request->user_id)->update(['is_block'=>1,'is_online'=>0]);
//
//            return $this->successResponse($id,'success');
//        }catch (\Exception $e){
//            return $this->errorResponse($e->getMessage(),$e->getCode());
//        }
//
//    }

    public function checkOnline(){
        try {
      
        $online_admin=Vet::whereHas('roles',function($q){
            $q->whereIn('name',['admin']);
        })->where('is_online',1)->get();
      
        $online_staff=SubAdmin::where('is_online',1)->get();
      
        $data =[
            'admin'=>$online_admin,
            'staff'=> $online_staff
        ];
        return $this->successResponse($data, 'Data Fetched Successfully');
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }
}
