<?php

namespace App\Http\Controllers\Admin;

use App\App;
use App\VetCare;
use App\AppSetting;
use App\VetCareApp;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use App\Http\Requests\AppRequest;
use App\Http\Controllers\Controller;
use App\Http\Requests\ClinicUserRequest;
use App\Http\Requests\VetCareAppUpdateRequest;

class VetCareAppController extends Controller
{
    private $noOfRecordPerPage = 10;
    private $paginate = false;

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $input = $request->only('search_value', 'search_by', 'page', 'pagination', 'perPage', 'app_id','all');
        $value = isset($input['search_value']) ? $input['search_value'] : '';
        try{
            $model = new App();
            $model = $model->where('app_type' , 'whitelabel-webapp');
            if(isset($value) && !empty($value)){
                $model = $model->where('name','Like','%'.$value.'%');
            }

            if (isset($input['pagination']) && $input['pagination'] != "") {
                $this->paginate = true;
                $app = $model->paginate($this->noOfRecordPerPage);
            }
            else if(isset($input['all']) && $input['all'] != "") {
                $app = $model->all();
            }
            else {
                $app_id = $input['app_id'];
                $app = $model->find($app_id);
            }
            $data = array(
                "app" => $app
            );
            return $this->successResponse($data['app'], 'Successfully Fetch List of VetCare Apps.', $this->paginate);
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }    }

    /**
     * Show the form for creating a new resource.
     *
     * @param AppRequest $request
     * @return \Illuminate\Http\Response
     */
    public function create(AppRequest $request)
    {
        $validatedData = $request->validated();
        $appSettingData = $request->only('primary_color','secondary_color','logo','fav_icon','title','emergency_fund','is_payment_required','faqs','zipcode_validation','is_suspended','extra_image','background_image');
        $this->user = auth()->user();
        try {
            $validatedData['api_key'] = $api_key_gen = Str::random(16);
            $validatedData['app_type'] = 'whitelabel-webapp';
            $send_email_on =isset($request->send_email_on) && !empty($request->send_email_on) ? $request->send_email_on :NULL;
            $validatedData['send_email_on'] = isset($request->send_chat_on_email) && $request->send_chat_on_email == true ? $send_email_on : NULL;
            $clinic = VetCare::find($request->clinic_id);
            $app = $clinic->app();
            $app = $app->create($validatedData);

            // App Settings
            if($request->hasFile('logo')) {
                $appSettingData['logo'] = $this->uploadFilePublicRepo($request->logo, 's3','vet_care_app');
            }
            // Extra Logo
            if($request->hasFile('extra_image')) {
                $appSettingData['extra_image'] = $this->uploadFilePublicRepo($request->extra_image, 's3','vet_care_app');
            }
            //background image
            if($request->hasFile('background_image')) {
                $appSettingData['background_image'] = $this->uploadFilePublicRepo($request->background_image, 's3','vet_care_app');
            }
            if($request->hasFile('fav_icon')) {
                $appSettingData['fav_icon'] = $this->uploadFilePublicRepo($request->fav_icon, 's3','vet_care_app');
            }
            $appSettingData['faqs'] = (isset($appSettingData['faqs']) && ($appSettingData['faqs'] != null))  ?  json_encode($appSettingData['faqs']) : '';
            $appSettingData['other'] = (isset($validatedData['other']) && ($validatedData['other'] != null))  ?  $validatedData['other'] : '';
            $appSettingData['app_id'] = $app->id;
            $appSettingData['clinic_id'] = $clinic->id;
            $app->appSettings()->create($appSettingData);
            return $this->successResponse($app, 'Successfully Created App.');
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }


    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(VetCareAppUpdateRequest $request, $id)
    {
        $appSettingData = $request->except('name','send_chat_on_email','send_email_on');

        try {
            $app = App::findOrfail($id);
            $send_email_on =isset($request['send_email_on']) && !empty($request['send_email_on']) ? $request['send_email_on'] :NULL;
            $request['send_email_on'] = isset($request['send_chat_on_email']) && $request['send_chat_on_email'] == true ? $send_email_on : NULL;

            if((isset($request['name']) && $request['name'] !=null) || (isset($request['send_chat_on_email']) && $request['send_chat_on_email'] !=null) || (isset($request['send_email_on']) && $request['send_email_on'] !=null) ){
                $app->update($request->only('name','is_suspended','send_chat_on_email','send_email_on'));
            }

            // App setting update
            $appSettingData['faqs'] = (isset($appSettingData['faqs']) && ($appSettingData['faqs'] != null))  ?  json_encode($appSettingData['faqs']) : $app->appSettings->faqs;
            $appSettingData['other'] = (isset($appSettingData['other']) && ($appSettingData['other'] != null))  ?  ($appSettingData['other']) : '';
            $appSettingData['logo'] = ($request->hasFile('logo'))  ?  $this->uploadFilePublicRepo($appSettingData['logo'], 's3','vet_care_app') : $app->appSettings->logo;
            $appSettingData['extra_image'] = ($request->hasFile('extra_image'))  ?  $this->uploadFilePublicRepo($appSettingData['extra_image'], 's3','vet_care_app') : null;
            $appSettingData['background_image'] = ($request->hasFile('background_image'))  ?  $this->uploadFilePublicRepo($appSettingData['background_image'], 's3','vet_care_app') : null;
            $appSettingData['fav_icon'] = ($request->hasFile('fav_icon'))  ?  $this->uploadFilePublicRepo($appSettingData['fav_icon'], 's3','vet_care_app') : $app->appSettings->fav_icon;
            $app->appSettings()->update($appSettingData);

            $updatedApp = App::findOrfail($id);

            $data = array(
                "app" => $updatedApp
            );
            return $this->successResponse($data, 'Successfully Record Updated.');
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    public function clinicSignup(ClinicUserRequest $request){

        $validated = $request->validated();
        try{
            if(array_key_exists('password',$validated)){
                $validated['password'] = bcrypt($validated['password']);
            }
            $data = VetCare::create($validated);
            $success['token'] = auth()->login($data);
            $success['user'] = $data;
            return $this->successResponse($success, 'Success');

        }
        catch (\Exception $exception){
            return $this->errorResponse($exception->getMessage(), $exception->getCode());

        }

    }

    public function clinicUpdate($id, Request $request){

        $validated = $request->only('name','clinic_name','phone_no','address','other');
        try{
            $clinic = VetCare::findOrfail($id);
            $data = $clinic->update($validated);
            return $this->successResponse($clinic, 'Success');
        }
        catch (\Exception $exception){
            return $this->errorResponse($exception->getMessage(), $exception->getCode());

        }

    }
}
