<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\UserRequest;
use Carbon\Carbon;
use Validator;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use JWTAuth;
use App\User;

class UserController extends Controller
{
    
    public function update($id, UserRequest $request)
    {
        $validatedData = $request->validated();
        try {
            $user = User::findOrfail($id);
            if($request->status == 0){
                $user->removeRole('users');
            }
            if($request->status == 1){
                $user->assignRole('users');
            }
            $user->update($validatedData);
            $data = array(
                "user" => $user
            );
            return $this->successResponse($data, 'Successfully Record Updated.');
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }
    public function deleted($id)
    {
        try {
            $user = User::findOrfail($id);
            $user->delete();
            $data = array(
                "user" => $user
            );
            return $this->successResponse($data, 'Successfully Record Deleted.');
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }


}
