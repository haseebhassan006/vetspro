<?php

namespace App\Http\Controllers\Admin;

use App\Vet;
use App\Chat;
use Validator;
use App\SubAdmin;
use Carbon\Carbon;
use App\ChatDetail;
use App\ChatEndedBy;
use Illuminate\Http\Request;
use App\Traits\TwilioSDKTrait;
use Aws\Exception\AwsException;
use Illuminate\Support\Facades\DB;
use App\Traits\OtherTwilioSDKTrait;
use Illuminate\Support\Facades\App;
use App\Http\Controllers\Controller;
use Twilio\Exceptions\TwilioException;
use Illuminate\Database\Eloquent\Model;
use App\Http\Resources\ChatArchiveCollection;

class ChatController extends Controller
{
    private $noOfRecordPerPage = 100;
    private $paginate = false;
    use TwilioSDKTrait;
    use OtherTwilioSDKTrait;

    public function __construct()
    {
        $this->generic();
        $this->construct();
    }

    public function index(Request $request){
        $input = $request->only('search_value', 'search_by', 'page', 'pagination', 'perPage', 'channel_sid', 'api_key', 'export', 'date_from', 'date_to','type');
        $value = isset($input['search_value'])?$input['search_value']:'';
        $key = isset($input['api_key']) ?: '';
        $export = @$input['export'];

        //$rec = ChatDetail::select(DB::raw("JSON_OBJECT(attributes)"))->get();
            //->whereRaw('json_contains(attributes, \'["' . $value . '"]\')')->paginate(10);
        $model = new ChatDetail();

        // Protect And Normal User Filter
        if($request->has('type') && !empty($request->type))
        {
//            if($request->type == 'protect_users')
//            {
                // For Protect Users
//                $model = $model->oRwhereRaw("(body) like '%$request->type%' OR (attributes) like '%$request->type%'");
//            }
//            else{
                // For Normal Users
//                $model = $model->orWhereRaw("(body) = '$request->type' OR (attributes) = '$request->type' AND (body) NOT LIKE '%protect_users%' OR (attributes) NOT LIKE ('%protect_users%')");
//                $model = $model->orWhereRaw("(body) like '%$request->type%' OR (attributes) like '%$request->type%' AND (body) NOT LIKE '%protect_users%' OR (attributes) NOT LIKE ('%protect_users%')");
//            }
            $model = $model->whereRaw("(body like '%".htmlspecialchars_decode(htmlspecialchars('"')).$request->type."%' OR attributes like '%".htmlspecialchars_decode(htmlspecialchars('"')).$request->type."%')");

        }



        if(isset($value) && !empty($value)){
            $model = $model->where('attributes', 'like', '%'. $value .'%');
//            $model = $model->whereJsonContains('attributes', [['user' => ['user_id' => $value]]]);
//            $model = $model->search($value);
        }
        if(isset($key) && !empty($key)){
            $find_app = $this->find_app($input['api_key']);
            if(isset($find_app)){
                $currentUri=\Route::getCurrentRoute()->uri;
                if($currentUri == "api/admin/chat/archive/all"){
                    if($find_app->app_type != "whitelabel-webapp" && $find_app->app_type != "vets"){
                        $app_id = $find_app->id;
                        $model = $model->with(['chat'=>function($q) use ($app_id, $request){
                            $q->select('id','vet_id','user_id','channel_sid','app_id')->with('ended_chat');
                        }])->whereHas('chat',function ($q) use ($app_id, $request){
                            $q->where('app_id',$app_id);
//                            if ($request->has('date_from') && $request->has('date_to')) {
//                                $q->whereBetween('created_at',
//                                    [$request->date_from . " 00:00:00", $request->date_to . " 23:59:00"]
//                                );
//                            }
                        })->groupBy('chat_id')->latest();
                    }else{
                        throw new \Exception('Api key is invalid');
                    }

                }
                if($currentUri != "api/admin/chat/archive/all"){
                    if($find_app->app_type == "whitelabel-webapp"){
                        $app_id = $find_app->id;
                        $model = $model->with(['chat'=>function($q) use ($app_id, $request){
                            $q->select('id','vet_id','user_id','channel_sid','app_id')->with('ended_chat');
                        }])->whereHas('chat',function ($q) use ($app_id, $request){
                            $q->where('app_id',$app_id);
//                            if ($request->has('date_from') && $request->has('date_to')) {
//                                $q->whereBetween('created_at',
//                                    [$request->date_from . " 00:00:00", $request->date_to . " 23:59:00"]
//                                );
//                            }
                        })->groupBy('chat_id')->latest();
                    }else{
                        throw new \Exception('Api key is invalid');
                    }
                }
                // if($currentUri == "api/admin/chat/archive/all" && $find_app->app_type != "whitelabel-webapp" && $find_app->app_type != "vets" ){
                //     $app_id = $find_app->id;
                //     $model = $model->with(['chat'=>function($q) use ($app_id){
                //         $q->select('id','vet_id','user_id','channel_sid','app_id')->with('ended_chat');
                //     }])->whereHas('chat',function ($q) use ($app_id){
                //         $q->where('app_id',$app_id);
                //     })->groupBy('chat_id')->latest();
                // }else{
                //     $app_id = $find_app->id;
                //     $model = $model->with(['chat'=>function($q) use ($app_id){
                //         $q->select('id','vet_id','user_id','channel_sid','app_id')->with('ended_chat');
                //     }])->whereHas('chat',function ($q) use ($app_id){
                //         $q->where('app_id',$app_id);
                //     })->groupBy('chat_id')->latest();
                // }

                if ($request->has('date_from') && $request->has('date_to')) {
                    $model = $model->whereBetween('created_at',
                        [$input['date_from'] . " 00:00:00", $input['date_to'] . " 23:59:00"]
                    );
                }
            }
        }
        else{
            $currentUri=\Route::getCurrentRoute()->uri;
            if($currentUri == "api/admin/chat/archive/all"){
                // $model = $model->WhereHas('chat',function($q){
                //     $q->WhereHas('app' , function($query){
                //         $query->where('app_type','!=','whitelabel-webapp');
                //         $query->select('id','name','app_type','api_key','model_type');
                //     });
                //     $q->select('id','vet_id','user_id','channel_sid','app_id')->with('ended_chat');
                // })->groupBy('chat_id')->latest();
                // $model = $model->WhereRaw("(attributes) NOT LIKE ('%VetCareUser%')");

                $model = $model->with(['chat'=>function($q){
                    $q->select('id','vet_id','user_id','channel_sid','app_id')->with('ended_chat');
                },'chat.app:id,name,app_type'])->whereHas('chat.app',function($query) use ($request){
                        $query->where('app_type','!=','whitelabel-webapp');
//                        if ($request->has('date_from') && $request->has('date_to')) {
//                            $query->whereBetween('created_at',
//                                [$request->date_from . " 00:00:00", $request->date_to . " 23:59:00"]
//                            );
//                        }
                })->groupBy('chat_id')->latest();


            }else{
                // $model = $model->WhereRaw("(attributes) LIKE ('%VetCareUser%')");

                // $model = $model->with(['chat'=>function($q){
                //     $q->select('id','vet_id','user_id','channel_sid','app_id')->with('ended_chat');
                // }])->groupBy('chat_id')->latest();


                $model = $model->with(['chat'=>function($q){
                    $q->select('id','vet_id','user_id','channel_sid','app_id')->with('ended_chat');
                },'chat.app:id,name,app_type'])->whereHas('chat.app',function($query) use ($request){
                        $query->where('app_type','=','whitelabel-webapp');
//                        if ($request->has('date_from') && $request->has('date_to')) {
//                            $query->whereBetween('created_at',
//                                [$request->date_from . " 00:00:00", $request->date_to . " 23:59:00"]
//                            );
//                        }
                })->groupBy('chat_id')->latest();

            }

            if ($request->has('date_from') && $request->has('date_to')) {
                $model = $model->whereBetween('created_at',
                    [$input['date_from'] . " 00:00:00", $input['date_to'] . " 23:59:00"]
                );
            }

            // $model = $model->with(['chat'=>function($q){
            //     $q->select('id','vet_id','user_id','channel_sid','app_id')->with('ended_chat');
            // }])->groupBy('chat_id')->latest();
        }
        try{
            $paginator = array();

//            get_sql($model);

            if (isset($input['pagination']) && $input['pagination'] != "") {
                $this->paginate = true;
                $chat = $model->paginate($this->noOfRecordPerPage);
            }
            elseif($export == 'true' || $export == true) {
                $chat = $model->get();
            }
            else {
                $channel = $input['channel_sid'];
                $chat = ChatDetail::with('chat')->whereHas('chat',function($q) use ($channel){
                    $q->where('channel_sid',$channel);
                })->groupBy('chat_id')->get();
            }
            $model = ChatArchiveCollection::collection($chat);

            return $this->successResponse($model, 'Archived chats',$this->paginate);
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    public function fetch(Request $request){
        try{
            $media_sid = $request->media_sid;
            $app = $request->app_name;
//            if($app == 'pawp'){
//                $output = $this->fetchPMediaMessage($media_sid);
//            }
//            else{
//                $output = $this->fetchMediaMessage($media_sid);
//            }
            $output = $this->fetchMediaMessage($media_sid);
            return $this->successResponse($output, 'Media chats');
        }
        catch (AwsException $e){
            return $this->errorResponse($e->getMessage(), $e->getStatusCode());
        }
    }
    /*
     * This method is called to end chat if user or vets forgets to end chat
     */
    public function endChatScriptOurTwilio(Request $request){
        try {
            $response = $this->fetchChannelsNotEnded();
            if(count($response) == 0){
                $message = count($response).' no chats found to end';
            }
            else{
                $message = count($response).' chats found to end';
            }
            return $this->successResponse($response, $message);
        }
        catch (TwilioException $e) {
            return $this->errorResponse($e->getMessage(), 400);
        }
        catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }

    }

    public function endChatScriptPawpTwilio(Request $request){
        try {
            $response = $this->fetchChannelsNotEndedPawp();
            return $this->successResponse($response, 'Successfully Removed');
        }
        catch (TwilioException $e) {
            return $this->errorResponse($e->getMessage(), 400);
        }
        catch (Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }

    }

    private function fetchChannelsNotEnded(){
        //Twilio channels in vpm database
//        $chat = Chat::doesntHave('chat_details')->get();
        $chat = Chat::where('status','false')->get();
        $channel_array = array();
        foreach ($chat as $record) {
            if($record->app_id != 4){
                try {
                    $userChannels = $this->twilio->chat->v2->services($this->serviceSid)
                        ->channels($record->channel_sid)
                        ->fetch();
                    if($userChannels->membersCount >= 3){
                        $chk_chat_ended = ChatEndedBy::where('chat_id',$record->id)->get();

                        if (count($chk_chat_ended) == 0) {
                            $channel_updated_date = $userChannels->dateUpdated->format('Y-m-d H:i:s');
                            $channel_updated_date_test = $record->created_at;
                            $now = Carbon::now('UTC')->toDateTimeString();
                            $hourdiff = round((strtotime($now) - strtotime($channel_updated_date)) / 3600, 1);
                            $hourdiff_test = round((strtotime($now) - strtotime($channel_updated_date_test)) / 3600, 1);
                            if (App::environment('local', 'staging')) {
                                if ($hourdiff_test > 1) {
                                    //Call the end chat method statically
                                    $channel_array[] = $record->channel_sid;
                                    $this->updateChannelUniqueName($record->channel_sid, $record->user_id, $record->app_id);

                                }
                            }
                            if (App::environment('production')) {
                                if ($hourdiff > 4) {
//                                    //Call the end chat method statically
                                    $channel_array[] = $record->channel_sid;
                                    $this->updateChannelUniqueName($record->channel_sid, $record->user_id, $record->app_id);

                                }
                            }

                        }

                    }
                }
                catch (TwilioException $e){
                    //Chat::where('channel_sid',$record->channel_sid)->delete();
//                    $this->removeChannel($record->channel_sid);
                }
            }
//            dd($record);
        }
        return $channel_array;
    }

    private function fetchChannelsNotEndedPawp(){
        //Twilio channels in vpm database
//        $chat = Chat::doesntHave('chat_details')->get();
        $chat = Chat::where('status','false')->get();

        $channel_array = array();
        foreach ($chat as $record) {
            if($record->app_id == 4){

                try {
                    $userChannels = $this->auth->chat->v2->services($this->tServiceSid)
                        ->channels($record->channel_sid)
                        ->fetch();
                    if($userChannels->membersCount == 3){
                        $channel_array[] = $record->channel_sid;
                        $channel_updated_date = $userChannels->dateUpdated->format('Y-m-d H:i:s');
                        $now = Carbon::now('UTC')->toDateTimeString();
                        $hourdiff = round((strtotime($now) - strtotime($channel_updated_date))/3600, 1);
                        if (App::environment('local', 'staging')) {
                            if ($hourdiff > 1) {
                                //Call the end chat method statically
                                $channel_array[] = $record->channel_sid;
                                $this->updateChannelEndChat($record->channel_sid);
                            }
                        }
                        if (App::environment('production')) {
                            if ($hourdiff > 4) {
                                //Call the end chat method statically
                                $channel_array[] = $record->channel_sid;
                                $this->updateChannelEndChat($record->channel_sid);
                            }
                        }
                    }

                }
                catch (TwilioException $e){
                    //Chat::where('channel_sid',$record->channel_sid)->delete();
//                    $this->removePawpChannel($record->channel_sid);

                }
            }
        }
        return $channel_array;

    }

    public function get_chats_by_vets(Request $request) {

        $input = $request->only('search_value', 'search_by', 'page', 'pagination', 'perPage', 'channel_sid', 'api_key', 'export', 'date_from', 'date_to','type');
        $value = isset($input['search_value'])?$input['search_value']:'';
        $key = isset($input['api_key']) ?: '';
        $export = @$input['export'];

        $model = new ChatDetail();

        // Protect And Normal User Filter
        if($request->has('type') && !empty($request->type))
        {
            $model = $model->whereRaw("(body like '%".htmlspecialchars_decode(htmlspecialchars('"')).$request->type."%' OR attributes like '%".htmlspecialchars_decode(htmlspecialchars('"')).$request->type."%')");
        }

        if(isset($value) && !empty($value)){
            $model = $model->where('attributes', 'like', '%'. $value .'%');
        }

                $user = auth()->user();
//                $model = $model->with(['chat'=>function($q){
//                    $q->select('id','vet_id','user_id','channel_sid','app_id')->with('ended_chat');
//                },'chat.app:id,name,app_type'])->whereHas('chat.app',function($query) use ($request){
//                    $query->where('app_type','!=','whitelabel-webapp');
//                })->groupBy('chat_id')->latest();
                $model = $model->with(['chat'=>function($q){
                    $q->select('id','vet_id','user_id','channel_sid','app_id')->with('ended_chat');
                },'chat.app:id,name,app_type'])->whereHas('chat', function ($q) use ($user) {
                    $q = $q->where('vet_id', $user->id);
                })->groupBy('chat_id')->latest();


            if ($request->has('date_from') && $request->has('date_to')) {
                $model = $model->whereBetween('created_at',
                    [$input['date_from'] . " 00:00:00", $input['date_to'] . " 23:59:00"]
                );
            }

        try{
            $paginator = array();

//            get_sql($model);

            if (isset($input['pagination']) && $input['pagination'] != "") {
                $this->paginate = true;
                $this->noOfRecordPerPage = 10;
                $chat = $model->paginate($this->noOfRecordPerPage);
            }
            elseif($export == 'true' || $export == true) {
                $chat = $model->get();
            }
            else {
                $channel = $input['channel_sid'];
                if ($channel != '') {
                    $chat = ChatDetail::with('chat')->whereHas('chat', function ($q) use ($channel) {
                        $q->where('channel_sid', $channel);
                    })->groupBy('chat_id')->get();
                }
            }
            return $this->successResponse($chat, 'Archived chats',$this->paginate);
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    /**
     * Creating chat from admin to staff and vice versa and staff to staff
     *
     * @param ChatRequest $request
     * @return \Illuminate\Http\Response
     * }
     */
    public function createStaffChat(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'to_user_role' => 'required|in:staff,admin',
            'to_user_id' => 'required_if:to_user_role,staff|exists:sub_admins,id',
            ]);

        if ($validator->fails()) {
            $errors[] = $validator->errors();
            return $this->errorResponse($validator->errors()->all(), 422);
        }

        // Creating chat from admin to staff and vice versa and staff to staff
        $user = auth()->user();
        $fromUserRole = $user->roles()->first() ? $user->roles()->first()->name : '';
        $toUserRole = $request->to_user_role;
        $fromUserObject = $user;
        $toUserObject = $toUserRole == 'admin' ? Vet::find(2) : SubAdmin::find($request->to_user_id);
        

        $channelName = 'admin_staff_chat' . '-' . Carbon::now();
        
        try{

            $response = $this->createStaffChannel($channelName, $fromUserObject, $toUserObject, $fromUserRole, $toUserRole);
            $success['channelsid'] = $response;

            return $this->successResponse($success, 'Chat Started');

        }
        catch (QueryException $e){
            return $this->errorResponse('Query Exception',500);
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(),$e->getCode());
        }
    }
}
