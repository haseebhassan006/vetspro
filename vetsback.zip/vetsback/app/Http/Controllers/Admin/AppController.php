<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\AppRequest;
use Carbon\Carbon;
use Illuminate\Support\Str;
use Validator;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use JWTAuth;
use App\App;
use App\Http\Resources\AppBackgroundResource;

class AppController extends Controller
{
    private $noOfRecordPerPage = 10;
    private $paginate = false;

    public function create(AppRequest $request)
    {
        $validatedData = $request->validated();
        try {
            $validatedData['api_key'] = $api_key_gen = Str::random(16);
            $send_email_on =isset($request->send_email_on) && !empty($request->send_email_on) ? $request->send_email_on :NULL;
            $validatedData['send_email_on'] = isset($request->send_chat_on_email) && $request->send_chat_on_email == true ? $send_email_on : NULL;
            $app = auth()->user()->appsMorph()->create($validatedData);
            $data = array(
                "app" => $app
            );
            return $this->successResponse($data, 'Successfully Created App.');
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    public function list(Request $request)
    {
        $input = $request->only('search_value', 'search_by', 'page', 'pagination', 'perPage', 'app_id','all','type','app_type');
        $value = isset($input['search_value']) ? $input['search_value'] : '';
        try{
            $model = new App();
            if(isset($value) && !empty($value)){
                $model = $model->search($value);
            }

            if($request->has('type') && $request->type != null){
                if ($request->type == 'vc') { //vetcare
                    $model = $model->where('app_type', 'whitelabel-webapp');
                }
                if($request->type == 'vpm'){
                    $model = $model->where('app_type', '!=' , 'whitelabel-webapp')->where('app_type', '!=' , 'vets');
                }

            }

            if($request->has('app_type') && $request->app_type != null){
                $model = $model->where('app_type', $request->app_type);
            }

            if (isset($input['pagination']) && $input['pagination'] != "") {
                $this->paginate = true;
                $app = $model->paginate($this->noOfRecordPerPage);
            }
            else if(isset($input['all']) && $input['all'] != "") {
                //$app_id = $input['app_id'];
                $app = $model->get();
            }
            else {
                $app_id = $input['app_id'];
                $app = $model->find($app_id);
            }
            $data = array(
                "app" => $app
            );
            return $this->successResponse($data['app'], 'Successfully Fetch List App.', $this->paginate);
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    public function update($id, AppRequest $request)
    {
        $validatedData = $request->validated();
        try {
            $app = App::findOrfail($id);
            //$validatedData['api_key'] = $api_key_gen = Str::random(16);
            $send_email_on =isset($request->send_email_on) && !empty($request->send_email_on) ? $request->send_email_on :NULL;
            $validatedData['send_email_on'] = isset($request->send_chat_on_email) && $request->send_chat_on_email == true ? $send_email_on : NULL;
            $app->update($validatedData);
            if(isset($validatedData['app_settings']) && $validatedData['app_settings'] !=null)
            {
                $validatedData['app_settings']['faqs'] = json_encode($validatedData['app_settings']['faqs']);
                $app->appSettings()->update($validatedData['app_settings']);
            }
            $data = array(
                "app" => $app
            );
            return $this->successResponse($data, 'Successfully Record Updated.');
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    public function suspendApp($id,Request $request)
    {
        try {
            $data = App::findOrfail($id);
            $data->update(['is_suspended' => $request->is_suspended]);
            $msg = $request->is_suspended == 1 ? ' is Suspended' : ' is Unsuspended';
            return $this->successResponse($data, $data->name.$msg);
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    //For Clinic Users only
    public function getList(){
        try{
            $app = App::select('name')->where('app_type','whitelabel-webapp')->get();
            return $this->successResponse($app, 'Successfully Fetch List App.');
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    public function getSettings($name){
        try{
            $app = App::with('settings')->where(['app_type'=>'whitelabel-webapp','name'=>$name])->get();
            return $this->successResponse($app, 'Successfully Fetch List App.');
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    public function getAppBackground(Request $request){
        try{
            $apps = App::with(['settings'])->where(['app_type'=>'whitelabel-webapp'])->whereHas('settings',function($q){
                $q->whereNotNull('background_image');
            })->get();
            $apps = AppBackgroundResource::collection($apps);
            return $this->successResponse($apps, 'Successfully Fetch List App.');
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }
}
