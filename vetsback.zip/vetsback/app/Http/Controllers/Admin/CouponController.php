<?php

namespace App\Http\Controllers\Admin;

use App\App;
use App\Coupon;
use App\Http\Requests\CouponRequest;
use App\Http\Requests\PackageRequest;
use App\Http\Requests\PaymentRequest;
use App\Package;
use App\Payment;
use App\Traits\StripePayment;
use App\User;
use App\VetCarePackage;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Database\QueryException;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Mockery\Exception;
use Stripe\Exception\ApiErrorException;
use App\Traits\FullTextSearch;

//use Stripe\Exception\UnknownApiErrorException;
use Stripe\ErrorObject;

class CouponController extends Controller
{
    use StripePayment;

    private $noOfRecordPerPage = 10;

    private $paginate = false;

    protected $userData;

    public function __construct()
    {

    }

    /**
     * Display a listing of the resource.
     *
     * @param Request $request
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $input = $request->only('search_value', 'search_by', 'page', 'pagination', 'perPage');
        $value = isset($input['search_value'])?$input['search_value']:'';
        try{
            $type = $request->type;
            $key = $request->key;
            if($type == 'packages'){
                $model = Package::with(['apps']);
                if(isset($value) && !empty($value)){
                    $model->where('name', 'LIKE' , '%' . $value . '%');
                    // $model->whereRaw("REPLACE(`name`, ' ' ,'') LIKE ?", ['%'.str_replace(' ', '', $value).'%']);
                }
                if($key){
                    $model->where('app_id',$key);
                }
            }
            elseif($type == 'payments'){
                $model = Payment::with('user');
            }
            else{
                $model = Coupon::with(['package'=>function($q){
                    $q->with('apps');
                }]);
                if(isset($value) && !empty($value)){
                    $model = $model->whereRaw(" (other) like '%$value%'");  
                }
                if($key){
                    $model = $model->where('package_id','=', $key);
                }
            }
            if (isset($input['pagination']) && $input['pagination'] != "") {
                $this->paginate = true;
                $data = $model->paginate($this->noOfRecordPerPage);
            } else {
                //$user_id = $input['user_id'];
                $data = $model->get();
            }
            return $this->successResponse($data, 'list', $this->paginate);
        }
        catch (Exception $e){
            return $this->errorResponse('List error');
        }
    }

    public function package(PackageRequest $request)
    {
        $validate = $request->validated();
        try{
            $app = App::find($validate['app_id']);

            //This switch check for app stripe key
            switch ($app->name){
                case 'vetsPlusMore':
                    $this->stripeConfig   = config('services.stripe.vetsplusmore');
                    break;
                case 'vetCareHotline':
                    $this->stripeConfig   = config('services.stripe.vetpethotline');
                    break;
                default:
                    $this->stripeConfig   = config('services.stripe.vetsplusmore');
            }

            //This switch check for user model from app type
            switch ($app->app_type){
                case 'whitelabel':
                    $model = new Package();
                    break;
                case 'whitelabel-webapp':
                    $model = new VetCarePackage();
                    break;
                default:
                    $model = new Package();
            }

            $this->stripe = new \Stripe\StripeClient($this->stripeConfig);
            //Add product in stripe
            $type = 'one_time';
            if($validate['is_recurring'] == 1){
                $type = 'recurring';
            }
            try{
                $stripe_package = $this->addProductStripe($validate['name'],$validate,$type);
                if($stripe_package['code'] == 200){
                    //$validate['price'] = 0.01 * $validate['price'];
                    $validate['price_id'] = $stripe_package->price_id;
                    $validate['product_id'] = $stripe_package->product_id;
                    $data = $model->create($validate);

                    #TODO check recurring and one time on stripe
                    return $this->successResponse($data, 'package added');
                }
                else{
                    return $this->errorResponse($stripe_package['message'],$stripe_package['code']);
                }
            }
            catch (ApiErrorException $e){
                return $this->errorResponse($e->getMessage(),$e->getCode());
            }
        }
        catch (Exception $e){
            return $this->errorResponse('Pakcage not created. try again');
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @param CouponRequest $request
     * @return \Illuminate\Http\Response
     */
    public function create(CouponRequest $request)
    {
            $validate = $request->validated();
            $user = auth()->user();
        try{
            $model = Coupon::search($validate['code'])->first();
            if(!$model){
                $package_id = $validate['package_id'];
                unset($validate['package_id']);
                $data = $user->coupon()->create(['other'=>$validate,'package_id'=>$package_id]);
                return $this->successResponse($data, 'coupon added');
            }
            else{
                return $this->errorResponse('Coupon with same code already exists',403);
            }

        }
        catch (QueryException $e){
            return $this->errorResponse($e->getMessage(),404);
        }

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id,Request $request)
    {
        //
        try{
            if($request->type == 'package'){
                $model = Package::with('apps');
            }
            else{
                $model = Coupon::with('package');
            }
            $data = $model->where('id',$id)->first();
            return $this->successResponse($data,  'list');
        }
        catch(QueryException $e){
            return $this->errorResponse($e->getMessage(),404);
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param int $id
     * @param PackageRequest $request
     * @return \Illuminate\Http\Response
     */
    public function edit($id, PackageRequest $request)
    {
        $user = auth()->user();
        $validatedData = $request->validated();
        try {
            if($request->type == 'protect' || $request->type == 'non-protect' || $request->type == 'non-credit'){
                $model = Package::find($id);
                $data = Package::findOrfail($id);
                //Edit on stripe
                if($request->has('is_recurring')){
                    //$app = $this->findAppById($model->app_id);
                    $this->init($model->app_id);
                    $is_recurring = $validatedData['is_recurring'];
                    $this->editProduct($model->product_id,$is_recurring);
                }
            }
            else{
                $model = Coupon::find($id);
                $data = Coupon::findOrfail($id);
            }
            $model->update($validatedData);

            return $this->successResponse($data, 'Successfully Record Updated.');
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param int $id
     * @param CouponRequest $request
     * @return \Illuminate\Http\Response
     */
    public function edit_coupon($id, CouponRequest $request)
    {
        $validatedData = $request->validated();
        try {
            $package_id = $validatedData['package_id'];
            unset($validatedData['package_id']);
            $model = Coupon::find($id);
            $model->update([
                'other'=>$validatedData,
                'package_id'=>$package_id
            ]);
            return $this->successResponse($model, 'Successfully Record Updated.');
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id,Request $request)
    {
        $user = auth()->user();
        try {
            if($request->type == 'package'){
                $data = Package::findOrfail($id)->delete();
            }
            else{
                $data = Coupon::findOrfail($id)->delete();
            }
            return $this->successResponse($data, 'Successfully Deleted.');
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    /**
     * @param $name
     * @param $metadata
     * @param $type
     * @return array
     */
    public function addProductStripe($name, $metadata, $type){
        //$json = json_encode($metadata);
        try{
            $product = $this->stripe->products->create([
                'name' => $name,
                'metadata'=> $metadata
            ]);
            $price = [
                'product' => $product->id,
                'unit_amount' => 100 * $metadata['price'],
                'currency' => $metadata['currency'],
            ];
            if($type == 'recurring'){
                $price['recurring'] = [
                    'interval' => $metadata['interval'],
                ];
            }
            $price_res = $this->stripe->prices->create([
                $price
            ]);
            //$this->createPlan($product->id,$metadata['currency'],$metadata['interval'],$metadata['price']);
            $product['code'] = 200;
            $product['price_id'] = $price_res->id;
            $product['product_id'] = $product->id;
        }
        catch (ApiErrorException $exception){
            $product['code'] = $exception->getHttpStatus();
            $product['message'] = $exception->getMessage();
        }
        return $product;
    }
}
