<?php

namespace App\Http\Controllers\Admin;

use App\Exports\SendFeedback;
use App\FeedbackEmail;
use App\Http\Resources\VetFeedbackResource;
use App\Mail\EmailFeedbacks;
use App\Vet;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Storage;
use JWTAuth;
use App\Chat;
use App\User;
use App\Guest;
use Validator;
use App\Reason;
use App\ExtraPet;
use App\Feedback;
use App\Template;
use App\VideoCall;
use Carbon\Carbon;
use App\ChatDetail;
use App\WebappUser;
use App\App as Apps;
use App\ChatEndedBy;
use App\VetCareUser;
use Twilio\Rest\Video;
use App\PivotVideoCall;
use App\Recommendation;
use App\VideoCallHistory;
use App\WebAppUsersExtra;
use App\ChatRecommendation;
use App\EmergencyVetClient;
use Illuminate\Http\Request;
use App\AdminNotificableUser;
use App\Traits\TwilioSDKTrait;
use App\Traits\PushNotification;
use App\Http\Requests\VetRequest;
use Illuminate\Support\Facades\DB;
use App\Mail\MailMeProtectUserInfo;
use App\Traits\OtherTwilioSDKTrait;
use Illuminate\Support\Facades\App;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail;
use Twilio\Exceptions\RestException;
use App\Http\Requests\TemplateRequest;
use Twilio\Exceptions\TwilioException;
use Illuminate\Database\QueryException;
use App\Mail\MailVcWhenEmergencyActivated;
use Carbon\Exceptions\UnknownGetterException;
use App\UserAppStatus;
use App\Http\Requests\VetProfileRequest;


class VetController extends Controller
{
    protected $user;

    use TwilioSDKTrait;
    use OtherTwilioSDKTrait;
    use PushNotification;

    public function __construct()
    {
        $this->generic();
        $this->construct();
    }

    public function login(VetRequest $request)
    {
        if(empty($request->device_token)){
            return $this->errorResponse('Device Token is required',422);
        }
        // credentials
        $credentials = $request->only(['email', 'password']);

        try {
            if ($token = $this->guard()->attempt($credentials)) {

                if($this->guard()->user()->hasRole('vets')){

                    $this->user = $this->guard()->user();

                    $this->user->update(['is_online'=>1]);

                    $dev_type = $request->dev_type;

                    if($dev_type == 'android' || $dev_type == 'ios' || $dev_type == 'web'){
                        //Update or create new device
                        $device = $this->user->devices()->where(['rec_id'=>$this->user->id])->first();

                        if (isset($device) && !empty($device)) {
                            $device->update([
                                'device_token'=>$request->device_token,
                                'udid'=>$request->udid,
                                'dev_type'=>$request->dev_type,
                                'app_version'=>$request->app_version,
                            ]);
                        }
                        else {
                            $this->user->devices()->create([
                                'rec_id'=>$this->user->id,
                                'device_token'=>$request->device_token,
                                'udid'=>$request->udid,
                                'dev_type'=>$request->dev_type,
                                'app_version'=>$request->app_version,
                            ]);
                        }
                    }
                    $app = $this->find_app($request->api_key);
                    $identity = 'app-'.$app->id.'_vet-'.$this->user->id;
                    //update appid on twilio user resource if new appid
                    if ($app->id != $this->user->app_id) {
                        $this->fetchAndUpdateUser($app->id,$identity);
                    }
                    //Response
                    $success['token'] = $token;
                    $success['twilioToken'] = $this->init($identity, $request->dev_type, $app->id);
                   // $success['pawpTwilioToken'] = $this->accessToken('vet-'.$this->user->id, $request->dev_type, $app->id);
                    $success['vets'] = $this->user->load('vetDetails');

                    $dateTime =  Carbon::now();
                    $this->user->vetAuthenticationHistory()->create([
                        'dateTime' => $dateTime,
                        'type' => 'login'
                    ]);
                    //Add vet id to queues table
                    $this->user->queue()->updateOrCreate(['vet_id'=>$this->user->id],['vet_id'=>$this->user->id,'status'=>false]);

                    AdminNotificableUser::updateOrCreate(['status'=>'true']);

                    return $this->successResponse($success, 'logged in');
                }
//                else {
//                    return $this->errorResponse('Wrong credentials or missing access rights to application.');
//                }
            }   else {
                return $this->errorResponse('Wrong credentials');
            }
        }
        catch (RestException $e){
            switch ($e->getStatusCode()) {
                case 20404:
                    $message = "User does not exists on our twilio service. Contact admin";
                    $code = 500;
                    break;
                case 404:
                    $message = "Login not successful. Retry";
                    $code = 404;
                    break;
                case 500:
                    $message = "Internal Failure.Report to admin";
                    $code = 500;
                    break;
                default:
                    $message = "Try again. Not successful";
                    $code = 400;
            }
            return $this->errorResponse($message, $e->getStatusCode());
        }
        catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    public function create(VetRequest $request)
    {
        $validatedData = $request->validated();
        try {
            $user = $request->user('vets');
            //bcrypt password
            if(array_key_exists('password',$validatedData)){
                $pwd = $validatedData['password'];
                $validatedData['password'] = bcrypt($validatedData['password']);
            }
            $data = $user->create($validatedData);

            $data->devices()->firstOrCreate([
                'device_token' => $request->device_token,
                'rec_id'=>$data->id,
                'udid'=>$request->udid,
                'app_version'=>$request->app_version,
                'dev_type'=>$request->dev_type
            ]);

            $data->assignRole($request->role);
            $app = $this->find_app($request->api_key);
            //Add user to twilio account as well
            $attributes = ["app_id"=>$app->id,"vet_id"=>$data->id,"email"=>$request->email];
            $identity = 'app-'.$app->id.'_vet-'.$data->id;
            $dataToTwilio = [
                'attributes' => json_encode($attributes),
                'friendlyName' => $request->first_name.' '.$request->last_name,
                'identity'=> $identity
            ];
            $createUser = $this->createUser($dataToTwilio);

            $success['token'] = auth()->login($user);
            //$success['twilioToken'] = $this->init($identity, $request->dev_type, $app->id);
            //$success['pawpTwilioToken'] = $this->accessToken('vet-'.$this->user->id, $request->dev_type, $app->id);
            $success['vet'] = $data;

            return $this->successResponse($success, 'Successfully Created Vet.');
        }
        catch (RestException $e) {
            return $this->errorResponse($e->getMessage(),$e->getCode());
        }
        catch (QueryException $e) {
            switch ($e->getCode()) {
                    case 23000:
                        $message = "Email already exists";
                    break;
//                    case label2:
//                        $message = "Email already exists";
//                    break;
//                    case label3:
//                        $message = "Email already exists";
                    break;
                default:
                    $message = "Try again. Query Error";
            }
            return $this->errorResponse($message,405);
        }
        catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(),$e->getCode());
        }
    }

    public function update($id, VetRequest $request)
    {
        $validated = $request->validated();
        $this->user = $this->guard()->user();
        $data = $validated;
        try {
            $identity = 'app-'.$this->user->app_id.'_user-'.$id;
            if($request->hasFile('profile')){
                $data['profile'] = $path = $this->uploadFile($request->profile,'vets');
                $this->user->vetDetails()->updateOrCreate(['vet_id'=>$id],['profile'=>$data['profile']]);
                $get_user_channels = $this->fetchUserChannel($identity);
                if($get_user_channels){
                    foreach ($get_user_channels as $channelData){
                        $channel_data = $this->fetchChannel($channelData->channelSid,'arr');
                        $attributes_data = $channel_data->attributes;
                        $json_data = json_decode($attributes_data,true);
                        //dd($json_data['user']['profile']);
                        //$json_data = json_decode($json_data,true);
                        $json_data['vet']['profile'] = $data['profile'];
                        $json_object = json_encode($json_data);
                        $this->updateChannelAttribute($channelData->channelSid,$json_object);
                    }
                }
            }
            if(array_key_exists('password',$validated)){
                $pwd = $validated['password'];
                $validated['password'] = bcrypt($validated['password']);
            }
            $this->user->update($validated);
            $response = $this->user->load('vetDetails');

            return $this->successResponse($response, 'Successfully Record Updated.');
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    public function guard()
    {
        return Auth::guard('vets');
    }
    /**
     * Logout user (Revoke the token)
     *
     * @return [string] message
     */
    public function logout()
    {
        $this->user = $this->guard()->user();
        $data = array(
            'is_online'=>0,
            'is_call'=>0
        );
        $this->user->update($data);
        $this->user->devices()->delete();

        $dateTime =  Carbon::now();
        $this->user->vetAuthenticationHistory()->create([
            'dateTime' => $dateTime,
            'type' => 'logout'
        ]);
        //Auth::logoutOtherDevices($user);
        $this->user->queue()->delete();

        DB::table('admin_notificable_users')->update(['status'=>'false']);

        auth()->logout();
        return $this->successResponse(true, 'Successfully logged out');
    }
    /**
     * Get the token array structure.
     *
     * @param string $token
     *
     * @return \Illuminate\Http\Response
     */
    protected function respondWithToken($token)
    {
        $a = [
            'access_token' => $token,
            'token_type' => 'bearer',
            'expires_in' => $this->guard()->factory()->getTTL() * 420000,
            //'twilioToken'=>$this->init($identity, $dev_type, $app_id),
            //'pawpTwilioToken'=>$this->accessToken('vet-'.$vet_id, $dev_type,$app_id)
        ];

        return $this->successResponse($a, 'user data');
    }
    /**
     * Refresh a token.
     *
     * @return \Illuminate\Http\Response
     */
    public function refresh()
    {
        return $this->respondWithToken(auth()->refresh());
    }
    /**
     * Feedback and vet protect
     * @param Request $request
     * @return \Illuminate\Http\Response
     */
    public function vetFeedback(Request $request)
    {
        $this->user = $this->guard()->user();
        try{
            $recommendation_id = $request->recommendation_id;
            $reason_id = $request->reason_id;
            $is_protect = $request->is_protect;
            $twilio_sid =  $request->twilio_sid;
            $appName = isset($request->app_name)?$request->app_name:'';
            $pet_id = isset($request->pet_id)?$request->pet_id:NULL;
            $app = $this->findAppByName($appName);
            $type = $request->type;
            $recommendation = Recommendation::find($recommendation_id);
            $reason = Reason::find($reason_id);

            if($type == 'chat') {
                $table = Chat::where('channel_sid', $twilio_sid)->first();
                if(!$table){
                    return $this->errorResponse('Error ! Chat not found in staging DB. May be created from local.',404);
                }
                $vetStatusupdate = Vet::find($table->vet_id);
                if(!empty($vetStatusupdate) && $vetStatusupdate->is_chat >= 1){
                    $vetStatusupdate->is_chat = $vetStatusupdate->is_chat - 1;
                    $vetStatusupdate->update();
                }
                //Update who ended the chat
                ChatEndedBy::create(['chat_id'=>$table->id,'ended_by'=>'vet']);
                $this->informToUser($request->vet_id,$twilio_sid,$request->user_id,$app->id);
            }
            elseif($type == 'video'){
                $table = VideoCall::where('room_sid',$twilio_sid)->firstOrFail();
            }

                switch ($app->app_type) {
                    case 'whitelabel':
                    case 'whitelabel-webapp':
                    if($type == 'chat'){
                            $this->updateChannelUniqueName( $twilio_sid );
                        }
                        $check_user_role = User::find($request->user_id);

                        if($app->app_type == 'whitelabel-webapp'){
                            $check_user_role = VetCareUser::find($request->user_id);
                        }
                        $username = $check_user_role->first_name.' '.$check_user_role->last_name;
                        if($check_user_role->hasRole('protect_users') && $is_protect == true){
                            $vet = Vet::find($request->vet_id);
                            $vetname = $vet->first_name.' '.$vet->last_name;
                            $date = Carbon::now()->format('l jS \\of F Y h:i:s');
                            //Email To Notify Admin
                            Mail::to(env('MAIL_TO'))->send(new MailMeProtectUserInfo($vetname,ucfirst($username),$date,ucfirst($app->name)));
                            //Email To Notify VetCare User
                            Mail::to($check_user_role->email)->send(new MailVcWhenEmergencyActivated($vetname,ucfirst($username),$date,ucfirst($app->name)));
                            //Emergency vet club
                            EmergencyVetClient::where('user_id',$request->user_id)->update(['is_latest'=>0]);
                            EmergencyVetClient::create([
                                'type'=>$type,
                                'vet_id'=>$request->vet_id,
                                'user_id'=>$request->user_id,
                                'is_protect'=>$is_protect,
                                'app_id'=>$app->id,
                                'is_latest'=>1 //is latest emergency
                            ]);

                            //Update User next activation Date for VetCare
                            $oldnextEmergencyActivation = $check_user_role->next_emergency_activation_date;
                            if($oldnextEmergencyActivation == null)
                            {
                                $registerDate = Carbon::parse($check_user_role->created_at);
                                $nextEmergencyActivation = $registerDate->addYear(1);
                            }else{
                                $oldnextEmergencyActivation = Carbon::parse($oldnextEmergencyActivation);
                                $diffInYears = $oldnextEmergencyActivation->diffInYears(Carbon::now());
                                $nextEmergencyActivation = $oldnextEmergencyActivation->addYears($diffInYears + 1);
                            }
                            $check_user_role->update(['next_emergency_activation_date' => $nextEmergencyActivation]);

                            //Send push to user when vet declares user active
                            //notification data
                            $notify = [
                                'is_protect'=>$is_protect,
                                'type'=> 'evp',
                                'vet'=>$vet
                            ];
                            if(count($check_user_role->devices) > 0 && $check_user_role->devices[0]->dev_type == 'ios'){
                                $binding_type = 'apn';
                            }
                            else{
                                $binding_type = 'fcm';
                            }
                            try{
                                if(count($check_user_role->devices) > 0){
                                    $res = $this->pushNotify($check_user_role->devices[0]->device_token,$binding_type,$notify,$app->name.' Emergency has been activated. ');
                                }
                            }
                            catch (RestException $twilioException){
                                return $this->errorResponse('Error ! User notified about emergency',$twilioException->getStatusCode());
                            }
                        }
                        break;
                    case 'webapp':
                        $check_user_role =
                        WebAppUsersExtra::with('webappuser')->where('user_id',$request->user_id)
                            ->whereRaw('id IN (select MAX(id) from webapps_users_extra GROUP BY user_id)')->first();
                        //For protect clients only
                        if($check_user_role->protected == 'protect_users' && $is_protect == true){
                            //Notify other clients of user getting protected
                            $appName = strtolower($appName);
                            switch($appName){
                                case 'pawp':
                                    $this->updateClientAboutPawpProtect($appName,$twilio_sid,$type,$pet_id,$check_user_role->db_user_id);
                                    break;
                                case 'onepet':
                                case 'petcube':
                                case 'petacumen':
                                case 'vidaah':
                                case 'nimble':
                                    $this->updateClientAboutProtect($appName,$twilio_sid,$recommendation->name,$reason->reasons);
                                    break;
                                case 'goodcharlievpm':
                                    $this->updateClientAboutProtect($appName,$twilio_sid,$recommendation->name,$reason->reasons);
                                    break;
                            }
                            //Emergency vet club
                            EmergencyVetClient::where('user_id',$request->user_id)->update(['is_latest'=>0]);
                            EmergencyVetClient::create([
                                'type'=>$type,
                                'vet_id'=>$request->vet_id,
                                'user_id'=>$request->user_id,
                                'is_protect'=>$is_protect,
                                'app_id'=>$app->id,
                                'is_latest'=>1 //is latest emergency
                            ]);
                            if($is_protect == true){$is_protect = 'protect_users';}

                            WebAppUsersExtra::where('id',$check_user_role->id)->update(['protected'=>$is_protect]);
                            $vet = Vet::find($request->vet_id);
                            $vetname = $vet->first_name.' '.$vet->last_name;
                            $username = $check_user_role->webappuser->first_name.' '.$check_user_role->webappuser->last_name;
                            $date = Carbon::now()->format('l jS \\of F Y h:i:s');

                            //Update User next activation Date for WebApp
                            $oldnextEmergencyActivation = $check_user_role->webappuser->next_emergency_activation_date;
                            if($oldnextEmergencyActivation == null)
                            {
                                $registerDate = Carbon::parse($check_user_role->webappuser->created_at);
                                $nextEmergencyActivation = $registerDate->addYear(1);
                            }else{
                                $oldnextEmergencyActivation = Carbon::parse($oldnextEmergencyActivation);
                                $diffInYears = $oldnextEmergencyActivation->diffInYears(Carbon::now());
                                $nextEmergencyActivation = $oldnextEmergencyActivation->addYears($diffInYears + 1);
                            }
                            $check_user_role->webappuser->update(['next_emergency_activation_date' => $nextEmergencyActivation]);

                            //Email To Notify Admin
                            Mail::to(env('MAIL_TO'))->send(new MailMeProtectUserInfo($vetname,ucfirst($username),$date,ucfirst($appName)));
                        }

                        //Chat ends update unique name , inform apps


                        if($type == 'chat' && $appName != 'pawp'){
                            $user_like_twilio = 'app-'.$app->id.'_user-'.$request->user_id;
                            $this->updateChannelUniqueName($twilio_sid,$request->user_id, $app->id, $appName,$is_protect,$recommendation->name,$reason->reasons,$user_like_twilio,$source='webApp');
                        }
                        elseif($type == 'chat' && $appName == 'pawp'){
                            $this->updateChannelEndChat($twilio_sid,$appName,$source='webApp');
                        }

                        break;
                    case 'sdk':
                        $check_user_role = Guest::find($request->user_id);
                        if($type == 'chat'){ $this->updateChannelUniqueName( $twilio_sid , $source='webApp');}
                        break;

                    default:
                        $this->updateChannelUniqueName( $twilio_sid );
                }
            //Insert feedback
            $data = Feedback::create([
                'table_id'=>$table->id,
                'recommendation_id'=>$recommendation_id,
                'reason_id'=>$reason_id,
                'type'=>$type,
                'app_id'=>$app->id
            ]);

            $feedback_email = FeedbackEmail::where('app_id', $app->id)->get();

            if ($feedback_email->count() > 0) {
                $export = 'excel';

                $model = new Feedback;
                $model = $model->where('id', $data->id);
                $model = $model->with(['video_expend', 'chat_expend', 'reason', 'recommendation']);

                $data_model = VetFeedbackResource::collection($model->get());
                $response['export_type'] = $export;
                $response['data'] = $data_model;
                if ($export == 'pdf') {
                    $filename = date('d-m-Y') . '_' . time() . '_VetFeedbacks.pdf';
                    $pdf = \PDF::loadView('emailFeedbackPdfView', $response)->setPaper('a4', 'landscape');
                    $attachment = $pdf->output();
                    $uploaded_file = $this->uploadFilePublicRepoV2($attachment, 's3', 'feedbacks', $filename);
                } else {
                    $filename = date('d-m-Y') . '_' . time() . '_VetFeedbacks.xlsx';
                    $attachment = \Excel::store(new SendFeedback($response), 'feedbacks/' . $filename, 's3');
                    $chk_file = Storage::disk('s3')->url('feedbacks/' . $filename . '');
                    $uploaded_file = $chk_file;
                }

                $from_address = '';
                $email_response['data'] = '';
                $subject = 'Vet Feedbacks';

                foreach ($feedback_email as $email) {
                    Mail::to($email->email)->send(new EmailFeedbacks($email_response, $from_address, $email->email, $subject, $uploaded_file));
                }

            }

            return $this->successResponse($data, 'Feedback submitted');
        }
        catch (QueryException $e){
            return $this->errorResponse($e->getMessage(),$e->getCode());
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(),$e->getCode());
        }
    }

    private function updateClientAboutPawpProtect($app_name,$twilio_sid,$type,$pet_id,$user_id){
        if($app_name == 'pawp'){
            //$their_user_id = WebappUser::find($user_id);
            if (App::environment('local', 'staging')) {
                if($type == 'chat'){
                    $params = array(
                        "pet" => $pet_id,
                        "user" => $user_id,
                        "channel_sid" => $twilio_sid
                    );
                }
                else{
                    $params = array(
                        "pet" => $pet_id,
                        "user" => $user_id,
                        "video_room_sid" => $twilio_sid
                    );
                }
                $this->notifyPawpConversationRequest($params,$type);
            }
            if (App::environment('production')){
                if($type == 'chat'){
                    $params = array(
                        "pet" => $pet_id,
                        "user" => $user_id,
                        "channel_sid" => $twilio_sid
                    );
                }
                else{
                    $params = array(
                        "pet" => $pet_id,
                        "user" => $user_id,
                        "video_room_sid" => $twilio_sid
                    );
                }
                $this->notifyPawpConversationRequest($params,$type);
            }
        }
//        if($app_name == lcfirst('onepet')){
//            $this->notifyWebappConversationRequest();
//        }
    }

    private function updateClientAboutProtect($app_name,$twilio_sid,$recommendation,$reason){

        $header = ['Content-Type'=> 'application/json'];

        if($app_name == 'onepet'){
            //Make HTTP Request to pawp
            if (App::environment('local', 'staging')) {
                $url = 'https://api.dev.onevet.ai/';
                $uri = 'v1/emergency-fund';
                $username = config('services.vpm-chats-local.onepet_user_key');
                $password = config('services.vpm-chats-local.onepet_user_secret');
            }
            if (App::environment('production')) {
                $url = 'https://api.onevet.ai/';
                $uri = 'v1/emergency-fund';
                $username = config('services.vpm-chats-prod.onepet_user_key');
                $password = config('services.vpm-chats-prod.onepet_user_secret');
            }
            $params = array(
                'reason'=>$reason,
                'channel_sid'=>$twilio_sid,
                'recommendation'=>$recommendation
            );
        }
        if($app_name == 'petcube'){
            //Make HTTP Request to pawp
            if (App::environment('local', 'staging')) {
                $url = 'https://qa.petcube.com';
                $uri = '/api/vpm/chat/'.$twilio_sid.'/end/';
                $username = config('services.vpm-chats-local.petcube_user_key');
                $password = config('services.vpm-chats-local.petcube_user_secret');
            }
            if (App::environment('production')) {
                $url = 'https://petcube.com';
                $uri = '/api/vpm/chat/'.$twilio_sid.'/end/';
                $username = config('services.vpm-chats-prod.petcube_user_key');
                $password = config('services.vpm-chats-prod.petcube_user_secret');
            }
            $params = array(
              'emergency'=>true
            );
        }
        if($app_name == 'vidaah'){
            //Make HTTP Request to pawp
            if (App::environment('local', 'staging')) {
                $url = 'https://vidaah-staging.web.app/';
                $uri = 'api/emergency';
                $username = config('services.vpm-chats-local.vidaah_user_key');
                $password = config('services.vpm-chats-local.vidaah_user_secret');
            }
            $params = array(
                'reason'=>$reason,
                'channel_sid'=>$twilio_sid,
                'recommendation'=>$recommendation
            );
            if (App::environment('production')) {
                $url = 'https://vidaah.vet/';
                $uri = 'api/emergency';
                $username = config('services.vpm-chats-local.vidaah_user_key');
                $password = config('services.vpm-chats-local.vidaah_user_secret');
            }
            $params = array(
                'reason'=>$reason,
                'channel_sid'=>$twilio_sid,
                'recommendation'=>$recommendation
            );
        }
        if($app_name == 'petacumen'){
            //Make HTTP Request to pawp
            if (App::environment('local', 'staging')) {
                $url = 'https://api.dogtastic.co';
                $uri = '/oauth/token';
                $username = config('services.vpm-chats-local.petacumen_user_key');
                $password = config('services.vpm-chats-local.petacumen_user_secret');
            }
            if (App::environment('production')) {
                $url = 'https://api.dogtastic.co';
                $uri = '/oauth/token';
                $username = config('services.vpm-chats-prod.petacumen_user_key');
                $password = config('services.vpm-chats-prod.petacumen_user_secret');
            }
            $params = array(
                'id'=>$twilio_sid
            );
        }
        if($app_name == 'goodcharlievpm'){
            //Make HTTP Request to goodcharlie vpm
            // if (App::environment('local', 'staging')) {
                $url = 'https://signup.goodcharlie.com/';
                $uri = '/signup/api/v1/videovet/emergency/updates';
                $username = '';
                $password = '';
            // }
            // if (App::environment('production')) {
                // $url = 'https://api.onevet.ai/';
                // $uri = 'v1/emergency-fund';
                // $username = config('services.vpm-chats-prod.onepet_user_key');
                // $password = config('services.vpm-chats-prod.onepet_user_secret');
            // }

            $user = WebAppUser::where('id',request()->user_id)->first();
            $vet = Vet::where('id',request()->vet_id)->first();

            $params = array(
                'user_id'=> $user->id,
                'email'=> $user->email,
                'first_name'=> $user->first_name,
                'last_name'=> $user->last_name,
                'twilio_sid'=>$twilio_sid,
                'reason'=>$reason,
                'recommendation'=>$recommendation,
                'vet_id'=> $vet->id,
                'vet_first_name'=> $vet->first_name,
                'vet_last_name'=> $vet->last_name,
                'emergency fund'=> isset($user->emergency_fund) ? $user->emergency_fund : NULL,
                'activation_date'=> Carbon::now()->format('Y-m-d H:i:s'),
            );

            $header['x-api-key'] = '12117801-e70d-4cfd-afa5-8dbd5ef54c8c';
        }

        $this->guzzleHttpRequestWithJson($url,$uri,$params,$username,$password,$header,$app_name);
    }
    /**
     * @return \Illuminate\Http\Response
     */
    public function createTemplate(TemplateRequest $request){
        try{
            $validated = $request->validated();
            $validatedData['data'] = $request->only(['title', 'body']);
            $user = auth()->user();
            $validatedData['vet_id'] = $user->id;
            if($request->has('image'))
            {
                $validatedData['image_url'] = $this->uploadFilePublicRepo($request->image,'s3','template_attachments');
            }
            $data = Template::create($validatedData);
            return $this->successResponse($data, 'Template Added');
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(),$e->getCode());
        }
    }

    public function getTemplate(){
        try{
            $user = auth()->user();
            $data = Template::where('vet_id',$user->id)->get();
            return $this->successResponse($data, 'My Template');
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(),$e->getCode());
        }
    }
    /**
     * @param TemplateRequest $request
     * @param $id
     * @return \Illuminate\Http\Response
     */
    public function editTemplate(TemplateRequest $request, $id){
        try{
            $validated = $request->validated();
            $validatedData['data'] = $request->only(['title', 'body']);
            $user = auth()->user();
            $validatedData['vet_id'] = $user->id;
            if($request->has('image'))
            {
                $validatedData['image_url'] = $this->uploadFilePublicRepo($request->image,'s3','template_attachments');
            }
            $data = Template::updateOrCreate(['id'=>$id],$validatedData);
            return $this->successResponse($data, 'Template Edited');
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(),$e->getCode());
        }
    }
    /**
     * @param $id
     * @return \Illuminate\Http\Response
     */
    public function deleteTemplate($id){
        try{
            $data = Template::find($id)->delete();
            return $this->successResponse($data, 'Template Deleted');
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(),$e->getCode());
        }
    }
    /**
     * Set vet status
     */
    public function updateStatus()
    {
        $this->user = $this->guard()->user();
        $data = array(
            'is_call'=>1
        );
        $this->user->update($data);
        $this->user->queue()->updateOrCreate(['vet_id'=>$this->user->id],['vet_id'=>$this->user->id,'status'=>false]);
        return $this->successResponse(true, 'Status Changed');
    }

    /**
     * Vet Shift status
     * @param Request $request
     * @return \Illuminate\Http\Response
     */
    public function updateShiftAndStatus(Request $request){

        $this->user = $this->guard()->user();
        $type = isset($request->type)?$request->type:'';
        $dev_type = $request->dev_type;

        if($type != ''){
            switch ($type){
                case 'away':
                    $data = array(
                        'is_call'=>0,
                        'is_online'=>0
                    );
                    $this->user->queue()->delete();
                    $dateTime =  Carbon::now();
                    $this->user->vetAuthenticationHistory()->create([
                        'dateTime' => $dateTime,
                        'type' => 'logout'
                    ]);
                    break;
                case 'available':
                    $data = array(
                        'is_call'=>0,
                        'is_online'=>1
                    );
                    $this->user->queue()->updateOrCreate(['vet_id'=>$this->user->id],['vet_id'=>$this->user->id,'status'=>false]);
                    $dateTime =  Carbon::now();
                    $this->user->vetAuthenticationHistory()->create([
                        'dateTime' => $dateTime,
                        'type' => 'login'
                    ]);
                    break;
                case 'active':
                    $data = array(
                        'is_online'=>1,
                        'is_call'=>0,
                    );
                    break;
            }
            $this->user->update($data);

            // Update Device
            if($dev_type == 'android' || $dev_type == 'ios' || $dev_type == 'web'){
                //Update or create new device
                if($type=='available'){
                    $device = $this->user->devices()->where(['rec_id'=>$this->user->id])->first();

                    if (isset($device) && !empty($device)) {
                        $device->update([
                            'device_token'=>$request->device_token,
                            'udid'=>$request->udid,
                            'dev_type'=>$request->dev_type,
                            'app_version'=>$request->app_version,
                        ]);
                    }
                    else {
                        $this->user->devices()->create([
                            'rec_id'=>$this->user->id,
                            'device_token'=>$request->device_token,
                            'udid'=>$request->udid,
                            'dev_type'=>$request->dev_type,
                            'app_version'=>$request->app_version,
                        ]);
                    }
                }
                if($type=='away'){
                    $this->user->devices()->delete();
                }
            }
        }
        return $this->successResponse($this->user, 'My Status');
    }


     /*
     * Twilio Chat refresh token
     */
    public function refreshTwilioApiToken(Request $request){

        $identity = $request->identity;
        $dev_type = $request->dev_type;
        $app_id = ($request->has('api_key')  && $request->api_key !== null && $request->api_key != '') ? $this->find_app($request->api_key)->id : null;
        $response['twilioToken'] = $this->init($identity, $dev_type, $app_id);
        //$response['pawpTwilioToken'] = $this->accessToken($identity, $dev_type, $app_id);
        return $this->successResponse($response, 'User token');
    }

    /**
     * if vet can activate emergency of user
     *
     * if vc-user cools down ends and not from paws
     *
     * @param Request $requset
     * @return type
     * @throws conditon
     **/
    public function canActivateUserEmergency(Request $request)
    {
        //TODO: check if user is in emergency
        try{
            $canActivateEmergency = true;
            $result = array();
            $vetCareUser = null;
            $now = Carbon::now();
            $validatedData = $request->only(['id', 'app_name']);
            $vetCareApp = Apps::whereIn('app_type',['whitelabel-webapp','webapp'])->where('name',$validatedData['app_name'])->first();
            $appSetting = null;
            $daysToActivateEmergency = 14;
            $isHandShakeEnabled = null ;
            if ($vetCareApp) {
                if ($vetCareApp->app_type == 'whitelabel-webapp') {

                    $appSetting = $vetCareApp->appSettings()->first();
                    $otherAttribute = json_decode($appSetting->other);
                    if (isset($otherAttribute->trial_period)) {
                        $daysToActivateEmergency = $otherAttribute->trial_period;
                    }
                    if (isset($otherAttribute->enable_handshake) && $otherAttribute->enable_handshake == 1) {
                        $isHandShakeEnabled = 1;
                    }

                    $vetCareUser = VetCareUser::find($validatedData['id']);
                    if ($vetCareUser && $vetCareApp && $validatedData['app_name'] != 'paws') {
                        $packageUsage = $vetCareUser->usage()->latest()->first();
                        if ($packageUsage) {
                            $result['subscriptionDate'] = $packageUsage->created_at;
                            $result['interval'] = $result['subscriptionDate']->diff($now);
                            $result['days'] = $result['interval']->format('%a');
                            if ($result['days'] < $daysToActivateEmergency) {
                                $canActivateEmergency = false;
                            }
                        }
                        if ($isHandShakeEnabled == 1) {
                            $result['interval'] = ($vetCareUser->created_at)->diff($now);
                            $result['days'] = $result['interval']->format('%a');
                            if ($result['days'] < $daysToActivateEmergency) {
                                $canActivateEmergency = false;
                            }
                        }
                    }
                } elseif ($vetCareApp->app_type == 'webapp') {

                    if (isset($vetCareApp->trial_period)) {
                        $daysToActivateEmergency = $vetCareApp->trial_period;
                    }

                    $isHandShakeEnabled = 1;
                    $vetCareUser = WebappUser::find($validatedData['id']);
                    if ($vetCareUser && $vetCareApp) {
                        if ($isHandShakeEnabled == 1) {
                            $userAppStatus=UserAppStatus::where(['user_id'=>$vetCareUser->id,'app_id'=> $vetCareApp->id])->first();
                            $result['subscriptionDate'] = $vetCareUser->created_at;
                            // $result['interval'] = ($vetCareUser->created_at)->diff($now);
                            // $result['days'] = $result['interval']->format('%a');

                            $result['subscriptionDate'] = $userAppStatus->created_at;
                            $result['days'] =$vetCareUser->getActiveDaysAttribute();
                            if ($result['days'] < $daysToActivateEmergency) {
                                $canActivateEmergency = false;
                            }
                        }
                    }
                }
            }
            if($vetCareUser && $canActivateEmergency){
                $nextEmergencyActivation = $vetCareUser->next_emergency_activation_date;
                if($nextEmergencyActivation != null)
                {
                    $result['nextEmergencyActivation'] = $nextEmergencyActivation;
                    $nextEmergencyActivation = Carbon::parse($nextEmergencyActivation);
                    if($nextEmergencyActivation > $now){
                        $canActivateEmergency = false;
                    }
                }
            }
            $result['canActivateEmergency'] = $canActivateEmergency;
            return $this->successResponse($result, 'Vet - Emergency Activation Status');
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(),$e->getCode());
        }
    }

    /**
     * return vet online status
     *
     * @return true/false
     * @throws conditon
     *
     */

    public function isVetOnline(Request $request){

        try{
            $onlineVets = Vet::role('vets')->where('is_online',1)->get();
            if(count($onlineVets) > 0){
                return $this->successResponse(true, count($onlineVets). ' Vet(s) are online');
            }
            else{
                $this->slackLog('All vets are offline','critical');
                return $this->successResponse(false, 'All vets are offline');
            }
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(),$e->getCode());
        }

    }

    //Update Vet Profile
    public function updateProfile($id, VetProfileRequest $request)
    {
        $validated = $request->validated();
        // $this->user = $this->guard()->user();
        $vet = Vet::find($id);
        $data = $validated;
        try {
            $identity = 'app-'.$vet->app_id.'_user-'.$id;
            if($request->hasFile('profile')){
                $data['profile'] = $path = $this->uploadFile($request->profile,'vets');
                $vet->vetDetails()->updateOrCreate(['vet_id'=>$id],['profile'=>$data['profile']]);
                $get_user_channels = $this->fetchUserChannel($identity);
                if($get_user_channels){
                    foreach ($get_user_channels as $channelData){
                        $channel_data = $this->fetchChannel($channelData->channelSid,'arr');
                        $attributes_data = $channel_data->attributes;
                        $json_data = json_decode($attributes_data,true);
                        //dd($json_data['user']['profile']);
                        //$json_data = json_decode($json_data,true);
                        $json_data['vet']['profile'] = $data['profile'];
                        $json_object = json_encode($json_data);
                        $this->updateChannelAttribute($channelData->channelSid,$json_object);
                    }
                }
            }

            $vet->update($validated);
            $response = $vet->load('vetDetails');

            return $this->successResponse($response, 'Successfully Record Updated.');
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }
}
