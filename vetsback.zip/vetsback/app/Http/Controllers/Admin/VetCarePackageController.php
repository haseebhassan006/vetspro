<?php

namespace App\Http\Controllers\Admin;

use App\App;
use App\VetCareUser;
use App\WellnessPlanItem;
use App\VetCarePackage;
use App\VetCarePackageUsage;
use App\VetCareSubscription;
use Illuminate\Http\Request;
use App\VetCarePackageBenefit;
use App\VetCarePackageMetaData;
use App\Http\Controllers\Controller;
use App\Http\Requests\PackageRequest;
use App\Traits\VetCareUserPaymentTrait;
use Stripe\Exception\ApiErrorException;

class VetCarePackageController extends Controller
{
    use VetCareUserPaymentTrait;
    private $noOfRecordPerPage = 10;
    private $paginate = false;

    public function getPackage(Request $request){

        try{
            $data = new VetCarePackage;

            if($request->has('app') && !empty($request->app))
            {
                $data = $data->whereHas('app',function ($q) use ($request) {
                    $q->where('name',$request->app);
                });
            }

            if($request->has('type') && !empty($request->type))
            {
                $data = $data->where('type',$request->type);
            }

            if($request->has('interval') && !empty($request->interval))
            {
                $data = $data->where('interval',$request->interval);
            }

            if($request->has('id') && !empty($request->id))
            {
                $data = $data->where('id',$request->id);
            }
            if($request->has('plan_items') && !empty($request->plan_items) && $request->plan_items==1)
            {
                $data = $data->where('plan_items','<>','');
            }
            if($request->has('plan_items') && empty($request->plan_items))
            {
                $data = $data->where('plan_items','');
            }
            
            // else{
            //     $data = $data->where('plan_items','');
            // }
            
            if (isset($request->pagination) && $request->pagination != "") {
                $this->paginate = true;
                $data = $data->with(['benefit','metadata'])->latest()->paginate($this->noOfRecordPerPage);
            } else {
                $data = $data->with(['benefit','metadata'])->latest()->get();
            }
            // $data = $data->with(['benefit','metadata'])->latest()->get()->makeHidden(['plan_items']);
            //->where('vet_care_id',$find_app->id)
            return $this->successResponse($data, 'Vet Care Package', $this->paginate);
          }
          catch (\Exception $e){
              return $this->errorResponse($e->getMessage(),$e->getCode());
          }

    }

    public function createPackage(PackageRequest $request){

        $validate = $request->validated();
        $plan_items = isset($request->plan_items) && sizeof($request->plan_items)>0 ? $request->plan_items : null ;
        if (!$request->has('interval_count')) {
            $validate['interval_count'] = 1;
        }
        try{
            // if default package exists already
            if($request->is_default == 1){
                $defaultPackageExist = VetCarePackage::where('vet_care_id',$request->vet_care_id)->where('is_default',1)->first();
                if($defaultPackageExist){
                    return $this->errorResponse($defaultPackageExist->name . ' already set as default package.',422);
                }
            }
            $app = App::findOrfail($request->vet_care_id);
            $this->stripeConfig   = config('services.stripe.vetcare');
            if($app && $app->stripe_key != ''){
                $this->stripeConfig   = $app->stripe_key;
            }
            $this->stripe = new \Stripe\StripeClient($this->stripeConfig);
            $model = new VetCarePackage();
            $benefits = null;

            $type = 'one_time';
            if($validate['is_recurring'] == 1){
                $type = 'recurring';
            }
            try{
                $stripePackageData = (collect($validate)->except('rules_and_regulations','faqs'))->toArray();
                //Add product in stripe
                $stripe_package = $this->createStripeProduct($stripePackageData['name'],$stripePackageData,$type);
                if($stripe_package['code'] == 200){
                    $validate['price_id'] = $stripe_package->price_id;
                    $validate['product_id'] = $stripe_package->product_id;
                    $validate['plan_items'] = $plan_items;
                    if($validate['plan_items'] == null){
                        unset($validate['plan_items']);
                    }
                    $data = $model->create($validate);
                    if($data && $request->has('benefits') && (count($request->benefits) > 0) ){
                        $benefits = $data->benefit()->sync($request->benefits);
                        $data['benefits'] = $benefits;
                    }
                    if($data){
                        $metadata = $data->metadata()->create($validate);
                        $data['metadata'] = $metadata;
                    }
                    return $this->successResponse($data, 'Vet Care Package Added');
                }
                else{
                    return $this->errorResponse($stripe_package['message'],$stripe_package['code']);
                }
            }
            catch (ApiErrorException $e){
                return $this->errorResponse($e->getMessage(),$e->getCode());
            }
            }
            catch (Exception $e){
                return $this->errorResponse('Vet Care Package not created. try again');
            }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param int $id
     * @param PackageRequest $request
     * @return \Illuminate\Http\Response
     */
    public function editPackage($id, PackageRequest $request)
    {
        $user = auth()->user();
        $validatedData = $request->validated();
        $plan_items = isset($request->plan_items) && sizeof($request->plan_items)>0 ? $request->plan_items : null ;
        $benefits = null;
        try {

            $model = VetCarePackage::findOrfail($id);
            // if default package exists already
            if($request->is_default == 1){
                $defaultPackageExist = VetCarePackage::where('vet_care_id',$model->vet_care_id)->where('is_default',1)->where('id','!=',$id)->first();
                if($defaultPackageExist && $defaultPackageExist->id != $id){
                    return $this->errorResponse($defaultPackageExist->name . ' already set as default package.',422);
                }
            }

            //Edit on stripe
            if($request->has('is_recurring')){
                // No app_id so 0 ( For)
                $this->initialize($model->app->id);
                $is_recurring = $validatedData['is_recurring'];
                $this->editProduct($model->product_id,$is_recurring);
            }
            $validatedData['plan_items'] = $plan_items;
            if($validatedData['plan_items'] == null){
                unset($validatedData['plan_items']);
            }
            $data = $model->update($validatedData);

            if($data && $request->has('benefits') ){
                $benefits = $model->benefit()->sync($request->benefits);
                $model['benefits'] = $benefits;

            }

            $model->metadata()->updateOrCreate(['package_id'=>$id],$validatedData);

            return $this->successResponse($model::with(['benefits','metadata']), 'Successfully Record Updated.');
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }


    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function deletePackage($id,Request $request)
    {
        $user = auth()->user();
        try {
            $data = VetCarePackage::findOrfail($id)->delete();
            VetCarePackageMetaData::where('package_id',$id)->delete();
            return $this->successResponse($data, 'Successfully Deleted.');
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    /**
     * Remove the specified vetcareUser from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function userDeleted($id,Request $request)
    {
        $message = '';
        try {
            $user = VetCareUser::findOrfail($id);
            if($user){
                if(!empty($user->stripe_id)){
                    $this->initialize($user->app_id);
                    try {
                        $this->deleteCustomer($user->stripe_id);
                        $message = 'Successfully Record Deleted.';

                    } catch (ApiErrorException $e){
                        $message = 'User Deleted from DB but got error from stripe while removing user from stripe. Error Details : '.$e->getMessage();

                    }
                }
            }
            // Mark that deleted by admin or staff
            auth()->user()->hasRole('admin') ? $deleted_by = 'admin' : $deleted_by = 'staff';
            $user->update(['is_deleted_by'=>$deleted_by]);
            $user->delete();
            $data = array(
                "user" => $user
            );
            return $this->successResponse($data, $message);
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    // UnsubscibeUser
    public function unsubscribeUser($id,Request $request){
        try{
            $user = VetCareUser::findOrfail($id);
            //Check for recurring payment
            if($user->usage()->count() > 0){
                $check_interval = VetCarePackage::findOrFail($user->usage[0]->package_id);
                if($check_interval->interval == 'month' || $check_interval->interval == 'day'){
                    $data = VetCareSubscription::where('user_id',$user->id)->firstOrFail();
                    $this->initialize($user->app_id);
                    $stripeResponse = $this->unsubscribe($data->subscription_id);
                    if($stripeResponse){
                        $data->update(['status' => $stripeResponse['status']]);
                    }
                    $data->delete();
                    if($check_interval->type == 'protect'){
                        $user->removeRole('protect_users');
                        $user->assignRole("users");
                    }

                }
                $trash = VetCarePackageUsage::where('user_id',$user->id)->delete();

                return $this->successResponse($trash, 'unsubscribe successful');
            }
            else{
                return $this->errorResponse('This user is not subscribed to any package',406);
            }
        }
        catch (ModelNotFoundException $e){
            return $this->errorResponse('This user is not subscribed to any package',406);
        }
        catch (ApiErrorException $e){
            return $this->errorResponse('Error from stripe while removing user from stripe. Error Details : '.$e->getMessage(), 406);
        }

    }

    public function getwellnessItems(Request $request){
        try{
            $data = WellnessPlanItem::all();
            return $this->successResponse($data, 'Data fetched successful');
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

}
