<?php

namespace App\Http\Controllers\Admin;

use App\FeedbackEmail;
use App\Http\Requests\FeedbackRequest;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Carbon\Carbon;
use Illuminate\Support\Str;
use Validator;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use JWTAuth;
use App\App;

class FeedbackController extends Controller
{

    private $noOfRecordPerPage = 10;
    private $paginate = false;

    public function create(FeedbackRequest $request)
    {
        $validatedData = $request->validated();
        try {
            $find_app = App::where('id',$request->app_id)->first();
            // App not found error
            if (!$find_app) {
                return errorResponse('App Not Found', 404);
            }
            $chk_record = FeedbackEmail::where('email', $request->email)->where('app_id', $request->app_id)->first();
            if (!$chk_record) {
                $data = new FeedbackEmail();
                $data->app_id = $request->app_id;
                $data->email = $request->email;
                $data->save();
                return $this->successResponse($data, 'Successfully Created Feedback Email.');
            } else {
                return $this->errorResponse('Email already exists.',404);
            }
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    public function list(Request $request)
    {
        $input = $request->only('search_value', 'search_by', 'page', 'pagination', 'perPage', 'all', 'email');
        $value = isset($input['search_value']) ? $input['search_value'] : '';
        try{
            $model = new FeedbackEmail();
            if(isset($value) && !empty($value)){
                $model = $model->where('email', 'like', '%'.$value.'%');
            }

            if($request->has('app_id') && !empty($request->app_id)) {
                $feedback_emails = $model->where('app_id',$request->app_id)->get();
            }

            if($request->has('id') && !empty($request->id)) {
                $feedback_emails = $model->where('id',$request->id)->get();
            } else {
                if (isset($input['pagination']) && $input['pagination'] != "") {
                    $this->paginate = true;
                    $feedback_emails = $model->paginate($this->noOfRecordPerPage);
                } else {
                    $feedback_emails = $model->get();
                }
            }

            $data = array(
                "feedback_emails" => $feedback_emails
            );
            return $this->successResponse($data['feedback_emails'], 'Successfully Fetch List Feedback Emails.', $this->paginate);
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    public function update($id, FeedbackRequest $request)
    {
        $validatedData = $request->validated();
        try {
            $find_app = App::where('id',$request->app_id)->first();
            // App not found error
            if (!$find_app) {
                return errorResponse('App Not Found', 404);
            }
            $chk_record = FeedbackEmail::where('email', $request->email)->where('app_id', $request->app_id)->where('id', '<>', $id)->first();
            if (!$chk_record) {
                $data = FeedbackEmail::findOrfail($id);
                $data->app_id = $request->app_id;
                $data->email = $request->email;
                $data->save();
                return $this->successResponse($data, 'Successfully Record Updated.');
            } else {
                return $this->errorResponse('Email already exists.',404);
            }
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    public function deleted($id,Request $request)
    {
        try {
            $data = FeedbackEmail::findOrfail($id);
            $data->delete();
            return $this->successResponse($data, 'Successfully Record Deleted.');
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

}
