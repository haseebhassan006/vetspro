<?php

namespace App\Http\Controllers\Admin;

use App\LinkCategory;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\LinkCategoryRequest;

class LinkCategoryController extends Controller
{
    private $noOfRecordPerPage = 10;
    private $paginate = false;

    public function index(Request $request)
    {

        
        try{
            $data = new LinkCategory();
           
            if($request->has('id') && !empty($request->id))
            {
                $data = $data->where('id',$request->id);
            }
           
            if($request->has('search') && !empty($request->search)){
                $data = $data->where('category_name', 'LIKE', '%' . $request->search . '%');
            }
            if (isset($request['pagination']) && $request['pagination'] != "" ) {
                if($request->has('limit') && !empty($request->limit)){
                    $this->noOfRecordPerPage = $request->limit;
                }
                $this->paginate = true;
                $data = $data->paginate($this->noOfRecordPerPage);
            }else{
                $data = $data->get();
            }
            return $this->successResponse($data, 'Category List of Links ',$this->paginate);
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(),$e->getCode());
        }
    }

    public function create(LinkCategoryRequest $request)
    {
        //
        try{
             $validated = $request->validated();

            $data = LinkCategory::create([
                'category_name' => $request->category
            ]);
            return $this->successResponse($data, 'Link Category Added  ');
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(),$e->getCode());
        }
       
    }

    public function edit(LinkCategoryRequest $request, $id)
    {
        try{
            $validated = $request->validated();
            $data = LinkCategory::updateOrCreate(['id'=>$id], [
                'category_name' => $request->category
            ]
        );
            return $this->successResponse($data, 'Link Category Updated');
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(),$e->getCode());
        }

    }

    public function destroy($id)
    {
        try{
            $data = LinkCategory::find($id)->Delete();
            return $this->successResponse($data, 'Link Category Deleted');
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(),$e->getCode());
        }

    }

}
