<?php

namespace App\Http\Controllers\Admin;

use App\App;
use App\Http\Requests\AppRequest;
use App\Http\Requests\Feedback;
use App\Reason;
use App\Recommendation;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Str;

class ReasonController extends Controller
{
    //
    public function create(Feedback $request)
    {
        $validatedData = $request->validated();
        try {
            $app = Reason::create($validatedData);
            return $this->successResponse($app, 'Reasons success');
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }
    public function update($id, Feedback $request){
        $validatedData = $request->validated();
        try {
            $app = Reason::findOrfail($id);
            $app->update($validatedData);
            return $this->successResponse($app, 'Successfully Record Updated.');
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }
    public function list(){
        try {
            $data = Reason::all();
            return $this->successResponse($data, 'Successfully Record Updated.');
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }
    public function destory($id){
        try {
            $data = Reason::all();
            return $this->successResponse($data, 'Successfully Record Updated.');
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }
}
