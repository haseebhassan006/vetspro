<?php

namespace App\Http\Controllers\Admin;

use App\SubAdmin;
use App\TemplateAttachment;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\TemplateAttachmentRequest;


class TemplateAttachmentController extends Controller
{

    /**
     * @return \Illuminate\Http\Response
     */
    public function createTemplate(TemplateAttachmentRequest $request){
        try{
            $validated = $request->validated();
            $user = auth()->user();
            // $validated['vet_id'] = $user->id;
            if($request->has('image'))
            {
                $validated['image_url'] = $this->uploadFilePublicRepo($request->image,'s3','template_attachments');
            }
            $data = TemplateAttachment::create($validated);
            $user->attachments()->save($data);
            return $this->successResponse($data, 'Template Added');
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(),$e->getCode());
        }
    }

    public function getTemplate(Request $request){
        try{
            $user = auth()->user();
            $data = $user->attachments();
            if($request->has('type') && $request->type == 'all')
            {
                $data = new TemplateAttachment;
            }
            if($request->has('id') && !empty($request->id))
            {
                $data = $data->where('id',$request->id);
            }
            $data = $data->get();
            return $this->successResponse($data, 'My Template');
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(),$e->getCode());
        }
    }
    /**
     * @param TemplateRequest $request
     * @param $id
     * @return \Illuminate\Http\Response
     */
    public function editTemplate(TemplateAttachmentRequest $request, $id){
        try{
            $validated = $request->validated();
            $user = auth()->user();
            // $validated['vet_id'] = $user->id;
            if($request->has('image'))
            {
                $validated['image_url'] = $this->uploadFilePublicRepo($request->image,'s3','template_attachments');
            }
            $data = TemplateAttachment::updateOrCreate(['id'=>$id],$validated);
            return $this->successResponse($data, 'Template Edited');
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(),$e->getCode());
        }
    }
    /**
     * @param $id
     * @return \Illuminate\Http\Response
     */
    public function deleteTemplate($id){
        try{
            $data = TemplateAttachment::find($id)->delete();
            return $this->successResponse($data, 'Template Deleted');
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(),$e->getCode());
        }
    }
}
