<?php

namespace App\Http\Controllers\Admin;

use App\Http\Requests\Feedback;
use App\Recommendation;
use App\Http\Controllers\Controller;

class RecommendationController extends Controller
{
    //
    public function create(Feedback $request)
    {
        $validatedData = $request->validated();
        try {
            $app = Recommendation::create($validatedData);
            return $this->successResponse($app, 'Recommendation success');
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    public function update($id, Feedback $request){
        $validatedData = $request->validated();
        try {
            $app = Recommendation::findOrfail($id);
            $app->update($validatedData);
            return $this->successResponse($app, 'Successfully Record Updated.');
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }
    public function list(){
        try {
            $data = Recommendation::all();
            return $this->successResponse($data, 'Successfully Record Updated.');
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }
}
