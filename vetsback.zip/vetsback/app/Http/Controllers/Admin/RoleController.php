<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\RoleRequest;
use Carbon\Carbon;
use Validator;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use JWTAuth;
use App\Role;

class RoleController extends Controller
{
    public function create(RoleRequest $request)
    {
        $validatedData = $request->validated();
        try {
            $role = Role::create($validatedData);
            
            $data = array(
                "role" => $role
            );
            return $this->successResponse($data, 'Successfully Created Role.');
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }
    public function list()
    {
        try {
            $role = Role::get();
            $data = array(
                "role" => $role
            );
            return $this->successResponse($data, 'Successfully Fetch List Role.');
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }
    public function get($id, RoleRequest $request)
    {
        try {
            $role = Role::findOrfail($id);
            $data = array(
                "role" => $role
            );
            return $this->successResponse($data, 'Successfully Record Get.');
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }
    public function update($id, RoleRequest $request)
    {
        $validatedData = $request->validated();
        try {
            $role = Role::findOrfail($id);
            $role->update($validatedData);
            $data = array(
                "role" => $role
            );
            return $this->successResponse($data, 'Successfully Record Updated.');
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    public function deleted($id, RoleRequest $request)
    {
        try {
            $role = Role::findOrfail($id);
            $role->delete();
            $data = array(
                "role" => $role
            );
            return $this->successResponse($data, 'Successfully Record Deleted.');
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }
}
