<?php

namespace App\Http\Controllers\Admin;

use App\VideoGallery;
use App\VideoGalleryCategory;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\VideoGalleryRequest;



class VideoGalleryController extends Controller
{

    private $noOfRecordPerPage = 10;
    private $paginate = false;

    /**
     * @return \Illuminate\Http\Response
     */
    public function create(VideoGalleryRequest $request){
        try{
            $validated = $request->validated();
            if($validated['is_visible']===false ){
                $validated['is_visible'] = 'false';
            }
            $data = VideoGallery::create($validated);
            return $this->successResponse($data, 'Video Added to Gallery');
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(),$e->getCode());
        }
    }

    public function index(Request $request){
        try{
            // $data = new VideoGallery();
            $data = VideoGallery::with('videoGalleryCategory');
            
            // $data = $data->with('videoGalleryCategory');
            // Only Visible 
            if(request()->has('visible') && !empty(request()->visible) && request()->visible!= 'false')
            {
                $data = $data->where('is_visible',true);
            }
            if($request->has('id') && !empty($request->id))
            {
                $data = $data->where('id',$request->id);
            }
            if($request->has('video_url') && $request->video_url == true)
            {
                $data = $data->where('video_url','!=','');
            }
            if($request->has('category') && !empty($request->category))
            {
                $category=$request->category;
                $data = $data->whereHas('videoGalleryCategory',function($q) use ($category){
                    $q->where('id','=',$category);
                });
            }
            if($request->has('search') && !empty($request->search)){
                $data = $data->where('title', 'LIKE', '%' . $request->search . '%');
            }
            if (isset($request['pagination']) && $request['pagination'] != "") {
                if($request->has('limit') && !empty($request->limit)){
                    $this->noOfRecordPerPage = $request->limit;
                }
                $this->paginate = true;
                $data = $data->paginate($this->noOfRecordPerPage);
            }else{
                $data = $data->get();
            }
            return $this->successResponse($data, 'Gallery Videos',$this->paginate);
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(),$e->getCode());
        }
    }

    /**
     * @param TemplateRequest $request
     * @param $id
     * @return \Illuminate\Http\Response
     */
    public function edit(VideoGalleryRequest $request, $id){
        try{
            $validated = $request->validated();
            if($validated['is_visible']===false ){
                $validated['is_visible'] = 'false';
            }
            $data = VideoGallery::updateOrCreate(['id'=>$id],$validated);
            return $this->successResponse($data, 'Gallery Video Edited');
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(),$e->getCode());
        }
    }

    public function delete(Request $request,$id){
        try{
            $data = VideoGallery::find($id)->Delete();
            return $this->successResponse($data, 'Video Deleted');
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(),$e->getCode());
        }
    }

    public function videoList(Request $request){
        try{
            // Only Visible 
            $data = VideoGalleryCategory::with(['video'=>function($q){
                $q->where('is_visible',true);
                $q->where('video_url','!=','');
            }]);
          
            if($request->has('id') && !empty($request->id))
            {
                $data = $data->where('id',$request->id);
            }

            if($request->has('search') && !empty($request->search)){
                $search_value=$request->search;
                // $data = $data->whereHas('video',function ($q) use ($search_value) {
                //     $q->where('title', 'LIKE', '%' . $search_value . '%');
                // });
                $data = $data->with(['video'=>function($q) use ($search_value){
                    $q->where('is_visible',true);
                    $q->where('video_url','!=','');
                    $q->where('title', 'LIKE', '%' . $search_value . '%');

                }]);
                // $data = $data->where('title', 'LIKE', '%' . $request->search . '%');
            }
            if (isset($request['pagination']) && $request['pagination'] != "") {
                if($request->has('limit') && !empty($request->limit)){
                    $this->noOfRecordPerPage = $request->limit;
                }
                $this->paginate = true;
                $data = $data->paginate($this->noOfRecordPerPage);
            }else{
                $data = $data->get();
            }
            return $this->successResponse($data, 'Gallery Videos',$this->paginate);
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(),$e->getCode());
        }
    }
}
