<?php

namespace App\Http\Controllers\Admin;

use App\User;
use App\VideoCall;
use App\WebappUser;
use Aws\S3\S3Client;
use App\VideoCallMedia;
use Illuminate\Filesystem\Cache;
use Illuminate\Http\Request;
use Spatie\Searchable\Search;
use Aws\Credentials\Credentials;
use function foo\func;
use function GuzzleHttp\Psr7\str;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use App\Http\Resources\VideoCallLog;
use App\Traits\SearchFullNameWithSpacesTrait;

class VideoCallController extends Controller
{
    private $noOfRecordPerPage = 10;
    private $paginate = false;
    use SearchFullNameWithSpacesTrait;

    public function index2(Request $request){
        $input = $request->only('search_value', 'search_by', 'page', 'pagination', 'perPage', 'filter');
        $value = isset($input['search_value'])?$input['search_value']:'';
        $search_by = isset($input['search_by'])?$input['search_by']:'';
        $search_column =  isset($input['filter'])?$input['filter']:'';
        $model = new VideoCall();
        if(isset($value) && !empty($value)){
            if($search_by == 'room_sid'){
                $model = $model->where('room_sid',$value);
                $model = $model->with(['history'=>function($q){
                    $q->select('video_call_id','status');
                },'user','vet','app','webapps','guest','mediaUrl'])->latest();
            }
            else{
                //Custom Logic for search
                $model = $model->with(['history','mediaUrl'])
                    ->orWhereHas('user',function($q) use ($value,$search_by,$search_column){
                        //$query = $this->key_value_search($q,$search_column,$value);
                        $q->where(function($query) use ($value){
                            $query->where('first_name', 'LIKE', $value.'%');
                            $query->orWhere('last_name', 'LIKE', '%'.$value);
                            $query->orWhere('email', 'LIKE', '%'.$value.'%');
                        });

//                                $q->where('email',$value)->orWhere('first_name','LIKE', $value.'%')->orWhere('last_name',$value);
//                            $q->where('email',$value)->orWhere('first_name',$value)->orWhere('last_name',$value);
                    })->orWhereHas('vet',function($q) use ($value,$search_by,$search_column){
                        $q->where(function($query) use ($value){
                            $query->where('first_name', 'LIKE', $value.'%');
                            $query->orWhere('last_name', 'LIKE', '%'.$value);
                            $query->orWhere('email', 'LIKE', '%'.$value.'%');
                        });
//                            $q->where('email',$value)->orWhere('first_name',$value)->orWhere('last_name',$value);
                    })->orWhereHas('webapps',function($q) use ($value,$search_by,$search_column){
                        $q->where(function($query) use ($value){
                            $query->where('first_name', 'LIKE', $value.'%');
                            $query->orWhere('last_name', 'LIKE', '%'.$value);
                            $query->orWhere('email', 'LIKE', '%'.$value.'%');
                        });
                    })->orWhereHas('app',function($q) use ($value,$search_by){
                        $q->where('name',$value);
//                            $q->where('name',$value);
                    })
                    ->orWhereHas('guest',function($q) use ($value,$search_by){
                        $q->where(function($query) use ($value){
                            $query->where('first_name', 'LIKE', $value.'%');
                            $query->orWhere('last_name', 'LIKE', '%'.$value);
                            $query->orWhere('email', 'LIKE', '%'.$value.'%');
                        });
                    })
                    ->latest()
                    ->whereRaw('id IN (select MAX(id) from video_calls GROUP BY room_sid)');
                //->orWhere('room_sid',$value);
                //$this->noOfRecordPerPage = $model->count();

            }
        }
        else{
            $model = $model->with(['history'=>function($q){
                $q->select('video_call_id','status');
            },'user','vet','app','webapps','guest','mediaUrl'])
                ->latest()
                ->whereRaw('id IN (select MAX(id) from video_calls GROUP BY room_sid)');
        }
        try{
            $paginator = array();
            if (isset($input['pagination']) && $input['pagination'] != "") {
                $this->paginate = true;
                $user = $model->paginate($this->noOfRecordPerPage);
                $paginator = VideoCallLog::collection($user);

            } else {
                $user_id = $input['user_id'];
                $user = $model->find($user_id);
            }
            return $this->successResponse($paginator, 'Successfully loading video calls.',$this->paginate);
        } catch (\Exception $e) {
            return $this->errorResponse($e->getTraceAsString(), $e->getCode());
        }
    }

    public function index(Request $request){
        $input = $request->only('search_value', 'search_by', 'page', 'pagination', 'perPage', 'filter','export','user_id', 'date_from', 'date_to' , 'type');
        $value = isset($input['search_value'])?$input['search_value']:'';
        $search_by = isset($input['search_by'])?$input['search_by']:'';
        $search_column =  isset($input['filter'])?$input['filter']:'';
        $type = @$input['type'];
        $export = @$input['export'];
        $model = new VideoCall();

        if(isset($value) && !empty($value)){

                if($search_by == 'room_sid'){
                    $model = $model->where('room_sid',$value);
                    $model = $model->with(['history'=>function($q){
                        $q->select('video_call_id','status');
                    },'user','vet','app','webapps','guest','mediaUrl','webapps.emergencyLatest'])->latest();
                }
                else{
                    //Custom Logic for search
                    $model = $model->with(['history','mediaUrl','webapps.emergencyLatest'])
                        ->orWhereHas('user',function($q) use ($value,$search_by,$search_column,$request){
                                //$query = $this->key_value_search($q,$search_column,$value);

                                if ($request->has('type') && $request->type != '') {
                                    $type = $request->type;
                                    $q->whereRaw('users.app_id = video_calls.app_id');
                                    $q->whereHas('roles',function ($q) use ($type){
                                        $q->where('name',$type);
                                    });
                                }
                                if ($request->has('date_from') && $request->has('date_to')) {
                                    $q->where(function ($q) use ($request) {
                                        $q->whereBetween('video_calls.created_at',
                                            [date('Y-m-d', strtotime($request->date_from)), date('Y-m-d', strtotime($request->date_to))]
                                        );
                                    });
                                }
                                $q->where(function($query) use ($value){
                                    $query = $this->SearchFullNameWithSpaces($query,$value);
                                    $query->orWhere('email', 'LIKE', '%'.$value.'%');
                                });

//                                $q->where('email',$value)->orWhere('first_name','LIKE', $value.'%')->orWhere('last_name',$value);
//                            $q->where('email',$value)->orWhere('first_name',$value)->orWhere('last_name',$value);
                        })->orWhereHas('vet',function($q) use ($value,$search_by,$search_column,$request){
                            if ($request->has('date_from') && $request->has('date_to')) {
                                $q->where(function ($q) use ($request) {
                                    $q->whereBetween('video_calls.created_at',
                                        [date('Y-m-d', strtotime($request->date_from)), date('Y-m-d', strtotime($request->date_to))]
                                    );
                                });
                            }
                            $q->where(function($query) use ($value){
                                $query = $this->SearchFullNameWithSpaces($query,$value);
                                $query->orWhere('email', 'LIKE', '%'.$value.'%');
                            });
//                            $q->where('email',$value)->orWhere('first_name',$value)->orWhere('last_name',$value);
                        })->orWhereHas('webapps',function($q) use ($value,$search_by,$search_column,$request){
                            if ($request->has('type') && $request->type != '') {
                                $type = $request->type;
                                $q->whereRaw('webapp_users.app_id = video_calls.app_id');
                                $q->whereHas('emergencyLatest',function ($q) use ($type){
                                    $q->where('protected',$type);
                                });
                            }

                            if ($request->has('date_from') && $request->has('date_to')) {
                                $q->where(function ($q) use ($request) {
                                    $q->whereBetween('video_calls.created_at',
                                        [date('Y-m-d', strtotime($request->date_from)), date('Y-m-d', strtotime($request->date_to))]
                                    );
                                });
                            }
                            $q->where(function($query) use ($value){
                                $query = $this->SearchFullNameWithSpaces($query,$value);
                                $query->orWhere('email', 'LIKE', '%'.$value.'%');
                            });
                            $q->whereHas('emergencyLatest');
                        })->orWhereHas('app',function($q) use ($value,$search_by){
                                $q->where('name',$value);
//                            $q->where('name',$value);
                        })
                        ->orWhereHas('guest',function($q) use ($value,$search_by,$request){
                            if ($request->has('date_from') && $request->has('date_to')) {
                                $q->where(function ($q) use ($request) {
                                    $q->whereBetween('video_calls.created_at',
                                        [date('Y-m-d', strtotime($request->date_from)), date('Y-m-d', strtotime($request->date_to))]
                                    );
                                });
                            }
                            $q->where(function($query) use ($value){
                                $query = $this->SearchFullNameWithSpaces($query,$value);
                                $query->orWhere('email', 'LIKE', '%'.$value.'%');
                            });
                        })
                        ->orderBy('start_time','desc')
                        ->whereRaw('id IN (select MAX(id) from video_calls GROUP BY room_sid)');
                    //->orWhere('room_sid',$value);
                    //$this->noOfRecordPerPage = $model->count();

                }
        }
        else{
            if (isset($type) && !empty($type)) {
                $model = $model->with(['history'=>function($q) use ($type){
                    $q->select('video_call_id','status');
                },'vet','app','guest','mediaUrl']);

                $model = $model->where(function($q) use ($type) {

//                    $q->whereHas('guest', function ($q) use ($type) {
//                        $q = $q->withTrashed();
//                        $q->whereRaw('guests.app_id = video_calls.app_id');
//                    });

                    $q->whereHas('vcUser', function ($q) use ($type) {
                        $q = $q->withTrashed();
                        $q->whereRaw('vet_care_users.app_id = video_calls.app_id');
                        $q->whereHas('roles', function ($q) use ($type) {
                            $q->where('name', $type);
                        });
                    });

                    $q->orWhereHas('user', function ($q) use ($type) {
                        $q = $q->withTrashed();
                        $q->whereRaw('users.app_id = video_calls.app_id');
                        $q->whereHas('roles', function ($q) use ($type) {
                            $q->where('name', $type);
                        });
                    });

                    $q->orWhereHas('webapps', function ($q) use ($type) {
                        $q = $q->withTrashed();
                        $q->whereRaw('webapp_users.app_id = video_calls.app_id');
                        $q->where(function ($q) use ($type) {
                            $q->whereRaw("'" . $type . "' = (select protected from webapps_users_extra where webapp_users.id = webapps_users_extra.user_id and webapps_users_extra.type = 'video' order by id desc limit 1)");
                        });
                    });
                });

            }
            else{
                $model = $model->with(['history'=>function($q) use ($type){
                    $q->select('video_call_id','status');
                },'user','vet','app','webapps'=>function($q) use ($type){
                    $q->with(['emergencyLatest']);
                },'guest','mediaUrl']);
            }

//                if (isset($type) && !empty($type)) {
//                    $model->whereHas('user.roles',function ($q) use ($type){
//                        $q->where('name',$type);
//                    })->orWhereHas('webapps',function ($q) use ($type) {
//                            $q->whereHas('emergencyLatest',function ($q) use ($type){
//                                $q->where('protected',$type);
//                            });
//                        });
//                    //dd($model->toSql(),$model->getBindings());
//                }
                $model->latest()
                ->whereRaw('id IN (select MAX(id) from video_calls GROUP BY room_sid)');
//            dd($model->toSql(),$model->count());
        }
        if ($request->has('date_from') && $request->has('date_to')) {
            $model = $model->whereBetween('created_at',
                [date('Y-m-d', strtotime($input['date_from'])), date('Y-m-d', strtotime($input['date_to']))]
            );
        }
        try{
            $response = array();
//            get_sql($model);

            if (isset($input['pagination']) && $input['pagination'] != "") {
                $this->paginate = true;
                $user = $model->paginate($this->noOfRecordPerPage);
                $response = VideoCallLog::collection($user);

            } elseif($export == 'true' || $export == true) {
                $response = VideoCallLog::collection($model->get());

            } else {
                $user_id = $input['user_id'];
                $response = $model->find($user_id);
                $response = VideoCallLog::make($response);
            }

            return $this->successResponse($response, 'Successfully loading video calls.',$this->paginate);
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    public function get_video_link($id,$file_name){
        try{
                //$model = new VideoCall();
                $credentials = new Credentials(env('AWS_ACCESS_KEY_ID'), env('AWS_SECRET_ACCESS_KEY'));
                $s3 = new S3Client([
                    'version' => 'latest',
                    'region'  =>   env('AWS_DEFAULT_REGION'),
                    'credentials' => $credentials,
                    'bucket'=>env('AWS_STAG_VIDEO')
                ]);
                $presignedUrl = null;
                $response = $s3->doesObjectExist(env('AWS_STAG_VIDEO'), $file_name.'.mp4');
                if($response){
                    $cmd = $s3->getCommand('GetObject', [
                        'Bucket' => env('AWS_STAG_VIDEO'),
                        'Key' =>$file_name.'.mp4'
                    ]);

                    //Pre Signed URL work
                    $request = $s3->createPresignedRequest($cmd, '+30 minutes');
                    $presignedUrl = (string)$request->getUri();
//                $model = VideoCall::where('room_sid',$file_name)->whereNotNull('end_time')->whereNotNull('start_time')->first();
                    $get_video = VideoCall::find($id);
                    if(isset($get_video->end_time) && !empty($get_video->end_time)){
                        VideoCallMedia::updateOrCreate(['video_call_id'=>$id],[
                            'media_url' => $presignedUrl,
                            'video_call_id'=>$id
                        ]);
                    }
                }

//                $current_time = $model->start_time;
//                $model->start_time = $current_time;
//                $model->created_at = $current_time;
//                $model->media_url = $presignedUrl;
//                $model->save();
                return $this->successResponse($presignedUrl,'Video call url');
        }
        catch (\Exception $e) {
            return $this->errorResponse($e->getTraceAsString(), $e->getCode());
        }
    }

    public function history($id){
        try{
            // $data = VideoCall::with(['history','vet'=>function($q){
            //     $q->with(['notification'=>function($q){
            //         $q->select('user_to_notify','seen_by_user');
            //     }]);
            // }])->where('room_sid',$id)->get();
            
            //changed relation as vet and staff bot can have call 
            $data = VideoCall::with(['history','model'=>function($q){
                $q->with(['notification'=>function($q){
                    $q->select('user_to_notify','seen_by_user');
                }]);
            }])->where('room_sid',$id)->get();

            return $this->successResponse($data,'Room history');
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getTraceAsString(), $e->getCode());
        }

    }

    protected function key_value_search($q,$search_column,$value){
//        if($search_column == 'first_name'){
//            $q->where('first_name',$value);
//        }
//        if($search_column == 'last_name'){
//            $q->where('last_name',$value);
//        }
//        if($search_column == 'email'){
//            $q->where('email',$value);
//        }
        switch ($search_column){
            case 'first_name':
                $query = $q->where('first_name',$value);
                break;
            case 'last_name':
                $query =  $q->where('last_name',$value);
                break;
            case 'email':
                $query = $q->where('email',$value);
                break;
            default:
                $query =  $q->search($value);
        }
        return $query;


    }
}
