<?php

namespace App\Http\Controllers\Admin;

use App\StaffNote;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;


class StaffNoteController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function getNote(Request $request)
    {
      
        try{
            $data = new StaffNote;
            $data = $data->with('notable');
            if($request->has('id') && !empty($request->id))
            {
                $data = $data->where('id',$request->id);
            }
            $data = $data->latest()->get();
            return $this->successResponse($data, 'All Notes');
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(),$e->getCode());
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function createNote(Request $request)
    {
        $user = auth()->user();
        try {
            $input = $request->only(['body', 'status']);
            $data = $user->notable()->create($input);
            return $this->successResponse($data, 'Note Added');
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }

    }


    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\StaffNote  $staffNote
     * @return \Illuminate\Http\Response
     */
    public function editNote($id,Request $request)
    {
        try{
            $input = $request->only(['body', 'status']);
            $user = auth()->user();
            $data = StaffNote::updateOrCreate(['id'=>$id],$input);
            return $this->successResponse($data, 'Note Edited');
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(),$e->getCode());
        }
    }

    
    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\StaffNote  $staffNote
     * @return \Illuminate\Http\Response
     */
    public function deleteNote($id)
    {
        try{
            $data = StaffNote::find($id)->delete();
            return $this->successResponse($data, 'Note Deleted');
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(),$e->getCode());
        }
    }
}
