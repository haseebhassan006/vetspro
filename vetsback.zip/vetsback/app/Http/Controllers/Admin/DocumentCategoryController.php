<?php

namespace App\Http\Controllers\Admin;

use App\DocumentCategory;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\DocumentCategoryRequest;

class DocumentCategoryController extends Controller
{

    private $noOfRecordPerPage = 10;
    private $paginate = false;

    public function index(Request $request)
    {
        try{
            $data = new DocumentCategory();
          
           
            if($request->has('search') && !empty($request->search)){
                $data = $data->where('name', 'LIKE', '%' . $request->search . '%');
            }
            if (isset($request['pagination']) && $request['pagination'] != "" ) {
                if($request->has('limit') && !empty($request->limit)){
                    $this->noOfRecordPerPage = $request->limit;
                }
                $this->paginate = true;
                $data = $data->paginate($this->noOfRecordPerPage);
            }else{
                $data = $data->get();
            }
            return $this->successResponse($data, 'Category List of Documents',$this->paginate);
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(),$e->getCode());
        }
    }

    public function store(DocumentCategoryRequest $request){

        $validatedData = $request->validated();

        try {
            $app = DocumentCategory::create($validatedData);
            return $this->successResponse($app, 'Reasons success');
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }

    }

    public function update(DocumentCategoryRequest $request, $id)
    {
        try{
            $validated = $request->validated();
            $data = DocumentCategory::updateOrCreate(['id'=>$id],$validated);
            return $this->successResponse($data, 'Category Updated');
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(),$e->getCode());
        }

    }

    public function destroy($id)
    {

    
        try{
            $data = DocumentCategory::find($id)->Delete();
            return $this->successResponse($data, 'Category Deleted');
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(),$e->getCode());
        }

    }
}
