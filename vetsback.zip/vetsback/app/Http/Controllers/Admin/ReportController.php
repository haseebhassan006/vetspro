<?php

namespace App\Http\Controllers\Admin;

use App\App;
use App\Vet;
use App\User;
use App\Guest;
use App\Coupon;
use App\Package;
use App\Payment;
use App\VetCare;
use App\Feedback;
use App\WebappUser;
use App\CouponUsage;
use App\VetCareUser;
use App\NoteProectUser; //NoteProectUser
use App\PackageUsage;
use App\UserAppStatus;
use App\VetCareCoupon;
use function foo\func;
use App\EmergencyVetClient;
use App\VetCareCouponUsage;
use App\BouncingVetCareUser;
use App\Traits\CustomSearch;
use App\VetCareUserFeedback;
use Illuminate\Http\Request;
use App\Traits\FullTextSearch;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Database\QueryException;
use App\Http\Resources\CouponUsageResource;
use App\Http\Resources\EmergencyClubReport;
use App\Http\Resources\UserPaymentResource;
use App\Http\Resources\VetCareUserPaymentResource;
use App\Http\Resources\VetFeedbackResource;
use App\Http\Resources\ProtectUserDataReport;
use App\Http\Resources\VatCareProtectUserReport;
use App\Traits\SearchFullNameWithSpacesTrait;
use App\Http\Resources\VetCareUserListResource;
use App\VetCareCouponCode;

class ReportController extends Controller
{
    //
    private $noOfRecordPerPage = 10;
    private $paginate = false;
    use SearchFullNameWithSpacesTrait;
    use CustomSearch;



    public function getAllUsers(Request $request)
    {
        $input = $request->only('search_value', 'search_by', 'page', 'pagination', 'perPage', 'type');
        $type = lcfirst($request->type);
        $app = $this->find_app($request->api_key);

        try {
            switch ($type) {
                case 'webapp':
                    $app_id = $app->id;
                    if ($request->has('search')) {
                        $value = $input['search_value'];
                        //$model = WebappUser::search($value);
                        $model = WebappUser::search($value);
//                        $model = $this->SearchFullNameWithSpaces($model,$value);
                        $model =$model->select('id', 'first_name', 'last_name', 'email')
                            ->with(['userExtraData','emergency' => function ($query) use ($value) {
                                $query->search($value)->select('user_id', 'type', 'protected', 'created_at', 'vet_id')->latest()
                                    ->with(['vetData' => function ($q) use ($value) {
                                        $q->search($value)->select('id', 'first_name', 'last_name');
                                    }]);
                            }, 'user_status' => function ($q) {
                                $q->select('id', 'user_id', 'status');
                                //->whereRaw('id IN (select MAX(id) from user_app_statuses GROUP BY user_id)');
                            }])->where('app_id', $app_id);

                    } else {
                        $model = WebappUser::select('id', 'first_name', 'last_name', 'email')->with(['userExtraData','emergency' => function ($q) {
                            $q->select('user_id', 'type', 'protected', 'vet_id', 'created_at')->latest()->with(['vetData' => function ($q) {
                                $q->select('id', 'first_name', 'last_name');
                            }]);
                        }, 'user_status' => function ($q) {
                            $q->select('id', 'user_id', 'status');
                            //->whereRaw('id IN (select MAX(id) from user_app_statuses GROUP BY user_id)');
                        }])->where('app_id', $app_id)->latest();
                    }
                    break;
                case 'whitelabel';
                    $app_id = $app->id;
                    if ($request->has('search')) {
                        $value = $input['search_value'];
                        $model = User::search($value)->with(['emergency' => function ($q) use ($value) {
                            $q->search($value)->select('user_id', 'type', 'is_protect', 'vet_id')->with(['vetData' => function ($q) use ($value) {
                                $q->search($value)->select('id', 'first_name', 'last_name');

                            }]);
                        }]);
//                        $model = $this->SearchFullNameWithSpaces($model,$value);
                        $model = $model->latest();
                    } else {
                        $model = User::with(['emergency' => function ($q) {
                            $q->select('user_id', 'type', 'is_protect', 'vet_id')->with(['vetData' => function ($q) {
                                $q->select('id', 'first_name', 'last_name');
                            }]);
                        }])->where('app_id', $app_id)->latest();
                    }
                    break;
                case 'sdk':
                    $app_id = $app->id;
                    $model = new Guest();
                    if ($request->has('search')) {
                        $value = $input['search_value'];
                        $model = $model->where('email','Like','%'.$value.'%')->orWhere('first_name',$value)->orWhere('last_name',$value);
//                        $model->search($value);
                    }
                    $model = $model->where('app_id', $app_id)->latest();
                    break;
            }

            if (isset($input['pagination']) && $input['pagination'] != "") {
                $this->paginate = true;
                $data = $model->paginate($this->noOfRecordPerPage);
            } else {
                $data = $model->get();
            }

            return $this->successResponse($data, 'Loaded successfully', $this->paginate);
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    public function protectedUsersOld(Request $request)
    {

        $isProtected = ($request->has('type') && $request['type'] == "true") ? true : false;
        $input = $request->only('search_value', 'search_by', 'page', 'pagination', 'perPage', 'api_key', 'type', 'date_from', 'date_to', 'app_id', 'pet_species');
        try {
            $value = isset($input['search_value']) ? $input['search_value'] : '';
            $data = new EmergencyVetClient();
            //$vetCareAppsOnly = App::where('app_type','whitelabel-webapp')->pluck('id');
            //$data = $data->whereNotIn('app_id',$vetCareAppsOnly);

            if ($request->has('date_from') && $request->has('date_to')) {
                $data = $data->whereBetween('created_at',
                    [$input['date_from'] . " 00:00:00", $input['date_to'] . " 23:59:00"]
                );
            }

            //If Search Value exist
            if (isset($value) && !empty($value) && !$request->has('app_id') && !$request->has('pet_species')) {
                $data = $data->orWhereHas('vetData', function ($q) use ($value) {
                    $q->where('email', $value);
                    $q = $this->SearchFullNameWithSpaces($q,$value);
                })->orWhereHas('webappData', function ($q) use ($value) {
                    $q->where('email', $value);
                    $q = $this->SearchFullNameWithSpaces($q,$value);
                    $q->with('comments');
                })->orWhereHas('userData', function ($q) use ($value) {
                    $q->Where('email', $value);
                    $q = $this->SearchFullNameWithSpaces($q,$value);
                })->orWhereHas('appData', function ($q) use ($value) {
                    $q->where('name', $value);
                })->when($isProtected, function ($q, $isProtected) {
                    $q->where('is_protect', $isProtected);
                })
                    ->with(['flagsEmergency' => function ($q) {
                        $q->latest();
                    }, 'notesEmergency' => function ($q) {
                        $q->latest();
                    }, 'userData.pets', 'webappData.pets'])
                    ->latest();


            } // If Searching by app_id
            elseif ($request->has('app_id') && !$request->has('pet_species')) {
                $data = $data->whereHas('appData', function ($q) use ($value, $input) {
//                    if (isset($value) && !empty($value)) {
//                        $q->where('name', $value);
//                    }
                    $q->where('id', $input['app_id']);
                })->orWhereHas('vetData', function ($q) use ($value, $input) {
                    if (isset($value) && !empty($value)) {
                        $q->where('email', $value);
                        $q = $this->SearchFullNameWithSpaces($q,$value);
                    }
                    $q->where('app_id', $input['app_id']);
                })->orWhereHas('webappData', function ($q) use ($value, $input) {
                    if (isset($value) && !empty($value)) {
                        $q->where('email', $value);
                        $q = $this->SearchFullNameWithSpaces($q,$value);
                        $q->with('comments');
                    }
                    $q->where('app_id', $input['app_id']);
                })->orWhereHas('userData', function ($q) use ($value, $input) {
                    if (isset($value) && !empty($value)) {
                        $q->Where('email', $value);
                        $q = $this->SearchFullNameWithSpaces($q,$value);
                    }
                    $q->where('app_id', $input['app_id']);
                })->when($isProtected, function ($q, $isProtected) {
                    $q->where('is_protect', $isProtected);
                })->with(['flagsEmergency' => function ($q) {
                        $q->latest();
                    }, 'notesEmergency' => function ($q) {
                        $q->latest();
                    }, 'userData.pets', 'webappData.pets'])
                    ->latest();


            } // If Searching by pet_species for pets and extra-pets
            elseif ($request->has('pet_species')) {
                $data = $data->orWhereHas('vetData', function ($q) use ($value) {
                    $q->where('email', $value);
                    $q = $this->SearchFullNameWithSpaces($q,$value);
                })->orWhereHas('webappData', function ($q) use ($value) {
                    $q->where('email', $value);
                    $q = $this->SearchFullNameWithSpaces($q,$value);
                    $q->with('comments');
                })->orWhereHas('userData', function ($q) use ($value) {
                    $q->where('email', $value);
                    $q = $this->SearchFullNameWithSpaces($q,$value);
                })->orWhereHas('appData', function ($q) use ($value) {
                    $q->where('name', $value);
                })->when($isProtected, function ($q, $isProtected) {
                    $q->where('is_protect', $isProtected);
                })
                    ->with(['flagsEmergency' => function ($q) {
                        $q->latest();
                    }, 'notesEmergency' => function ($q) {
                        $q->latest();
                    }, 'userData.pets' => function ($q) use ($input) {
                        $q->where('species', $input['pet_species']);
                    }, 'webappData.pets' => function ($q) use ($input) {
                        $q->where('species', $input['pet_species']);
                    }
                    ])
                    ->latest();

            }
            else {
                $data = $data->with(['vetData', 'webappData', 'userData', 'userData.pets', 'webappData.pets', 'appData', 'flagsEmergency' => function ($q) {
                    $q->latest();
                }, 'notesEmergency' => function ($q) {
                    $q->latest();
                }])->when($isProtected, function ($q, $isProtected) {
                    $q->where('is_protect', $isProtected);
                })->latest();

            }
            //dd($data->paginate(3));

            if (isset($input['pagination']) && $input['pagination'] != "") {
                $this->paginate = true;
                $data = $data->paginate($this->noOfRecordPerPage);
            } else {
                $data = $data->get();
            }

            //$data = EmergencyClubReport::collection($data);

            return $this->successResponse($data, 'Successfully records fetched', $this->paginate);
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    public function protectedUsers(Request $request)
    {

        $isProtected = ($request->has('type') && $request['type'] == "true") ? true : false;
        $input = $request->only('search_value', 'search_by', 'page', 'pagination', 'perPage', 'api_key', 'type', 'date_from', 'date_to', 'app_id', 'pet_species');

        try {
            $value = isset($input['search_value']) ? $input['search_value'] : '';

            if ($request->has('app_type') == 'whitelabel-webapp') {
                $data = EmergencyVetClient::whereHas('appData', function($q){
                    $q->where('app_type', 'whitelabel-webapp');
                });
            }else{
                // $data = new EmergencyVetClient();
                $data = EmergencyVetClient::where('is_protect',true)->whereHas('appData', function($q){
                    $q->where('app_type', '!=', 'whitelabel-webapp');
                });
            }
            $data = $data->with('vetDataWithTrashed','appData','vetCareUserDataWithThrashed','webappDataWithThrashed','userDataWithTrashed');

            //If Search Value exist
            if (isset($value) && !empty($value)) {
                $data = $data->whereHas('vetData', function ($q) use ($value, $input, $request) {
                    if ($request->has('date_from') && $request->has('date_to')) {
                        $q->where(function ($q) use ($request) {
                            $q->whereBetween('user_protect_users.created_at',
                                [$request->date_from . " 00:00:00", $request->date_to . " 23:59:59"]
                            );
                        });
                    }
                    if ($request->has('app_id') && !empty($request->app_id)) {
                        $q->where(function ($q) use ($request) {
                            $q->where('app_id' , $request->app_id);
                        });
                    }
                    $q->where(function ($q) use ($value) {
                        $q->where('email', 'LIKE', '%' . $value . '%');
                        $q = $this->SearchFullNameWithSpaces($q, $value);
                    });
                //webapp
                })->orWhereHas('webappDataWithThrashed', function ($q) use ($value, $input, $request) {
                    if ($request->has('date_from') && $request->has('date_to')) {
                        $q->where(function ($q) use ($request) {
                            $q->whereBetween('user_protect_users.created_at',
                                [$request->date_from . " 00:00:00", $request->date_to . " 23:59:59"]
                            );
                        });
                    }
                    if ($request->has('app_id') && !empty($request->app_id)) {
                        $q->where(function ($q) use ($request) {
                            $q->where('app_id' , $request->app_id);
                        });
                    }
                    $q->where(function ($q) use ($value) {
                        $q->where('email', 'LIKE', '%' . $value . '%');
                        $q = $this->SearchFullNameWithSpaces($q, $value);
                    });
                //whitelabel-webapp
                })->orWhereHas('vetCareUserDataWithThrashed', function ($q) use ($value, $input, $request) {
                    if ($request->has('date_from') && $request->has('date_to')) {
                        $q->where(function ($q) use ($request) {
                            $q->whereBetween('user_protect_users.created_at',
                                [$request->date_from . " 00:00:00", $request->date_to . " 23:59:59"]
                            );
                        });
                    }
                    if ($request->has('app_id') && !empty($request->app_id)) {
                        $q->where(function ($q) use ($request) {
                            $q->where('app_id' , $request->app_id);
                        });
                    }
                    $q->where(function ($q) use ($value) {
                        $q->where('email', 'LIKE', '%' . $value . '%');
                        $q = $this->SearchFullNameWithSpaces($q, $value);
                    });
                //whitelabel
                })->orWhereHas('userDataWithTrashed', function ($q) use ($value, $input, $request) {
                    if ($request->has('date_from') && $request->has('date_to')) {
                        $q->where(function ($q) use ($request) {
                            $q->whereBetween('user_protect_users.created_at',
                                [$request->date_from . " 00:00:00", $request->date_to . " 23:59:59"]
                            );
                        });
                    }
                    if ($request->has('app_id') && !empty($request->app_id)) {
                        $q->where(function ($q) use ($request) {
                            $q->where('app_id' , $request->app_id);
                        });
                    }
                    $q->where(function ($q) use ($value) {
                        $q->where('email', 'LIKE', '%' . $value . '%');
                        $q = $this->SearchFullNameWithSpaces($q, $value);
                    });
                })->when($isProtected, function ($q, $isProtected) {
                    $q->where('is_protect', $isProtected);
                })
                    ->with(['flagsEmergency' => function ($q) {
                        $q->latest();
                    }, 'notesEmergency' => function ($q) {
                        $q->latest();
                    }, 'userDataWithTrashed.pets', 'webappDataWithThrashed.pets'])
                    ->latest();
            }
            //
            $app = $this->findAppById($input['app_id'] ?? '');
//            if ($request->has('app_id') && isset($value) && !empty($value)) {
//                $data = $data->whereHas('appData', function ($q) use ($value, $input) {
//                        $q->where('id', $input['app_id']);
//                })->orWhereHas('vetData', function ($q) use ($value, $input) {
//                        $q->where('app_id', $input['app_id']);
//                        $q->where('email', 'LIKE', '%' . $value . '%');
//                        $q = $this->SearchFullNameWithSpaces($q, $value);
//                //webapp
//                })->orWhereHas('webappData', function ($q) use ($value, $input) {
//                        $q->where('app_id', $input['app_id']);
//                        $q->where('email', 'LIKE', '%' . $value . '%');
//                        $q = $this->SearchFullNameWithSpaces($q,$value);
//                //whitelabel-webapp
//                })->orWhereHas('vetCareUserData', function ($q) use ($value, $input) {
//                        $q->where('app_id', $input['app_id']);
//                        $q->where('email', 'LIKE', '%' . $value . '%');
//                        $q = $this->SearchFullNameWithSpaces($q, $value);
//                //whitelabel
//                })->orWhereHas('userData', function ($q) use ($value, $input) {
//                        $q->where('app_id', $input['app_id']);
//                        $q->where('email', 'LIKE', '%' . $value . '%');
//                        $q = $this->SearchFullNameWithSpaces($q, $value);
//                })->when($isProtected, function ($q, $isProtected) {
//                    $q->where('is_protect', $isProtected);
//                })->with(['flagsEmergency' => function ($q) {
//                        $q->latest();
//                    }, 'notesEmergency' => function ($q) {
//                        $q->latest();
//                    }, 'userData.pets', 'webappData.pets'])
//                    ->latest();
//            }
//            else {
//                $data = $data->with(['vetData', 'webappData', 'vetCareUserData', 'userData', 'userData.pets', 'webappData.pets', 'appData', 'flagsEmergency' => function ($q) {
//                    $q->latest();
//                }, 'notesEmergency' => function ($q) {
//                    $q->latest();
//                }])->when($isProtected, function ($q, $isProtected) {
//                    $q->where('is_protect', $isProtected);
//                })->latest();
//
//            }


            $data = $data->where('is_protect',true);
            if ($request->has('app_id') && !empty($request->app_id)) {
                $data = $data->where('app_id' , $request->app_id);
            }

            if ($request->has('date_from') && $request->has('date_to')) {
                $data = $data->whereBetween('created_at',
                    [$input['date_from'] . " 00:00:00", $input['date_to'] . " 23:59:59"]
                );
            }

            $data = $data->orderBy('created_at', 'desc');

            if (isset($input['pagination']) && $input['pagination'] != "") {
                $this->paginate = true;
                $data = $data->paginate($this->noOfRecordPerPage);
            } else {
                $data = $data->get();
            }

            if ($request->has('app_type') == 'whitelabel-webapp') {
                $data = VatCareProtectUserReport::collection($data);
            }else{
                $data = EmergencyClubReport::collection($data);
            }

            return $this->successResponse($data, 'Successfully records fetched', $this->paginate);
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    public function protectedUsersData(Request $request)
    {

        $input = $request->only('search_value', 'search_by', 'page', 'date_from', 'date_to', 'pagination', 'perPage', 'type', 'app_type');
        $app = $this->findAppById($request->app_id);
        $type = $app->app_type ?? NULL;

        try {

            if ($request->has('app_type') == 'whitelabel-webapp') {
                if ($request->has('search')) {
                    $value = $input['search_value'];
                    $model = VetCareUser::whereHas('roles', function($q){
                        $q->where('name', 'protect_users')
                        ->where('guard_name', 'vcusers');
                        })->where(function($q) use ($value) {
                            $q->where('email','Like','%'.$value.'%')->orWhere('first_name',$value)
                                ->orWhere('last_name',$value)->latest();
                        });
                }else{
                    $model = VetCareUser::whereHas('roles', function($q){
                        $q->where('name', 'protect_users')
                        ->where('guard_name', 'vcusers');
                        })->latest();
                }
            }else{

                if ($request->has('search')) {

                    $value = $input['search_value'];
                    $model = WebappUser::whereHas('emergency', function($q){
                        $q->where('protected', 'protect_users');
                        });
                    if ($request->has('date_from') && $request->has('date_to')) {
                        $model = $model->where(function($q) use ($value, $input) {
                            $q->where(function($q) use ($value) {
                                $q->where('email','Like','%'.$value.'%')->orWhere('first_name',$value)
                                    ->orWhere('last_name',$value);
                            })->whereBetween('created_at',
                                [$input['date_from'] . " 00:00:00", $input['date_to'] . " 23:59:00"]
                            )->latest();

                        });
                    } else {
                        $model = $model->where(function($q) use ($value) {
                            $q->where(function($q) use ($value) {
                                $q->where('email','Like','%'.$value.'%')->orWhere('first_name',$value)
                                    ->orWhere('last_name',$value)->latest();
                            });
                        });
                    }

                }else{
                    if ($request->has('date_from') && $request->has('date_to')) {
                        $model = WebappUser::whereHas('emergency', function ($q) {
                            $q->where('protected', 'protect_users');
                        })->whereBetween('created_at',
                            [$input['date_from'] . " 00:00:00", $input['date_to'] . " 23:59:00"]
                        )->latest();
                    } else {
                        $model = WebappUser::whereHas('emergency', function ($q) {
                            $q->where('protected', 'protect_users');
                        })->latest();
                    }
                }
            }

            if ($request->has('date_from') && $request->has('date_to')) {
                $model = $model->whereBetween('created_at',
                    [$input['date_from'] . " 00:00:00", $input['date_to'] . " 23:59:00"]
                );
            }

            switch ($type) {
                case 'webapp':
                    $app_id = $app->id;
                    if ($request->has('search')) {
                        $value = $input['search_value'];
                        $model = WebappUser::whereHas('emergency', function($q){
                            $q->where('protected', 'protect_users');
                            })->where('app_id', $app_id);

                        $model = $model->where('email','Like','%'.$value.'%')->orWhere('first_name',$value)->orWhere('last_name',$value)->latest();
                    }else{
                        $model = WebappUser::whereHas('emergency', function($q){
                            $q->where('protected', 'protect_users');
                            })->where('app_id', $app_id)->latest();
                    }
                    break;
                case 'whitelabel';

                    $app_id = $app->id;
                    if ($request->has('search')) {
                        $value = $input['search_value'];
                        $model = User::whereHas('roles', function($q){
                            $q->where('name', 'protect_users')
                            ->where('guard_name', 'users');
                            })
                            ->where('app_id', $app_id)
                            ->where(function($q) use ($value) {
                               $q->where('email','Like','%'.$value.'%')->orWhere('first_name',$value)
                                   ->orWhere('last_name',$value)->latest();
                            });
                            if ($request->has('date_from') && $request->has('date_to')) {
                                $model = $model->whereBetween('created_at',
                                    [$input['date_from'] . " 00:00:00", $input['date_to'] . " 23:59:00"]
                                );
                            }
                    }else{
                        $model = User::whereHas('roles', function($q){
                            $q->where('name', 'protect_users')
                                ->where('guard_name', 'users');
                        })->where('app_id', $app_id)->latest();

                        if ($request->has('date_from') && $request->has('date_to')) {
                            $model = $model->whereBetween('created_at',
                                [$input['date_from'] . " 00:00:00", $input['date_to'] . " 23:59:00"]
                            );
                        }


                    }
                    break;
                case 'whitelabel-webapp';
                    $app_id = $app->id;
                    if ($request->has('search')) {
                        $value = $input['search_value'];
                        if ($request->has('date_from') && $request->has('date_to')) {
                            $model = VetCareUser::whereHas('roles', function ($q) {
                                $q->where('name', 'protect_users')
                                    ->where('guard_name', 'vcusers');
                            })
                                ->where('app_id', $app_id)
                                ->whereBetween('created_at',
                                    [$input['date_from'] . " 00:00:00", $input['date_to'] . " 23:59:00"]
                                )->where('email', 'Like', '%' . $value . '%')->orWhere('first_name', $value)
                                ->orWhere('last_name', $value)->latest();
                        } else {
                            $model = VetCareUser::whereHas('roles', function ($q) {
                                $q->where('name', 'protect_users')
                                    ->where('guard_name', 'vcusers');
                            })
                                ->where('app_id', $app_id)
                                ->where('email', 'Like', '%' . $value . '%')->orWhere('first_name', $value)
                                ->orWhere('last_name', $value)->latest();
                        }
                    }else{
                        if ($request->has('date_from') && $request->has('date_to')) {
                            $model = VetCareUser::whereHas('roles', function ($q) {
                                $q->where('name', 'protect_users')
                                    ->where('guard_name', 'vcusers');
                            })->whereBetween('created_at',
                                [$input['date_from'] . " 00:00:00", $input['date_to'] . " 23:59:00"]
                            )->where('app_id', $app_id)->latest();
                        } else {
                            $model = VetCareUser::whereHas('roles', function ($q) {
                                $q->where('name', 'protect_users')
                                    ->where('guard_name', 'vcusers');
                            })
                                ->where('app_id', $app_id)->latest();
                        }
                    }
                    break;
                case 'sdk':
                    $app_id = $app->id;
                    $model = new Guest();
                    if ($request->has('search')) {
                        $value = $input['search_value'];
                        $model = $model->where('email','Like','%'.$value.'%')->orWhere('first_name',$value)->orWhere('last_name',$value);
                    }
                    $model = $model->where('app_id', $app_id)->latest();
                    break;
            }

            if (isset($input['pagination']) && $input['pagination'] != "") {
                $this->paginate = true;
                $data = $model->paginate($this->noOfRecordPerPage);
            } else {
                $data = $model->get();
            }

            $data = ProtectUserDataReport::collection($data);

            return $this->successResponse($data, 'Loaded successfully', $this->paginate);
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    public function getAllUsersStatus($type, Request $request)
    {
        $input = $request->only('search_value', 'search_by', 'page', 'pagination', 'perPage', 'api_key', 'type', 'key', 'search_all');
        try {
            $value = isset($input['search_value']) ? $input['search_value'] : '';
            $key = isset($input['key']) ? $input['key'] : '';
            $data = new UserAppStatus();
            $check_app_type = $this->findAppByName($key);
            $search_after_app_select = isset($input['search_all']) ? $input['search_all'] : false;
            //If search is true
            if (isset($value) && !empty($value) && $search_after_app_select == false) {
                $data = $data->with(['user' => function ($q) use ($value) {
                    $q->search($value);
                }])->where('status', $type)->latest();
            } else if (isset($check_app_type) && !empty($check_app_type) && $search_after_app_select == false) {
                $data = $data->with('user')->where(['status' => $type, 'app_id' => $check_app_type->id])->latest();
            } else if (isset($search_after_app_select) && !empty($search_after_app_select)) {
                $data = $data->with(['user' => function ($q) use ($value) {
                    $q->where('email', 'LIKE', '%' . $value . '%');
                }])->where(['status' => $type, 'app_id' => $check_app_type->id])->latest();
            }
            if (isset($input['pagination']) && $input['pagination'] != "") {
                $this->paginate = true;
                $data = $data->paginate($this->noOfRecordPerPage);
            }
            return $this->successResponse($data, 'Successfully records fetched', $this->paginate);
        } catch (QueryException $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    public function getUserPaymentDetails(Request $request)
    {
        $input = $request->only('search_value', 'search_by', 'page', 'pagination', 'perPage', 'api_key', 'type', 'key', 'search_all','date_from','date_to','sort_by');
        try {
            $value = isset($input['search_value']) ? $input['search_value'] : '';
            $key = isset($input['key']) ? $input['key'] : '';
            $search_by = isset($input['search_by']) ? $input['search_by'] : '';
            $sortBy = isset($input['sort_by']) ? $input['sort_by'] : 'DESC';
            $model = new Payment();
            $app = $this->find_app($key);

//            if(!empty($key) && isset($key))
//            {
//                $app = $this->find_app($key);
//                //This model is only used when there is search by coupon checked from admin
//                if ($search_by == 'coupon' && $model->has('paymentUser.coupon_usage')) {
//                    $temp_package = Package::where('app_id',$app->id)->get();
//                    foreach ($temp_package as $pack){
//                        $temp_pack_usage[] = $pack->id;
//                    }
//                    $find_coupon = Coupon::whereIn('package_id',$temp_pack_usage)->whereRaw("MATCH (other) AGAINST (? IN NATURAL LANGUAGE MODE)",$value)->first();
//                    if(isset($find_coupon)){
//                        $usage_arr = CouponUsage::where('coupon_id',$find_coupon->id)->get();
//                        foreach ($usage_arr as $usage){
//                            $temp_coupon_usage[] = $usage->user_id;
//                        }
//                        $model = $model->with(['paymentUser'=>function($q) use($value,$temp_coupon_usage){
//                            $q->with(['payProtectUser', 'emergency' => function ($q) use($value) {
//                                $q->latest();
//                            } ,'coupon_usage' => function ($q) use($value) {
//                                $q->with('coupon');
//                            }]);
//                        }])->whereIn('user_id',$temp_coupon_usage);
//                    }
//
//                    //dd($model->toSql(),$model->getBindings());
//                }
//
//                //Search by coupon ends
//                else {
//                    //When search value is not empty
//                    if ($value != '') {
//                        $user_arr = User::search($value)->get();
//                        foreach ($user_arr as $user){
//                            $temp_user[] = $user->id;
//                        }
//                        $model = $model->with(['paymentUser'=>function($q) use($value,$temp_user){
//                            $q->with(['payProtectUser', 'emergency' => function ($q) use($value) {
//                                $q->latest();
//                            } ,'coupon_usage' => function ($q) use($value) {
//                                $q->with('coupon');
//                            }]);
//                        }])->whereIn('user_id',$temp_user);
//                    }
//                    //Use case when there is a date filter
//                    if ($request->has('date_from') && $request->has('date_to')) {
//                        $model = $model->with(['paymentUser'=>function($q) use($value){
//                            $q->with(['payProtectUser', 'emergency' => function ($q) {
//                                $q->latest();
//                            } ,'coupon_usage' => function ($q) {
//                                $q->with('coupon:id,other');
//                            }
//                            ]);
//                        }])->whereBetween('date',
//                            [$input['date_from'] . " 00:00:00", $input['date_to'] . " 23:59:00"]
//                        );
//                    }
//                    if($request->has('key')){
//                        $model = $model->with(['paymentUser'=>function($q) use($value,$app){
//                            $q->where('app_id', $app->id)->with(['payProtectUser', 'emergency' => function ($q) {
//                                $q->latest();
//                            } ,'coupon_usage' => function ($q) {
//                                $q->with('coupon:id,other');
//                            }
//                            ]);
//                        }]);
//                    }
//                }
//            }
            //This model is only used when there is search by coupon checked from admin
            if ($search_by == 'coupon' && $model->has('paymentUser.coupon_usage')) {
                $find_coupon = Coupon::whereRaw("MATCH (other) AGAINST (? IN NATURAL LANGUAGE MODE)",$value)->first();
                $usage_arr = CouponUsage::where('coupon_id',$find_coupon->id)->get();
                foreach ($usage_arr as $usage){
                    $temp_coupon_usage[] = $usage->user_id;
                }
                $model = $model->with(['paymentUser'=>function($q) use($value,$temp_coupon_usage,$app){
                    $q->where('app_id',$app->id)->with(['payProtectUser', 'emergency' => function ($q) use($value) {
                        $q->latest();
                    } ,'coupon_usage' => function ($q) use($value) {
                        $q->with('coupon');
                    }]);
                }])->whereIn('user_id',$temp_coupon_usage);
                //dd($model->toSql(),$model->getBindings());
            }

            //Search by coupon ends
            else {
                //When search value is not empty
                if ($value != '') {
                    $user_arr = User::search($value)->where('app_id',$app->id)->get();
                        foreach ($user_arr as $user){
                            $temp_user[] = $user->id;
                        }
                        $model = $model->with(['paymentUser'=>function($q) use($value,$temp_user){
                            $q->with(['payProtectUser', 'emergency' => function ($q) use($value) {
                                $q->latest();
                            } ,'coupon_usage' => function ($q) use($value) {
                                $q->with('coupon');
                            }]);
                        }])->whereIn('user_id',$temp_user);
                    }
                //Use case when there is a date filter
                if ($request->has('date_from') && $request->has('date_to')) {
                    $model = $model->with(['paymentUser'=>function($q) use($value,$app){
                        $q->where('app_id',$app->id)->with(['payProtectUser', 'emergency' => function ($q) {
                            $q->latest();
                        } ,'coupon_usage' => function ($q) {
                            $q->with('coupon:id,other');
                        }
                        ]);
                    }])->whereBetween('date',
                        [$input['date_from'] . " 00:00:00", $input['date_to'] . " 23:59:00"]
                    );
                }
                if($request->has('key')){
                    $model = $model->with(['paymentUser'=>function($q) use($value,$app){
                        $q->where('app_id',$app->id)->where('app_id', $app->id)->with(['payProtectUser', 'emergency' => function ($q) {
                            $q->latest();
                        } ,'coupon_usage' => function ($q) {
                            $q->with('coupon:id,other');
                        }
                        ]);
                    }]);
                }
                else{
                    $model = $model->with(['paymentUser'=>function($q) use($value,$app){
                                $q->where('app_id',$app->id)->with(['payProtectUser', 'emergency' => function ($q) {
                                    $q->latest();
                                } ,'coupon_usage' => function ($q) {
                                    $q->with('coupon:id,other');
                                }
                            ]);
                        }]);

                }
                //$model = $model->where('app_id', $app->id)->latest();
            }
            $model = $model->latest();
            if (isset($input['pagination']) && $input['pagination'] != "") {
                $this->paginate = true;

                $model = $model->paginate($this->noOfRecordPerPage);
            } else {
                $model = $model->get();
            }
//            dd($model);
            //call to a resource collection

            $model = UserPaymentResource::collection($model);

            return $this->successResponse($model, 'Successfully records fetched', $this->paginate);
        } catch (QueryException $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    public function getPaymentReport(Request $request){
        $input = $request->only('search_value', 'search_by', 'page', 'pagination', 'perPage', 'api_key', 'type', 'key', 'search_all','date_from','date_to');
        try {
            $value = isset($input['search_value']) ? $input['search_value'] : '';
            $key = isset($input['key']) ? $input['key'] : '';
            $search_by = isset($input['search_by']) ? $input['search_by'] : '';
            $app = $this->find_app($key);
            $model = new User();
            //This model is only used when there is search by coupon checked from admin
            if ($search_by == 'coupon') {
                $upper_case = ucfirst($value);
                $lower_case = strtolower($value);
                $full_case = strtoupper($value);
                $temp_str_case = $upper_case.' '.$lower_case.' '.$full_case;
                $find_coupon = Coupon::search($temp_str_case)->get();
                $temp_coupon_usage = array();
                if($find_coupon){
                    foreach ($find_coupon as $coupon){
                        $usage_arr = CouponUsage::where('coupon_id', $coupon->id)->get();

                        foreach ($usage_arr as $usage) {
                            $temp_coupon_usage[] = $usage->user_id;
                        }
                    }
                    //whereRaw("MATCH (+other) AGAINST (? IN NATURAL LANGUAGE MODE)", $value)->first();

                }
                if ($request->has('date_from') && $request->has('date_to')) {
                    $model = $model->whereHas('latestPaymentHasMany',function($q) use ($input){
                            $q->whereBetween('date', [$input['date_from'] . " 00:00:00", $input['date_to'] . " 23:59:00"]
                            );
                        });
                }
                else{
                    $model = $model->with(['latestPaymentHasMany', 'payProtectUser', 'emergency' => function ($q) {
                        $q->latest();
                    }])->whereHas('coupon_usage', function ($q) use ($value) {
                        $q->with('coupon:id,other');
                    });
                }

                    $model =  $model->where('app_id', $app->id)->whereIn('id', $temp_coupon_usage)
                        ->orderByRaw('(Select max(created_at) from payments p where p.user_id = users.id ) desc');
            }

            //Search by coupon ends
            else {
                //When search value is not empty
                if ($value != '') {
                    // Search by first name + space + last name
                    $model = $model->orWhere(function ($q) use ($value, $app) {
                        {
                            $q = $this->SearchFullNameWithSpaces($q,$value);
                            //->where('app_id', $app->id)->latest();
                        }
                    });
                }
                //Use case when there is a date filter
                if ($request->has('date_from') && $request->has('date_to')) {
                    $model = $model->whereHas('latestPaymentHasMany',function($q) use ($input){
                            $q->whereBetween('date', [$input['date_from'] . " 00:00:00", $input['date_to'] . " 23:59:00"]
                            );
                        })
                        ->with(['latestPaymentHasMany','payProtectUser', 'emergency' => function ($q) {
                            //$q->latest();
                        },
                            'coupon_usage' => function ($q) use ($value) {
                                $q->with('coupon:id,other');
                            }

                        ])
                        ->orderByRaw('(Select max(created_at) from payments p where p.user_id = users.id ) desc');
                }
                else{
                    $model = $model
                        ->has('latestPaymentHasMany')
                        ->with(['latestPaymentHasMany', 'payProtectUser', 'emergency' => function ($q) {
                        },
                            'coupon_usage' => function ($q) use ($value) {
                            $q->with('coupon:id,other');
                        },
                        ])
                        ->orderByRaw('(Select max(created_at) from payments p where p.user_id = users.id ) desc');

                }
                $model = $model->where('app_id', $app->id);
            }
//            dd($model->toSql());
            if (isset($input['pagination']) && $input['pagination'] != "") {
                $this->paginate = true;
                $model = $model->paginate($this->noOfRecordPerPage);
            } else {
                $model = $model->get();
            }
//             dd($model);
            //call to a resource collection
            $model = UserPaymentResource::collection($model);

            return $this->successResponse($model, 'Successfully records fetched', $this->paginate);
        } catch (QueryException $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    public function guard()
    {
        //return Auth::guard('vets');
        return Auth::guard('admin');
    }

    // Delete Emergency Record
    public function deleteEmergencyRecord($id)
    {
        try {
            $data = EmergencyVetClient::find($id)->delete();
            return $this->successResponse($data, 'Deleted successfully');
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    // Coupon Usage Report
    public function couponUsageReport(Request $request){
        $isProtected = ($request->has('type') && $request['type']=="true") ? true : false ;
        $input = $request->only('search_value', 'search_by', 'page', 'pagination','key');
        $key = isset($input['key']) ? $input['key'] : '';
        $search_by = isset($input['search_by']) ? $input['search_by'] : '';
        try {
            $value = isset($input['search_value'])?$input['search_value']:'';
            $data = new CouponUsage;

            // Search by User
            if(isset($value) && !empty($value) && $search_by != 'coupon'){
                $data = $data
                ->whereHas('user' , function ($q) use ($value) {
                    $q->where('email', $value);
                    $q = $this->SearchFullNameWithSpaces($q,$value);
                })
                ->with(['coupon']);
            }
            // Search by Coupon
            else if (isset($value) && !empty($value) &&  $search_by == 'coupon'){
                $data = $data
                ->whereHas('coupon' , function ($q) use ($value) {
                    $upper_case = ucfirst($value);
                    $lower_case = strtolower($value);
                    $full_case = strtoupper($value);
                    $temp_str_case = $upper_case.' '.$lower_case.' '.$full_case;
                    $q->search($temp_str_case);
//                    $q->where('other->name','like', '%' . $value . '%');
                })
                ->whereHas('user');
            }else{
                $data = $data
                ->with(['coupon'])
                ->whereHas('user')
                ->latest();
            }
            $data = $data->with([
                'coupon.package' => function ($q) use ($value)  {
                $q->withTrashed();
            },'coupon.package.apps'])
            ->whereHas('coupon.package.apps' , function ($q) use ($key) {
                if(!empty($key)){
                    $app = $this->find_app($key);
                    $q->where('id',$app->id);
                }
            })
            ->where('coupon_id','!=',1)->latest();
            // dd($data->toSql());

            if (isset($input['pagination']) && $input['pagination'] != "") {
                $this->paginate = true;
                $data = $data->paginate($this->noOfRecordPerPage);
            }
            else{
                $data = $data->get();
            }

            $data = CouponUsageResource::collection($data);

            return $this->successResponse($data, 'Successfully records fetched',$this->paginate);
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }

    }

    public function getAllVetCare(Request $request){
        try{
            $input = $request->only('search_value', 'search_by', 'page', 'pagination', 'perPage', 'type');

            $model = new VetCare();

            if(@$input['type']){
               $model = $model->with('loadVetCareUser');
            }

            if (isset($input['pagination']) && $input['pagination'] != "") {
                $this->paginate = true;
                $data = $model->paginate($this->noOfRecordPerPage);
            } else {
                $data = $model->get();
            }

            return $this->successResponse($data, 'Loaded successfully', $this->paginate);
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    public function getAllVetCareUsers(Request $request){
        $input = $request->only('search_value', 'search_by', 'page', 'pagination', 'perPage', 'app_id','export','date_from','date_to','user_id','package_id','key','ef_status','user_type','subscription_status');
        try {

            $key = isset($input['key']) ? $input['key'] : '';
            $app = $this->find_app($key);


            if(!$app)
            {
                return $this->errorResponse('No App is linked with this Clinic.', 404);
            }

            $value = isset($input['search_value'])?$input['search_value']:'';

            $model = VetCareUser::latest()->search($value);
            $model = $model->with(['emergencyLatestFilter.notesEmergencyLatest','emergencyLatest.notesEmergencyLatest','defaultPet','usage.package','usageLatest.package','payment','userDetails','vetCareUserFeedbacks.vet','pets','user_status']);

            if (isset($input['pagination']) && $input['pagination'] != "") {
                $this->paginate = true;
                //Use case when there is a date filter

                if ($request->has('date_from') && $request->has('date_to')) {
                    $model = $model->whereBetween('created_at',
                        [$input['date_from'] . " 00:00:00", $input['date_to'] . " 23:59:00"]
                    );
                }

                if($request->has('user_type')){
                    //protected or normal user
                        $role_name= $input['user_type'];
                        $model = $model->whereHas('roles',function ($q) use ($role_name){
                            $q->where('name',$role_name);
                        });

                }

                //Use case when there is a user statuses filter
                // if ($request->has('status')){
                //     $request_status = @$input['status'];
                //     $eagerloading = $model->whereHas('user_status',function($q) use($request_status){
                //         $q = $q->where('status',$request_status);
                //     });
                // }
                if(@$request->has('package_id')){
                    $package_id = @$input['package_id'];
                    $eagerloading = $model->whereHas('usageLatest',function($q) use($package_id){
                        $q = $q->where('package_id',$package_id);
                    });
                }
                else{
                    $eagerloading = $model->with(['emergency','usageWithThrashed.package','usageSubscription'=>function($q){
                        $q->with('subscriptonsData');
                    }]);
                }
                if($request->has('ef_status') && !empty($input['ef_status'])){
                        $ef_status= $input['ef_status']; //true ,false , denied
                        $app_id = $app->id;

                        $eagerloading = $model->whereHas('emergencyLatestFilter',function ($q) use ($ef_status,$app_id){
                            $q->where('status',$ef_status);
                        });
                        // if($ef_status!='false'){

                        //     $eagerloading = $model->whereHas('emergencyLatestFilter',function ($q) use ($ef_status,$app_id){
                        //         $q->where(function ($query)  use ($ef_status)  {
                        //             $query->whereHas('notesEmergencyLatest');
                        //         });
                        //     });

                        // } else{
                        //     $eagerloading = $model->whereHas('emergencyLatestFilter',function ($q) use ($ef_status,$app_id){
                        //         $q->whereHas('notesEmergencyLatest' , function($q) use ($ef_status) {
                        //             $q = $q->where('paid' , $ef_status);
                        //         });
                        //         // $q->doesnthave('notesEmergencyLatest');
                        //     });
                        // }

                }
                if($request->has('subscription_status') && !empty($input['subscription_status'])){
                    $is_handshake = is_handshake_enabled($app->id);
                    if($is_handshake){
                        //check in user app statuses
                        $model = $model->whereHas('user_status') ;
                    }else{
                            // $model = $model->whereHas('usage');
                            $model = $model->whereHas('usageSubscription');
                            // $model = $model->doesnthave('usage');
                    }
                }
                if($input['export'] === 'true' || $input['export'] === true){
                    $this->paginate = false;
                    $users =  $eagerloading->where('app_id',$app->id)->latest()->get();
                }
                else{
                    $users =  $eagerloading->where('app_id',$app->id)->latest()->paginate($this->noOfRecordPerPage);

                }
            }
            else{
                $users =  $model->where('app_id',$app->id)->where('id',$request->user_id)->get();
            }

            $users = VetCareUserListResource::collection($users);


            return $this->successResponse($users, 'Record Fetched Successfully .', $this->paginate);
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }

    }

    public function getAllVetCareDeletedUsers(Request $request){
        $input = $request->only('search_value', 'search_by', 'page', 'pagination', 'perPage', 'app_id','export','date_from','date_to','user_id','package_id','key','ef_status','user_type','subscription_status');
        try {

            $key = isset($input['key']) ? $input['key'] : '';
            $app = $this->find_app($key);


            if(!$app)
            {
                return $this->errorResponse('No App is linked with this Clinic.', 404);
            }

            $value = isset($input['search_value'])?$input['search_value']:'';

            $model = VetCareUser::onlyTrashed()->latest();
            if(!empty($value)){
//                $model = $model->where('email','Like','%'.$value.'%');
                $model = $model->where(function ($query) use ($value) {
                    $query->where('email','Like','%'.$value.'%')->orWhere('first_name','Like','%'.$value.'%')
                    ->orWhere('last_name','Like','%'.$value.'%');
                });
            }
            // dd($model->count());
            $model = $model->with(['emergencyLatestFilter.notesEmergencyLatest','emergencyLatest.notesEmergencyLatest','defaultPet','usage.package','usageLatest.package','payment','userDetails','vetCareUserFeedbacks.vet','pets','user_status']);
            if (isset($input['pagination']) && $input['pagination'] != "") {
                $this->paginate = true;
                //Use case when there is a date filter

                if ($request->has('date_from') && $request->has('date_to') && !empty($request->date_from) && !empty($request->date_to)) {
                    $model = $model->whereBetween('created_at',
                        [$input['date_from'] . " 00:00:00", $input['date_to'] . " 23:59:00"]
                    );
                }

                if($request->has('user_type') && !empty($request->user_type)){
                    //protected or normal user
                        $role_name= $input['user_type'];
                        $model = $model->whereHas('roles',function ($q) use ($role_name){
                            $q->where('name',$role_name);
                        });

                }
            //     if($request->has('ef_status') && !empty($request->user_type) ){
            //         $ef_status= $input['ef_status']; //true ,false , denied
            //         $app_id = $app->id;
            //         $eagerloading = $model->whereHas('emergencyfilter',function ($q) use ($ef_status,$app_id){
            //             $q->whereHas('notesEmergencyLatest',function ($q) use ($ef_status,$app_id){
            //                 $q->where('app_id','=',$app_id);
            //             });
            //         });
            // }
                if($request->has('ef_status')){
                    $ef_status= $input['ef_status']; //true ,false , denied
                    $app_id = $app->id;
                    $eagerloading = $model->whereHas('emergencyLatestFilter',function ($q) use ($ef_status,$app_id){
                        $q->where('status',$ef_status);
                    });
                    // $eagerloading = $model->whereHas('emergencyfilter',function ($q) use ($ef_status,$app_id){
                    //                 $q->whereHas('notesEmergencyLatest',function($query) use ($ef_status,$app_id){
                    //                     $query->where('paid',$ef_status)->where('is_last_created',1);
                    //                 });
                    //         });
                }
                if($request->has('subscription_status') && !empty($input['subscription_status'])){
                    $is_handshake = is_handshake_enabled($app->id);
                    if($is_handshake){
                        //check in user app statuses
                        $model = $model->whereHas('user_status');


                    }else{
                            // $model = $model->whereHas('usage');
                            $model = $model->whereHas('usageSubscription');
                            // $model = $model->doesnthave('usage');

                    }
                }

                if($request->has('export') && $request->export === 'true' || $request->export === true){
                    $this->paginate = false;
                    $model =  $model->where('app_id',$app->id)->latest()->get();
                }
                else{
                    $model =  $model->where('app_id',$app->id)->latest()->paginate($this->noOfRecordPerPage);
                }
            }
            else{
                $model =  $model->where('app_id',$app->id)->latest()->get();
            }

            $model = VetCareUserListResource::collection($model);


            return $this->successResponse($model, 'Record Fetched Successfully .', $this->paginate);
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }

    }

    public function getAllBouncingVetCareUsers(Request $request){
        try{
            $input = $request->only('search_value', 'page', 'pagination', 'perPage', 'app_id');
            $value = isset($input['search_value'])?$input['search_value']:'';
            $key = isset($input['key']) ? $input['key'] : '';
            $appId = isset($input['app_id'])?$input['app_id']:'';


            $model = BouncingVetCareUser::where('app_id',$appId);

            if(!empty($value)){
                $model = $model->where('email','Like','%'.$value.'%')
                ->orWhere(function ($query) use ($value) {
                    $query->where('email','Like','%'.$value.'%')->orWhere('first_name','Like','%'.$value.'%')
                    ->orWhere('last_name','Like','%'.$value.'%');
                });
            }

            if(!empty($appId)){
                $model = $model->where('app_id',$appId);
            }

            $model = $model->latest();

            if (isset($input['pagination']) &&  strtolower($input['pagination']) != "false") {
                $this->paginate = true;
                $data = $model->paginate($this->noOfRecordPerPage);
            } else {
                $data = $model->get();
            }

            return $this->successResponse($data, 'Loaded successfully', $this->paginate);
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    public function vetFeedbacks(Request $request){
        $input = $request->only('search_value', 'search_by', 'page', 'pagination', 'perPage', 'app_id','export','date_from','date_to','user_id','package_id');
        $appId = isset($input['app_id'])?$input['app_id']:'';
        $vetCareAppsOnly = App::where('app_type','whitelabel-webapp')->pluck('id');
        try {

            $value = isset($input['search_value'])?$input['search_value']:'';
            $model = Feedback::latest();
            if(!empty($appId)){
                $model = $model->where('app_id',$appId);
                }else{
                    $data = $model->whereIn('app_id',$vetCareAppsOnly);
                }
            $model = $model->with(['video','chat','reason','recommendation']);
            if($value != ''){
                $model = $model->whereHas('video.vcUser',function($q) use($value){
                    $q->where('email','Like','%'.$value.'%')
                    ->orWhere(function($q) use($value){
                        $q->where('email','Like','%'.$value.'%')->orWhere('first_name','Like','%'.$value.'%')
                        ->orWhere('last_name','Like','%'.$value.'%');
                    });
                });

                if(!empty($appId)){
                $model = $model->where('app_id',$appId);
                }else{
                    $data = $model->whereIn('app_id',$vetCareAppsOnly);
                }
                $model = $model->orWhereHas('video.vet',function($q) use($value){
                    $q->where('email','Like','%'.$value.'%')
                    ->orWhere(function($q) use($value){
                        $q->where('email','Like','%'.$value.'%')->orWhere('first_name','Like','%'.$value.'%')
                        ->orWhere('last_name','Like','%'.$value.'%');
                    });
                });

                if(!empty($appId)){
                $model = $model->where('app_id',$appId);
                }else{
                    $data = $model->whereIn('app_id',$vetCareAppsOnly);
                }
                $model = $model->orWhereHas('chat.vcUser',function($q) use($value){
                    $q->where('email','Like','%'.$value.'%')
                    ->orWhere(function($q) use($value){
                        $q->where('email','Like','%'.$value.'%')->orWhere('first_name','Like','%'.$value.'%')
                        ->orWhere('last_name','Like','%'.$value.'%');
                    });
                });

                if(!empty($appId)){
                $model = $model->where('app_id',$appId);
                }else{
                    $data = $model->whereIn('app_id',$vetCareAppsOnly);
                }
                $model = $model->orWhereHas('chat.vet',function($q) use($value){
                    $q->where('email','Like','%'.$value.'%')
                    ->orWhere(function($q) use($value){
                        $q->where('email','Like','%'.$value.'%')->orWhere('first_name','Like','%'.$value.'%')
                        ->orWhere('last_name','Like','%'.$value.'%');
                    });
                });
            }

            if(!empty($appId)){
                $model = $model->where('app_id',$appId);
                }else{
                    $data = $model->whereIn('app_id',$vetCareAppsOnly);
                }

            if (isset($input['pagination']) && $input['pagination'] != "") {
                $this->paginate = true;

                if($request->has('export') && $request->export === 'true' || $request->export === true){
                    $this->paginate = false;
                    if(!empty($appId)){
                        $model = $model->where('app_id',$appId);
                    }else{
                        $model =  $model->whereIn('app_id',$vetCareAppsOnly)->latest()->get();
                    }
                }
                else{
                    if(!empty($appId)){
                        $model = $model->where('app_id',$appId);
                    }else{

                    }
                    $model =  $model->whereIn('app_id',$vetCareAppsOnly)->latest()->paginate($this->noOfRecordPerPage);
                }
            }
            else{
                if(!empty($appId)){
                    $model = $model->where('app_id',$appId);
                }
                $model =  $model->whereIn('app_id',$vetCareAppsOnly)->latest()->get();
            }

            $model = VetFeedbackResource::collection($model);


            return $this->successResponse($model, 'Record Fetched Successfully .', $this->paginate);
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }

    }



    public function getVetCareUsersFeedbacks(Request $request){
        try{
            $input = $request->only('search_value', 'page', 'pagination', 'perPage', 'app_id');
            $value = isset($input['search_value'])?$input['search_value']:'';
            $appId = isset($input['app_id'])?$input['app_id']:'';


            $model = VetCareUserFeedback::with(['user','vet']);

            $model->whereHas('user' , function ($q) use ($value) {
                if(!empty($value)){
                    $q = $q->where('email','Like','%'.$value.'%')
                    ->orWhere(function ($query) use ($value) {
                        $query->where('email','Like','%'.$value.'%')
                        ->orWhere('first_name','Like','%'.$value.'%')
                        ->orWhere('last_name','Like','%'.$value.'%');
                    });
                }
            });
            if(!empty($appId)){
                $model = $model->where('app_id',$appId);
            }

            $model = $model->latest();

            if (isset($input['pagination']) &&  strtolower($input['pagination']) != "false") {
                $this->paginate = true;
                $data = $model->paginate($this->noOfRecordPerPage);
            } else {
                $data = $model->get();
            }

            return $this->successResponse($data, 'Loaded successfully', $this->paginate);
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    // TODO : Without Filter for quick release
    public function getVetCareUserPaymentReportOld(Request $request){
        $input = $request->only('search_value', 'search_by', 'page', 'pagination', 'perPage', 'api_key', 'type', 'key', 'search_all','date_from','date_to');
        try {
            $value = isset($input['search_value']) ? $input['search_value'] : '';
            $key = isset($input['key']) ? $input['key'] : '';
            $search_by = isset($input['search_by']) ? $input['search_by'] : '';
            $app = $this->find_app($key);
            $model = new VetCareUser();
            //This model is only used when there is search by coupon checked from admin
            // if ($search_by == 'coupon') {
            //     $upper_case = ucfirst($value);
            //     $lower_case = strtolower($value);
            //     $full_case = strtoupper($value);
            //     $temp_str_case = $upper_case.' '.$lower_case.' '.$full_case;
            //     $find_coupon = Coupon::search($temp_str_case)->get();
            //     $temp_coupon_usage = array();
            //     if($find_coupon){
            //         foreach ($find_coupon as $coupon){
            //             $usage_arr = CouponUsage::where('coupon_id', $coupon->id)->get();

            //             foreach ($usage_arr as $usage) {
            //                 $temp_coupon_usage[] = $usage->user_id;
            //             }
            //         }
            //         //whereRaw("MATCH (+other) AGAINST (? IN NATURAL LANGUAGE MODE)", $value)->first();

            //     }
            //     if ($request->has('date_from') && $request->has('date_to')) {
            //         $model = $model->whereHas('latestPaymentHasMany',function($q) use ($input){
            //             $q->whereBetween('date', [$input['date_from'] . " 00:00:00", $input['date_to'] . " 23:59:00"]
            //             );
            //         });
            //     }
            //     else{
            //         $model = $model->with(['latestPaymentHasMany', 'payProtectUser', 'emergency' => function ($q) {
            //             $q->latest();
            //         }])->whereHas('coupon_usage', function ($q) use ($value) {
            //             $q->with('coupon:id,other');
            //         });
            //     }

            //     $model =  $model->where('app_id', $app->id)->whereIn('id', $temp_coupon_usage)
            //         ->orderByRaw('(Select max(created_at) from payments p where p.user_id = users.id ) desc');
            // }

            //Search by coupon ends
            // else {
                //When search value is not empty
                // if ($value != '') {
                //     // Search by first name + space + last name
                //     $model = $model->orWhere(function ($q) use ($value, $app) {
                //         {
                //             $q = $this->SearchFullNameWithSpaces($q,$value);
                //             // ->where('app_id', $app->id)->latest();
                //         }
                //     });
                //     $model = $model->orWhere(function ($q) use ($value, $app) {
                //         {
                //             $q = $this->SearchFullNameWithSpaces($q,$value);
                //             //->where('app_id', $app->id)->latest();
                //         }
                //     });
                // }
                //Use case when there is a date filter
                // if ($request->has('date_from') && $request->has('date_to')) {
                //     $model = $model->whereHas('latestPaymentHasMany',function($q) use ($input){
                //         $q->whereBetween('date', [$input['date_from'] . " 00:00:00", $input['date_to'] . " 23:59:00"]
                //         );
                //     })
                //         ->with(['latestPaymentHasMany','payProtectUser', 'emergency' => function ($q) {
                //             //$q->latest();
                //         },
                //             'coupon_usage' => function ($q) use ($value) {
                //                 $q->with('coupon:id,other');
                //             }

                //         ])
                //         ->orderByRaw('(Select max(created_at) from payments p where p.user_id = users.id ) desc');
                // }
                // else{
                    $model = $model
                        ->has('latestPaymentHasMany')
                        ->with(['latestPaymentHasMany', 'payProtectUser', 'userDetails' , 'emergency' => function ($q) {
                        },
                            'coupon_usage' => function ($q) use ($value) {
                                $q->with('coupon:id,other');
                            },
                            'usage'
                        ])
                        ->orderByRaw('(Select max(created_at) from vet_care_user_payments p where p.user_id = vet_care_users.id ) desc');

                // }
                $model = $model->where('app_id', $app->id);
            // }
            if (isset($input['pagination']) && $input['pagination'] != "") {
                $this->paginate = true;
                $model = $model->paginate($this->noOfRecordPerPage);
            } else {
                $model = $model->get();
            }
            //call to a resource collection

            $model = UserPaymentResource::collection($model);

            return $this->successResponse($model, 'Successfully records fetched', $this->paginate);
        } catch (QueryException $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    public function getVetCareUserPaymentReport(Request $request){
        $input = $request->only('search_value', 'search_by', 'page', 'pagination', 'perPage', 'api_key', 'type', 'key', 'search_all','date_from','date_to');
        try {
            $value = isset($input['search_value']) ? $input['search_value'] : '';
            $key = isset($input['key']) ? $input['key'] : '';
            $search_by = isset($input['search_by']) ? $input['search_by'] : '';
            $app = $this->find_app($key);
            $model = new VetCareUser();

            //This model is only used when there is search by coupon checked from admin
            if ($search_by == 'coupon') {
                $upper_case = ucfirst($value);
                $lower_case = strtolower($value);
                $full_case = strtoupper($value);
                $temp_str_case = $upper_case.' '.$lower_case.' '.$full_case;
                $find_coupon_code = VetCareCouponCode::where('code','like',"%$value%")->with("vetCareCouponUsages")->withTrashed()->get();
                $temp_coupon_usage = array();
                if($find_coupon_code){
                    foreach ($find_coupon_code as $coupon_code){
                        $usage_arr = $coupon_code->vetCareCouponUsages;
                        foreach ($usage_arr as $usage) {
                            $temp_coupon_usage[] = $usage->user_id;
                        }
                    }
                }
                if ($request->has('date_from') && $request->has('date_to')) {
                    $model = $model->whereHas('latestPaymentHasMany',function($q) use ($input){
                        $q->whereBetween('date', [$input['date_from'] . " 00:00:00", $input['date_to'] . " 23:59:00"]
                        );
                    });
                }
                else{
                    $model = $model->with(['latestPaymentHasMany', 'payProtectUser', 'emergency' => function ($q) {
                        $q->latest();
                    }])->whereHas('coupon_usage');
                }
                $model =  $model->where('app_id', $app->id)->whereIn('id', $temp_coupon_usage);
            }
            else{
                $model = $model->where('app_id', $app->id)->when($value, function ($q) use ($value) {
                    $q->where(function ($q) use ($value) {
                        $q = $q->where('email', 'LIKE', '%' .$value.'%')
                            ->orWhere('first_name','Like','%'.$value.'%')
                            ->orWhere('last_name','Like','%'.$value.'%');
                    });
                });
            }

            $model = $model
                ->has('latestPaymentHasMany')
                ->with(['latestPaymentHasMany', 'payProtectUser', 'userDetails' , 'emergency' => function ($q) {
                },
                    'coupon_usage' => function ($q) use ($value) {
                        $q->with(['couponCode' => function($q) {
                            $q->select('id','code');
                        } ]);

                    },
                    'usage' => function($q){
                        $q->with(['couponCode' => function($q) {
                            $q->select('id','code');
                        } ]);
                    }
                ])
                ->orderByRaw('(Select max(created_at) from vet_care_user_payments p where p.user_id = vet_care_users.id ) desc');

            $model = $model->where('app_id', $app->id);

            if (isset($input['pagination']) && $input['pagination'] != "") {
                $this->paginate = true;
                $model = $model->paginate($this->noOfRecordPerPage);
            } else {
                $model = $model->get();
            }

            //call to a resource collection
            // $model = UserPaymentResource::collection($model);

            $model = VetCareUserPaymentResource::collection($model);

            return $this->successResponse($model, 'Successfully records fetched', $this->paginate);
        } catch (QueryException $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
        catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    public function getVetCareProtectUserReport_old(Request $request)
    {
        $isProtected = $request->has('type') && $request['type'] == "true";
        $input = $request->only('search_value', 'search_by', 'page', 'pagination', 'perPage', 'api_key', 'type', 'date_from', 'date_to', 'app_id', 'pet_species');
        try {
            $value = isset($input['search_value']) ? $input['search_value'] : '';
            $vetCareAppsOnly = App::where('app_type','whitelabel-webapp')->pluck('id');

            $data = EmergencyVetClient::whereIn('app_id',$vetCareAppsOnly);
            //$data = $data->whereIn('app_id',$vetCareAppsOnly);

            if ($request->has('date_from') && $request->has('date_to')) {
                $data = $data->whereBetween('created_at',
                    [$input['date_from'] . " 00:00:00", $input['date_to'] . " 23:59:00"]
                );
            }

            //If Search Value exist
            if (isset($value) && !empty($value) && !$request->has('app_id') && !$request->has('pet_species')) {
                $data = $data->orWhereHas('vetData', function ($q) use ($value) {
                    $q->where('email', $value);
                    $q = $this->SearchFullNameWithSpaces($q,$value);
                })->orWhereHas('vetCareUserData', function ($q) use ($value) {
                    $q->where('email', $value);
                    $q = $this->SearchFullNameWithSpaces($q,$value);
                    $q->with('comments');
                })->orWhereHas('appData', function ($q) use ($value) {
                    $q->where('name', $value);
                })->when($isProtected, function ($q, $isProtected) {
                    $q->where('is_protect', $isProtected);
                })->with(['flagsEmergency' => function ($q) {
                        $q->latest();
                    }, 'notesEmergency' => function ($q) {
                        $q->latest();
                    }, 'vetCareUserData.pets'])
                    ->latest();


            } // If Searching by app_id
            elseif ($request->has('app_id') && !$request->has('pet_species')) {
                $data = $data->whereHas('appData', function ($q) use ($value, $input) {
                    $q->where('id', $input['app_id']);
                })->orWhereHas('vetData', function ($q) use ($value, $input) {
                    if (isset($value) && !empty($value)) {
                        $q->where('email', $value);
                        $q = $this->SearchFullNameWithSpaces($q,$value);
                    }
                    $q->where('app_id', $input['app_id']);
                })->orWhereHas('vetCareUserData', function ($q) use ($value, $input) {
                    if (isset($value) && !empty($value)) {
                        $q->where('email', $value);
                        $q = $this->SearchFullNameWithSpaces($q,$value);
                        $q->with('comments');
                    }
                    $q->where('app_id', $input['app_id']);

                })->when($isProtected, function ($q, $isProtected) {
                    $q->where('is_protect', $isProtected);
                })
                    ->with(['flagsEmergency' => function ($q) {
                        $q->latest();
                    }, 'notesEmergency' => function ($q) {
                        $q->latest();
                    }, 'vetCareUserData.pets'])
                    ->latest();


            } // If Searching by pet_species for pets and extra-pets
            elseif ($request->has('pet_species')) {
                $data = $data->orWhereHas('vetData', function ($q) use ($value) {
                    $q->where('email', $value);
                    $q = $this->SearchFullNameWithSpaces($q,$value);
                })->whereHas('vetCareUserData', function ($q) use ($value,$input) {
                    $q->where('email', $value);
                    $q = $this->SearchFullNameWithSpaces($q,$value);
                    $q->with(['comments','pets' => function ($q) use ($input) {
                        $q->where('species', $input['pet_species'])->where('model_type','App\VetCareUser');
                    }
                    ]);
                })->orWhereHas('appData', function ($q) use ($value) {
                    $q->where('name', $value);
                })->when($isProtected, function ($q, $isProtected) {
                    $q->where('is_protect', $isProtected);
                })
                    ->with(['flagsEmergency' => function ($q) {
                        $q->latest();
                    }, 'notesEmergency' => function ($q) {
                        $q->latest();
                    }
                    ])->latest();

            }
            else {
                $data = $data->with(['vetData', 'vetCareUserData', 'vetCareUserData.pets', 'appData', 'flagsEmergency' => function ($q) {
                    $q->latest();
                }, 'notesEmergency' => function ($q) {
                    $q->latest();
                }])->when($isProtected, function ($q, $isProtected) {
                    $q->where('is_protect', $isProtected);
                })->latest();

            }

            if (isset($input['pagination']) && $input['pagination'] != "") {
                $this->paginate = true;
                $data = $data->paginate($this->noOfRecordPerPage);
            } else {
                $data = $data->get();
            }


            return $this->successResponse($data, 'Successfully records fetched', $this->paginate);
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    public function getVetCareProtectUserReport(Request $request)
    {
        $isProtected = $request->has('type') && $request['type'] == "true";
        $input = $request->only('search_value', 'search_by', 'page', 'pagination', 'perPage', 'api_key', 'type', 'date_from', 'date_to', 'app_id', 'pet_species');
        try {
            $value = isset($input['search_value']) ? $input['search_value'] : '';
            $vetCareAppsOnly = App::where('app_type','whitelabel-webapp')->pluck('id');

            $data = EmergencyVetClient::whereIn('app_id',$vetCareAppsOnly);

            if ($request->has('date_from') && $request->has('date_to')) {
                $data = $data->whereBetween('created_at',
                    [$input['date_from'] . " 00:00:00", $input['date_to'] . " 23:59:00"]
                );
            }

            // if searching by app
            if($request->has('app_id') && !empty($request->app_id)){
                $data = $data->where('app_id',$request->app_id);
            }

            $data = $data->with(['vetData', 'vetCareUserData', 'vetCareUserData.pets', 'appData', 'flagsEmergency' => function ($q) {
                $q->latest();
            }, 'notesEmergency' => function ($q) {
                $q->latest();
            }])->latest();
            $data = $data->whereHas('vetCareUserData'); //deleted user will  not shown up in this result set

            if($request->has('app_id') && !empty($request->app_id)){
                $data = $data->where('app_id',$request->app_id);
            }
            //If Search Value exist
            if (isset($value) && !empty($value)) {
                $data->whereHas('vetCareUserData', function ($q) use ($value) {
                    $q->where('email','Like','%'.$value.'%');
                    $q = $this->SearchFullNameWithSpaces($q,$value);
                    $q->with('comments');
                })->with(['flagsEmergency' => function ($q) {
                        $q->latest();
                    }, 'notesEmergency' => function ($q) {
                        $q->latest();
                    }, 'vetCareUserData.pets'])
                    ->latest();
            }

            if($request->has('app_id') && !empty($request->app_id)){
                $data = $data->where('app_id',$request->app_id);
            }


            if (isset($input['pagination']) && $input['pagination'] != "") {
                $this->paginate = true;
                $data = $data->paginate($this->noOfRecordPerPage);
            } else {
                $data = $data->get();
            }


            return $this->successResponse($data, 'Successfully records fetched', $this->paginate);
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }


}
