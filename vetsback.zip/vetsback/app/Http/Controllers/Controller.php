<?php

namespace App\Http\Controllers;

use App\App;
use App\Package;
use Log;
use Carbon\Carbon;
use App\VetCarePackage;
use Illuminate\Http\Request;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Carbon\Exceptions\UnknownGetterException;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    private $result;
    protected $_model, $_storageDir;
    /**
     * success response method.
     *
     * @return \Illuminate\Http\Response
     */
    public function successResponse($result = [], $message,$paginate = FALSE,$code=200){

        $this->result = $result;

        if($paginate == TRUE){
            $this->paginate($result);
        }

        $response = [
            'success' => true,
            'status_code'    =>$code,
            'message' => [$message],
           // 'message' =>$message,
            'data'   => $this->result
        ];
        return response()->json($response, 200);
    }



    /**
     * return error response.
     *
     */
    public function errorResponse($error, $code = 400,$errorMessages = []){

        $statusCode = $code == 0 ? 400 : $code;
        $response = [
            'success' => false,
            'status_code' =>$statusCode,
            'message' => is_array($error) == TRUE ? $error : [$error],
            //'message' => $error,
            //'data'    => $errorMessages
            'data'    => []
        ];

        return response()->json($response, $statusCode);
    }
//    public static function errorResponse( $error = '', $errorMessages = [],$code = 401)
//    {
//        $statusCode = $code == 0 ? 402 : $code;
//        $response = [
//            'success' => false,
//            'status_code'    => $statusCode,
//            'message' => $error,
//            'data'    => $errorMessages
//        ];
//
//        return response()->json($response, $code);
//    }


    public function uploadFile(UploadedFile $file,$folder = NULL){
        $folder = $folder == NULL ? 'misc' : $folder;
        try{
            $resp = Storage::putFile($folder,$file,'public');
            $path = Storage::url($resp);
        }catch (\Exception $e){
            throw new \Exception($e->getMessage());
        }

        return $path;
    }

    public function uploadFileProtectRepo(UploadedFile $file,$bucket,$filename){
        try{
            $s3 = Storage::disk($bucket)->getDriver()->getAdapter()->getClient();
            $resp = Storage::disk($bucket)->putFile($filename, $file);
            $cmd = $s3->getCommand('GetObject', [
                'Bucket' => env('AWS_VETPROTECT_ATTACHMENT'),
                'Key' => $resp
            ]);
            //Pre Signed URL work
            $request = $s3->createPresignedRequest($cmd, '+10080 minutes');
            return $presignedUrl = (string)$request->getUri();
        }catch (\Exception $e){
            throw new \Exception($e->getMessage());
        }
    }

    //Public Upload to S3
    public function uploadFilePublicRepo(UploadedFile $file,$bucket,$folderName){
        try{
            $s3 = Storage::disk($bucket);
            $file_name =  uniqid() .'.'. $file->getClientOriginalExtension();
            $s3filePath = $folderName . '/' . $file_name;
            $s3->put($s3filePath, file_get_contents($file), 'public');
            return $s3->url($s3filePath);
        }catch (\Exception $e){
            throw new \Exception($e->getMessage());
        }
    }

    public function uploadFilePublicRepoV2($file,$bucket,$folderName,$file_name){
        try{
            $s3 = Storage::disk($bucket);
            $s3filePath = $folderName . '/' . $file_name;
            $s3->put($s3filePath, $file, 'public');
            return $s3->url($s3filePath);
        }catch (\Exception $e){
            throw new \Exception($e->getMessage());
        }
    }

    public function paginate($data = []){

        $paginationArray = NULL;
        if($data != NULL){
            $paginationArray = array ('list'=>$data->items(),'pagination'=>[]);
            $paginationArray['pagination']['total'] = $data->total();
            $paginationArray['pagination']['current'] = $data->currentPage();
            $paginationArray['pagination']['first'] = 1;
            $paginationArray['pagination']['last'] = $data->lastPage();
            if($data->hasMorePages()) {
                if ( $data->currentPage() == 1) {
                    $paginationArray['pagination']['previous'] = 0;
                } else {
                    $paginationArray['pagination']['previous'] = $data->currentPage()-1;
                }
                $paginationArray['pagination']['next'] = $data->currentPage()+1;
            }
            else {
                $paginationArray['pagination']['previous'] = $data->currentPage()-1;
                $paginationArray['pagination']['next'] =  $data->lastPage();
            }
            if ($data->lastPage() > 1) {
                $paginationArray['pagination']['pages'] = range(1,$data->lastPage());
            }
            else {
                $paginationArray['pagination']['pages'] = [1];
            }
            $paginationArray['pagination']['from'] = $data->firstItem();
            $paginationArray['pagination']['to'] = $data->lastItem();
            //$paginationArray;
            //
            return $this->result = $paginationArray;

            /// }else {
            //     $paginationArray = $data;
            //     return $this->result = $paginationArray;
            // }
        }
        //return $paginationArray;
    }


    public function delete(Request $request,$id){

        try{
            $obj = $this->_model::find($id)->delete();

            return $this->successResponse($obj,'success');

        }catch (\Exception $e){
            return $this->errorResponse($e->getMessage(),$e->getCode());
        }

    }
    /**
     * success response method.
     *
     * @return \Illuminate\Http\Response
     */
    public function testResponse($result = [], $message,$paginate = FALSE,$code=200){

        $this->result = $result;
        if($paginate == TRUE){
            $this->paginate($result);
        }

        try{
            $obj = array();
            return $this->successResponse($obj,'success');
        }
        catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }


    }

    public static function saveImage($file, $module = 'user', $dynamicFolder = '', $extensions = ['jpeg', 'png', 'gif', 'bmp', 'svg'])
    {
        $currentFileSystem = config('filesystems.default');
        if ($currentFileSystem == 'local' || $currentFileSystem == 'public') {
            if (config('app.check_file_size')) {
                $fileSize = $file->getClientSize() / 1000;
                $sysytemFileSize = (int) config('app.file_size_in_kb');
                if ($fileSize > $sysytemFileSize) {
                    return false;
                }
            }
            list($name, $ext) = explode('.', $file->hashName());
            if (in_array($file->guessExtension(), $extensions)) {

                $image = Image::make($file);

                $width = $image->width();
                $height = $image->height();

                if (config('app.image_sizes')) {
                    $store = Storage::put(config('app.public.files.' . $module . '.folder_name') . '/' . $dynamicFolder . '/' . $name . '.' . $ext, $image->resize($width, $height)->stream($ext, config('app.image_compression')));
                    $store = Storage::put(config('app.public.files.' . $module . '.folder_name') . '/' . $dynamicFolder . '/' . $name . '-2x.' . $ext, $image->resize($width / 2, $height / 2)->stream($ext, config('app.image_compression')));
                    $store = Storage::put(config('app.public.files.' . $module . '.folder_name') . '/' . $dynamicFolder . '/' . $name . '-3x.' . $ext, $image->resize($width / 3, $height / 3)->stream($ext, config('app.image_compression')));
                } else {
                    $store = Storage::put(config('app.public.files.' . $module . '.folder_name') . '/' . $dynamicFolder . '/' . $name . '.' . $ext, $image->resize($width, $height)->stream($ext, config('app.image_compression')));
                }
                return $name . '.' . $ext;

            } else {
                return false;
            }

        } else {
            $folder = $dynamicFolder == '' ? 'misc' : $dynamicFolder;

            try {
                //$resp = Storage::put($file->getClientOriginalExtension(), $file);
                $resp = Storage::putFile($folder, $file, 'public');
                $path = Storage::url($resp);
            } catch (\Exception $e) {
                throw new \Exception($e->getMessage());
            }

            return $path;

        }

    }
    public function find_app($api_key){
            $app = App::where('api_key',$api_key)->first();
        if(!empty($app)){
            return $app;
        }
        else{
            throw new \Exception('Api key is invalid');

//            return $this->errorResponse(404,['Api key is incorrect']);
        }
    }
    public function findAppById($app_id){
        $app = App::find($app_id);
        return $app;
    }
    public function findAppByName($name){
        return App::where('name',$name)->first();
    }

    public function checkUserPayment($user): int
    {
        //Check payment via package
        if($user->usage()->count() == 0){
            $left_days = false;
        }
        else{
            $get_interval_days = Package::find($user->usage[0]->package_id);
            $interval_days = $get_interval_days->interval;
            //$days = ;
            switch ($interval_days){
                case 'month':
                    $days = 30;
                    break;
                case 'week':
                    $days = 7;
                    break;
                case 'day':
                    $days = 1;
                    break;
                case 'year':
                    $days = 365;
                    break;
                default:
                    throw new UnknownGetterException($interval_days);
            }

            //$payment_date = $user->payment[0]->date;
            $payment_date = $user->latestPayment->date;
            $package_days = Carbon::now()->addDays($days);
            $package_date = $package_days->toDateString();
            //dd($days,$package_days->toDateString());
            $current_days = Carbon::parse($payment_date)->diffInDays($package_date);
            $left_days = true;
            if ((int)$current_days == $current_days && (int)$current_days < 0 ){
                $left_days = false;
            }
        }

        return $left_days;
        //return $this->successResponse($current_days,'Payment days');

    }

    public function ifVcPackageProtected($id)
    {
        $package = VetCarePackage::find($id);
        if($package){
            $package = $package->benefit();
            $emergencyExist = $package->where('features','emergencyActivation')->first();
            if($emergencyExist){
                return true;
            }
        }
        return false;
    }

    public function slackLog($msg,$type = 'info'){
        $env = 'Environment-'.strtoupper(env('APP_ENV'));
        switch ($type) {
            case 'warning':
                Log::warning($env . ' : ' .$msg);
                break;
            case 'info':
                Log::info($env . ' : ' .$msg);
                break;
            case 'error':
                Log::error($env . ' : ' .$msg);
                break;
            case 'critical':
                Log::critical($env . ' : ' .$msg);
                break;
            default:
                Log::info($env . ' : ' .$msg);
                break;
        }
    }
}
