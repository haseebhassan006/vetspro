<?php

namespace App\Http\Controllers;

use App\AdminNotificableUser;
use App\Mail\MailAdminWhenNoVetOnline;
use App\Package;
use App\PackageUsage;
use App\Payment;
use App\PaymentProtectUser;
use App\User;
use App\Vet;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

class CronController extends Controller
{
    //
    public function cronMakeUserProtect(){
        $now = Carbon::now('UTC');
        $subscription_data = PaymentProtectUser::where('state','false')->get();
        $response = $this->errorResponse('No protect client found',204);
        foreach ($subscription_data as $data){
            $before = $data->subscription_timestamp;
            $interval = $now->diffInDays($before);
            if($interval > 14){
                //$days = $interval->format('%a');//now do whatever you like with $days
                $user = User::find($data->user_id);

                $usage = PackageUsage::where('user_id',$user->id)->first();

                if($usage){
                    $package = Package::find($usage->package_id);

                    if($package->type == 'protect'){
                        $payment_protect_user = PaymentProtectUser::where(['user_id'=>$user->id,
                            'state'=>'false'])->update(['subscribed_at'=>$now,
                            'state'=>'true']);
//                        $payment_protect_user->subscribed_at = $now;
//                        $payment_protect_user->save(['timestamps' => false]);

                        //Find User
                        $user->removeRole('users');
                        $user->assignRole('protect_users');
                        $response  = $this->successResponse('true','Protect client updated');
                    }
                }

            }
        }
        return $response;

    }
    public function checkVetAvailability()
    {
        try{
            $vet = Vet::whereHas(
                'roles', function($q){
                    $q->where('name', 'vets');
                }
            )->where('is_online',1)->get();
            if($vet->isEmpty()){
                if(count($vet) < 1){
                    Mail::to(env('MAIL_TO'))->send(new MailAdminWhenNoVetOnline(Carbon::now('America/Toronto')));
                    return $this->errorResponse('Notified Admin',202);
                }
                else{
                    return $this->successResponse([],'All Vets are available');
                }
            }
            else{
                return $this->successResponse([],'All Vets are available');
            }
        }
        catch (\Exception $exception){
            return $this->errorResponse($exception->getMessage(),404);

        }

    }

}
