<?php

namespace App\Http\Controllers\Trainer;

use Carbon\Carbon;
use App\TrainerSchedule;
use App\AppointmentBooking;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\Http\Requests\Trainer\TrainerScheduleEditRequest;
use App\Http\Requests\Trainer\TrainerScheduleCreateRequest;
use App\Http\Requests\Trainer\AppointmentUpdateRequest;
use App\Http\Resources\AppointmentResource;

class TrainerScheduleController extends Controller
{
    /**
     * Display a listing of the schedules.
     *
     * @return \Illuminate\Http\Response
     */
    public function get(Request $request)
    {
        try {
            $trainer = $this->trainer();
            $schedules = $this->trainer()->schedules();

            if($request->has('status') & ($request->status != null)){
                $schedules = $schedules->where('booking_status' , $request->status);
            }

            if($request->has('id') & !empty($request->id)){
                $schedules =  $schedules->where('id',$request->id)->get();
            }else{
                if($request->has('pagination') & !empty($request->pagination))
                {
                    $schedules =  $schedules->paginate($request->pagination);
                }else{
                    $schedules =  $schedules->get();
                }
            }

            return $this->successResponse($schedules,'Schedules Fetched Succesfully',FALSE,201);            
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    /**
     * Display a listing of the appointments.
     *
     * @return \Illuminate\Http\Response
     */
    public function getAppointment(Request $request)
    {
        try {
            $trainer = $this->trainer();
            $appointments = $this->trainer()->appointments();

            if($request->has('status') & ($request->status != null)){
                $appointments = $appointments->where('status' , $request->status);
            }

            if ($request->has('date_from') && $request->has('date_to')) {
                $appointments = $appointments->whereBetween('created_at',
                    [$request->date_from . " 00:00:00", $request->date_to . " 23:59:00"]
                );
            }

            if($request->has('id') & !empty($request->id)){
                $appointments =  $appointments->where('id',$request->id)->get();
            }else{
                if($request->has('pagination') & !empty($request->pagination))
                {
                    $appointments =  $appointments->paginate($request->pagination);
                }else{
                    $appointments =  $appointments->get();
                }
            }
            $data = AppointmentResource::collection($appointments);
            return $this->successResponse($data,'Appointments Fetched Succesfully',FALSE,201);            
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    public function updateAppointment($id,AppointmentUpdateRequest $request)
    {
        $requestData = $request->validated();
        try{
            $appointment = $this->trainer()->appointments()->where('id',$id)->update($requestData);
            $appointment = $this->trainer()->appointments()->where('id',$id)->get();
            $responseData = AppointmentResource::collection($appointment);
            return $this->successResponse($responseData, 'Appointment Succesfully Updated.');
            } catch (\Exception $e) {
                return $this->errorResponse($e->getMessage(), $e->getCode());
            }
    }
    /**
     * Show the form for creating a new resource.
     * 
     * @param  \App\TrainerSchedule  $trainerSchedule
     * @return \Illuminate\Http\Response
     */
    public function create(TrainerScheduleCreateRequest $request)
    {
        $data = $request->validated();
        $schedule = array();
        try {
            $trainer = $this->trainer();
            foreach ($data as $slot) {
                // Parsing date to Carbon
                $slot['slot_from_time'] = Carbon::parse($slot['slot_from_time']);
                $slot['slot_to_time'] = Carbon::parse($slot['slot_to_time']);
                $slot['date'] = Carbon::parse($slot['date']);
                $schedule = $trainer->schedules()->create($slot);
            }
            return $this->successResponse(true,count($data) . ' Slot(s) added and available for booking',FALSE,201);            
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }


    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\TrainerSchedule  $trainerSchedule
     * @return \Illuminate\Http\Response
     */
    public function edit($id,TrainerScheduleEditRequest $request)
    {
        $data = $request->validated();
        try {
            $schedule = $this->trainer()->schedules()->find($id);
            if($schedule){
                // Parsing date to Carbon
                $data['slot_from_time'] = Carbon::parse($data['slot_from_time']);
                $data['slot_to_time'] = Carbon::parse($data['slot_to_time']);
                $data['date'] = Carbon::parse($data['date']);
                $updatedSchedule = $schedule->update($data);
                return $this->successResponse($updatedSchedule,'Schedule has been updated');
            }else{
                return $this->errorResponse('You are not authorized to update this schedule',403);
            }            
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }


    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\TrainerSchedule  $trainerSchedule
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        try {
            $schedule = TrainerSchedule::find($id);
            if($schedule){
                $schedule->delete();
                return $this->successResponse(true,'Slot has been deleted',FALSE,201);            
            }else{
                return $this->errorResponse('Invalid slot Id',422);
            }
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    /**
    * Get the current trainer .
    *
    * @return \Illuminate\Contracts\Auth\Guard
    */
    public function trainer()
    {
        return Auth::guard('trainer')->user();
    }

}
