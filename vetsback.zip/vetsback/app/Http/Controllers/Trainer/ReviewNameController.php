<?php

namespace App\Http\Controllers\Trainer;

use App\FeedbackName;
use App\Http\Controllers\Controller;
use App\Http\Resources\ReviewNameResource;
use App\ReviewName;
use Illuminate\Http\Request;

class ReviewNameController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $reviewName = new ReviewName();
        $reviewNames = $reviewName->take(3)->get();

        $reviewNameResouces = ReviewNameResource::collection($reviewNames);

        return $this->successResponse($reviewNameResouces, 'Successfully Fetch Trainer Review Name List.');

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\FeedbackName  $feedbackName
     * @return \Illuminate\Http\Response
     */
    public function show(FeedbackName $feedbackName)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\FeedbackName  $feedbackName
     * @return \Illuminate\Http\Response
     */
    public function edit(FeedbackName $feedbackName)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\FeedbackName  $feedbackName
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, FeedbackName $feedbackName)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\FeedbackName  $feedbackName
     * @return \Illuminate\Http\Response
     */
    public function destroy(FeedbackName $feedbackName)
    {
        //
    }
}
