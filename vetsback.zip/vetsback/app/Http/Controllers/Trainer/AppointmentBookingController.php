<?php

namespace App\Http\Controllers\Trainer;

use Carbon\Carbon;
use App\TrainerSchedule;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\Http\Requests\Appointment\createAppointmentRequest;
use App\Http\Resources\AppointmentResource;
use App\Traits\VetCareUserPaymentTrait;
use Illuminate\Support\Facades\DB;

class AppointmentBookingController extends Controller
{
    use VetCareUserPaymentTrait;

    public function createAppointment(createAppointmentRequest $request){

        $data = $request->validated();
        $response = array();
        $user = $this->user();
        $pet_id = $request->pet_id;
        $this->initialize($user->app_id);
        try {
            //check if requested pet is user's pet
            $user_pets = $user->with('pets')->whereHas('pets' , function ($q) use ($pet_id){
                $q->where('id',$pet_id);
            })->first();
            if(!$user_pets){
                return $this->errorResponse('Sorry, please choose the correct pet', FALSE , 403);
            }
            // Check if slot available
            $slot = TrainerSchedule::where('id',$request->schedule_id)->first();
            if($slot->booking_status == 'Booked'){
                return $this->errorResponse('Sorry, This slot is already booked. Please book another slot or trainer', FALSE , 403);
            }
            //Create Payment
            if($request->has('payment') && (count($data['payment']) > 0) ){
                /**
                 * make payment of booking appointment
                  */
                $petName = $user_pets->pets->where('id',$pet_id)->first();

                $petName = $petName->name??"";
                $stripPaymentMeta = $data['payment'];
                $stripPaymentMeta['currency'] = 'usd';
                $stripPaymentMeta['price'] =  $data['payment']['amount'];
                $stripPaymentMeta['cus_id'] = $user_pets->stripe_id;
                unset($stripPaymentMeta['amount']);
                $createStripeToken = $this->createStripeToken($stripPaymentMeta);
                $source = $createStripeToken['token']->id;

                $stripPayment = $this->createPaymentIntent($stripPaymentMeta['price'],$stripPaymentMeta['currency'],$user_pets->stripe_id,$petName,$source );

                $charge_id = $stripPayment->price_id; // Stripe Response
                $payment = [
                    'trainer_id' => $request->trainer_id,
                    'app_id' => $user->app_id,
                    'charge_id' => $charge_id,
                    'amount' => $stripPaymentMeta['price'],
                    'date' => Carbon::now(),
                    'status' =>$stripPayment->code == 200? 'success':'failed',
                    'stripe_response' => $stripPayment
                ];
                $response['payment'] = $user->appointmentPayment()->create($payment);


            }
            $response['appointment'] = $user->appointmentBooking()->create([
                'trainer_id' => $request->trainer_id,
                'app_id' => $user->app_id,
                'schedule_id' => $request->schedule_id,
                'pet_id' => $pet_id,
                'appointment_payment_id' => $request->has('payment') ? $response['payment']['id'] : '',
                'status' => ($request->has('payment') && $response['payment']['id']) && $stripPayment['code'] == 200 ? 'completed' : 'pending',
                'booking_note' => $request->has('booking_note') ? $request->booking_note : '',
                'contact_no' => $request->has('contact_no') ? $request->contact_no : '',
            ]);



            // Update Status of Trainer Slot
            if(isset($response['appointment'])){
                $slot->update([
                    'booking_status' => 'Booked'
                ]);
            }

            return $this->successResponse($response,'Appointment has been created and in pending state',FALSE,201);
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    /**
     * funtion to get all appointments of logged-in user
     *
     * @param Request $request
     * @return JSON
     **/
    public function getMyAppointments(Request $request)
    {
        try {


            $isLowestFee =  $request->get('is_lowest_fee');
            $isLowestFee = ($isLowestFee === "true"||$isLowestFee === true)?true:false;

            $isMale = $request->get('is_male');
            $isMale = ($isMale === "true" || $isMale === true)?true:false;

            $isFemale = $request->get('is_female');
            $isFemale = ($isFemale === "true" || $isFemale === true)?true:false;

            $isMostExperience = $request->get('is_most_experience');
            $isMostExperience = ($isMostExperience === "true" || $isMostExperience === true)?true:false;

            $isHighestRate = $request->get('is_highest_rate');
            $isHighestRate = ($isHighestRate === "true" || $isHighestRate === true)?true:false;


            $user = $this->user();
            $appointments  = $user->load('appointmentBooking.trainer','appointmentBooking.app','appointmentBooking.user','appointmentBooking.schedule','appointmentBooking.appointmentPet','appointmentBooking.appointmentPayment');
            $appointments = $appointments->appointmentBooking;

            /*  */

            $appointments = DB::table('appointment_bookings')->where('model_type',get_class($user))->where('model_id',$user->id)
            ->leftJoin('trainers','trainers.id','appointment_bookings.trainer_id')
            ->leftJoin('trainer_schedules','trainer_schedules.trainer_id','appointment_bookings.trainer_id');
            if($isLowestFee)
            {
                $appointments = $appointments->orderBy('trainer_schedules.charges','asc');
            }
            if($isMale)
            {
                $appointments = $appointments->where('trainers.sex','M')->orderBy('trainers.id','asc');
            }
            if($isFemale)
            {
                $appointments = $appointments->where('trainers.sex','F')->orderBy('trainers.id','asc');
            }
            if($isMostExperience)
            {
                $appointments = $appointments->orderBy('trainers.experience','desc');
            }
            if($isHighestRate)
            {
                $appointments = $appointments->orderByRaw('(avg_rate/count_rate) desc');
            }
            $appointments= $appointments->distinct()->pluck('appointment_bookings.id');
           $appointmentIds= $appointments->toArray();


            $appointments  = $user->load(['appointmentBooking'=>function($q) use($appointmentIds){
                $appointmentIds = implode(",",$appointmentIds);
                return $q
                ->with('trainer','app','user','schedule','appointmentPet','appointmentPayment')->orderBy(DB::raw("FIELD(ID,{$appointmentIds})"));

            }]);
            $appointments = $appointments->appointmentBooking;

            if($request->has('status') & ($request->status != null)){
                $appointments = $appointments->where('status' , $request->status);
            }

            if($request->has('id') & !empty($request->id)){
                $appointments =  $appointments->where('id',$request->id)->get();
            }else{
                if($request->has('pagination') & !empty($request->pagination))
                {
                    $appointments =  $appointments->paginate($request->pagination);
                }else{
                 //   $appointments =  $appointments->get();
                }
            }
            $responseData = AppointmentResource::collection($appointments);
            return $this->successResponse($responseData,'Appointments Fetched Succesfully',FALSE,201);
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    /**
    * Get the current trainer .
    *
    * @return \Illuminate\Contracts\Auth\Guard
    */
    public function user()
    {
        return Auth::user();
    }
}
