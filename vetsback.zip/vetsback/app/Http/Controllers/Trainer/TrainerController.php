<?php

namespace App\Http\Controllers\Trainer;

use App\AppointmentBooking;
use App\AppointmentPet;
use App\Trainer;
use Carbon\Carbon;
use App\TrainerSchedule;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class TrainerController extends Controller
{
    public function getAllTrainers(Request $request){
        try {
            $trainers = new Trainer;

            if($request->has('id') & !empty($request->id)){
                $trainers = $trainers->selectRaw('trainers.*,round((avg_rate/(3*5*count_rate))*100,2) as satisfaction')->with(['schedules'=>function($q){
                    $q->selectRaw('trainer_id, min(charges) as min_charge, max(charges) as max_charge');
                },'reviews'=>function($q){
                    $q->select('id', 'trainer_id', 'user_id', 'booking_id', 'review_text',DB::raw('DATE_FORMAT(created_at,"%Y/%m/%d") as created_on'))
                    ->with('users:id,first_name,last_name,email,email_verified_at');
                }]);



              $trainers =  $trainers->where('id',$request->id)->get();

                $trainers->makeHidden(['email','avg_rate','count_rate','phone_number','sex','is_call','verification_token','is_active','updated_at','deleted_at']);


                //append waiting rate
                $avg= DB::select('SELECT (SUM(review_name_trainer_review.rate)/(5* COUNT(*)) )*100 AS rate FROM `trainer_reviews`
                JOIN review_name_trainer_review ON review_name_trainer_review.`trainer_review_id` = trainer_reviews.id
                WHERE review_name_id = 3
                AND trainer_reviews.trainer_id = '.$request->id.'
                GROUP BY trainer_reviews.trainer_id');

                $rate = $avg[0]->rate;
                $trainers[0]['wait_time'] =  $rate;

            }else{
                if($request->has('pagination') & !empty($request->pagination))
                {
                    $trainers =  $trainers->paginate($request->pagination);
                }else{
                    $trainers =  $trainers->get();
                }
            }
            return $this->successResponse($trainers , count($trainers) . ' Trainer(s) Fetched Succesfully');
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    public function getAllTrainerSlots(Request $request){

        try {

            $slots = new TrainerSchedule;

            if ($request->has('trainer_id') & !empty($request->trainer_id)) {
                $slots =  $slots->where('trainer_id', $request->trainer_id);
            }

            // By Status
            if ($request->has('booking_status') & !empty($request->booking_status)) {
                $slots =  $slots->where('booking_status', $request->booking_status);
            }
            if($request->has('appointment_pet_id') & !empty($request->appointment_pet_id)){
                $appointmentPet=  AppointmentBooking::where('appointment_pet_id',$request->appointment_pet_id)->pluck('schedule_id');
                $scheduleIds = $appointmentPet->toArray();
                $slots =  $slots->whereIn('id', $scheduleIds);

            }
            // Only Future Slots
            $level = '>=';
            $now = Carbon::now()->toDateString();
            if($request->has('is_expiry') & ($request->is_expiry != null)){
                $level = $request->is_expiry == 1 ? '<' : '>' ;
            }
            $slots = $slots->where('date' ,  $level , $now);

            if($request->has('id') & !empty($request->id)){
                $slots =  $slots->where('id',$request->id)->get();
            }else{
                if($request->has('pagination') & !empty($request->pagination))
                {
                    $slots =  $slots->paginate($request->pagination);
                }else{
                    $slots =  $slots->get();
                }
            }
            return $this->successResponse($slots , count($slots) . ' Slot(s) Fetched Succesfully');
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }
}
