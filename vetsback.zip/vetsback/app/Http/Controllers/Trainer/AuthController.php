<?php

namespace App\Http\Controllers\Trainer;

use JWTAuth;
use stdClass;
use Validator;
use App\Trainer;
use App\SubAdmin;
use Carbon\Carbon;
use Illuminate\Http\Request;
use App\AdminNotificableUser;
use App\Traits\TwilioSDKTrait;
use Illuminate\Support\Facades\DB;
use App\Traits\OtherTwilioSDKTrait;
use Illuminate\Support\Facades\App;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use App\Http\Requests\AdminUserRequest;
use Illuminate\Database\QueryException;
use App\Http\Requests\subAdminUpdateRequest;
use Carbon\Exceptions\UnknownGetterException;
use App\Http\Requests\SubAdminRegisterRequest;
use App\Http\Requests\Trainer\TrainerUpdateRequest;
use App\Http\Requests\Trainer\TrainerRegisterRequest;
use App\Http\Requests\Trainer\TrainerLoginRequest;
use App\Http\Requests\Trainer\TrainerResendVerificationRequest;
use App\Http\Requests\Trainer\TrainerChangePasswordRequest;
use Illuminate\Support\Facades\Mail;

class AuthController extends Controller
{
    protected $user;
    use TwilioSDKTrait;
    use OtherTwilioSDKTrait;
    private $noOfRecordPerPage = 10;
    private $paginate = false;

    public function __construct()
    {
        $this->generic();
        $this->construct();
    }

    /**
    * Get the guard to be used during authentication.
    *
    * @return \Illuminate\Contracts\Auth\Guard
    */
    public function guard()
    {
        return Auth::guard('trainer');
    }

    /**
     * login API
     *
     * @return \Illuminate\Http\Response
     */
    public function login(TrainerLoginRequest $request) //login request data
    {
        try {
            $credentials = $request->only(['email', 'password']);
            if ($token = $this->guard()->attempt($credentials)) {
                $this->user = $this->guard()->user();
                if($this->user->is_active!=1){
                    return $this->errorResponse('Account is temporary deactive , Please contact to Admin.');
                }
                if($this->user->email_verified_at == NULL && $this->user->verification_token!=NULL){
                    return $this->errorResponse('Account is not verifed  , Please verify your  account.');
                }
                if ($this->user->hasRole(['trainer'])) {
                    $dateTime =  Carbon::now();
                    $this->user->AuthenticationHistory()->create([
                        'dateTime' => $dateTime,
                        'type' => 'login'
                    ]);
                    $this->user->update(['is_online'=>1]); // Set Online
                    
                    $identity = 'trainer-'.$this->user->id;
                    $identity = is_local_env() ? 'local-' . $identity : $identity;

                    $dev_type = $request->dev_type;
                    if ($dev_type == 'android' || $dev_type == 'ios' || $dev_type == 'web') {
                        //Update or create new device
                            $this->user->devices()->updateOrCreate(['rec_id'=>$this->user->id],
                                [
                                'device_token'=>$request->device_token,
                                'udid'=>$request->udid,
                                'dev_type'=>$request->dev_type,
                                'app_version'=>$request->app_version,
                            ]);
                    }
                    $success['token'] = $token;
                    $success['trainerTwilioToken'] = $this->init($identity);
                    $success['trainer'] = $this->user;
                    return $this->successResponse($success, 'logged in as Trainer');
                } else {
                    return $this->errorResponse('Wrong credentials or missing access rights to application.');
                }
            } else {
                return $this->errorResponse('Wrong credentials or missing access rights to application.');
            }
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    /**
     * register API
     *
     * @param TrainerRegisterRequest $request
     * @return \Illuminate\Http\Response
     */
    public function create(TrainerRegisterRequest $request)
    {
        $validatedData = $request->except('udid','app_version','dev_type','device_token','password_confirmation','schedule');
        \DB::beginTransaction();
        try{
            $trainer = new Trainer;
            //check for profile_image 
            if($request->hasFile('profile_image')) {
                $validatedData['profile_image'] = $this->uploadFilePublicRepo($request->profile_image, 's3','vet_care_app');
            }
            if(array_key_exists('password',$validatedData)){
                $pwd = $validatedData['password'];
                $validatedData['password'] = bcrypt($validatedData['password']);
            }
            $token = str_random(64);
            $validatedData['verification_token'] =$token;
            $validatedData['specialties'] =json_encode($request->specialties);
            $data = $trainer->create($validatedData); // Saving Trainer to DB
            $data->assignRole('trainer'); // Assigning Role
            //Add trainer to twilio account as well
            $attributes = ["trainer_id"=>$data->id,"role"=>'trainer',"email"=>$data->email];
            $identity = 'trainer-'.$data->id;
            $identity = is_local_env() ? 'local-' . $identity : $identity;

            $dataToTwilio = [
                'attributes' => json_encode($attributes),
                'friendlyName' => $data->first_name.' '.$data->last_name,
                'identity'=> $identity
            ];
            $createUser = $this->createUser($dataToTwilio); // To Twilio Trait
            // Setting Device
            $data->devices()->firstOrCreate([
                'device_token' => $request->device_token,
                'rec_id'=>$data->id,
                'udid'=>$request->udid,
                'app_version'=>$request->app_version,
                'dev_type'=>$request->dev_type
            ]);
            $data->update(['is_online'=>1]); // Set Online
            // add schedule
            $schedule = array();
            if(isset($request->schedule) && sizeof($request->schedule)>0){
                foreach ($request->schedule as $slot) {
                    // Parsing date to Carbon
                    $slot['slot_from_time'] = Carbon::parse($slot['slot_from_time']);
                    $slot['slot_to_time'] = Carbon::parse($slot['slot_to_time']);
                    $slot['date'] = Carbon::parse($slot['date']);
                    $schedule[] = $data->schedules()->create($slot);
                }
            }
             // Setting URL for email
             $url = url('/trainer') . "/verify-email/" . $token . '?email=' . $data->email;
            //  Mail::send('customauth.trainer_verify', ['token' => $token, 'url' => $url], function ($message) use ($request) {
            //      $message->to($request->email);
            //      $message->subject('Veridy Email Notification');
            //  });
            //Response
            // $success['token'] = auth()->login($data);
            // $success['trainerTwilioToken'] = $this->init($identity);
            // $success['trainer'] = $data;
            // $success['trainer']['schedule'] = $schedule;
            $success['verification_link'] =$url ;

            // $dateTime =  Carbon::now();
            // auth()->user()->AuthenticationHistory()->create([
            //     'dateTime' => $dateTime,
            //     'type' => 'login'
            // ]);
            \DB::commit();
            
            return $this->successResponse($success, 'Successfully Created Trainer. verification link sent to your email');
        }catch (RestException $e) {
            \DB::rollback();
            return $this->errorResponse($e->getMessage(),$e->getCode());
        }
        catch (QueryException $e) {
            \DB::rollback();
            switch ($e->getCode()) {
                case 23000:
                    $message = "Email already exists";
                break;
                default:
                    $message = "Try again. Query Error";
            }
            return $this->errorResponse($message,405);
        }
        catch (\Exception $e) {
            \DB::rollback();
            return $this->errorResponse($e->getMessage(),$e->getCode());
        }
    }

    /**
     * Trainer Update and validating through Request Class
     * @param TrainerUpdateRequest $request
     * @return \Illuminate\Http\Response
     */
    public function update($id,TrainerUpdateRequest $request)
    {
        $data = $request->validated();
        try{
            $trainer = Trainer::findOrfail($id);
            $data['profile_image'] = ($request->hasFile('profile_image'))  ?  $this->uploadFilePublicRepo($data['profile_image'], 's3','vet_care_app') : null;
            $data['specialties'] =json_encode($data['specialties']);
            $trainer->update($data);
                return $this->successResponse($trainer, 'Trainer Succesfully Updated.');
            } catch (\Exception $e) {
                return $this->errorResponse($e->getMessage(), $e->getCode());
            }
    }
    /**
     * Delete
     * @param id $id
     * @return \Illuminate\Http\Response
     */
    public function deleted($id)
    {
        try {
            $trainer = Trainer::findOrfail($id);
            $trainer->delete();
            $data = array(
                "trainer" => $trainer
            );
            return $this->successResponse($data, 'Trainer Record Deleted.');
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    public function resendVerification(TrainerResendVerificationRequest $request){
        $input = $request->only(['email']);
        try {
            $trainer = Trainer::where(['email'=> $input['email']])->first();
            $token = str_random(64);
             // Setting URL for email
             $url = url('/trainer') . "/verify-email/" . $token . '?email=' . $input['email'];
             Mail::send('customauth.trainer_verify', ['token' => $token, 'url' => $url], function ($message) use ($request) {
                 $message->to($request->email);
                 $message->subject('Veridy Email Notification');
             });
            $trainer->verification_token = $token;
            $trainer->update();
            $data = array(
                // "trainer" => $trainer
                "link" => $url
            );
            return $this->successResponse($data, 'Trainer Verification Link Sent Successfully.');
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    public function getEmail($token)
    {

        return view('customauth.passwords.trainer_email_verify', [
            'token' => $token,
            'email' => request()->email,
        ]);
    }

    public function updateVerifyEmail(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'email' => 'required|email|exists:trainers',
        ]);

        if ($validator->fails()) {
            $errors[] = $validator->errors();
            return back()->withInput()->withErrors($validator);
        }

        $trainer = Trainer::where(['email' => $request->email, 'verification_token' => $request->token])
            ->first();

        if (!$trainer) {
            return back()->withInput()->withErrors('Invalid token!');
        }

        $trainer->verification_token = NULL;

        $trainer->email_verified_at =carbon::now();

        $trainer->update();

        return redirect('/thankyou/email-verified');
    }
    
    public function list(Request $request)
    {
        try {
            $trainer = new Trainer;
            if (isset($request['pagination']) && $request['pagination'] != "") {
                $this->paginate = true;
                $trainer = $trainer->paginate($this->noOfRecordPerPage);
            } else {
                $trainer_id = $request['trainer_id'];
                $trainer = $trainer->find($trainer_id);
            }
            $data = array(
                "trainer" => $trainer
            );
            return $this->successResponse($data, 'Successfully Fetch Trainer List.');
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    /**
     * Change password from old password
     *
     * @return JSON RESPONSE
     */
    public function changePassword(TrainerChangePasswordRequest $request)
    {
        if($this->guard()->user())
        {   
            $this->user = $this->guard()->user();
            if(Hash::check($request->old_password, $this->user->password)){
                $password = bcrypt($request->password);
                $this->user->update(['password' => $password]);
                return $this->successResponse(true, 'Password Updated Succesfully.');
            }else{
                return $this->errorResponse('Invalid current password. Please try again or request RESET PASSWORD.' , 422);
            }
        }
    }

    /**
     * Logout user (Revoke the token)
     *
     * @return [string] message
     */
    public function logout()
    {
        if($this->guard()->user())
        {   
            $this->user = $this->guard()->user();
            $data = array(
                'is_online'=>0,
            );
            $this->user->update($data);
            $dateTime =  Carbon::now();
            $this->user->AuthenticationHistory()->create([
                'dateTime' => $dateTime,
                'type' => 'logout'
            ]);
            auth()->logout();
            return $this->successResponse(true, 'Successfully logged out');
        }
    }

    /*
     * Twilio Chat refresh token
     */
    public function refreshTwilioApiToken(Request $request){
        $identity = $request->identity;
        $dev_type = $request->dev_type;
        $response['twilioToken'] = $this->init($identity, $dev_type);
        return $this->successResponse($response, 'Twilio Token');
    }
}
