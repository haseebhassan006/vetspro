<?php

namespace App\Http\Controllers\Trainer;

use App\AppointmentPayment;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Resources\AppoinmentPaymentResource;

class PaymentController extends Controller
{

    public function index(Request $request)
    {
        $limit = 10;
        $trainerId = $request->get('trainer_id');
        $appId = $request->get('app_id');
        $petId = $request->get('pet_id');
        $status =  $request->get('status');
        $contactNo =  $request->get('contact');


        $payment = new AppointmentPayment();

        $payment= $payment->when($trainerId,function($q) use($trainerId){
            $q->where('trainer_id',$trainerId);
        })


        ->when($appId,function($q) use($appId){
            $q->where('app_id',$appId);
        })

        ->when($petId,function($q) use($petId){
            $q->whereHas('appointmentBookings',function($q) use($petId){
                $q->where('pet_id',$petId);
            });
        })

        ->when($status,function($q) use($status){
            $q->where('status',$status);
        })


        ->when($contactNo,function($q) use($contactNo){
            $q->where('contact_no','like',"%$contactNo%");
        });

        $payments = $payment->paginate($limit);
        $paymentResouce = AppoinmentPaymentResource::collection($payments);
        return $paymentResouce;



    }
}
