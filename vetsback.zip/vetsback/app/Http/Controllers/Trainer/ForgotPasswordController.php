<?php

namespace App\Http\Controllers\Trainer;

use App\App;
use Validator;
use App\VetCare;
use Carbon\Carbon;
use App\Trainer;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Password;
use Illuminate\Foundation\Auth\SendsPasswordResetEmails;

class ForgotPasswordController extends Controller
{
    protected $redirectPath = '/success';

    public function __construct()
    {
        Config::set("auth. defaults.passwords", "trainers");
    }
    //
    /*
 |--------------------------------------------------------------------------
 | Password Reset Controller
 |--------------------------------------------------------------------------
 |
 | This controller is responsible for handling password reset emails and
 | includes a trait which assists in sending these notifications from
 | your application to your users. Feel free to explore this trait.
 |
 */
    use SendsPasswordResetEmails;

    public function __invoke(Request $request)
    {
        $this->validateEmail($request);
        // We will send the password reset link to this user. Once we have attempted
        // to send the link, we will examine the response then see the message we
        // need to show to the user. Finally, we'll send out a proper response.
        try {
            $response = $this->broker()->sendResetLink(

                $request->only('email')
            );
            // return ['received' => true];
            $success = $this->successResponse('Reset link sent to your email.', 'Reset link sent to your email.');
            $error = $this->errorResponse('Unable to send reset link', 401);
        } catch (\Exception $exception) {
        }
        return $response == Password::RESET_LINK_SENT
            ? $success
            : $error;
    }

    //    public function broker()
    //    {
    //        return Password::broker();
    //    }

    /**
//     * Write code on Method
//     *
//     * @return response()
//     */
    //    public function showForgetPasswordForm()
    //    {
    //        return view('auth.passwords.forgetPassword');
    //    }
    //
    //    /**
    //     * Write code on Method
    //     *
    //     * @return response()
    //     */
    //    public function submitForgetPasswordForm(Request $request)
    //    {
    //        $request->validate([
    //            'email' => 'required|email|exists:users',
    //        ]);
    //
    //        $token = Str::random(64);
    //
    //        DB::table('password_resets')->insert([
    //            'email' => $request->email,
    //            'token' => $token,
    //            'created_at' => Carbon::now()
    //        ]);
    //
    //        Mail::send('emails.forgetPassword', ['token' => $token], function($message) use($request){
    //            $message->to($request->email);
    //            $message->subject('Reset Password');
    //        });
    //
    //        return back()->with('message', 'We have e-mailed your password reset link!');
    //    }
    //    /**
    //     * Write code on Method
    //     *
    //     * @return response()
    //     */
    //    public function showResetPasswordForm($token) {
    //        return view('auth.passwords.forgetPasswordLink', ['token' => $token]);
    //    }
    //
    //    /**
    //     * Write code on Method
    //     *
    //     * @return response()
    //     */
    //    public function submitResetPasswordForm(Request $request)
    //    {
    //        $request->validate([
    //            'email' => 'required|email|exists:users',
    //            'password' => 'required|string|min:6|confirmed',
    //            'password_confirmation' => 'required'
    //        ]);
    //
    //        $updatePassword = DB::table('password_resets')
    //            ->where([
    //                'email' => $request->email,
    //                'token' => $request->token
    //            ])
    //            ->first();
    //
    //        if(!$updatePassword){
    //            return back()->withInput()->with('error', 'Invalid token!');
    //        }
    //
    //        $user = VetCare::where('email', $request->email)
    //            ->update(['password' => Hash::make($request->password)]);
    //
    //        DB::table('password_resets')->where(['email'=> $request->email])->delete();
    //
    //        return redirect('/success')->with('message', 'Your password has been changed!');
    //    }


    public function ForgotPassword(Request $request)
    {

        $request->validate([
            'email' => 'required|email|exists:trainers',
        ]);
        try {
            $token = str_random(64);

            DB::table('password_resets')->insert(
                ['email' => $request->email, 'token' => $token, 'created_at' => Carbon::now()]
            );

            // Setting URL
            $url = url('/trainer') . "/reset-password/" . $token . '?email=' . $request->email ;
                Mail::send('customauth.trainer_verify', ['token' => $token, 'url' => $url], function ($message) use ($request) {
                    $message->to($request->email);
                    $message->subject('Reset Password Notification');
                });
            $success = $this->successResponse('Reset link sent to your email.', 'Reset link sent to your email.');
            // $success=$this->successResponse($url,'Reset link sent to your email');            
            return $success;
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    public function getPassword($token)
    {

        return view('customauth.passwords.trainer_reset', [
            'token' => $token,
            'email' => request()->email,
            'id' => request()->id
        ]);
    }

    public function updatePassword(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'email' => 'required|email|exists:trainers',
            'password' => 'required|string|min:6|confirmed',
            'password_confirmation' => 'required',
        ]);

        if ($validator->fails()) {
            $errors[] = $validator->errors();
            return back()->withInput()->withErrors($validator);
        }

        $updatePassword = DB::table('password_resets')
            ->where(['email' => $request->email, 'token' => $request->token])
            ->first();

        if (!$updatePassword) {
            return back()->withInput()->withErrors('Invalid token!');
        }

        $user = Trainer::where(['email' => $request->email])
            ->update(['password' => bcrypt($request->password)]);


        DB::table('password_resets')->where(['email' => $request->email, 'token' => $request->token])->delete();

        return redirect('/thankyou');
    }
}
