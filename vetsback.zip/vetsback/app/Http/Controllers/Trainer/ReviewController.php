<?php

namespace App\Http\Controllers\Trainer;

use App\AppointmentBooking;
use App\TrainerReview;
use App\Trainer;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Resources\AppointmentReviewResource;
use Illuminate\Support\Facades\Auth;
use App\Http\Requests\Trainer\TrainerCreateFeebackRequest;
use App\ReviewNameTrainerReview;
use Twilio\Exceptions\RestException;

class ReviewController extends Controller
{
    //
    private $noOfRecordPerPage = 10;
    private $paginate = false;


    public function index(Request $request)
    {
        $input = $request->only('search_value', 'search_by', 'page', 'pagination', 'perPage',  'date_from', 'date_to','trainer_id');

        try {
            $trainerReview = new TrainerReview();

            $user = auth()->user();

            if(isset($input['trainer_id']) && $input['trainer_id'] != ""){
                $trainer_id = $input['trainer_id'];
                $trainerReview = $trainerReview::where('trainer_id',$trainer_id);
            }

            if (isset($input['pagination']) && $input['pagination'] != "") {
                $this->paginate = true;
                $trainerReview = $trainerReview->paginate($this->noOfRecordPerPage);
            }
            else  {
                $trainerReview = $trainerReview::get();
            }
            $trainerReview = AppointmentReviewResource::collection($trainerReview);

            return $this->successResponse($trainerReview, 'Successfully Fetch Trainer Feedback List.',$this->paginate);
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }



    public function create(TrainerCreateFeebackRequest $request)
    {
        $input = request()->only('trainer_id','booking_id','booking_pet_id','review_text');
        try{
            $user = auth()->user();

            $trainerReview = new TrainerReview;
            $appointment_id = $input['booking_id'];

            $trainer=Trainer::with('appointments')->whereHas(
                'appointments', function ($q) use ($appointment_id)  {
                $q->where('id', $appointment_id);
            })->findorfail($input['trainer_id']);

            $input['user_id'] = $user->id;
            $input['booking_id'] = $trainer->appointments[0]->id;
            $input['trainer_id'] = $trainer->id;

            $appointmentBooking = AppointmentBooking::find($input['booking_id']);


            $trainerReview = $trainerReview->fill($input); // Saving Trainer to DB

            $trainerReview = $appointmentBooking->reviews()->save($trainerReview);
            $trainerReview->ratings()->sync($request->get('ratings'));

            $trainerReview->load('raviewRatings');

            $data = AppointmentReviewResource::make($trainerReview);

            return $this->successResponse($data, 'Successfully Created Trainer Feedback.');
        }catch (RestException $e) {
            return $this->errorResponse($e->getMessage(),$e->getCode());
        }
    }


    public function update(TrainerCreateFeebackRequest $request)
    {
        $input = request()->only('trainer_id','booking_id','booking_pet_id','review_text',
        'ratings',
        'trainer_review_id'
         );
        $validatedData = $request->except('trainer_review_id','api_key','ratings');

        try{
            $user = auth()->user();

            $trainerReview = TrainerReview::where('id',$input['trainer_review_id'])->where('user_id',$user->id)->first();

            if(!$trainerReview){
                return $this->errorResponse("No Data Found",404);
            }
            $appointment_id = $input['booking_id'];
            $trainer=Trainer::with('appointments')->whereHas(
                'appointments', function ($q) use ($appointment_id)  {
                $q->where('id', $appointment_id);
            })->findorfail($input['trainer_id']);

            $input['user_id'] = $user->id;
            $input['booking_id'] = $trainer->appointments[0]->id;
            $input['trainer_id'] = $trainer->id;
            $trainerReview->update($validatedData); // update Trainer review to DB
            foreach($request->get('ratings') as $rating)
            {
               $reviewNameTrainerReview = ReviewNameTrainerReview::where('review_name_id',$rating['review_name_id'])
               ->where('trainer_review_id',$input['trainer_review_id'])->first();
               $reviewNameTrainerReview->rate = $rating['rate'];
               $reviewNameTrainerReview->save();

            }

            $trainerReview->load('raviewRatings');

            $trainerReview = AppointmentReviewResource::make($trainerReview);


            return $this->successResponse($trainerReview, 'Successfully Created Trainer Feedback.');
        }catch (RestException $e) {
            return $this->errorResponse($e->getMessage(),$e->getCode());
        }
    }

    public function destroy(Request $request){
        $input = request()->only('review_id');
        try{
            $user = auth()->user();

            $trainerReview = TrainerReview::where('id',$input['review_id'])->where('user_id',$user->id)->first();

            if(!$trainerReview){
                return $this->errorResponse("No Data Found",404);
            }
            // delete Trainer review to DB
            $trainerReview->delete();
            $trainerReview = AppointmentReviewResource::make($trainerReview);
            return $this->successResponse($trainerReview, 'Successfully Trainer Feedback Deleted.');
        }catch (RestException $e) {
            return $this->errorResponse($e->getMessage(),$e->getCode());
        }

    }


}
