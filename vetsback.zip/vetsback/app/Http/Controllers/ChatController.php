<?php

namespace App\Http\Controllers;

use App\App;
use App\Chat;
use App\ChatDetail;
use App\FailedHandshake;
use App\Http\Requests\ChatRequest;
use App\Package;
use App\Pet;
use App\TChatInfo;
use App\TChatMessage;
use App\Traits\CustomSearch;
use App\Traits\TwilioSDKTrait;
use App\Vet;
use Carbon\Carbon;
use Carbon\Exceptions\UnknownGetterException;
use Illuminate\Database\QueryException;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Twilio\Rest\Client;
use GuzzleHttp\Client as Http;

class ChatController extends Controller
{
    use TwilioSDKTrait;
    use CustomSearch;

    private $noOfRecordPerPage = 10;
    private $paginate = false;


    public function __construct()
    {
        $this->generic();
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $input = $request->only('search_value', 'search_by', 'PageSize', 'pagination', 'Page');
        try{
            $url = '';
            $user = auth()->user();
            if($user->hasRole('admin')){
                $url = 'https://chat.twilio.com/v2/Services/ISbaa48843bb7544519d587e5e92182993/Channels?Type=private';
            }
            if($user->hasRole('vets')){
                $url = 'https://chat.twilio.com/v2/Services/ISbaa48843bb7544519d587e5e92182993/Users/app-'.$user->app_id.'_vet-'.$user->id.'/Channels?Type=private';
            }
            if($user->hasAnyRole(['users','protect_users'])){
                $url = 'https://chat.twilio.com/v2/Services/ISbaa48843bb7544519d587e5e92182993/Users/app-'.$user->app_id.'_user-'.$user->id.'/Channels?Type=private';
            }

            $channels = $this->fetchAllChannels($url);
            return $this->successResponse($channels, 'Inbox');
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(),$e->getCode());
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @param ChatRequest $request
     * @return \Illuminate\Http\Response
     * }
     */
    public function create(ChatRequest $request)
    {
        $validated = $request->validated();
        $user = auth()->user();
        try{
            $app = $this->find_app($request->api_key);
            $pet = new Pet();
            if($app->app_type == 'sdk'){
                $guard = 'guests';
                $pet_info = $request->pet_info;
                $pet_info['user_id'] = $user->id;
                $search_in_pet = $user->where('pet_id',$request->pet_id)->first();
                if(!$search_in_pet){
                    $pet_info = $user->pets()->create($pet_info);
                    $user->where('id',$user->id)->update(['pet_id'=>$pet_info->id]);
                }
            }
            else{
                $guard = 'api';
                $pet_info = $pet->find($request->pet_id);
            }
            //dd(auth()->guard($guard)->user());
            $vet_id = $this->checkOnlineVet();
            if(!$vet_id){
                //Log failed calls
                FailedHandshake::create([
                    'request'=> json_encode($request->all()),
                    'response'=>json_encode(['message'=>get_vet_busy_text($app->id),'code'=>406]),
                    'app_id'=>$app->id
                ]);
                return $this->errorResponse(get_vet_busy_text($app->id),406);
            }
            //Create Channel when there is an vet online
            $vet_info = Vet::find($vet_id);
            $vet_full_name = $vet_info->first_name.' '.$vet_info->last_name;
            $user_full_name = $user->first_name.' '.$user->last_name;
            $vet_profile = '';
            $user_profile = '';
            if($vet_info->vetDetails != NULL){
                $vet_profile = $vet_info->vetDetails->profile;
            }
            if($user->userDetails != NULL){
                $user_profile = $user->userDetails->profile;
            }
            $is_protect = $user->roles->pluck('name');
            $channelName = 'app_'.$user->app_id.'-user_'.$user->id.'-vet_'.$vet_id.'-pet_'.$pet_info->id.'-'.Carbon::now();
            $response = $this->createChannel($channelName,$user->id,$vet_id,$user->app_id,$vet_full_name,$user_full_name,$pet_info,$user_profile,$vet_profile,$app->name,$is_protect);
            $success['channelsid'] = $response;
            return $this->successResponse($success, 'Message sent');
        }
        catch (QueryException $e){
            return $this->errorResponse('Query Exception',500);
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(),$e->getCode());
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     * @throws \Exception
     */
    public function store(Request $request)
    {
        //
        //dd($request->all());
        $event = $request->EventType;
        $from = $request->From;
        $channel_sid = $request->ChannelSid;
        $body = $request->Body;
        $attributes = json_decode($request->Attributes,true);
        $member_data = $this->fetchAllMembers($channel_sid);
        //$message_index = $request->MessageSid;
        $channel_name = $this->fetchChannelName($channel_sid);
        $sender_id = '';
        $rec_id = '';
        foreach($member_data as $a_member){
            if($from == $a_member['member_id']){
                $sender_id = $a_member['identity'];
                //unset($a_member['identity']);
            }
            if($from != $a_member['member_id']){
                $rec_id = $a_member['identity'];
                //unset($a_member['identity']);
            }
        }


        $webhook_id = $this->fetchWebhooks($channel_sid);

//        $t_chat_info = TChatInfo::firstOrCreate([
//            'chat_id' => $chat->id,
//            'member_data' => json_encode($member_data),
//            'channel_sid'  => $channel_sid,
//            'webhook_id'   => $webhook_id
//        ]);

//        $t_chat_message = TChatMessage::firstOrCreate([
//            'msg_sid' => $message_index,
//            'channel_sid'=> $channel_sid,
//            'c_friendly_name'=> $channel_name
//        ]);

        if ($event == 'onMessageSent') {

            // Save Chat basic data in chats table
            $chat = Chat::firstOrCreate([
                'data'=> json_encode($request->all()),
                'channel_sid'=>$request->ChannelSid
            ]);

            $res = $this->successResponse($chat, 'Message text Resource Completed');
        }
        if($event == 'onMediaMessageSent'){

            $msg_file = $request->MediaFilename;

            $file_ext = $request->MediaContentType;

            $media_url = time() . '_.' . $msg_file;

            $msg_sid = $request->sid;

            $media_sid = $request->MediaSid;

            //Get the current message info
            $this->fetchSingleMessage($channel_sid,$msg_sid);

            //To get media from twilio message and save the path in our file structure
            $output = $this->fetchMediaMessage($media_sid);

            $json = json_decode($output);

            $tempFromTwilio = $json->links->content_direct_temporary;

            //$get_chat_id = TChatInfo::where('channel_sid',$channel_sid)->first();

//            ChatDetail::firstOrCreate([
//                'chat_id'=> $get_chat_id->chat_id,
//                'body'=> $body,
//                't_chat_type_id'=>2,
//            ]);
            // Save Chat basic data in chats table
            $chat = Chat::firstOrCreate([
                'data'=> json_encode($request->all())
            ]);
            $res = $this->successResponse($chat, 'Message attachment Resource Completed');

        }
//        $t_chat_message = TChatMessage::where('channel_sid',$channel_sid)->update([
//            'last_message'=> $body
//        ]);

        return $res;

    }



    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    function stripslashes_deep($value)
    {
        $value = is_array($value) ?
            array_map('stripslashes_deep', $value) :
            stripslashes($value);

        return $value;
    }
}
