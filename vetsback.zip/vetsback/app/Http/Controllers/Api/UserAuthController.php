<?php

namespace App\Http\Controllers\Api;

use App\App;
use App\User;
use Exception;
use Carbon\Carbon;
use App\UserDetail;
use App\WebappUser;
use App\WebAppUsersExtra;
use Illuminate\Http\File;
use Tymon\JWTAuth\JWTAuth;
use App\Mail\ContactSupport;
use Illuminate\Http\Request;
use App\ReportUserTypeStatus;
use App\Traits\TwilioSDKTrait;
use App\Http\Requests\UserRequest;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail;
use Twilio\Exceptions\TwilioException;
use Illuminate\Database\QueryException;
use App\Http\Requests\UserContactSupport;
use Illuminate\Support\Facades\Validator;
use App\Http\Requests\WhitelableUserUpdateRequest;
use Illuminate\Support\Facades\Hash;

class UserAuthController extends Controller
{
    use TwilioSDKTrait;

    public function __construct()
    {
        $this->generic();
    }
//

    /**
     * login API
     *
     * @param UserRequest $request
     * @return \Illuminate\Http\Response
     */
    public function login(Request $request)
    {
        $input = $request->all();
        $validator = Validator::make($input, [
            'email' => 'required|email',
            'password' => 'required',
            'device_token'=>'required',
            'udid'=>'required',
           // 'app_id'=>'required',
            'dev_type'=>'required',
            'app_version'=>'required',
        ]);
        if ($validator->fails()) {
            return $this->errorResponse($validator->errors()->all());
        }
        $credentials = $request->only(['email', 'password']);
        try {
            if ($token = $this->guard()->attempt($credentials)) {
                $user = auth()->user();
                if(!$user->hasAnyRole('users','protect_users')){
                    return $this->errorResponse('UnAuthorized. Please contact admin',401);
                }

                $app_id = $this->find_app($request->api_key);
                $user->updateAppId($app_id->id);
                //Update or create new device
                $user->devices()->delete();
                $user->devices()->updateOrCreate(['device_token'=>$request->device_token],[
                    'rec_id'=>$user->id,
                    'device_token'=>$request->device_token,
                    'udid'=>$request->udid,
                    'dev_type'=>$request->dev_type,
                    'app_version'=>$request->app_version
                ]);
                //update appid on twilio user resource if new appid
                if ($app_id->id != $user->app_id) {
                    $identity = 'app-'.$app_id->id.'_user-'.$user->id;
                    $identity = is_local_env() ? 'local-' . $identity : $identity;
                    $this->fetchAndUpdateUser($app_id->id,$identity);
                }
                $success['token'] = $token;
                $success['twilioToken'] = $this->init(is_local_env() ?  'local-' . 'app-'.$app_id->id.'_user-'.$user->id : 'app-'.$app_id->id.'_user-'.$user->id, $request->dev_type, $app_id->id);
                $success['user'] = auth()->user()->load(['devices','userDetails','usage','latestPayment']);

                $dateTime =  Carbon::now();

                auth()->user()->userAuthenticationHistory()->create([
                    'dateTime' => $dateTime,
                    'type' => 'login',
                ]);

                return $this->successResponse($success, 'logged in');
            } else {
                return $this->errorResponse('Wrong credentials');
            }
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    /**
     * register API
     *
     * @param UserRequest $request
     * @return \Illuminate\Http\Response
     */
    public function create(UserRequest $request)
    {
        $validatedData = $request->validated();
        try {
            if(array_key_exists('password',$validatedData)){
                $pwd = $validatedData['password'];
                $validatedData['password'] = bcrypt($validatedData['password']);
            }
            $app_id = $this->find_app($request->api_key);
            $validatedData['app_id'] = $app_id->id;
            $user = User::create($validatedData);
            $other = ['phone_no'=>$validatedData['phone_no']];
            $user_details = ['user_id'=>$user->id,'other'=>$other];
            $user->userDetails()->create($user_details);
            $user->assignRole("users");
            $user->devices()->updateOrCreate(['dev_type'=>$request->dev_type],[
                'device_token' => $request->device_token,
                'rec_id'=>$user->id,
                'udid'=>$request->udid,
                'app_version'=>$request->app_version
            ]);

            //Add user to twilio account as well
            $attributes = ["app_id"=>$app_id->id,"user_id"=>$user->id,"email"=>$request->email];
            $identity = 'app-'.$app_id->id.'_user-'.$user->id;
            $identity = is_local_env() ? 'local-' . $identity : $identity;
            $dataToTwilio = [
                'attributes' => json_encode($attributes),
                'friendlyName' => $request->first_name.' '.$request->last_name,
                'identity'=> $identity
            ];
            $createUser = $this->createUser($dataToTwilio);
            $success['token'] = auth()->login($user);
            $success['twilioToken'] = $this->init($identity, $request->dev_type, $request->app_id);
            //$success['user'] = $user->getUserDetails($user->id);
            $success['user'] = $user->load(['devices','userDetails','usage','latestPayment']);


            return $this->successResponse($success, 'signed up');
        }
        catch (TwilioException $e) {
            return $this->errorResponse($e->getMessage(), $e->getStatusCode());
        }
        catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }

    }
    /**
     * Logout user (Revoke the token)
     *
     * @param Request $request
     * @return  [string] message
     */
    public function logout(Request $request)
    {
        $user = $request->user();
        //$user->update(['is_online'=>0]);

        $dateTime =  Carbon::now();
        $user->update(['is_online'=>0]);
        $user->devices()->delete();
        $user->userAuthenticationHistory()->create([
            'dateTime' => $dateTime,
            'type' => 'logout'
        ]);

        auth()->logout();
        return $this->successResponse(true, 'Successfully logged out');
    }
    /**
     * Get the authenticated User
     *
     * @return  [json] user object
     */
    public function user()
    {
        try {
            $user = auth()->user();
            //$data['basic'] = $user->getUserDetails($user->id);
            $data = $user->load(['userDetails','usage','latestPayment']);
            return $this->successResponse($data, 'user data');
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }
    /**
     * add_profile user and validating through Request Class
     * @param UserRequest $request
     * @return \Illuminate\Http\Response
     */
    public function update($id,UserRequest $request)
    {
        $data = $request->validated();
        //dd($data['other']);
        $user = auth()->user();
        try {
            unset($data['api_key']);
            $identity = 'app-'.$user->app_id.'_user-'.$id;
            $identity = is_local_env() ? 'local-' . $identity : $identity;

            if($request->hasFile('profile')){
                $data['profile'] = $path = $this->uploadFile($request->profile,'users');
                $get_user_channels = $this->fetchUserChannel($identity);
                if($get_user_channels){
                    foreach ($get_user_channels as $channelData){
                        $channel_data = $this->fetchChannel($channelData->channelSid,'arr');
                        $attributes_data = $channel_data->attributes;
                        $json_data = json_decode($attributes_data,true);
                        //dd($json_data['user']['profile']);
                        //$json_data = json_decode($json_data,true);
                        $json_data['user']['profile'] = $data['profile'];
                        $json_object = json_encode($json_data);
                        $this->updateChannelAttribute($channelData->channelSid,$json_object);
                    }
                }

            }
            $data['other'] = $data;
            $user->userDetails()->updateOrCreate(['user_id'=>$user->id],$data);
            //Update channel attributes data on twilio
            $user->update($data);
            $data = $user->load(['userDetails','usage','payment']);
            return $this->successResponse($user, 'user data');
        }
        catch (QueryException $e) {
            switch ($e->getCode()) {
                case 23000:
                    $message = "Record not updated. Try again";
                    break;
                default:
                    $message = "Try again. Query Error";
            }
            return $this->errorResponse($message,405);
        }catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    /**
     * Updating user and validating through Request Class
     * @param WhitelableUserUpdateRequest $request
     * @return \Illuminate\Http\Response
     */
    public function update_password(WhitelableUserUpdateRequest $request) //api not working please breif
    {
        $data = $request->validated();
        $user = $request->user();
        try {
            if (array_key_exists('new_password', $data)) {
                if ( Hash::check($data['old_password'], $user->password) == false) {
                    throw new \Exception('invalid password');
                }
                $data['password'] = bcrypt($data['new_password']);
            }
            unset($data['new_password'],$data['old_password']);
            $user->update(['password' =>  $data['password']]);
            $user = $user->getUserDetails($user->id);
            return $this->successResponse($user, 'Password updated successfully');
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    /**
     * Get the token array structure.
     *
     * @param string $token
     *
     * @return \Illuminate\Http\Response
     */
    protected function respondWithToken($token)
    {
        $a = [
            'token' => $token,
            'token_type' => 'bearer',
            'expires_in' => auth()->factory()->getTTL() * 60
        ];

        return $this->successResponse($a, 'user data');
    }
    /**
     * Refresh a token.
     *
     * @return \Illuminate\Http\Response
     */
    public function refresh()
    {

        return $this->respondWithToken(auth()->refresh(true, true));
    }

    /**
     * Get the guard to be used during authentication.
     *
     * @return \Illuminate\Contracts\Auth\Guard
     */
    public function guard()
    {
        return Auth::guard('api');
    }

    /**
     * Get the authenticated User.
     *
     */
    public function me()
    {
        return response()->json(auth()->user());
    }

    public function upload(Request $request)
    {
        // dd($request->file('file'));
        $file ="";
        if ($files =  $request->file('file')) {
            foreach ($request->file('file') as $key => $file) {
                $file = $this->saveImage($file);
            }
        }
        return response()->json($file, 200);
    }

    public function contactSupport(UserContactSupport $request){
        $data = $request->validated();
        $user = auth()->user();
        try{
            $subject = $request->subject;
            $text = $request->text;
            $user_name = $user->first_name.' '.$user->last_name;
            $email = $user->email;
            Mail::to(env('MAIL_TO'))->send(new ContactSupport($subject,$text,ucfirst($user_name),$email));

            return $this->successResponse(true,'Email sent');
        }catch (\Exception $e){
            return $this->errorResponse($e->getMessage(),$e->getCode());
        }
    }


    public function putDummyRecords(){
        ##For Users
        $users = new User;
        $users = $users->withTrashed()->get();
        $rep = new ReportUserTypeStatus;
        $count = [
            'user_count' => 0,
            'webAppUser_count' => 0
        ];
        foreach($users as $user)
        {
            $data = [
                'user_id' => $user->id,
                'app_id' => $user->app_id,
                'role' => count($user->role_names) > 0 ? $user->role_names[0] : 'users',
            ];
            $asd = $rep->create($data);
            if($asd){
                $count['user_count']++;
            }
        }

        ##For WebAppUsers
        $wausers = new WebappUser;
        $wausers = $wausers->withTrashed()->get();
        $rep = new ReportUserTypeStatus;
        foreach ($wausers as $user) {
            $u = new WebAppUsersExtra;
            $u = $u->where('user_id',$user->id)->orderBy('created_at', 'DESC')->first();
            $data = [
                'user_id' => $user->id,
                'app_id' => $user->app_id,
                'role' => ($u == null) ? 'users' : $u->protected,
            ];
            $asd = $rep->create($data);
            if($asd){
                $count['webAppUser_count']++;
            }
        }
        return $this->successResponse($count,$count['user_count'] + $count['webAppUser_count'] . ' Records added');
    }

    public function runMigration(Request $request){

        try{
            if($request->has('password') && $request->password == 'ali'){
                $Asd = \Artisan::call('migrate');
                return $this->successResponse(true,'Migration run successfully');
            }else{
                return $this->errorResponse('Invalid password',401);
            }
        }catch (\Exception $e){
            return $this->errorResponse($e->getMessage(),$e->getCode());
        }


    }

}
