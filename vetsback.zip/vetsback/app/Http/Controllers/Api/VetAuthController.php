<?php

namespace App\Http\Controllers\Vet;

use App\Traits\TwilioSDKTrait;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use App\User;
use App\Vet;
use Illuminate\Support\Facades\Auth;

class VetAuthController extends Controller
{
    //
    use TwilioSDKTrait;
    protected $user;
    public function login(Request $request)
    {
        $input = $request->all();
        $validator = Validator::make($input, [
            'email' => 'required|email',
            'password' => 'required',
            'device_token'=>'required',
            'udid'=>'required',
            'app_id'=>'required',
            'dev_type'=>'required',
            'app_version'=>'required',
        ]);
        if ($validator->fails()) {
            return $this->errorResponse($validator->errors()->all());
        }
        $credentials = $request->only(['email', 'password']);
        try{
            if ($token = $this->guard()->attempt($credentials)) {
                //return $this->respondWithToken($token);
                $this->user = auth()->guard('vets')->user();

                //Update or create new device
                $device =  $this->user->devices->firstWhere('udid',$request->udid);

                if(isset($device)){
                    $this->user->devices()->where('udid',$request->udid)->update([
                        'device_token'=>$request->device_token,
                        'dev_type'=>$request->dev_type,
                        'app_version'=>$request->app_version,
                    ]);
                }
                else{
                    $this->user->devices()->create([
                        'rec_id'=> $this->user->id,
                        'device_token'=>$request->device_token,
                        'udid'=>$request->udid,
                        'dev_type'=>$request->dev_type,
                        'app_version'=>$request->app_version,
                    ]);
                }
                $success['token'] = $token;
                $success['twilioToken'] = $this->init('app-'.$request->app_id.'_vet-'.$this->user->id,$request->dev_type,$request->app_id);
                $success['vet'] = $this->user;

                return $this->successResponse($success, 'logged in');
            }else{
                return $this->errorResponse('Wrong credentials');
            }
        }catch (\Exception $e){
            return $this->errorResponse($e->getMessage(),$e->getCode());
        }
    }

    /**
     * Get the guard to be used during authentication.
     *
     * @return \Illuminate\Contracts\Auth\Guard
     */
    public function guard()
    {
        return Auth::guard('vets');
    }
}
