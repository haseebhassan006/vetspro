<?php

namespace App\Http\Controllers\Api;

use App\Vet;
use App\Chat;
use App\Queue;
use Exception;
use App\ExtraPet;
use App\SubAdmin;
use App\VideoCall;
use Carbon\Carbon;
use App\ChatDetail;
use App\WebappUser;
use App\ChatEndedBy;
use App\FailedHandshake;
use App\VideoCallHistory;
use App\WebAppUsersExtra;
use Twilio\Jwt\AccessToken;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Aws\Exception\AwsException;
use Twilio\Jwt\Grants\ChatGrant;
use App\Http\Controllers\Controller;
use Twilio\Exceptions\RestException;
use Twilio\Exceptions\TwilioException;
use App\Http\Requests\TwilioApiRequest;
use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\Storage;

class PawpUserConversationController extends TwilioApiController
{
    //
    /**
     * @param TwilioApiRequest $request
     * @return Response
     */
    public function handshake(TwilioApiRequest $request){
        $validated = $request->validated();
        // Get Activated Staff
        $subAdmin = $this->isSubAdminOnline();
        try {
            //$vet_id = $this->checkVetChat();
            $app = $this->find_app($request->api_key);
            $conversation_request = $request->conversation_request;
//            if($vet_id == false){
//                FailedHandshake::create([
//                    'request'=> json_encode($request->all()),
//                    'response'=>json_encode(['message'=>'Vets are busy at the moment. Try again later','code'=>406]),
//                    'app_id'=>$app->id
//                ]);
//                return $this->errorResponse('Vets are busy at the moment. Try again later', 406);
//            }
            if($conversation_request == 'chat'){ $vet_id = $this->checkVetChat();}
            elseif($conversation_request == 'video'){ $vet_id = $this->checkVetVideo();}
            if($vet_id == false){
                FailedHandshake::create([
                    'request'=> $request->all(),
                    'response'=>['message'=>'Vets are busy at the moment. Try again later','code'=>406],
                    'app_id'=>$app->id
                ]);
                return $this->errorResponse('Vets are busy at the moment. Try again later', 406);
            }
            $app = $this->find_app($request->api_key);
            $channel = isset($request->channel_sid) ? $request->channel_sid : '';
            $room = isset($request->room_sid) ? $request->room_sid : '';
            $type = isset($request->type) ? $request->type : '';
            $status = isset($request->status) ? $request->status : '';
            $oldVetId = isset($request->vet_id)?$request->vet_id:null;
            $is_protect = $request->is_protect;
            $protect_client = $is_protect;
            //isset($request->is_protect)?$request->is_protect:'users';
            $their_user_id = isset($request->user_id)?$request->user_id:null;
            $conversation_request = $request->conversation_request;
            $dev_type = $request->dev_type;

            $validated['app_id'] = $app->id;
            $pet = $validated['pet'];

            $pet['age'] = isset($pet['age'])?$pet['age']:null;
            $pet['weight'] = isset($pet['weight'])?$pet['weight']:null;
            $pet['color'] = isset($pet['color'])?$pet['color']:null;
            $pet['pet_id'] = isset($pet['id'])?$pet['id']:null;

            unset($validated['api_key']);
            unset($validated['pet']);
            unset($validated['conversation_request']);
            unset($validated['is_protect']);
            if(!empty($channel)){ unset($validated['channel_sid']); }
            if(!empty($room)){ unset($validated['room_sid']); }
            if(!empty($type)){ unset($validated['type']); }
            if(!empty($status)){ unset($validated['status']); }
            if(!empty($old_vet_id)){ unset($validated['vet_id']); }

            //Step 1 : Create User
            $user = WebappUser::updateOrCreate(['email'=>$request->email],$validated);
            $extra_data = WebAppUsersExtra::create(['type'=>$conversation_request,'protected'=>$is_protect,
                'user_id'=>$user->id,'db_user_id'=>$their_user_id,'vet_id'=>$vet_id]);
            //Step 2 : Create Pet
            $pet_info = ExtraPet::updateOrCreate(['pet_id'=>$pet['id'],'user_id'=>$user->id,'name'=>$pet['name']],['pet_id'=>$pet['pet_id'],
                'sex'=>$pet['sex'],'breed'=>$pet['breed'],'weight'=>$pet['weight'],'age'=>$pet['age'],'color'=>$pet['color'],'species'=>$pet['species']
            ]);
            //Call the parent method create
            //All logic here
            try{
                $res = parent::create($conversation_request,$user,$pet_info,$protect_client,$app,$oldVetId,$room,$vet_id);
                $response = array();
                switch ($conversation_request){
                    case 'chat';
                        $attributes = [
                            "user" => $res['userObject'],
                            "vet" => $res['vetObject'],
                            "pet" => [
                                $pet_info
                            ],
                            "app"=>[$app->name]
                        ];
                        $this->updateChannelName($request->channel_sid,$res['friendlyName'],$attributes);
                        $this->updateMemberIdentity($request->twilio_user_sid,'_user-'.$user->id);
                        $this->addMember($request->channel_sid,'vet-'.$res['vetObject']['vet_id'],$this->tChannelRoleVetSid);
                        $this->addMember($request->channel_sid,'admin-2',$this->tChannelRoleAdminSid);
                        // Adding Activated Staff to Chat
                        if($subAdmin !=null){
                            foreach($subAdmin as $staff)
                            {
                                $member_subAdmin = ($subAdmin != null) ? 'staff-'.$staff->id : '' ;
                                $this->addMember($request->channel_sid,$member_subAdmin,$this->tChannelRoleAdminSid);
                            }
                        }
                        $this->autoMessage($request->channel_sid,'vet-'.$res['vetObject']['vet_id']);
                        Chat::updateOrCreate(['channel_sid'=>$request->channel_sid],[
                            'vet_id'=>$res['vetObject']['vet_id'], 'user_id'=>$user->id, 'app_id'=>$app->id,'pet_id'=>$pet_info->id,'status'=>'false'
                        ]);
                        $response['vet_id'] = $res['vetObject']['vet_id'];
                        break;
                    case 'video';
                        $response['room'] = $res;
                        break;
                }
                return $this->successResponse($response, 'User handshake successful');
            }
            catch (\Exception $e){
                //throw new \Exception($e->getMessage());
                return $this->errorResponse($e->getMessage(), $e->getCode());
            }


        }
        catch (Exception $e){
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    /**
     * @param Request $request
     * @return Response
     */
    public function endChatByUser(Request $request){
        try {
            $channelSid = $request->channel_sid;
            $vet = Chat::where('channel_sid',$channelSid)->first();
            if($vet->vet_id){
                $vetStatusupdate = Vet::find($vet->vet_id);
                    if(!empty($vetStatusupdate) && $vetStatusupdate->is_chat >= 1){
                        $vetStatusupdate->is_chat = $vetStatusupdate->is_chat - 1;
                        $vetStatusupdate->update();
                    }
//                ChatEndedBy::create(['chat_id'=>$vet->id,'ended_by'=>'user']);
                $this->accessEndChatPrivateMethod($channelSid,$vet->vet_id,'user');
            }
            return $this->successResponse(true, 'End chat successful');
        }
        catch (Exception $e){
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    /**
     * @param Request $request
     * @return Response
     */
    public function roomEvents(Request $request){
        try{
            $participantList = array();
            $status = $request->StatusCallbackEvent;
            $room = $request->RoomSid;
            $composition_id = $request->CompositionSid;
            switch ($status){
                case 'participant-connected':
                    $event = 'connected';
                    $participantList = $this->pRoomEvents($room,$event);
                    $notificationData = $this->vetsInQueue(); //Get all queue list where status is false
                    if(!empty($participantList)) {
                        if($participantList['type'] == 'vet') {
                            $vet = Vet::find($participantList['id']);
                            foreach ($notificationData as $nData) {
                                if ($status == 'participant-connected') {
                                    $tempQueue['vet_id'] = $nData['vet_id'];
                                    if ($nData['vet_id'] == $vet->id && $tempQueue['vet_id'] == $vet->id) {
                                        unset($nData['vet_id']);
                                    }
                                    if (isset($nData['vet_id']) && !empty($nData['vet_id'])) {
                                        //Get vet id from notification data
                                        $vetData = Vet::find($nData['vet_id']);
                                        if ($vetData->devices->dev_type == 'ios') {
                                            $binding_type = 'apn';
                                            $binding_address = $vetData->devices->device_token;
                                        } else {
                                            $binding_type = 'fcm';
                                            $binding_address = $vetData->devices->device_token;
                                        }
                                        $data = [
                                            'type' => 'endCall',
                                            //'user_id'=>$user_id
                                        ];
                                        //Make Vet available for next call
                                        //Vet notified to end call as some other vet joined the call
                                        $this->userEndCallbindings('vet_' . $vet->id, $binding_address, $binding_type, $data, 'default', 'Another vet has already joined');
                                    }
                                }
                            }
                        }
                    }

                    break;
                case 'participant-disconnected':
                case 'disconnected':
//                $event = 'disconnected';
//                $participantList = $this->pRoomEvents($room,$event);
//                if(!empty($participantList)){
//                    foreach ($participantList as $var){
//                        if($var['vet_id']){
//                            $vet = Vet::find($var['vet_id']);
//                        }
////                        elseif (){
////                            $user = WebAppUsersExtra::where('db_user_id',$var['vet_id'])->first();
////
////                        }
//
//                        if(isset($vet)){
//                            $video = VideoCall::where(['room_sid'=>$room,'vet_id'=>$var])->first();
//                            $queue_status = Queue::where('vet_id',$var)->first();
//                            $end_time = Carbon::now();
//                            $vet->update(['is_call'=> 0]);
//                            $video->update(['end_time'=>$end_time]);
//                            $queue_status->update(['status'=>false]);
//                            VideoCallHistory::create(['video_call_id'=>$video->id,'status'=>'completed','type'=>'vet']);
//                        }
////                        elseif(isset($user)){
////                            $video = VideoCall::where(['room_sid'=>$room,'user_id'=>$user->user_id])->first();
////                            if(isset($video)){
////                                VideoCallHistory::create(['video_call_id'=>$video->id,'status'=>'completed','type'=>'user']);
////                                //Find vet from video call
////                                //Queue::where('vet_id',$video->vet_id)->update(['status'=>false]);
////                                //Vet::where('id',$video->vet_id)->update(['is_call'=>false]);
////                            }
////
////                        }
//                    }
////                    if($participantList['type'] == 'vet'){
////                        $vet = Vet::find($participantList['id']);
////                        $video = VideoCall::where(['room_sid'=>$room,'vet_id'=>$participantList['id']])->first();
////                        $queue_status = Queue::where('vet_id',$participantList['id'])->first();
////                        $end_time = Carbon::now();
////                        $vet->update(['is_call'=> 0]);
////                        $video->update(['end_time'=>$end_time]);
////                        $queue_status->update(['status'=>false]);
////                        VideoCallHistory::create(['video_call_id'=>$video->id,'status'=>'completed','type'=>$participantList['type']]);
////                    }
////                    elseif($participantList['type'] == 'user'){
////                        $user = WebAppUsersExtra::where('db_user_id',$participantList['id'])->first();
////                        $video = VideoCall::where(['room_sid'=>$room,'user_id'=>$user->user_id])->first();
////                        VideoCallHistory::create(['video_call_id'=>$video->id,'status'=>'completed','type'=>'user']);
////                    }
//
//                }e
                break;
                case 'composition-available':
                    $this->addComposition($room, $composition_id, $status);
                    break;
            }

            $result = $this->successResponse(true, 'Vet Call Status updated');
        }
        catch (RestException $e){
            $result = $this->errorResponse($e->getMessage(), $e->getStatusCode());

        }
        return $result;

    }

    public function compositionHooks(Request $request)
    {
        $event = $request->StatusCallbackEvent;
        $room = $request->RoomSid;
        $composition_id = $request->CompositionSid;
        switch ($event) {
            case 'composition-available':
                $this->addComposition($room, $composition_id, $event);
                break;
        }
    }

    private function isSubAdminOnline(){
        return
        SubAdmin::where('is_active', 1)
         ->get();
    }


}
