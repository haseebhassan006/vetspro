<?php

namespace App\Http\Controllers\Api;
use App\App;
use App\AppSetting;
use App\EmergencyVetClient;
use App\Http\Requests\CreatePetRequest;
use App\Http\Requests\UserRequest;
use App\Http\Requests\UserTokenV2;
use App\Http\Requests\VetCareUserSignUpRequest;
use App\Http\Requests\WebAppUserRequest;
use App\Vet;
use App\Chat;
use App\ExtraPet;
use App\Feedback;
use App\VetCarePet;
use App\VetCareUser;
use App\VideoCall;
use Carbon\Carbon;
use App\ChatDetail;
use App\WebappUser;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Monolog\Logger;
use App\ChatEndedBy;
use App\UserAppStatus;
use App\FailedHandshake;
use App\WebAppUsersExtra;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Log\LogManager;
use App\Http\Requests\ChatRequest;
use App\Mail\MailMeProtectUserInfo;
use App\WebappUserExtraInformation;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\Controller;
use App\Mail\InformClientErrorEmail;
use Illuminate\Support\Facades\Mail;
use Stripe\Exception\ApiErrorException;
use Stripe\Exception\UnexpectedValueException;
use Twilio\Exceptions\TwilioException;
use App\Http\Requests\TwilioApiRequest;
use http\Exception\BadMessageException;
use Illuminate\Database\QueryException;
use App\Http\Requests\UserStatusRequest;
use App\Http\Requests\UserStatusV2Request;
use App\Http\Requests\VetFeedbackRequest;
use Mockery\Exception\BadMethodCallException;
use App\Http\Resources\VetVpmFeedbackResource;
use App\Http\Resources\UserSubscriptionStatusResource;
use App\Http\Requests\OtherUserWebappRegistrationRequest;
// use App\Http\Requests\UpdateUserRegistraionDateRequest;
// use App\Http\Resources\UpdateUserRegistraionDateResource;
use Symfony\Component\HttpKernel\Exception\HttpException;

class OtherUserConversationController extends TwilioApiController
{
    /*
     * This api is for handshake request for all webapp users
     *
     */
    public function handshake(TwilioApiRequest $request){
        $validated = $request->validated();
        $app = $this->find_app($request->api_key);
        if(!isset($app) && empty($app)){
            $path_uri = $request->path();
            switch ($path_uri){
                case str_contains($path_uri,'vidaah');
                    $app = 'vidaah';
                    break;
                case str_contains($path_uri,'onepet');
                    $app = 'onepet';
                    break;

            }
            $this->statusErrorCodes(500,$app,'Invalid Api Key');
            return $this->errorResponse('Invalid Api Key', 500);
        }
        $conversation_request = $request->conversation_request;
        try{
            if($conversation_request == 'chat'){ $vet_id = $this->checkVetChat();}
            elseif($conversation_request == 'video'){ $vet_id = $this->checkVetVideo();}
            if($vet_id == false){
                FailedHandshake::create([
                    'request'=> $request->all(),
                    'response'=>['message'=>'Vets are busy at the moment. Try again later','code'=>406],
                    'app_id'=>$app->id
                ]);
                //Log::error('Vets are busy at the moment. Try again later');
                //\logger('Vets are busy at the moment. Try again later');
                return $this->errorResponse('Vets are busy at the moment. Try again later', 406);
            }
            $channel = isset($request->channel_sid) ? $request->channel_sid : '';
            $room = isset($request->room_sid) ? $request->room_sid : '';
            $type = isset($request->type) ? $request->type : '';
            $status = isset($request->status) ? $request->status : '';
            $oldVetId = isset($request->vet_id)?$request->vet_id:null;
            $is_protect = isset($request->is_protect)?$request->is_protect:'users';
            $dev_type = $request->dev_type;
            $validated['app_id'] = $app->id;
            $pet = $validated['pet'];
            $sex_type = @$pet['sex_type'];

            unset($validated['api_key']);
            unset($validated['pet']);
            unset($validated['conversation_request']);
            unset($validated['is_protect']);
            if(!empty($channel)){ unset($validated['channel_sid']); }
            if(!empty($room)){ unset($validated['room_sid']); }
            if(!empty($type)){ unset($validated['type']); }
            if(!empty($status)){ unset($validated['status']); }
            if(!empty($old_vet_id)){ unset($validated['vet_id']); }

            //Step 1 : Create User
            $user = WebappUser::updateOrCreate(['email'=>$request->email],$validated);
            $extra_data = WebAppUsersExtra::create(['type'=>$conversation_request,'protected'=>$is_protect,'user_id'=>$user->id]);
//            dd($extra_data);
            //Step 2 : Create Pet
            $pet_info = ExtraPet::updateOrCreate(['user_id'=>$user->id,'name'=>$pet['name']],[
                'sex'=>$pet['sex'],'breed'=>$pet['breed'],'weight'=>$pet['weight'],'age'=>$pet['age'],
                'color'=>$pet['color'],'species'=>$pet['species'],'sex_type'=>$sex_type,'app_id'=>$app->id
            ]);

            //Call the parent method create
            $protect_client = $is_protect;
            try {
                $res = parent::create($conversation_request, $user, $pet_info, $protect_client, $app, $oldVetId, $room,$vet_id);

                if ($conversation_request == 'chat') {
                    parent::channelUserCreation($res['friendlyName'], $res['userObject'],
                        $res['vetObject'], $pet_info, $app->name, [$protect_client]);

                    //Update vet information in webapp extra table
                    WebAppUsersExtra::where(['type' => $conversation_request, 'protected' => $is_protect, 'user_id' => $user->id])->update(['vet_id' => $res['vetObject']['vet_id']]);

                    $response['channel'] = parent::fetchMyChannel($res['friendlyName']);

                    //$response['vet'] = $res['vetObject']['vet_id'];
                    $member_vet = 'app-1_vet-' . $res['vetObject']['vet_id'];
                   // $response['vet'] = $member_vet;
                    $response['vet']['id'] = $member_vet;
                    $response['vet']['username'] = $res['vetObject']['vet_name'];
                    //Update user twilio sid
                    $user_sid = parent::fetchUserSid('app-' . $app->id . '_user-' . $user->id);
                    WebappUser::where('email', $request->email)->update(['twilio_user_sid' => $user_sid->sid]);

                } else {
                    $response['room_sid'] = $res;
                }
                $identity = 'app-' . $app->id . '_user-' . $user->id;
                $response['identity'] = $identity;
                $response['twilioToken'] = parent::myToken($identity, $dev_type, $app->id);

                return $this->successResponse($response, 'User handshake successful');
            }
            catch (QueryException | \Exception $e){
                $code = $e->getCode();
                if($code == 0){
                    $code = 500;
                }
                $this->statusErrorCodes($code,$app->name,$e->getMessage());
                return $this->errorResponse($e->getMessage(), $code);
            }
        }
        catch (QueryException | \Exception $e){
            $code = $e->getCode();
            if($code == 0){
                $code = 500;
            }
            $this->statusErrorCodes($code,$app->name,'Invalid Request');
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }

    }
    /*
     * Twilio Chat refresh token
     */
    public function refresh(Request $request){
        $identity = $request->identity;
        $dev_type = $request->dev_type;
        $app = $this->find_app($request->api_key);
        //$token = $request->token;
        $response['twilioToken'] = parent::myToken($identity, $dev_type, $app->id);
        return $this->successResponse($response, 'User token');
    }
    /*
     * When user wants to end chat from thier side
     */
    public function endCoversationByUser(Request $request){
        try {

            $channelSid = $request->channel_sid;
            if($request->has('channel_sid') && $request->channel_sid != ""){
                $vet = Chat::where('channel_sid',$channelSid)->first();
                if(!$vet){
                    return $this->errorResponse('Channel not found.',404);
                }
            }

            if($vet->vet_id){
                $vetStatusupdate = Vet::find($vet->vet_id);
                if(!empty($vetStatusupdate) && $vetStatusupdate->is_chat >= 1){
                    $vetStatusupdate->is_chat = $vetStatusupdate->is_chat - 1;
                    $vetStatusupdate->update();
                }
                ChatEndedBy::create(['chat_id'=>$vet->id,'ended_by'=>'user']);
                $this->chatEndByUser($channelSid,$vet->vet_id,$vet->user_id,$vet->app_id);
            }
            return $this->successResponse(true, 'End chat successful');
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }
    /*
     * When user wants to end chat from thier side
     */
    public function endCoversationByUserTestCase(Request $request){
        try {
            $channelSid = $request->channel_sid;
            $vet = Chat::where('channel_sid',$channelSid)->first();
            if($vet->vet_id){
                $this->chatEndByUserTestCase($channelSid,$vet->vet_id);
            }
            return $this->successResponse(true, 'End chat successful');
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }
    public function webAppUserCreate(WebAppUserRequest $request){
        $validated = $request->validated();
        $app = App::find($request->app_id);
    //    dd($request->all());
        try{
            $canUseEmergencyFunds = false;
            $now = Carbon::now();
            $dev_type = $request->dev_type;
            $validated['app_id'] = $app->id;
            if ($request->has('pet')) {
                $pet = $validated['pet'];
            }

            $status = 'subscribed';
            if ($request->has('status')) {
                $status = $request->status;
            }

            $type = isset($request->type)?$request->type:"monthly";
            $is_protect = isset($request->role)?$request->role:'users';

            if ($is_protect == 'protect_users') {
                if (!$request->has('emergency_fund')) {
                    return $this->errorResponse('The emergency fund is required.', 404);
                }
            }

            if ($request->role == 'users') {
                if ($request->has('emergency_fund')) {
//                    $request = $request->except(['emergency_fund']);
                    return $this->errorResponse('Please remove emergency fund parameter.', 404);
                }
            }

            if ($is_protect != 'protect_users' && $is_protect != 'users') {
                return $this->errorResponse('The role field is required, should be "users" or "protect_users".', 404);
            }

            if ($request->has('pet')) {
                $pet['species'] = strtolower($pet['species']);
                if ($pet['species'] != 'cat' && $pet['species'] != 'dog') {
                    return $this->errorResponse('The species field is required, should be "cat" or "dog".', 404);
                }
                unset($validated['pet']);
            }

            unset($validated['api_key']);
            unset($validated['role']);
            unset($validated['api_key']);
            $date_time = date('Y-m-d h:i:s');

            //Step 1 : Create User
            $user = new WebappUser;

            $user->app_id = $request['app_id'];
            $user->email = $validated['email'];
            $user->dev_type = isset($validated['dev_type'])?$validated['dev_type']:'';
            $user->last_name = isset($validated['last_name'])?$validated['last_name']:'';
            $user->first_name = isset($validated['first_name'])?$validated['first_name']:'';
            $user->phone_no = isset($validated['phone_no'])?$validated['phone_no']:'';
            $user->your_registration_date = $date_time;

            if ($request->has('emergency_fund')) {
                $user->emergency_fund = isset($validated['emergency_fund'])?$validated['emergency_fund']:null;
            }
            $user->save();

            $extra_data = WebAppUsersExtra::create(['protected'=>$is_protect,'user_id'=>$user->id]);

            if ($request->has('pet')) {
                //Step 2 : Create Pet
                $pet_info = new ExtraPet;

                $pet_info->pet_id = isset($pet['pet_id']) ? $pet['pet_id'] : null;
                $pet_info->name = isset($pet['name']) ? $pet['name'] : '';
                $pet_info->profile = isset($pet['profile']) ? $pet['profile'] : null;
                $pet_info->sex = isset($pet['sex']) ? $pet['sex'] : '';
                $pet_info->breed = isset($pet['breed']) ? $pet['breed'] : '';
                $pet_info->weight = isset($pet['weight']) ? $pet['weight'] : '';
                $pet_info->age = isset($pet['age']) ? $pet['age'] : '';
                $pet_info->color = isset($pet['color']) ? $pet['color'] : '';
                $pet_info->species = isset($pet['species']) ? $pet['species'] : '';
                $pet_info->sex_type = isset($pet['sex_type']) ? $pet['sex_type'] : '';
                $pet_info->user_id = $user->id;
                $pet_info->app_id = $app->id;

                $pet_info->save();
            }

            $array = [
                'user_id'=>$user->id,
                'status'=>$status,
                'app_id'=>$app->id,
                'date_time'=>$date_time,
                'type'=>$type
            ];

            $user_timestamp = Carbon::parse(date('Y-m-d', strtotime($user->created_at)));
            $trial_period = Carbon::parse(date('Y-m-d', strtotime('+'. $app->trial_period .' days')));
            $current_timestamp1 = Carbon::now();
            $current_timestamp = $current_timestamp1->addDays($app->trial_period);
            $remaining_trial_period = $user_timestamp->diffInDays($current_timestamp);

            if($user_timestamp >= $trial_period && $is_protect == 'protect_users'){
                $canUseEmergencyFunds = true;
            }

            $temp = UserAppStatus::create($array);
            $user->role = $is_protect;
            $user->status = $status;
            $user->trial_period = $remaining_trial_period;
            $user->can_use_emergency_funds = $canUseEmergencyFunds;

            try {
                $identity = 'app-' . $app->id . '_user-' . $user->id;
                $identity = is_local_env() ? 'local-' . $identity : $identity;

                $response['user'] = $user->load('pets');
                $response['twilioToken'] = parent::myToken($identity, $dev_type, $app->id);
                $response['emergency_stats'] = webappuserEmergencyStatus($user->id,$app->id);

                return $this->successResponse($response, 'User registered successfully.');
            }
            catch (QueryException | \Exception $e){
                $code = $e->getCode();
                if($code == 0){
                    $code = 500;
                }
                $this->statusErrorCodes($code,$app->name,$e->getMessage());
                return $this->errorResponse($e->getMessage(), $code);
            }
        }
        catch (QueryException | \Exception $e){
            $code = $e->getCode();
            if($code == 0){
                $code = 500;
            }
            $this->statusErrorCodes($code,$app->name,'Invalid Request');
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }

    }

    public function talkToVet(VetCareUserSignUpRequest $request)
    {
        $validatedData = $request->validated();
        $coupon_id = 1;

        try {
            $app = App::find($request->app_id);
            $appSettings = AppSetting::where('app_id',$app->id)->first();
            $channel = isset($request->channel_sid) ? $request->channel_sid : '';
            $room = isset($request->room_sid) ? $request->room_sid : '';
            $type = isset($request->type) ? $request->type : '';
            $status = isset($request->status) ? $request->status : '';
            $oldVetId = null;
            $canUseEmergencyFunds = false;
            $dev_type = $request->dev_type;
            $conversation_request = 'chat';
            if ($request->has('conversation_request')) {
                $conversation_request = $request->conversation_request;
            }

            if ($conversation_request == 'chat') {
                $vet_id = $this->checkVetChat();
            } elseif ($conversation_request == 'video') {
                $vet_id = $this->checkVetVideo();
            }

            if($vet_id == false){
                FailedHandshake::create([
                    'request'=> $request->all(),
                    'response'=>['message'=>'Vets are busy at the moment. Try again later','code'=>406],
                    'app_id'=>$app->id
                ]);
                //Log::error('Vets are busy at the moment. Try again later');
                //\logger('Vets are busy at the moment. Try again later');
                return $this->errorResponse('Vets are busy at the moment. Try again later', 406);
            }

            $validatedData['app_id'] = $app->id;
            $validatedData['password'] = bcrypt('externalUsers#');
            $validator = Validator::make($validatedData, [
                'email' => 'email|exists:webapp_users,email',
            ]);
            if ($validator->fails()) {
                return $this->errorResponse('User not found. Please register user first.',404);
            }

            //Get Registered user
            $user = WebappUser::where('email',$request->email)->where('app_id',$request->app_id)->first();
            if ($user->emergencyLastestProtect) {
                $is_protect = $user->emergencyLastestProtect->protected;
                $user_timestamp = Carbon::parse(date('Y-m-d', strtotime($user->created_at)));
                $efa = false;
                $protected = false;
                $trial_period = false;
                $current_timestamp1 = Carbon::now();
                $current_timestamp = $current_timestamp1->addDays($app->trial_period);
                $remaining_trial_period = $user_timestamp->diffInDays($current_timestamp);

                if ($is_protect == 'protect_users') {
                    $protected = true;
                }

                if ($remaining_trial_period > 0) {
                    $trial_period = true;
                }

                if ($user->next_emergency_activation_date != '') {
                    if (date('Ymd') <= date('Ymd', strtotime($user->next_emergency_activation_date))) {
                        $efa = true;
                    }
                }

                if($efa == false && $protected == true && $trial_period == true){
                    $canUseEmergencyFunds = false;
                } elseif($efa == true && $protected == true && $trial_period == false){
                    $canUseEmergencyFunds = false;
                } elseif($efa == false && $protected == true && $trial_period == false){
                    $canUseEmergencyFunds = true;
                }

                $user->trial_period = $remaining_trial_period;
                $user->can_use_emergency_funds = $canUseEmergencyFunds;

            } else {
                return $this->errorResponse('User role not found.',404);
            }

            // check whethere user has status subscribed
            $userStatus = UserAppStatus::where('user_id',$user->id)->where('app_id',$app->id)->latest()->first();

            if($userStatus){
                if($userStatus->status == 'cancelled'){
                    return $this->errorResponse('User Subscription has been cancelled.',404);
                }
            }else{
                return $this->errorResponse('User not subscribed yet .',404);
            }

            //Add user to twilio account as well
            $attributes = ["app_id" => $app->id, "user_id" => $user->id, "email" => $request->email];
            $identity = 'app-' . $app->id . '_user-' . $user->id;
            $identity = is_local_env() ? 'local-' . $identity : $identity;


            //Attach Default Pet to User
            if($request->has('pet_id') && $request->pet_id != ''){
                $defaultPet = ExtraPet::where('user_id',$user->id)->where('id',$request->pet_id)->first();
                if(!$defaultPet){
                    return $this->errorResponse('Pet not found.',404);
                }
            }

//            $success['token'] = auth()->login($user);

            //Call the parent method create
            $protect_client = $is_protect;

            $res = parent::create($conversation_request, $user, $defaultPet, $protect_client, $app, $oldVetId, $room, $vet_id);

            if ($conversation_request == 'chat') {
                parent::channelUserCreation($res['friendlyName'], $res['userObject'],
                    $res['vetObject'], $defaultPet, $app->name, [$protect_client]);

                //Update vet information in webapp extra table
                WebAppUsersExtra::where(['type' => $conversation_request, 'protected' => $is_protect, 'user_id' => $user->id])->update(['vet_id' => $res['vetObject']['vet_id']]);

                $response['channel'] = parent::fetchMyChannel($res['friendlyName']);

                //$response['vet'] = $res['vetObject']['vet_id'];
                $member_vet = 'app-1_vet-' . $res['vetObject']['vet_id'];

                // $response['vet'] = $member_vet;

                $vet_model=Vet::with('vetDetails')->find($res['vetObject']['vet_id']);
                $response['vet']['id'] = $member_vet;
                $response['vet']['username'] = $res['vetObject']['vet_name'];
                $response['vet']['profile_image'] = $vet_model->vetDetails ? $vet_model->vetDetails->profile : null;

                //Update user twilio sid
                $user_sid = parent::fetchUserSid('app-' . $app->id . '_user-' . $user->id);
                WebappUser::where('email', $request->email)->update(['twilio_user_sid' => $user_sid->sid]);

            } else {
                $response['room_sid'] = $res;
            }

            $identity = 'app-' . $app->id . '_user-' . $user->id;
            $identity = is_local_env() ? 'local-' . $identity : $identity;

            $response['identity'] = $identity;
            $success['twilioToken'] = parent::myToken($identity, $request->dev_type, $request->app_id);
            $success['user'] = $user;
            $success['emergency_stats'] = webappuserEmergencyStatus($user->id,$app->id);

            // Only Stringify response
            $response['stringify_response'] = json_encode($success);


            // Delete Record from bouncing user
//            $this->deleteVetCareBouncingUser($user->email,$user->app_id);

            return $this->successResponse($response, 'User Found Successfully');

        } catch (TwilioException $e) {
            return $this->errorResponse($e->getMessage(), $e->getStatusCode());
        } catch (ApiErrorException $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        } catch (\Stripe\Exception\BadMethodCallException $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }catch (UnexpectedValueException $e){
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }

    }

    public function refreshV2(UserTokenV2 $request){
        $identity = $request->identity;
        $dev_type = $request->dev_type;
        $app = App::find($request->app_id);
        //$token = $request->token;
        $response['twilioToken'] = parent::myToken($identity, $dev_type, $app->id);
        return $this->successResponse($response, 'User token');
    }

    public function vetFeedbackV2(VetFeedbackRequest $request){
        try {
            $validated = $request->validated();
            $app = App::find($request->app_id);
            $type = strtolower($validated['type']);
            if($type == 'chat'){
                $model = Chat::where('channel_sid',$validated['channel_sid'])->with('vet')->first();
            }else{
                $model = VideoCall::where('room_sid',$validated['room_sid'])->with('vet')->first();
            }

            if (!$model) {
                return $this->errorResponse($type . ' not found', 404);
            }
            $feedback = Feedback::where('app_id',$app->id)->where('type',$type)->where('table_id',$model->id);

            if($feedback->count() < 1){
                return $this->errorResponse('Feedback not found', 404);
            }

            $feedback = $feedback->with('reason','recommendation')->first();
            $feedback['vet'] = $model->vet->where('id', $model->vet_id)->first();

            $result = VetVpmFeedbackResource::make($feedback);

            return $this->successResponse($result, 'Vet Feedback');
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    /*
    * Used for user actions such as when user registers
    * when user cancels from clients app
    */
    public function userActionsV2(UserStatusV2Request $request) {
        $validated = $request->validated();
        try{
            $app = App::find($request->app_id);
            $validated['app_id'] = $app->id;
            $email = $request->email;
            $status = $request->status;
            $date_time = isset($request->date_time)?$request->date_time:date('Y-m-d h:i:s');
            $type = isset($request->type)?$request->type:"monthly";

//            if($request->status == 'subscribed'){
//                $find_user = WebappUser::updateOrCreate(
//                    ['app_id' => $app->id, 'email' => $email],
//                    $validated
//                );
//                //$find_user = WebappUser::create($validated);
//            }
//            else{
                $find_user = WebappUser::where('email',$email)->first();
                $chk_status = null;
                $chk_protected = null;
//            }
            //User Status History
            if($find_user) {
                if ($find_user->user_status_latest) {
                    $chk_status = $find_user->user_status_latest->status;
                }
                if ($find_user->emergencyLastestProtect) {
                    $chk_protected = $find_user->emergencyLastestProtect->protected;
                }

                $is_protect = isset($request->role) ? $request->role : $find_user->emergencyLastestProtect->protected;

                if ($is_protect != 'protect_users' && $is_protect != 'users') {
                    return $this->errorResponse('role not found', 404);
                }
                if ($status != 'cancelled' && $status != 'subscribed' && $status != 'upgrade') {
                    return $this->errorResponse('status not found', 404);
                }
//                if ($request->role == 'protect_users' && $find_user->emergencyLastestProtect->protected == 'protect_users' && $find_user->user_status_latest->status != $status) {
//                    return $this->errorResponse("Error: User is already protected.",401);
//                } elseif ($request->role == 'users' && $find_user->emergencyLastestProtect->protected == 'users') {
//                    return $this->errorResponse("Error: User is already exist.",401);
//                }
                if ($chk_status != 'cancelled') {
                    if ($request->role == 'users' && $find_user->emergencyLastestProtect->protected == 'protect_users') {
                        return $this->errorResponse("Error: Can't degrade User from protected.", 401);
                    }
                }

                if ($is_protect == 'protect_users' && $find_user->emergency_fund == 0) {
                    if (!$request->has('emergency_fund')) {
                        return $this->errorResponse('The emergency fund is required.', 404);
                    }
                    if ($request->has('emergency_fund')) {
                        $find_user->emergency_fund = $request->emergency_fund;
                        $find_user->save();
                    }
                }

                if ($chk_protected != $request->role) {
                    WebAppUsersExtra::create([
                        'user_id' => $find_user->id,
                        'vet_id' => $find_user->emergencyLastestProtect->vet_id,
                        'type' => $find_user->emergencyLastestProtect->type,
                        'protected' => $is_protect
                    ]);
                }
                if ($chk_status != $status) {
                    $array = [
                        'user_id'=>$find_user->id,
                        'status'=>$status,
                        'app_id'=>$app->id,
                        'date_time'=>$date_time,
                        'type'=>$type
                    ];
                    $temp = UserAppStatus::create($array);
                }

                // $data = WebappUser::select('id','email','your_registration_date','app_id')->with(['user_status'=>function ($q){
                //     $q->latest();
                // }])->where('email',$email)->latest()->take(1)->get();
                //     $data = WebappUser::select('id','email','your_registration_date','app_id')->where('email',$email)->latest()->take(1)->get();
                $data['email'] = $find_user->email;
                $data['registration'] = $find_user->your_registration_date;
                if ($is_protect == 'protect_users') {
                    $data['emergency_fund'] = $find_user->emergency_fund;
                }
                $data['role'] = $is_protect;
                $data['status'] = $status;
                if ($is_protect == 'protect_users' && $find_user->emergency_fund > 0) {
                    if ($request->has('emergency_fund')) {
                        $data['note'] = 'The emergency fund cannot be updated.';
                    }
                }
                return $this->successResponse($data,'User action successful');
            }
            else{
                return $this->errorResponse('user not found',404);
            }
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(),$e->getCode());
        }
    }

    public function addPet(CreatePetRequest $request)
    {
        $validated = $request->validated();
        $data = $validated;
        $app = App::find($request->app_id);
        try{

            if($request->has('email') && $request->email != ""){
                $user = WebappUser::where('email',$request->email)->first();
                if(!$user){
                    return $this->errorResponse('User not found',404);
                }
            }else{
                return $this->errorResponse('User Email is required',400);
            }

            $data['species'] = strtolower($data['species']);
            if ($data['species'] != 'cat' && $data['species'] != 'dog') {
                return $this->errorResponse('The species field is required, should be "cat" or "dog".', 404);
            }

            $data['user_id'] = $user->id;

            $pet_info = new ExtraPet;

            $pet_info->user_id = $data['user_id'];
            $pet_info->app_id = $app->id;

            $pet_info->name = $data['name'];
            $pet_info->sex = $data['sex'];
            $pet_info->sex_type = $data['sex_type'];
            $pet_info->breed = $data['breed'];
            $pet_info->weight = $data['weight'];
            $pet_info->age = $data['age'];
            $pet_info->color = $data['color'];
            $pet_info->species = $data['species'];

            if($request->hasFile('profile')){
                $pet_info->profile = $this->uploadFile($request->profile,'pets');
            }

            $pet_info->save();

//            $response = $user->load('pets');
            $response['email'] = $user->email;
            $response['pet'] = $pet_info;
            return $this->successResponse($response, 'Pet Added');
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(),$e->getCode());

        }
    }

    public function updatePet(Request $request)
    {
        try{

            $validator = Validator::make($request->all(), [
                'email' => 'required|email|exists:webapp_users,email',
                'pet_id' => 'required|exists:extra_pets,id',

            ]);

            if ($validator->fails()) {
                return $this->errorResponse($validator->errors()->first(), 422);
            }

            if($request->has('email') && $request->email != ""){
                $user = WebappUser::where('email',$request->email)->first();
                if(!$user){
                    return $this->errorResponse('User not found',404);
                }
            }else{
                return $this->errorResponse('User Email is required',400);
            }

            if (strtolower($request->pet['species']) != 'cat' && strtolower($request->pet['species']) != 'dog') {
                return $this->errorResponse('The species field is required, should be "cat" or "dog".', 404);
            }

            $old_data = $user->pets()->find($request->pet_id);
            if(!$old_data){
                return $this->errorResponse('Pet ID invalid. Pet not found',404);
            }
            if($request->has('pet')){
                $data = $request->pet;
                $data['species'] = strtolower($data['species']);
                if($request->hasFile('pet.profile')){
                    $data['profile'] = $path = $this->uploadFile($request->pet['profile'],'pets');
                }
                $old_data->where('id',$request->pet_id)->update($data);
            }

            $success['pet'] = $user->pets()->find($request->pet_id);
            return $this->successResponse($success, 'Pet Updated');
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(),$e->getCode());

        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @return \Illuminate\Http\Response
     */
    public function removePet(Request $request)
    {
        try{

            $validator = Validator::make($request->all(), [
                'email' => 'required|email|exists:webapp_users,email',
                'pet_id' => 'required|exists:extra_pets,id',

            ]);

            if ($validator->fails()) {
                return $this->errorResponse($validator->errors()->first(), 422);
            }

            if($request->has('email') && $request->email != ""){
                $user = WebappUser::where('email',$request->email)->first();
                if(!$user){
                    return $this->errorResponse('User not found',404);
                }
            }else{
                return $this->errorResponse('User Email is required',400);
            }

            $pet = $user->pets()->find($request->pet_id);
            if(!$pet){
                return $this->errorResponse('Pet ID invalid. Pet not found',404);
            }

            $old_data = $pet->delete();
            return $this->successResponse($old_data, 'Pet data deleted successfully');
        }
        catch (Exception $e){
            return $this->errorResponse($e->getMessage(),$e->getCode());
        }

    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function getPets(Request $request)
    {
        $input = $request->only('search_value', 'search_by', 'page', 'pagination', 'perPage');
        try{

            $validator = Validator::make($request->all(), [
                'email' => 'required|email|exists:webapp_users,email',

            ]);

            if ($validator->fails()) {
                return $this->errorResponse($validator->errors()->first(), 422);
            }

            if($request->has('email') && $request->email != ""){
                $user = WebappUser::where('email',$request->email)->first();
                if(!$user){
                    return $this->errorResponse('User not found',404);
                }
            }else{
                return $this->errorResponse('User Email is required',400);
            }


            $users = $user->pets()->get();

            $users = $users->values();
            $data['list'] = $users->all();
            //$data['payment'] = $payment;

            return $this->successResponse($data, 'pet list');
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(),$e->getCode());
        }

    }

    /*
    * Vet feedbacks with respect to chat and video
    */
    public function vetFeedbacks(VetFeedbackRequest $request){
        try {
            $validated = $request->validated();
            $app = $this->find_app($request->api_key);
            $type = strtolower($validated['type']);
            if($type == 'chat'){
                $model = Chat::where('channel_sid',$validated['channel_sid'])->with('vet')->first();
            }else{
                $model = VideoCall::where('room_sid',$validated['room_sid'])->with('vet')->first();
            }
            if (!$model) {
                return $this->errorResponse($type . ' not found', 404);
            }
            $feedback = Feedback::where('app_id',$app->id)->where('type',$type)->where('table_id',$model->id);
            if($feedback->count() < 1){
                return $this->errorResponse('Feedback not found', 404);
            }

            $feedback = $feedback->with('reason','recommendation')->first();
            $feedback['vet'] = $model->vet->first();

            $result = VetVpmFeedbackResource::make($feedback);

            return $this->successResponse($result, 'Vet Feedback');
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    /**
     * This method is for clients to save their user information
     * @param OtherUserWebappRegistrationRequest $request
     * @return \Illuminate\Http\JsonResponse|Response
     */
    public function getWebAppUserRegistrationData(OtherUserWebappRegistrationRequest $request){
        try{
            $validate = $request->validated();

            $app = $this->find_app($request->api_key);

            unset($validate['api_key']);

            $user = WebappUser::updateOrCreate(['first_name'=>$request->first_name,'last_name'=>$request->last_name,
                'app_id'=>$app->id,'email'=>$request->email]);

            $validate['user_id'] = $user->id;

            $data = WebappUserExtraInformation::updateOrCreate($validate);

            return $this->successResponse($data, 'User Data Save Success');
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }

    }

    public function channelWebhooks(Request $request){
        try{

            // dd($request->all());
            // $response = $this->postChannelWebhooks($request->channel_sid);
            // $header = ['Content-Type'=> 'application/json'];
            // $url = 'https://api.dogtastic.co/';
            // $uri = 'api/vpm-hooks';
            // $params = array(
            //     'channel_sid'=>$channel_sid,
            // );
            // $this->httpRequestWithJson($url,$uri,$request->all(),$username,$password,$header);
            // return $this->successResponse(, 'Webhooks');

        }
        catch (TwilioException $exception){
            throw new \Exception($exception->getMessage());
        }
    }
    /*
     * Inform the clients about the failure during handshake
     * via email
     */
    public function statusErrorCodes($code,$app,$body){
        $date = Carbon::now()->toDateTimeString();
        $app = strtolower($app);
        $emails = array();
        array_push($emails,'ali.raza@invisionsolutions.ca');
        switch ($code){
            case 401:
            case 500:
                switch ($app){
                    case 'vidaah':
                    array_push($emails,'juan_moreno@juansolutions.com');
                    // case 'petacumen':
                    //     case 'onepet':
                    // case 'vetsplsumore':
                    Mail::to($emails)->send(new InformClientErrorEmail($date,$app,$body,$code));
                    break;
                }
                break;
        }
    }
    /*
     * Used for user actions such as when user registers
     * when user cancels from clients app
     */
    public function userActions(UserStatusRequest $request){
        $validated = $request->validated();
        try{
            $app = $this->find_app($request->api_key);
            $validated['app_id'] = $app->id;
            $email = $request->email;
            $status = $request->status;
            $date_time = $request->date_time;
            $type = isset($request->type)?$request->type:"monthly";
            if($request->status == 'subscribed'){
                $find_user = WebappUser::updateOrCreate(
                    ['app_id' => $app->id, 'email' => $email],
                    $validated
                );
                //$find_user = WebappUser::create($validated);
            }
            else{
                $find_user = WebappUser::where('email',$email)->first();
            }
            //User Status History
            if($find_user){
                $array = [
                    'user_id'=>$find_user->id,
                    'status'=>$status,
                    'app_id'=>$app->id,
                    'date_time'=>$date_time,
                    'type'=>$type
                ];
                $temp = UserAppStatus::create($array);
                // $data = WebappUser::select('id','email','your_registration_date','app_id')->with(['user_status'=>function ($q){
                //     $q->latest();
                // }])->where('email',$email)->latest()->take(1)->get();
                //     $data = WebappUser::select('id','email','your_registration_date','app_id')->where('email',$email)->latest()->take(1)->get();
                $data['email'] = $find_user->email;
                $data['registration'] = $find_user->your_registration_date;
                $data['status'] = $temp->status;
                return $this->successResponse($data,'User action successful');
            }
            else{
                return $this->errorResponse('You need to subscribe first,before cancellation',400);
            }
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(),$e->getCode());
        }
    }
    /*
     * This api is for handshake request for all webapp users
     *
     */
    public function testcases()
    {
        $a=rand(1, 3);
        //$a++;
        $email = "joeytest".$a."@onepet.com";
        $data = [
            "first_name" => "joey",
            "last_name" => "test",
            "email" => $email,
            "conversation_request" => "chat",
            "pet" => [
                "name" => "kitty",
                "sex" => "female",
                "breed" => "british",
                "weight" => "",
                "age" => "",
                "color" => "white",
                "species" => "Cat"
            ],
            "api_key" => "HjM2G1RdYWHeeRQx",
            "is_protect" => "users",
            "your_registration_date" => "2021-02-11 14:00:00",
            "dev_type" => "web"
        ];
        $validated = $data;
        $app = $this->find_app($validated['api_key']);
        // if(!isset($app) && empty($app)){
        //     $path_uri = $request->path();
        //     switch ($path_uri){
        //         case str_contains($path_uri,'vidaah');
        //             $app = 'vidaah';
        //             break;
        //         case str_contains($path_uri,'onepet');
        //             $app = 'onepet';
        //             break;

        //     }
        //     $this->statusErrorCodes(500,$app,'Invalid Api Key');
        //     return $this->errorResponse('Invalid Api Key', 500);
        // }
        $conversation_request = $validated['conversation_request'];
        try{
            if($conversation_request == 'chat'){ $vet_id = $this->checkVetChat();}
            elseif($conversation_request == 'video'){ $vet_id = $this->checkVetVideo();}
            if($vet_id == false){
            //    FailedHandshake::create([
            //        'request'=> $request->all(),
            //        'response'=>['message'=>'Vets are busy at the moment. Try again later','code'=>406],
            //        'app_id'=>$app->id
            //    ]);
            //     Log::error('Vets are busy at the moment. Try again later');
            //     \logger('Vets are busy at the moment. Try again later');
                return $this->errorResponse('Vets are busy at the moment. Try again later', 406);
            }
            $channel = isset($validated['channel_sid']) ? $validated['channel_sid'] : '';
            $room = isset($validated['room_sid']) ?$validated['room_sid'] : '';
            $type = isset($validated['type']) ? $validated['type'] : '';
            $status = isset($validated['status']) ? $validated['status'] : '';
            $oldVetId = isset($validated['vet_id'])?$validated['vet_id']:null;
            $is_protect = isset($validated['is_protect'])?$validated['is_protect']:'users';
            $dev_type = $validated['dev_type'];
            $validated['app_id'] = $app->id;
            $pet = $validated['pet'];

            unset($validated['api_key']);
            unset($validated['pet']);
            unset($validated['conversation_request']);
            unset($validated['is_protect']);
            if(!empty($channel)){ unset($validated['channel_sid']); }
            if(!empty($room)){ unset($validated['room_sid']); }
            if(!empty($type)){ unset($validated['type']); }
            if(!empty($status)){ unset($validated['status']); }
            if(!empty($old_vet_id)){ unset($validated['vet_id']); }

            //Step 1 : Create User
            $user = WebappUser::updateOrCreate(['email'=>$email],$validated);
            $extra_data = WebAppUsersExtra::create(['type'=>$conversation_request,'protected'=>$is_protect,'user_id'=>$user->id]);
            //Step 2 : Create Pet
            $pet_info = ExtraPet::updateOrCreate(['user_id'=>$user->id,'name'=>$pet['name']],[
                'sex'=>$pet['sex'],'breed'=>$pet['breed'],'weight'=>$pet['weight'],'age'=>$pet['age'],
                'color'=>$pet['color'],'species'=>$pet['species'],'app_id'=>$app->id
            ]);

            //Call the parent method create
            $protect_client = [$is_protect];
            try {
                $res = parent::create($conversation_request, $user, $pet_info, $protect_client, $app, $oldVetId, $room,$vet_id);

                if ($conversation_request == 'chat') {
                    parent::channelUserCreation($res['friendlyName'], $res['userObject'],
                        $res['vetObject'], $pet_info, $app->name, $protect_client);

                    //Update vet information in webapp extra table
                    WebAppUsersExtra::where(['type' => $conversation_request, 'protected' => $is_protect, 'user_id' => $user->id])->update(['vet_id' => $res['vetObject']['vet_id']]);

                    $response['channel'] = parent::fetchMyChannel($res['friendlyName']);

                    //$response['vet'] = $res['vetObject']['vet_id'];
                    $member_vet = 'app-1_vet-' . $res['vetObject']['vet_id'];
                    // $response['vet'] = $member_vet;
                    $response['vet']['id'] = $member_vet;
                    $response['vet']['username'] = $res['vetObject']['vet_name'];
                    //Update user twilio sid
                    $user_sid = parent::fetchUserSid('app-' . $app->id . '_user-' . $user->id);
                    WebappUser::where('email', $email)->update(['twilio_user_sid' => $user_sid->sid]);

                } else {
                    $response['room_sid'] = $res;
                }
                $identity = 'app-' . $app->id . '_user-' . $user->id;
                $response['identity'] = $identity;
                $response['twilioToken'] = parent::myToken($identity, $dev_type, $app->id);

                return $this->successResponse($response, 'User handshake successful');
            }
            catch (QueryException | \Exception $e){
                $code = $e->getCode();
                if($code == 0){
                    $code = 500;
                }
                $this->statusErrorCodes($code,$app->name,$e->getMessage());
                return $this->errorResponse($e->getMessage(), $code);
            }
        }
        catch (QueryException | \Exception $e){
            $code = $e->getCode();
            if($code == 0){
                $code = 500;
            }
            //$this->statusErrorCodes($code,$app->name,$request->all());
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }

    }

    public function updateOldExtraInfoRecords() {

        ini_set('max_execution_time', '0');

        $users = WebappUser::with(['user_status_latest']);
        $current_date = date('Y-m-d h:i:s');
        $current_year_month = date('Ym');

        $users->whereNotExists(function($query)
        {
            $query->select(DB::raw(1))
                ->from('webapps_users_extra')
                ->whereRaw('webapp_users.id = webapps_users_extra.user_id');
        });

        $users = $users->get();

        foreach ($users as $user) {

            WebAppUsersExtra::create([
                'user_id' => $user->id,
                'vet_id' => '',
                'type' => 'chat',
                'protected' => 'users',
                'created_at' => date('Y-m-d H:i:s', strtotime($user->created_at))
            ]);

        }

    }

    public function updateOldAppStatusRecords()
    {

        ini_set('max_execution_time', '0');

        $users = WebappUser::with(['user_status_latest']);
        $current_date = date('Y-m-d h:i:s');
        $current_year_month = date('Ym');

        $users->whereNotExists(function($query)
        {
            $query->select(DB::raw(1))
                ->from('user_app_statuses')
                ->whereRaw('webapp_users.id = user_app_statuses.user_id')
                ->whereRaw('webapp_users.app_id = user_app_statuses.app_id');
        });

        $users = $users->get();

        foreach ($users as $user) {

            UserAppStatus::create([
                'user_id' => $user->id,
                'app_id' => $user->app_id,
                'status' => 'subscribed',
                'type' => 'monthly',
                'created_at' => date('Y-m-d H:i:s'),
                'date_time' => date('Y-m-d H:i:s')
            ]);

        }

    }

    public function updateRecords() {
        //
        ini_set('max_execution_time', '0');
        \Log::alert('Cron Start');
        $users = WebappUser::with(['user_status_latest']);
        $current_date = date('Y-m-d h:i:s');
        $current_year_month = date('Ym');
        $users->whereHas('user_status_latest', function ($q) use ($current_date)  {
            $q->where('status', 'subscribed');
        });
        $users = $users->get();
        $updatedCount = 0;

        foreach ($users as $user) {

            $user_stamp = $user->user_status_latest->date_time;
            if ($user_stamp == '') {
                $user_stamp = $user->user_status_latest->created_at;
            }

            $month = strtotime($user_stamp);
            $end = strtotime(date('Y-m-d'));

            while($month < $end) {
                //Restrict from future date on current month
                $month = strtotime("+1 month", $month);
                if (date('Ymd', $month) <= date('Ymd')) {
                    $create = UserAppStatus::create([
                        'user_id' => $user->id,
                        'app_id' => $user->app_id,
                        'status' => 'subscribed',
                        'type' => 'monthly',
                        'created_at' => date('Y-m-d H:i:s', $month),
                        'date_time' => date('Y-m-d H:i:s', $month)
                    ]);
                    $updatedCount++;
                }
            }
        }

        \Log::alert($updatedCount. ' records updated');
        \Log::alert('Cron End');
    }

    public function updateWebappActivationStatus() {
        $app = App::where('app_type', 'webapp')->pluck('id');
        $webappuser = EmergencyVetClient::whereIn('app_id', $app)->groupBy('user_id')->orderBy('id', 'DESC')->get();

        $new_sn=0;
        $old_sn=0;
        foreach ($webappuser as $user) {
            //Update User next activation Date for WebApp
            $nextEmergencyActivation = null;
            $oldnextEmergencyActivation = $user->webappData[0]->next_emergency_activation_date;
            if ($oldnextEmergencyActivation != '') {
                $month = date('Ym', strtotime($oldnextEmergencyActivation));
                $end = date('Ym', strtotime('+1 year'));
            }
            if ($oldnextEmergencyActivation == null) {
                $registerDate = Carbon::parse($user->created_at);
                $nextEmergencyActivation = $registerDate->addYear(1);
                $new_sn++;
            } else {
                if ($month < $end) {
                    $oldnextEmergencyActivation = Carbon::parse($oldnextEmergencyActivation);
                    $diffInYears = $oldnextEmergencyActivation->diffInYears(Carbon::now());
//                    $nextEmergencyActivation = $oldnextEmergencyActivation->addYears($diffInYears + 1);
                }
                $old_sn++;

            }
            $user->webappData[0]->update(['next_emergency_activation_date' => $nextEmergencyActivation]);
        }

        echo $new_sn. " new updated...";
        echo $old_sn. " old updated...";

    }

    // public function updateUserRegistraionDate(UpdateUserRegistraionDateRequest $request){
    // $validated = $request->validated();
    // try{
    //     $user = WebappUser::with('user_status')->where(['email'=>$request->email])->first();
    //     if(!$user){
    //         return $this->errorResponse('User not found',404);
    //     }
    //     $user->created_at = $request->date; // zuhair asked to update users created date only for petcube app
    //     $user->your_registration_date = $request->date;
    //     $user->update();
    //     if( $user->user_status[0] ){
    //         $user->user_status[0]->date_time = $request->date;
    //         $user->user_status[0]->created_at = $request->date;
    //         $user->user_status[0]->update();
    //     }
    //     $user = UpdateUserRegistraionDateResource::make($user);
    //     return $this->successResponse($user, 'Record Updated Successfully.');
    // }
    // catch (\Exception $e){
    //     return $this->errorResponse($e->getMessage(),$e->getCode());
    // }
    // }

}
