<?php

namespace App\Http\Controllers\Api;

use App\Payment;
use App\Traits\TwilioSDKTrait;
use App\User;
use Carbon\Carbon;
use App\VetCareUser;
use App\VetCarePackage;
use App\Package;
use App\VetCareUserPayment;
use App\VetCarePackageUsage;
use App\VetCareSubscription;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Twilio\Exceptions\RestException;
use App\Traits\VetCareUserPaymentTrait;
use Twilio\Rest\Client;
use Storage;

class StripeController extends Controller
{
    //
    use TwilioSDKTrait;
    use VetCareUserPaymentTrait;

    /**
     * Stripe webhook event to test payment
     */
    public function stripeWebhook(Request $request){
        try {
            $payload = $request->all();
            $event = \Stripe\Event::constructFrom($payload
            //json_decode($payload, true)
            );
        } catch(\UnexpectedValueException $e) {
            // Invalid payload
            http_response_code(400);
            exit();
        }

        // Handle the event
        $paymentIntent = $event->data->object; // contains a \Stripe\PaymentIntent
        $eventType = $event->type;
 
        //Find the customer of failded payment
        //Update the customer of failed payment
        //Update application database payment cycle
        //Notify user about stripe response
        $customer = $this->getCustomerDetail($paymentIntent->customer, $eventType);
        $amount = 0;
        switch ($event->type) {
            case 'charge.succeeded';
            break;
            case 'charge.failed':
                    $amount = $paymentIntent->amount * 0.01;
            //$this->updatePaymentInfo($customer->id,$amount,$paymentIntent->id,$paymentIntent->status);
            break;
            case 'payment_intent.succeeded':
            //$amount = $paymentIntent['amount_received'] * 0.01;
            //break;
            case 'invoice.paid':
            case 'invoice.created':
            case 'subscription_schedule.canceled':
            case 'payment_intent.requires_action':
            case 'payment_intent.payment_failed':
            case 'invoice.payment_succeeded':
            //case 'invoice.payment_action_required':
                if($paymentIntent['subtotal'] != 0){
                    $amount = $paymentIntent['subtotal'] * 0.01;
                }
            break;
            case 'invoice.payment_failed':
                $amount = $paymentIntent['amount_due'] * 0.01;
                //$this->updatePaymentInfo($customer->id,$amount,$paymentIntent->id,$paymentIntent->status);
                // Then define and call a method to handle the successful payment intent.
                break;
            // ... handle other event types
            default:
                echo 'Received unknown event type ' . $event->type;
        }
        if($customer){
            $app_id = $this->findAppById($customer->app_id);
            $this->updatePaymentInfo($customer->id,$amount,$paymentIntent->id,$paymentIntent->status,$app_id->app_type);
            //Check user login send push else email
            if($customer->is_online == 1 && $amount != 0){
                $this->notifyUser($customer,$event->type,$amount);
            }
            $response = [
                'success' => true,
                'status_code'=>200,
                'message' => ['Webhook response'],
                'data'   => $customer
            ];
            return response()->json($response, 200);
        }
        else{
            return response()->json('No customer found against '.$paymentIntent->customer.' in our system.', 418);

        }

    }

    public function getCustomerDetail($customer,$eventType){

        $user = User::where('stripe_id',$customer)->first();
        $vetCareUser = VetCareUser::where('stripe_id',$customer)->first();
        //checking stripe id exist
        if ($user) {
            switch ($eventType) {
                case 'charge.failed':
                    if($user->usage()->count() > 0){
                        $check_interval = Package::findOrFail($user->usage[0]->package_id);
                        if($check_interval->interval == 'month'){
                            $data = Subscription::where('user_id',$user->id)->latest()->firstOrFail();

                            // Saving reasons of package cancellation
                            $reason['reason'] = config('constant.stripe_msg');

                            $data->update([
                                'status' => 'canceled',
                                'others' => $reason,
                            ]);

                            if($check_interval->type == 'protect'){
                                $user->removeRole('protect_users');
                                $user->assignRole('users');
                            }
                        }
                        $trash = PackageUsage::where('user_id',$user->id)->delete();
                    }
                    
                    break;

                case 'subscription_schedule.canceled':
                    if($user->usage()->count() > 0){
                        $check_interval = Package::findOrFail($user->usage[0]->package_id);
                        if($check_interval->interval == 'month'){
                            $data = Subscription::where('user_id',$user->id)->latest()->firstOrFail();

                            // Saving reasons of package cancellation
                            $reason['reason'] = config('constant.stripe_msg');

                            $data->update([
                                'status' => 'canceled',
                                'others' => $reason,
                            ]);

                            if($check_interval->type == 'protect'){
                                $user->removeRole('protect_users');
                                $user->assignRole('users');
                            }
                        }
                        $trash = PackageUsage::where('user_id',$user->id)->delete();
                    }else{
                        echo "No customer found";
                    }

                    break;

                case 'invoice.payment_failed':
                    if($user->usage()->count() > 0){
                        $check_interval = Package::findOrFail($user->usage[0]->package_id);
                        if($check_interval->interval == 'month'){
                            $data = Subscription::where('user_id',$user->id)->latest()->firstOrFail();

                            // Saving reasons of package cancellation
                            $reason['reason'] = config('constant.stripe_msg');

                            $data->update([
                                'status' => 'canceled',
                                'others' => $reason,
                            ]);

                            if($check_interval->type == 'protect'){
                                $user->removeRole('protect_users');
                                $user->assignRole('users');
                            }
                        }
                        $trash = PackageUsage::where('user_id',$user->id)->delete();
                    }
                    
                    break;

                case 'invoice.payment_succeeded':
                    if($user->trashUsage()->count() > 0){
                        $check_interval = Package::findOrFail($user->trashUsage[0]->package_id);
                        if($check_interval->interval == 'month'){
                            $data = Subscription::where('user_id',$user->id)->latest()->firstOrFail();

                            $data->update([
                                'status' => 'active'
                            ]);

                            if($check_interval->type == 'protect'){
                                $user->removeRole('protect_users');
                                $user->assignRole('users');
                            }
                        }
                        // $trash = PackageUsage::onlyTrashed()->where('user_id',$user->id)->restore();
                        $packageUsageData = PackageUsage::onlyTrashed()->where('user_id',$user->id)->first();
                        if ($packageUsageData) {
                            $packageUsage = $packageUsageData->replicate();
                            $packageUsage->created_at = Carbon::now();
                            $packageUsage->save();
                        }
                    }
                    break;

                case 'charge.succeeded':
                    if($user->trashUsage()->count() > 0){
                        $check_interval = Package::findOrFail($user->trashUsage[0]->package_id);
                        if($check_interval->interval == 'month'){
                            $data = Subscription::where('user_id',$user->id)->latest()->firstOrFail();

                            $data->update([
                                'status' => 'active'
                            ]);

                            if($check_interval->type == 'protect'){
                                $user->removeRole('protect_users');
                                $user->assignRole('users');
                            }
                        }
                        // $trash = PackageUsage::onlyTrashed()->where('user_id',$user->id)->restore();
                        $packageUsageData = PackageUsage::onlyTrashed()->where('user_id',$user->id)->first();
                        if ($packageUsageData) {
                            $packageUsage = $packageUsageData->replicate();
                            $packageUsage->created_at = Carbon::now();
                            $packageUsage->save();
                        }
                    }
                    break;
                
                default:
                    # code...
                    break;
            }
            return User::where('stripe_id',$customer)->first();
        }
        if ($vetCareUser) {
            switch ($eventType) {
                case 'charge.failed':
                    if (is_handshake_enabled($vetCareUser->app_id)) {
                        $data = $vetCareUser->user_status();

                        $data->update([
                            'status' => 'cancelled'
                        ]);
                        $trash = VetCarePackageUsage::where('user_id',$vetCareUser->id)->delete();
                    }else{
                        if($vetCareUser->usage()->count() > 0){
                            $check_interval = VetCarePackage::findOrFail($vetCareUser->usage[0]->package_id);
                            if($check_interval->interval == 'month'){
                                $data = VetCareSubscription::where('user_id',$vetCareUser->id)->latest()->firstOrFail();
    
                                // Saving reasons of package cancellation
                                $reason['reason'] = config('constant.stripe_msg');

                                $data->update([
                                    'status' => 'canceled',
                                    'others' => $reason,
                                ]);
    
                                if($check_interval->type == 'protect'){
                                    $vetCareUser->removeRole('protect_users');
                                    $vetCareUser->assignRole('users');
                                }
                            }
                            $trash = VetCarePackageUsage::where('user_id',$vetCareUser->id)->delete();
                        }
                    }
                    
                    break;

                case 'subscription_schedule.canceled':
                    if (is_handshake_enabled($vetCareUser->app_id)) {
                        $data = $vetCareUser->user_status();

                        $data->update([
                            'status' => 'cancelled'
                        ]);
                        $trash = VetCarePackageUsage::where('user_id',$vetCareUser->id)->delete();
                    }else{
                        if($vetCareUser->usage()->count() > 0){
                            $check_interval = VetCarePackage::findOrFail($vetCareUser->usage[0]->package_id);
                            if($check_interval->interval == 'month'){
                                $data = VetCareSubscription::where('user_id',$vetCareUser->id)->latest()->firstOrFail();
    
                                // Saving reasons of package cancellation
                                $reason['reason'] = config('constant.stripe_msg');

                                $data->update([
                                    'status' => 'canceled',
                                    'others' => $reason,
                                ]);
    
                                if($check_interval->type == 'protect'){
                                    $vetCareUser->removeRole('protect_users');
                                    $vetCareUser->assignRole('users');
                                }
                            }
                            $trash = VetCarePackageUsage::where('user_id',$vetCareUser->id)->delete();
                        }else{
                            echo "No customer found";
                        }
                    }
                    
                    break;

                case 'invoice.payment_failed':
                    if (is_handshake_enabled($vetCareUser->app_id)) {
                        $data = $vetCareUser->user_status();

                        $data->update([
                            'status' => 'cancelled'
                        ]);
                        $trash = VetCarePackageUsage::where('user_id',$vetCareUser->id)->delete();
                    }else{
                        if($vetCareUser->usage()->count() > 0){
                            $check_interval = VetCarePackage::findOrFail($vetCareUser->usage[0]->package_id);
                            if($check_interval->interval == 'month'){
                                $data = VetCareSubscription::where('user_id',$vetCareUser->id)->latest()->firstOrFail();
    
                                // Saving reasons of package cancellation
                                $reason['reason'] = config('constant.stripe_msg');

                                $data->update([
                                    'status' => 'canceled',
                                    'others' => $reason,
                                ]);
    
                                if($check_interval->type == 'protect'){
                                    $vetCareUser->removeRole('protect_users');
                                    $vetCareUser->assignRole('users');
                                }
                            }
                            $trash = VetCarePackageUsage::where('user_id',$vetCareUser->id)->delete();
                        }
                    }
                    
                    break;

                case 'payment_intent.succeeded':
                    if (is_handshake_enabled($vetCareUser->app_id)) {
                        $data = $vetCareUser->user_status();

                        $data->update([
                            'status' => 'subscribed'
                        ]);

                        // $trash = VetCarePackageUsage::onlyTrashed()->where('user_id',$vetCareUser->id)->restore();
                        $packageUsageData = VetCarePackageUsage::onlyTrashed()->where('user_id',$vetCareUser->id)->first();
                        if ($packageUsageData) {
                            $packageUsage = $packageUsageData->replicate();
                            $packageUsage->created_at = Carbon::now();
                            $packageUsage->save();
                        }
                    }else{
                        if($vetCareUser->trashUsage()->count() > 0){
                            // dd('dsd');
                            $check_interval = VetCarePackage::findOrFail($vetCareUser->trashUsage[0]->package_id);
                            if($check_interval->interval == 'month'){
                                $data = VetCareSubscription::where('user_id',$vetCareUser->id)->latest()->firstOrFail();

                                $data->update([
                                    'status' => 'active'
                                ]);
    
                                if($check_interval->type == 'protect'){
                                    $vetCareUser->removeRole('protect_users');
                                    $vetCareUser->assignRole('users');
                                }
                            }
                            // $trash = VetCarePackageUsage::onlyTrashed()->where('user_id',$vetCareUser->id)->restore();
                            $packageUsageData = VetCarePackageUsage::onlyTrashed()->where('user_id',$vetCareUser->id)->first();
                            if ($packageUsageData) {
                                $packageUsage = $packageUsageData->replicate();
                                $packageUsage->created_at = Carbon::now();
                                $packageUsage->save();
                            }
                        }
                    }
                    break;

                case 'charge.succeeded':
                    if (is_handshake_enabled($vetCareUser->app_id)) {
                        $data = $vetCareUser->user_status();

                        $data->update([
                            'status' => 'subscribed'
                        ]);

                        // $trash = VetCarePackageUsage::onlyTrashed()->where('user_id',$vetCareUser->id)->restore();
                        $packageUsageData = VetCarePackageUsage::onlyTrashed()->where('user_id',$vetCareUser->id)->first();
                        if ($packageUsageData) {
                            $packageUsage = $packageUsageData->replicate();
                            $packageUsage->created_at = Carbon::now();
                            $packageUsage->save();
                        }
                    }else{
                        if($vetCareUser->trashUsage()->count() > 0){
                            // dd('dsd');
                            $check_interval = VetCarePackage::findOrFail($vetCareUser->trashUsage[0]->package_id);
                            if($check_interval->interval == 'month'){
                                $data = VetCareSubscription::where('user_id',$vetCareUser->id)->latest()->firstOrFail();

                                $data->update([
                                    'status' => 'active'
                                ]);
    
                                if($check_interval->type == 'protect'){
                                    $vetCareUser->removeRole('protect_users');
                                    $vetCareUser->assignRole('users');
                                }
                            }
                            // $trash = VetCarePackageUsage::onlyTrashed()->where('user_id',$vetCareUser->id)->restore();
                            $packageUsageData = VetCarePackageUsage::onlyTrashed()->where('user_id',$vetCareUser->id)->first();
                            if ($packageUsageData) {
                                $packageUsage = $packageUsageData->replicate();
                                $packageUsage->created_at = Carbon::now();
                                $packageUsage->save();
                            }
                        }
                    }
                    break;
                
                default:
                    # code...
                    break;
            }
            return VetCareUser::where('stripe_id',$customer)->first();
        }
    }

    public function updatePaymentInfo($user_id,$price,$charge_id,$charge_status,$app_type){

        if ($app_type == 'whitelabel') {
            $modal = new Payment;
        }elseif ($app_type == 'whitelabel-webapp'){
            $modal = new VetCareUserPayment;
        }
        
        if ($modal) {
            return $modal->create(
                [
                    'user_id'=>$user_id,
                    'amount'=>$price,
                    'charge_id'=>$charge_id,
                    'status'=>$charge_status,
                    'date'=>Carbon::now()->toDateTimeString()
                ]
            );
        }
    }

    public function notifyUser($customer,$status,$price){
        //Send push to user when vet declares user active
        //notification data
        switch ($status){
            case 'charge.succeeded':
            case 'payment_intent.succeeded':
            case 'invoice.payment_succeeded':
                $response = 'deducted';
                break;
            case 'payment_intent.requires_action':
            case 'payment_intent.payment_failed':
            case 'invoice.payment_action_required':
            //case 'invoice.payment_failed':
            case 'charge.failed':
                $response = 'declined';
                break;
            default:
                $response = 'rejected';
        }
        $app = $this->findAppById($customer->app_id);
        $notify = [
            'payment'=>$status
        ];

        try{
            if(isset($customer->devices)){
                if($customer->devices[0]->dev_type == 'ios'){
                    $binding_type = 'apn';
                }
                else{
                    $binding_type = 'fcm';
                }
                $this->sendPushToUser($customer->devices[0]->device_token,$binding_type,$notify,ucfirst($app->name).' : Payment of amount USD '.$price.' has been '.$response.'.');
            }
        }
        catch (RestException $twilioException){
            http_response_code(400);
        }

    }
    /**
     * @param $device_token
     * @param $binding_type
     * @param $data
     * @param $body
     * @return array
     */
    protected function sendPushToUser($device_token, $binding_type, $data , $body): array
    {
        $twilioApiKey    = config('services.vpm-chats-local.api_key');
        $twilioApiSecret   = config('services.vpm-chats-local.api_secret');
        $user_notify_sid = config('services.vpm-chats-local.user_notify_sid');
        $twilio = new Client( $twilioApiKey, $twilioApiSecret);
        // Create a notification
        $tobinding = json_encode([
            'binding_type'=>$binding_type,
            'address'=>$device_token
        ]);
        $notification_sid = $twilio
            ->notify->services($user_notify_sid)
            ->notifications->create([
                //"tag" => [$binding->sid],
                "toBinding" => [
                    $tobinding
                ],
                // "identity" => $identity,
                "body" => $body,
                "data" => $data,
                // "category"=>'AcceptOrReject',
                "sound" => "default"
            ]);
        $response['notification_sid'] = $notification_sid->sid;
        return $response;
    }
}
