<?php

namespace App\Http\Controllers\Api;

use Illuminate\Foundation\Auth\SendsPasswordResetEmails;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Password;

class ForgotPasswordController extends Controller
{
    protected $redirectPath = '/success';
    //
    /*
 |--------------------------------------------------------------------------
 | Password Reset Controller
 |--------------------------------------------------------------------------
 |
 | This controller is responsible for handling password reset emails and
 | includes a trait which assists in sending these notifications from
 | your application to your users. Feel free to explore this trait.
 |
 */
    use SendsPasswordResetEmails;
    public function __invoke(Request $request)
    {
        $this->validateEmail($request);
        // We will send the password reset link to this user. Once we have attempted
        // to send the link, we will examine the response then see the message we
        // need to show to the user. Finally, we'll send out a proper response.
        $response = $this->broker()->sendResetLink(
            $request->only('email')
        );
        // return ['received' => true];
        $success = $this->successResponse('Reset link sent to your email.','Reset link sent to your email.');
        $error = $this->errorResponse('Unable to send reset link',401);
        return $response == Password::RESET_LINK_SENT
            ? $success
            : $error;
    }

    public function broker()
    {
        return Password::broker(request()->get('api'));
    }

}
