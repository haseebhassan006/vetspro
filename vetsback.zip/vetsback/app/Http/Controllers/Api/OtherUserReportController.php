<?php

namespace App\Http\Controllers\Api;
use App\App;
use App\WebappUser;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\Controller;
use Stripe\Exception\ApiErrorException;
use Stripe\Exception\UnexpectedValueException;
use http\Exception\BadMessageException;
use Illuminate\Database\QueryException;
use Mockery\Exception\BadMethodCallException;
use App\Http\Resources\WebAppUserProfileResource;

use Symfony\Component\HttpKernel\Exception\HttpException;

class OtherUserReportController extends TwilioApiController
{
    private $noOfRecordPerPage = 10;
    private $paginate = false;
    /*
     * This api is for handshake request for all webapp users
     *
     */

    // Start  fetch webapp users profile
    public function getWebAppUsersProfile(Request $request)
    {

        $input = $request->only('search_value', 'search_by', 'page', 'pagination', 'perPage', 'user_id','app_name','type','email','status','date_from','date_to','selectedProtect','is_subscribe_chk');
        $app_id = $request->app_id;

        $is_subscribe_chk = (isset($input['is_subscribe_chk']) && $input['is_subscribe_chk'] == 1) ? 1 : 0;
        $value = isset($input['search_value'])?$input['search_value']:'';
        $type = isset($input['type'])?$input['type']:'';
        $email = isset($input['email'])?$input['email']:'';
        $status = isset($input['status'])?$input['status']:'';
        $selectedProtect = isset($input['selectedProtect'])?$input['selectedProtect']:'';
        try{
                    $user =  WebappUser::with(['userExtraData','emergency','emergencyLastestProtect','apps','user_status','user_status_latest'])->where('app_id',$app_id)->latest();

                    if ($request->has('status')) {
                        $user = $user->whereRaw('(SELECT status FROM user_app_statuses WHERE user_id = webapp_users.id ORDER BY id DESC LIMIT 1) = "'. $request->status .'"');
                    } else {
                        if (!$is_subscribe_chk) {
                            $user = $user->whereRaw('(SELECT status FROM user_app_statuses WHERE user_id = webapp_users.id ORDER BY id DESC LIMIT 1) IN ("cancelled", "subscribed", "upgrade")');
                        }
                    }

                    if($selectedProtect != ''){
                        $user = $user->whereRaw('(SELECT protected FROM webapps_users_extra WHERE user_id = webapp_users.id ORDER BY id DESC LIMIT 1) = "'. $selectedProtect . '"');
                    }

                    if ($request->has('date_from') && $request->has('date_to')) {
                        $date_from = date('Y-m-d', strtotime($input['date_from']));
                        $date_to = date('Y-m-d', strtotime($input['date_to']));
                        if ($is_subscribe_chk) {
                            $date_from = $date_from.' 00:00:00';
                            $date_to = $date_to.' 23:59:59';
                            $user = $user->whereRaw('(SELECT status FROM user_app_statuses WHERE user_id = webapp_users.id AND created_at BETWEEN "'. $date_from . '"  AND "' . $date_to . '" ORDER BY id DESC LIMIT 1) = "subscribed"');

                        } else {
                            $user = $user->whereBetween('your_registration_date',
                                [$input['date_from'] . " 00:00:00", $input['date_to'] . " 23:59:59"]
                            );
                        }
                    } else {
                        if ($is_subscribe_chk) {
                            $user = $user->whereRaw('(SELECT status FROM user_app_statuses WHERE user_id = webapp_users.id ORDER BY id DESC LIMIT 1) = "subscribed"');
                        }
                    }

                    $user = $user->latest();

            if ($value != ''){
                $user =  $user->where(function ($query) use ($value) {
                    $query->where('first_name', 'LIKE', '%' . $value . '%')
                        ->orWhere('last_name', 'LIKE', '%' . $value . '%')
                        ->orWhere('email', 'LIKE', '%' . $value . '%');
                });

                $user = $user->latest();
            }

            if (isset($input['pagination']) && $input['pagination'] != "") {
                $this->paginate = true;
                $user = $user->paginate($this->noOfRecordPerPage);
            } else {

                $user = $user->get();

            }
            $user = WebAppUserProfileResource::collection($user);

            return $this->successResponse($user, 'Successfully Get User Details.', $this->paginate);
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }
    // End  fetch webapp users profile

}
