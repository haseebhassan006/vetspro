<?php

namespace App\Http\Controllers\Api;

use App\Http\Requests\CreatePetDetailRequest;
use App\Http\Requests\CreatePetRequest;
use Illuminate\Database\QueryException;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Mockery\Exception;

class PetController extends Controller
{
    private $noOfRecordPerPage = 10;
    private $paginate = false;
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        //
        $input = $request->only('search_value', 'search_by', 'page', 'pagination', 'perPage');
        try{
            $user = auth()->user();
            //$payment = $this->checkUserPayment($user);
            if (isset($input['perPage']) && $input['perPage'] != "" && is_int($input['perPage'])) {
                $this->noOfRecordPerPage = $input['perPage'];
            }
            if (isset($input['pagination']) && $input['pagination'] != "") {
                $this->paginate = true;
//                $users = $user->pets()->paginate($this->noOfRecordPerPage);
                $users = $user->pets()->get();
            } else {
                $users = $user->pets()->where('user_id', $user->id)->first();
            }

            $users = $users->values();
            $data['list'] = $users->all();
            //$data['payment'] = $payment;

            return $this->successResponse($data, 'pet list');
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(),$e->getCode());
        }

    }

    /**
     * Show the form for creating a new resource.
     *
     * @param CreatePetRequest $request
     * @return \Illuminate\Http\Response
     */
    public function create(CreatePetRequest $request)
    {
        //
        $validated = $request->validated();
        $data = $validated;
        try{
            $user = auth()->user();
            $data['user_id'] = $user->id;

            if($request->hasFile('profile')){
                $data['profile'] = $this->uploadFile($request->profile,'pets');
            }
            $user->pets()->create($data);
            $response = $user->load('pets');
            return $this->successResponse($response, 'pet added');
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(),$e->getCode());

        }
    }
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(CreatePetDetailRequest $request,$id)
    {
        try{
            $user = auth()->user();
            $validated = $request->validated();
           //user->pets->pet()->create();
            if($request->has('pet_veterians')){
                $validated['pet_veterians'][0]['pet_id'] = $id;
                $veteriandata = $validated['pet_veterians'][0];
                $user->pets->petVeterians()->firstOrCreate (
                    $validated['pet_veterians'][0]
                );
            }
            if($request->has('pet_medicals')){
                $validated['pet_medicals'][0]['pet_id'] = $id;
                $user->pets->petMedicals()->firstOrCreate(
                    $validated['pet_medicals'][0]
                );
            }
            if($request->has('pet_insurnaces')){
                $validated['pet_insurnaces'][0]['pet_id'] = $id;
                $user->pets->petInsurnaces()->firstOrCreate(
                    $validated['pet_insurnaces'][0]
                );
            }
//             $user->pets->petMedicals()->create($validated);
//            $user->pets->petInsurnaces()->create($validated);
//            dd();

            $success['pet'] = auth()->user()->pets()->find($id);
            return $this->successResponse($success, 'pet added');
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(),$e->getCode());

        }
    }

    /**
     * Display the specified resource.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     * @throws \Exception
     */
    public function show($id)
    {
        try{
            $user = auth()->user();

            $success['pet'] = $user->pets()->find($id);
            //$pet = $user->pets()->find($id);
            //$success['detail'] = $pet->petVeterians()->where('pet_id',$id)->get();
            $response = $this->successResponse($success, 'my pet');
        }
        catch(QueryException $e){
            //dd($e->getSql());
            throw new \Exception($e->getMessage());
            // Note any method of class PDOException can be called on $ex.
        }
        catch (\Exception $e){
            //dd($e);
            $response = $this->errorResponse($e->getMessage(),$e->getCode());

        }

        return $response;
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        try{
            $user = auth()->user();

            $old_data = $user->pets()->find($id);

            if($request->has('pet')){
                $data = $request->pet;
                if($request->hasFile('pet.profile')){
                    $data['profile'] = $path = $this->uploadFile($request->pet['profile'],'pets');
                }
                $old_data->where('id',$id)->update($data);
            }
//            if($request->has('pet_insurnaces')){
//                $user->pets->petInsurnaces()->where('id',$id)->update($request->pet_insurnaces[0]);
//            }
//            if($request->has('pet_medicals')){
//                $user->pets->petMedicals()->where('id',$id)->update($request->pet_medicals[0]);
//            }
//            if($request->has('pet_veterians')){
//                $user->pets->petVeterians()->where('id',$id)->update($request->pet_veterians[0]);
//            }

            $success['pet'] = $user->pets()->find($id);
            return $this->successResponse($success, 'my pet');
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(),$e->getCode());

        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        try{
            $user = auth()->user();
            $pet = $user->pets()->find($id);
            $old_data = $pet->delete();
            return $this->successResponse($old_data, 'success deleted');
        }
        catch (Exception $e){
            return $this->errorResponse($e->getMessage(),$e->getCode());
        }

    }
}
