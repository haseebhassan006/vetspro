<?php

namespace App\Http\Controllers\Client;

use App\Http\Requests\ChatRequest;
use App\Http\Requests\TwilioApiRequest;
use App\Notification;
use App\ExtraPet;
use App\Pet;
use App\Traits\OtherTwilioSDKTrait;
use App\Traits\TwilioSDKTrait;
use App\Vet;
use App\VideoCall;
use App\VideoCallHistory;
use App\WebappUser;
use Carbon\Carbon;
use Illuminate\Database\QueryException;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Http\Response;
use Twilio\Exceptions\RestException;
use Twilio\Exceptions\TwilioException;
use Twilio\Jwt\AccessToken;
use Twilio\Jwt\Grants\ChatGrant;
use Twilio\Jwt\Grants\VideoGrant;
use Twilio\Rest\Client;


class TwilioApiController extends Controller
{
    use OtherTwilioSDKTrait;
    use TwilioSDKTrait;
    const accepted = 'accepted';
    const declined = 'declined';
    const notanswered = 'notanswered';
    const inprogress = 'inprogress';
    const completed = 'completed';

    public function __construct()
    {
        $this->construct();
        $this->generic();
    }
    /**
     * Display a listing of the resource.
     *
     * @return Response
     */
    public function index()
    {
        //
    }
    public function create($conversation,$user,$pet_info,$is_protect,$app,$oldVetId = NULL,$room_sid = NULL,$vet_id)
    {
        $res = array();
        $room_data = array();
        try{
            if($conversation == 'chat'){
                $vet_info = Vet::find($vet_id);
                $vet_full_name = $vet_info->first_name.' '.$vet_info->last_name;
                $user_full_name = $user->first_name.' '.$user->last_name;
                $vet_profile = '';
                $user_profile = '';
                //dd($vet_info->vetDetails(),$user->userDetails());
                if($vet_info->vetDetails != NULL){
                    $vet_profile = $vet_info->vetDetails->profile;
                }
                if($user->userDetails != NULL){
                    $user_profile = $user->userDetails->profile;
                }
                $friendlyName = $vet_full_name.'-'.$user_full_name.'-'.Carbon::now();

                $userObject = [
                    "user_id"=>$user->id,
                    "user_name"=>$user_full_name,
                    "profile"=>$user_profile,
                    "role"=>[$is_protect],
                    "app_id"=>$user->app_id
                ];
                $vetObject = [
                    "vet_id"=>$vet_info->id,
                    "vet_name"=>$vet_full_name,
                    "profile"=>$vet_profile,
                ];
                $res['userObject'] = $userObject;
                $res['vetObject'] = $vetObject;
                $res['friendlyName'] = $friendlyName;
                return $res;
//                return $this->successResponse($res, 'User handshake successful');
            }
            if($conversation == 'video'){
                $vets = $this->vetsInQueue();
                //$vet_id = $this->checkVetVideo($oldVetId);
                if(count($vets) < 1){
                    return $this->errorResponse(get_vet_busy_text($user->app_id),403);
                }
                if($room_sid){
                    $response = $this->getRoom($room_sid);
                }
                else{
                    $roomname = $user->first_name.'-'.Carbon::now();
                    $response = $this->makeRoom($roomname);
                }
                $a = 0;
                foreach ($vets as $vet){
                    $vet_info = Vet::find($vet['vet_id']);
                    $vet_id = $vet_info->id;
                    $room_data = [
                        'sid'=>$response->sid,
                        'status'=>$response->status,
                        'uniqueName'=>$response->uniqueName,
                        'statusCallback'=>$response->statusCallback,
                        'statusCallbackMethod'=>$response->statusCallbackMethod,
                        'endTime'=>$response->endTime,
                        'duration'=>$response->duration,
                        'type'=>$response->type,
                        'maxParticipants'=>$response->maxParticipants,
                        'recordParticipantsOnConnect'=>$response->recordParticipantsOnConnect,
                        'url'=>$response->url,
                        //'vet_id'=>$vet_info->id,
                        //'vet' =>$vets,
                    ];
                    $binding = array();
                    if($response->status == 'in-progress'){
                        $room = [
                            'sid' =>$response->sid,
                            'uniqueName'=>$response->uniqueName
                        ];
                        $data = [
                            //'device_token' => $vet_info->devices->device_token,
                            'room' => $room,
                            'pet'=> $pet_info,
                            'is_protect'=>'false',
                            'type'=>'video',
                            'datetime'=> Carbon::now()->timestamp,
                            'username'=>$user->first_name.' '.$user->last_name,
                            'user_profile'=>$user->userDetails,
                            'role'=>[$is_protect],
                            'app'=>$app->name
                        ];
                        if($vet_info->devices->dev_type == 'ios'){
                            $binding_type = 'apn';
                            $binding_address = $vet_info->devices->device_token;
                        }
                        else{
                            $binding_type = 'fcm';
                            $binding_address = $vet_info->devices->device_token;
                        }
                        try{
                            if($app->name == lcfirst('pawp')){
                                $binding = $this->userBindings('vet_'.$vet_id,$binding_address,$binding_type,$data,'IncomingVideoCall.caf','Call incoming');
                            }
                            else{
                                $binding = $this->createBindings('vet_'.$vet_id,$binding_address,$binding_type,$data,'IncomingVideoCall.caf','Call incoming');
                            }
                        }
                        catch (RestException $twilioException){
                            throw new RestException($twilioException->getMessage(),$twilioException->getCode(),$twilioException->getStatusCode());
                            //return $this->errorResponse('Service is down.Try again later',$twilioException->getStatusCode());
                        }
                        //Insert data into notifications model
                        $notify = Notification::create([
                            'sid' => $binding['notification_sid'],
                            'user_to_notify' => $vet_info->id,
                            'user_who_fired_event'=>$user->id,
                            'unique_key' =>  $binding['unique_key']
                        ]);
                        $video = VideoCall::create([
                            'room_sid'=>$response->sid,
                            'vet_id'=>$vet_info->id,
                            'user_id'=>$user->id,
                            'app_id'=>$user->app_id,
                            'start_time'=>Carbon::now()
                        ]);
                        $history_tbl = VideoCallHistory::create([
                            'video_call_id'=>$video->id,
                            'status'=>self::inprogress,
                            'type'=>'user',
                        ]);
                        $a++;
                    }
                    else{
                        throw new \Exception('Video expired');
                    }
                }
                return $room_data;
            }
        }
        catch (QueryException $e){
            //throw new \Exception($e->getMessage());
            return $this->errorResponse($e->getMessage(), 422);
        }
        catch (\Exception $e){
            //throw new \Exception($e->getMessage());
           return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    /**
     * @param null $vet_id
     * @return int
     * vet_id : availability for chatting
     */
    public function checkVetChat($vet_id=null) : int
    {
        $vet = Vet::role('vets')->where('is_online',1)->inRandomOrder()->first();
        return isset($vet->id) ? $vet->id:false;
    }

    /**
     * @param null $vet_id
     * @return int
     * vet id : availability for video call
     */
    public function checkVetVideo($vet_id=null) : int
    {
        $vet = Vet::role('vets')->where('is_online',1)->where('is_call',0)->inRandomOrder()->first();
        return isset($vet->id) ? $vet->id:false;
    }

    /**
     * Video action after call end,reject,complete
     * @param Request $request
     * @return Response
     */
    public function action(Request $request): Response
    {
        $status = $request->status;
        $user_id = $request->user_id?:null;
        $room_sid  = $request->room_sid;
//        if($user_id == null){
//            $user_id = VideoCallHistory::where('room_sid',$room_sid)->first();
//        }
        $vet_id = $request->vet_id;
        $type = $request->type;
        $vet_status = Vet::find($vet_id);
        $history = $this->history($room_sid);
        if($status == self::accepted){
            $vet_status->is_call = 1;
        }
        elseif($status == self::declined){
            $vet_status->is_call = 0;
        }
        elseif ($status == self::completed){
            $end_time = Carbon::now();
            $vet_status->is_call = 0;
            $end_time_update_db = VideoCall::where('id',$history->id)->update(['end_time'=>$end_time]);
        }
        $vet_status->save();
        $save_history = $this->addHistory($history->id,$status,$type);
        return $this->successResponse($vet_status, 'Video call status');
    }

    /***
     * @param $channel_name
     * @param $user_object
     * @param $vet_object
     * @param $pet_info
     * @param $app
     * @param $is_protect
     * @throws TwilioException
     */
    protected function channelUserCreation($channel_name,$user_object,$vet_object,$pet_info,$app,$is_protect){
        return $this->createChannel(
            $channel_name,$user_object['user_id'],$vet_object['vet_id'],
            $user_object['app_id'],$vet_object['vet_name'],
            $user_object['user_name'],$pet_info,$user_object['profile'],
            $vet_object['profile'],$app,$is_protect
        );
    }

    protected function myToken($user,$dev_type,$app_id): string
    {
        return $this->init($user,$dev_type,$app_id);
    }

    protected function fetchMyChannel($friendlyname): string
    {
        try {
            return $this->fetchChannel( $friendlyname );
        } catch (TwilioException $e) {
        }
    }

    protected function fetchUserSid($identity)
    {
        try {
           return $this->fetchMyUserSid( $identity );
        } catch (TwilioException $e) {
        }
    }
    /** Video access methods start
     * @param $room_name
     * @return
     * @throws TwilioException
     */
    public function createRoom(Request $request){
        $name = $request->name;
        $twilio = $this->auth;
        try{
            $room = $twilio->video->v1->rooms
                ->create([
                    "recordParticipantsOnConnect" => True,
                   // "statusCallback" => $this->configRoom,
                    "type" => "group",
                    "uniqueName" => $name
                ]);
        }
        catch (TwilioException $e){
            $room = [
                'message'=>$e->getMessage(),
                'status'=>'false'
            ];
        }

        return $room;
    }

    public function history($room_sid){
        $temp = VideoCall::where('room_sid',$room_sid)->first();
        //$history = VideoCallHistory::where('video_call_id',$temp->id)->first();
        return $temp;
    }

    public function addHistory($video_id,$status,$type){
        $temp = new VideoCallHistory();
        $temp->video_call_id = $video_id;
        $temp->status = $status;
        $temp->type = $type;
        $temp->save();
    }

    public function accessEndChatPrivateMethod($channelSid,$vet_id,$value){
        $this->updateChannelEndChatByPawp($channelSid,$vet_id,$value);
    }

    public function chatEndByUser($channelSid,$vet_id){
        $this->chatEndedByUserApp($channelSid,$vet_id);
    }
    public function chatEndByUserTestCase($channelSid,$vet_id){
        $this->chatEndedByUserAppTestCase($channelSid,$vet_id);
    }

    public function postChannelWebhooks($channel){
       return $this->getChannelWebhooks($channel);
    }
    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return Response
     */
    public function destroy($id)
    {
        //
    }
}
