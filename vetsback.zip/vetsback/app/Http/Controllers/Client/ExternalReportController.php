<?php

namespace App\Http\Controllers\Client;

use App\WebappUser;
use App\Feedback;
use App\VetCareUser;
use App\UtmAttribute;
use App\VetCareUserPayment;
use App\BouncingVetCareUser;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\Http\Requests\CreatePetRequest;
use Illuminate\Support\Facades\Validator;
use App\Http\Resources\VetFeedbackResource;
use App\Http\Resources\ExternalUserApiResource;
use App\Http\Resources\ExternalPaymentApiResource;

class ExternalReportController extends Controller
{
    private $noOfRecordPerPage = 10;
    private $paginate = false;
    private $user;

    public function __construct()
    {
        $url = request()->url();
        $re = '/((\w* ){0,5})(user)(( \w*){0,5})/i';
        $index = strpos($url, 'user') + strlen('user');
        $result = substr($url, $index);
        $result = explode('/',$result);
        $appName = $result[1];
        $app = \App\App::where('name',$appName)->first();
        $this->app = $app;

    }

    public function user(Request $request){
        $input = $request->only('search_value', 'search_by', 'page', 'pagination', 'perPage', 'app_id','export','date_from','date_to','email','package_id');
        try {
            $app = $this->app;

            if(!$app)
            {
                return $this->errorResponse('No App is linked with this Clinic.', 404);
            }

            $value = isset($input['search_value'])?$input['search_value']:'';

            $model = VetCareUser::latest()->search($value);
            $model = $model->with(['defaultPet','usage.package','usageLatest.package','payment','userDetails','vetCareUserFeedbacks.vet','pets','user_status_latest']);

            if ($request->has('date_from') && $request->has('date_to')) {
                $model = $model->whereBetween('created_at',
                    [$input['date_from'] . " 00:00:00", $input['date_to'] . " 23:59:00"]
                );
            }

            if(@$request->has('package_id')){
                $package_id = @$input['package_id'];
                $eagerloading = $model->whereHas('usageLatest',function($q) use($package_id){
                    $q = $q->where('package_id',$package_id);
                });
            }else{
                $eagerloading = $model->with(['usageWithThrashed.package','usageSubscription'=>function($q){
                    $q->with('subscriptonsData');
                }]);
            }

            if($request->has('email') & !empty($request->email)){
                $users =  $model->where('app_id',$app->id)->where('email',$request->email)->get();
                $users = ExternalUserApiResource::collection($users);
            }else{
                if($request->has('pagination') & !empty($request->pagination)){
                    $this->paginate = true;
                    $users =  $eagerloading->where('app_id',$app->id)->latest()->paginate($request->pagination);
                }
                else{
                    $this->paginate = false;
                    $users =  $eagerloading->where('app_id',$app->id)->latest()->get();
                }

                $users = ExternalUserApiResource::collection($users);
            }

            return $this->successResponse($users, 'User Record Fetched Successfully.', $this->paginate);
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }

    }

    public function payment(Request $request){
        $input = $request->only('search_value', 'search_by', 'page', 'pagination', 'perPage', 'app_id','export','date_from','date_to','email','status');
        try {
            $app = $this->app;

            $value = isset($input['search_value'])?$input['search_value']:'';

            if(!$app)
            {
                return $this->errorResponse('No App is linked with this Clinic.', 404);
            }

            $model = VetCareUserPayment::whereHas('user',function($q) use($app,$value){
                $q->where('app_id',$app->id);
                $q->where(function($q) use($app,$value){
                    $q->where('email','Like','%'.$value.'%')
                    ->orWhere(function($q) use($app,$value){
                        $q->where('email','Like','%'.$value.'%')->orWhere('first_name','Like','%'.$value.'%')
                        ->orWhere('last_name','Like','%'.$value.'%');
                    });
                });
            });

            $model = $model->with('user.usage.package');

            //Use case when there is a date filter
            if ($request->has('date_from') && $request->has('date_to')) {
                $model = $model->whereBetween('created_at',
                    [$input['date_from'] . " 00:00:00", $input['date_to'] . " 23:59:00"]
                );
            }
            if(@$request->has('status')){
                $status = @$input['status'];
                $model = $model->where('status',$status);
            }


            if($request->has('pagination') & !empty($request->pagination)){
                $this->paginate = true;
                $users =  $model->paginate($request->pagination);
            }
            else{
                $this->paginate = false;
                $users =  $model->get();
            }

            $users = ExternalPaymentApiResource::collection($users);

            return $this->successResponse($users, 'Payment Record Fetched Successfully.', $this->paginate);
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }

    }

    public function vetFeedbacks(Request $request){
        $input = $request->only('search_value', 'search_by', 'page', 'pagination', 'perPage', 'app_id','export','date_from','date_to','user_id','package_id');
        try {
            $app = $this->app;

            if(!$app)
            {
                return $this->errorResponse('No App is linked with this Clinic.', 404);
            }

            $value = isset($input['search_value'])?$input['search_value']:'';
            $model = Feedback::latest();
            $model = $model->where('app_id',$app->id);
            $model = $model->with(['video','chat','reason','recommendation']);
            if($value != ''){
                $model = $model->whereHas('video.vcUser',function($q) use($value){
                    $q->where('email','Like','%'.$value.'%')
                    ->orWhere(function($q) use($value){
                        $q->where('email','Like','%'.$value.'%')->orWhere('first_name','Like','%'.$value.'%')
                        ->orWhere('last_name','Like','%'.$value.'%');
                    });
                });

                $model = $model->where('app_id',$app->id);
                $model = $model->orWhereHas('video.vet',function($q) use($value){
                    $q->where('email','Like','%'.$value.'%')
                    ->orWhere(function($q) use($value){
                        $q->where('email','Like','%'.$value.'%')->orWhere('first_name','Like','%'.$value.'%')
                        ->orWhere('last_name','Like','%'.$value.'%');
                    });
                });

                $model = $model->where('app_id',$app->id);
                $model = $model->orWhereHas('chat.vcUser',function($q) use($value){
                    $q->where('email','Like','%'.$value.'%')
                    ->orWhere(function($q) use($value){
                        $q->where('email','Like','%'.$value.'%')->orWhere('first_name','Like','%'.$value.'%')
                        ->orWhere('last_name','Like','%'.$value.'%');
                    });
                });

                $model = $model->where('app_id',$app->id);
                $model = $model->orWhereHas('chat.vet',function($q) use($value){
                    $q->where('email','Like','%'.$value.'%')
                    ->orWhere(function($q) use($value){
                        $q->where('email','Like','%'.$value.'%')->orWhere('first_name','Like','%'.$value.'%')
                        ->orWhere('last_name','Like','%'.$value.'%');
                    });
                });
            }

            $model = $model->where('app_id',$app->id);
            // if ($request->has('date_from') && $request->has('date_to')) {
            //     $model = $model->whereBetween('created_at',
            //         [$input['date_from'] . " 00:00:00", $input['date_to'] . " 23:59:00"]
            //     );
            // }
            $model = $model->where('app_id',$app->id);

            // return $this->successResponse($model, 'Record Fetched Successfully .', $this->paginate);

            if (isset($input['pagination']) && $input['pagination'] != "") {
                $this->paginate = true;

                if($request->has('export') && $request->export === 'true' || $request->export === true){
                    $this->paginate = false;
                    $model =  $model->where('app_id',$app->id)->latest()->get();
                }
                else{
                    $model =  $model->where('app_id',$app->id)->latest()->paginate($this->noOfRecordPerPage);
                }
            }
            else{
                $model =  $model->where('app_id',$app->id)->latest()->get();
            }

            $model = VetFeedbackResource::collection($model);


            return $this->successResponse($model, 'Record Fetched Successfully .', $this->paginate);
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }

    }

    public function bouncingUser(Request $request){
        $input = $request->only('search_value','page', 'pagination', 'perPage', 'app_id','export','date_from','date_to');
        try {
            $app = $this->app;

            if(!$app)
            {
                return errorResponse('No App is linked with this Clinic.', 404);
            }

            $value = isset($input['search_value'])?$input['search_value']:'';

            $model = BouncingVetCareUser::where('app_id',$app->id);

            if(!empty($value)){
                $model = $model->where('email','Like','%'.$value.'%')
                ->orWhere(function ($query) use ($value) {
                    $query->where('email','Like','%'.$value.'%')->orWhere('first_name','Like','%'.$value.'%')
                    ->orWhere('last_name','Like','%'.$value.'%');
                });
            }

            //Use case when there is a date filter
            if ($request->has('date_from') && $request->has('date_to')) {
                $model = $model->whereBetween('created_at',
                    [$input['date_from'] . " 00:00:00", $input['date_to'] . " 23:59:00"]
                );
            }
            $model = $model->where('app_id',$app->id);


            if ($request->has('user_id') && !empty($request->user_id)) {
                $this->paginate = false;
                $model =  $model->where('id',$request->user_id)->get();
            }else{
                if (isset($input['pagination']) && $input['pagination'] == "true") {
                    $this->paginate = true;
                    $model =  $model->latest()->paginate($this->noOfRecordPerPage);
                }else{
                    $this->paginate = false;
                    $model =  $model->latest()->get();
                }
            }

            // if (isset($input['pagination']) && $input['pagination'] == "true") {
            //     $this->paginate = true;
            //     $model =  $model->latest()->paginate($this->noOfRecordPerPage);
            //     if($request->has('export') && $request->export === 'true' || $request->export === true){
            //         $this->paginate = false;
            //         $model =  $model->latest()->get();
            //     }
            //     else{
            //         $model =  $model->latest()->paginate($this->noOfRecordPerPage);

            //     }
            // }
            // else{
            //     if($request->has('user_id') && !empty($request->user_id)){
            //         $model =  $model->where('id',$request->user_id)->get();
            //     }else{
            //         $model =  $model->get();
            //     }
            // }

            return $this->successResponse($model, 'Record Fetched Successfully .', $this->paginate);
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }

    }

    /**
     * Show the form for creating a new resource.
     *
     * @param CreatePetRequest $request
     * @return \Illuminate\Http\Response
     */
    public function addPet(CreatePetRequest $request)
    {

        $validated = $request->validated();
        $data = $validated;
        try{

            if($request->has('email') && $request->email != ""){
                $user = VetCareUser::where('email',$request->email)->where('app_id',$request->app_id)->first();
                if(!$user){
                    return $this->errorResponse('User not found',404);
                }
            }else{
                return $this->errorResponse('User Email is required',400);
            }

            $data['user_id'] = $user->id;

            if($request->hasFile('profile')){
                $data['profile'] = $this->uploadFile($request->profile,'pets');
            }
            $data['species'] = strtolower($data['species']);
            if ($data['species'] != 'cat' && $data['species'] != 'dog') {
                return $this->errorResponse('The species field is required, should be "cat" or "dog".', 404);
            }
            $pet_info = $user->pets()->create($data);
//            $response = $user->load('pets');
            $response['email'] = $user->email;
            $response['pet'] = $pet_info;
            return $this->successResponse($response, 'Pet Added');
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(),$e->getCode());

        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function updatePet(Request $request)
    {
        try{

            $validator = Validator::make($request->all(), [
                'email' => 'required|email|exists:vet_care_users,email',
                'pet_id' => 'required|exists:vet_care_pets,id',

            ]);

            if ($validator->fails()) {
                return $this->errorResponse($validator->errors()->first(), 422);
            }

            if($request->has('email') && $request->email != ""){
                $user = VetCareUser::where('email',$request->email)->where('app_id',$request->app_id)->first();
                if(!$user){
                    return $this->errorResponse('User not found',404);
                }
            }else{
                return $this->errorResponse('User Email is required',400);
            }

            if (strtolower($request->pet['species']) != 'cat' && strtolower($request->pet['species'] != 'dog')) {
                return $this->errorResponse('The species field is required, should be "cat" or "dog".', 404);
            }

            $old_data = $user->pets()->find($request->pet_id);
            if(!$old_data){
                return $this->errorResponse('Pet ID invalid. Pet not found',404);
            }
            if($request->has('pet')){
                $data = $request->pet;
                $data['species'] = strtolower($data['species']);
                if($request->hasFile('pet.profile')){
                    $data['profile'] = $path = $this->uploadFile($request->pet['profile'],'pets');
                }
                $old_data->where('id',$request->pet_id)->update($data);
            }

            $success['pet'] = $user->pets()->find($request->pet_id);
            return $this->successResponse($success, 'Pet Updated');
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(),$e->getCode());

        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @return \Illuminate\Http\Response
     */
    public function removePet(Request $request)
    {
        try{

            $validator = Validator::make($request->all(), [
                'email' => 'required|email|exists:vet_care_users,email',
                'pet_id' => 'required|exists:vet_care_pets,id',

            ]);

            if ($validator->fails()) {
                return $this->errorResponse($validator->errors()->first(), 422);
            }

            if($request->has('email') && $request->email != ""){
                $user = VetCareUser::where('email',$request->email)->where('app_id',$request->app_id)->first();
                if(!$user){
                    return $this->errorResponse('User not found',404);
                }
            }else{
                return $this->errorResponse('User Email is required',400);
            }

            $pet = $user->pets()->find($request->pet_id);
            if(!$pet){
                return $this->errorResponse('Pet ID invalid. Pet not found',404);
            }

            $old_data = $pet->delete();
            return $this->successResponse($old_data, 'Pet data deleted successfully');
        }
        catch (Exception $e){
            return $this->errorResponse($e->getMessage(),$e->getCode());
        }

    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function getPets(Request $request)
    {
        $input = $request->only('search_value', 'search_by', 'page', 'pagination', 'perPage');
        try{

            $validator = Validator::make($request->all(), [
                'email' => 'required|email|exists:vet_care_users,email',

            ]);

            if ($validator->fails()) {
                return $this->errorResponse($validator->errors()->first(), 422);
            }

            if($request->has('email') && $request->email != ""){
                $user = VetCareUser::where('email',$request->email)->where('app_id',$request->app_id)->first();
                if(!$user){
                    return $this->errorResponse('User not found',404);
                }
            }else{
                return $this->errorResponse('User Email is required',400);
            }


            $users = $user->pets()->get();

            $users = $users->values();
            $data['list'] = $users->all();
            //$data['payment'] = $payment;

            return $this->successResponse($data, 'pet list');
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(),$e->getCode());
        }

    }

    public function switchDefaultPet(Request $request)
    {
        try {
            $validator = Validator::make($request->all(), [
                'email' => 'required|email|exists:vet_care_users,email',
                'pet_id' => 'required|exists:vet_care_pets,id',
            ]);

            if ($validator->fails()) {
                return $this->errorResponse($validator->errors()->first(), 422);
            }

            if($request->has('email') && $request->email != ""){
                $user = VetCareUser::where('email',$request->email)->where('app_id',$request->app_id)->first();
                if(!$user){
                    return $this->errorResponse('User not found',404);
                }
            }else{
                return $this->errorResponse('User Email is required',400);
            }

            $newPet = $user->pets()->find($request->pet_id);

            if(!$newPet){
                return $this->errorResponse('Pet not found',404);
            }

            $defaultPet = $user->defaultPet()->sync($request->pet_id);
            return $this->successResponse($defaultPet, 'Pet Switched Successfully');
        } catch (Exception $e) {
            return $this->errorResponse($e->getMessage(),$e->getCode());
        }
    }

    public function utmAttributes(Request $request){

        $input = $request->only('date_from','date_to','page', 'pagination', 'perPage');

        try {
            $model = new UtmAttribute;
            //Use case when there is a date filter
            if ($request->has('date_from') && $request->has('date_to')) {
                $model = $model->whereBetween('created_at',
                    [$input['date_from'] . " 00:00:00", $input['date_to'] . " 23:59:00"]
                );
            }


            if ($request->has('user_id') && !empty($request->user_id)) {
                $this->paginate = false;
                $model =  $model->where('id',$request->user_id)->get();
            }else{
                if (isset($input['pagination']) && $input['pagination'] == "true") {
                    $this->paginate = true;
                    $model =  $model->latest()->paginate($this->noOfRecordPerPage);
                }else{
                    $this->paginate = false;
                    $model =  $model->latest()->get();
                }
            }

            return $this->successResponse($model, 'Record Fetched Successfully .', $this->paginate);
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }

    }
}
