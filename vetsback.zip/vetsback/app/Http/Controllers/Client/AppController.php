<?php

namespace App\Http\Controllers\Client;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\AppRequest;
use Carbon\Carbon;
use Illuminate\Support\Str;
use Validator;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use JWTAuth;
use App\App;
use App\AppSetting;

class AppController extends Controller
{
    private $noOfRecordPerPage = 10;
    private $paginate = false;
    private $user;


    public function __construct()
    {
        $this->user = $this->guard()->user();
    }

    public function create(AppRequest $request)
    {

        $validatedData = $request->validated();
//        $this->user = $this->guard()->user();
        try {
            $validatedData['api_key'] = $api_key_gen = Str::random(16);
            $validatedData['app_type'] = 'whitelabel-webapp';
            if($request->hasFile('logo')) {
                $validatedData['logo'] = $this->uploadFilePublicRepo($request->logo, 's3','vet_care_app');
            }
            $app = $this->user->app()->create($validatedData);
            $validatedData['app_id'] = $app->id;
            AppSetting::create($validatedData);
            return $this->successResponse($app, 'Successfully Created App.');
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    public function list(Request $request)
    {
        $input = $request->only('search_value', 'search_by', 'page', 'pagination', 'perPage', 'app_id','all');
        //dd($input);
        try{
            if (isset($input['pagination']) && $input['pagination'] != "") {
                $this->paginate = true;
                $app = $this->user->app()->paginate($this->noOfRecordPerPage);
            }
            else if(isset($input['all']) && $input['all'] != "") {
                $app = $this->user->app()->all();
            }
            else {
                $app_id = $input['app_id'];
                $app = $this->user->app()->find($app_id);
            }
            $data = array(
                "app" => $app
            );
            return $this->successResponse($data['app'], 'Successfully Fetch List App.', $this->paginate);
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    public function update($id, AppRequest $request)
    {
        $validatedData = $request->validated();
        try {
            $app = $this->user->app()->findOrfail($id);
            //$validatedData['api_key'] = $api_key_gen = Str::random(16);
            $app->update($validatedData);
            $data = array(
                "app" => $app
            );
            return $this->successResponse($data, 'Successfully Record Updated.');
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    
    public function updateTheme($id, Request $request)
    {
        try {
            $validatedData = $request->only('logo','primary_color','secondary_color');
            $app = $this->user->app()->findOrfail($id);
            if($request->hasFile('logo')) {
                $validatedData['logo'] = $this->uploadFilePublicRepo($request->logo, 's3','vet_care_app');
            }
            $appSettings = new AppSetting();
            $res = $appSettings->where('app_id',$app->id)->update($validatedData);

            if($res){
                $res = $appSettings->where('app_id',$app->id)->first();
            }
            
            return $this->successResponse($res, 'Successfully Record Updated.');
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }
    
    //For Clinic Users only
    public function getList(){
        try{
            $app = App::select('name')->with('settings')->where('app_type','whitelabel-webapp')->get();
            return $this->successResponse($app, 'Successfully Fetch List App.');
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    public function getSettings($name){
        try{
            $app = App::with('settings')->where(['app_type'=>'whitelabel-webapp','name'=>$name])->get();
            return $this->successResponse($app, 'Successfully Fetch List App.');
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    public function guard()
    {
        return Auth::guard('clinic');
    }
}
