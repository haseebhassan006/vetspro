<?php

namespace App\Http\Controllers\Client;

use App\App;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class PublicController extends Controller
{
    //
    public function getList(){
        try{
            $app = App::select('id','name')->with('settings')->where('app_type','whitelabel-webapp')->get();
            return $this->successResponse($app, 'Successfully Fetch List App.');
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    public function getSettings($name){
        try{
            $app = App::where(['app_type'=>'whitelabel-webapp','name'=>$name])->with('clinic')->get();
            return $this->successResponse($app, 'Successfully Fetch List App.');
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }
}
