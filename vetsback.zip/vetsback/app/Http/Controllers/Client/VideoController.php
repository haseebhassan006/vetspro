<?php

namespace App\Http\Controllers\Client;

use App\App;
use App\EmergencyVetClient;
use App\FailedHandshake;
use App\Guest;
use App\Http\Requests\ChatRequest;
use App\Http\Requests\AppointmentCallRequest;
use App\Http\Resources\VpmCallCollection;
use App\Notification;
use App\PawpVideoData;
use App\Pet;
use App\PivotVideoCall;
use App\Queue;
use App\SdkPetDetail;
use App\StatusVideoCall;
use App\Traits\OtherTwilioSDKTrait;
use App\Traits\PushNotification;
use App\Traits\TwilioSDKTrait;
use App\User;
use App\Vet;
use App\VetCarePet;
use App\AppointmentBooking;
use App\TrainerSchedule;
use App\AppointmentPet;
use App\VideoCall;
use App\VideoCallHistory;
use App\VideoCallMedia;
use App\WebAppUsersExtra;
use Aws\Credentials\Credentials;
use Aws\Exception\AwsException;
use Aws\S3\S3Client;
use Carbon\Carbon;
use Illuminate\Database\QueryException;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Mockery\Exception;
use Twilio\Exceptions\RestException;
use Twilio\Exceptions\TwilioException;
use function foo\func;
use App\SubAdmin;

class VideoController extends Controller
{
    use TwilioSDKTrait;
    use PushNotification;
    //use OtherTwilioSDKTrait;

    private $noOfRecordPerPage = 10;
    private $paginate = false;
    const accepted = 'accepted';
    const declined = 'declined';
    const notanswered = 'notanswered';
    const inprogress = 'inprogress';
    const completed = 'completed';

    public function __construct()
    {
        $this->generic();
    }

    /**
     * Display a listing of the resource.
     *
     * @return Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function videoAppointment(AppointmentCallRequest $request){
        $validated = $request->validated();
        $appointment=AppointmentBooking::find($request->appointment_id);
        try{
            // \DB::connection()->enableQueryLog();
            $appointmentSchedule=TrainerSchedule::where('id',$appointment->schedule_id)
            ->whereDate('slot_from_time','>=',Carbon::now())
            ->whereDate('slot_from_time','>=',Carbon::now()->format('H:i:s'))
            ->whereDate('slot_to_time','<=',Carbon::now())
            ->whereDate('slot_to_time','<=',Carbon::now()->format('H:i:s'))
            ->first();
            // $queries = \DB::getQueryLog();
            // return dd($queries);
            if(empty($appointmentSchedule)){
                return $this->errorResponse('Warning! Slot not found',404);
            }
            $user = auth()->guard()->user();
            $app = $this->find_app($request->api_key);
            $type = isset($request->status)?$request->status:self::inprogress;
            $room_data = array();

            //Call only the vets that are in queue
            $vets = $this->vetQueue();
            if(count($vets) < 1){
                //Log failed calls
                FailedHandshake::create([
                    'request'=> json_encode($request->all()),
                    'response'=>json_encode(['message'=>'Vets are busy at the moment. Try again later','code'=>406]),
                    'app_id'=>$app->id
                ]);
                return $this->errorResponse('Vet is on another call.',406);
            }

            $pet = new AppointmentPet();
            //$app = $this->find_app($request->api_key);

            $pet_info = $pet->find($appointment->appointment_pet_id);

            $roomName = $user->first_name.'-'.Carbon::now();

            $response = $this->createRoom($roomName);

            $is_protect = $user->roles->pluck('name');

            $a = 0;
                foreach ($vets as $vet){
                    $vet_info = Vet::find($vet['vet_id']);
                    $vet_id = $vet_info->id;
                    $room_data = [
                        'sid'=>$response->sid,
                        'status'=>$response->status,
                        'uniqueName'=>$response->uniqueName,
                        'statusCallback'=>$response->statusCallback,
                        'statusCallbackMethod'=>$response->statusCallbackMethod,
                        'endTime'=>$response->endTime,
                        'duration'=>$response->duration,
                        'type'=>$response->type,
                        'maxParticipants'=>$response->maxParticipants,
                        'recordParticipantsOnConnect'=>$response->recordParticipantsOnConnect,
                        'url'=>$response->url,
                        //'vet_id'=>$vet_info->id,
                       //'vet' =>$vets,

                    ];
                    $binding = array();
                    if($response->status == 'in-progress'){
                        $room = [
                                'sid' =>$response->sid,
                                'uniqueName'=>$response->uniqueName
                        ];
                        $data = [
                            //'device_token' => $vet_info->devices->device_token,
                            'room' => $room,
                            'pet'=> $pet_info,
                            'is_protect'=>'false',
                            //'vet_id'=>$vet_info->id,
                            //'dev_type'=>$vet_info->devices->dev_type,
                            'type'=>'video',
                            'datetime'=> Carbon::now()->timestamp,
                            'username'=>$user->first_name.' '.$user->last_name,
                            'user_profile'=>$user->userDetails,
                            'role'=>$is_protect,
                            'app'=>$app->name,
                            'user_id'=>$user->id,

                        ];
                        if($vet_info->devices->dev_type == 'ios'){
                            $binding_type = 'apn';
                            $binding_address = $vet_info->devices->device_token;
                        }
                        else{
                            $binding_type = 'fcm';
                            $binding_address = $vet_info->devices->device_token;
                        }
                        $binding = $this->createBindings('vet_'.$vet_id,$binding_address,$binding_type,$data,'IncomingVideoCall.caf','Call incoming');
                        //Busy all the vets when they recieve push try for a video call
                        //$vet_info->update(['is_call'=>true]);
                        //Queue::where('vet_id',$vet_info->id)->update(['status'=>true]);
                    }


                    $video = VideoCall::create([
                        'room_sid'=>$response->sid,
                        'vet_id'=>$vet_info->id,
                        'user_id'=>$user->id,
                        'app_id'=>$user->app_id,
                        'start_time'=>Carbon::now()->timezone('America/Toronto')
                    ]);
                    VideoCallHistory::create([
                        'video_call_id'=>$video->id,
                        'status'=>$type,
                        'type'=>'user',
                    ]);
                    $a++;
                }
                return $this->successResponse($room_data, 'Video call started');
            }


        catch (QueryException $e){
            return $this->errorResponse($e->getMessage(),401);
        }
    catch (RestException $e){
        return $this->errorResponse($e->getMessage(),$e->getStatusCode());
    }
    catch (\Exception $e){
        return $this->errorResponse($e->getMessage(),$e->getCode());
    }



    }
    public function create(ChatRequest $request)
    {
        $validated = $request->validated();
        try{
            $user = auth()->guard()->user();
            $app = $this->find_app($request->api_key);
            $type = isset($request->status)?$request->status:self::inprogress;
            $room_data = array();

            //Call only the vets that are in queue
            $vets = $this->vetQueue();
            $staffs = $this->staffQueue();
            
                if((count($vets) < 1) &&  (count($staffs) < 1)){
                    //Log failed calls
                    FailedHandshake::create([
                        'request'=> json_encode($request->all()),
                        'response'=>json_encode(['message'=>'Vets and Staffs are busy at the moment. Try again later','code'=>406]),
                        'app_id'=>$app->id
                    ]);
                    return $this->errorResponse('Vet and Staff are on another call.',406);
                }

                $pet = new VetCarePet();
                //$app = $this->find_app($request->api_key);

                $pet_info = $pet->find($request->pet_id);

                $roomName = $user->first_name.'-'.Carbon::now();

                $response = $this->createRoom($roomName);

                $is_protect = $user->roles->pluck('name');

                $a = 0;
                if((count($vets) >= 1) &&  (count($staffs) < 1) ){

                    foreach ($vets as $vet){
                        $vet_info = Vet::find($vet['vet_id']);
                        $vet_id = $vet_info->id;
                        $room_data = [
                            'sid'=>$response->sid,
                            'status'=>$response->status,
                            'uniqueName'=>$response->uniqueName,
                            'statusCallback'=>$response->statusCallback,
                            'statusCallbackMethod'=>$response->statusCallbackMethod,
                            'endTime'=>$response->endTime,
                            'duration'=>$response->duration,
                            'type'=>$response->type,
                            'maxParticipants'=>$response->maxParticipants,
                            'recordParticipantsOnConnect'=>$response->recordParticipantsOnConnect,
                            'url'=>$response->url,
                            //'vet_id'=>$vet_info->id,
                           //'vet' =>$vets,
    
                        ];
                        $binding = array();
                        if($response->status == 'in-progress'){
                            $room = [
                                    'sid' =>$response->sid,
                                    'uniqueName'=>$response->uniqueName
                            ];
                            $data = [
                                //'device_token' => $vet_info->devices->device_token,
                                'room' => $room,
                                'pet'=> $pet_info,
                                'is_protect'=>'false',
                                //'vet_id'=>$vet_info->id,
                                //'dev_type'=>$vet_info->devices->dev_type,
                                'type'=>'video',
                                'datetime'=> Carbon::now()->timestamp,
                                'username'=>$user->first_name.' '.$user->last_name,
                                'user_profile'=>$user->userDetails,
                                'role'=>$is_protect,
                                'app'=>$app->name,
                                'user_id'=>$user->id,
    
                            ];
                            if($vet_info->devices->dev_type == 'ios'){
                                $binding_type = 'apn';
                                $binding_address = $vet_info->devices->device_token;
                            }
                            else{
                                $binding_type = 'fcm';
                                $binding_address = $vet_info->devices->device_token;
                            }
                            $binding = $this->createBindings('vet_'.$vet_id,$binding_address,$binding_type,$data,'IncomingVideoCall.caf','Call incoming');
                            //Busy all the vets when they recieve push try for a video call
                            //$vet_info->update(['is_call'=>true]);
                            //Queue::where('vet_id',$vet_info->id)->update(['status'=>true]);
                        }
    
                       Notification::create([
                            'sid' => $binding['notification_sid'],
                            'user_to_notify' => $vet_info->id,
                            'user_who_fired_event'=>$user->id,
                            'unique_key' =>  $binding['unique_key']
                        ]);
                        // $video = VideoCall::create([
                        //     'room_sid'=>$response->sid,
                        //     'vet_id'=>$vet_info->id,
                        //     'user_id'=>$user->id,
                        //     'app_id'=>$user->app_id,
                        //     'start_time'=>Carbon::now()->timezone('America/Toronto')
                        // ]);

                        $video =$vet_info->video()->create([
                            'room_sid'=>$response->sid,
                            'user_id'=>$user->id,
                            'app_id'=>$user->app_id,
                            'start_time'=>Carbon::now()->timezone('America/Toronto')
                        ]);

                        VideoCallHistory::create([
                            'video_call_id'=>$video->id,
                            'status'=>$type,
                            'type'=>'user',
                        ]);
                        $a++;
                    }
                }elseif((count($vets) < 1) &&  (count($staffs) >= 1)){
                    foreach ($staffs as $staff){
                        $staff_info = SubAdmin::find($staff['staff_id']);

                        $staff_id = $staff_info->id;

                        $room_data = [
                            'sid'=>$response->sid,
                            'status'=>$response->status,
                            'uniqueName'=>$response->uniqueName,
                            'statusCallback'=>$response->statusCallback,
                            'statusCallbackMethod'=>$response->statusCallbackMethod,
                            'endTime'=>$response->endTime,
                            'duration'=>$response->duration,
                            'type'=>$response->type,
                            'maxParticipants'=>$response->maxParticipants,
                            'recordParticipantsOnConnect'=>$response->recordParticipantsOnConnect,
                            'url'=>$response->url,
                            //'vet_id'=>$vet_info->id,
                           //'vet' =>$vets,
    
                        ];
                        $binding = array();
                        if($response->status == 'in-progress'){
                            $room = [
                                    'sid' =>$response->sid,
                                    'uniqueName'=>$response->uniqueName
                            ];
                            $data = [
                                //'device_token' => $vet_info->devices->device_token,
                                'room' => $room,
                                'pet'=> $pet_info,
                                'is_protect'=>'false',
                                //'vet_id'=>$vet_info->id,
                                //'dev_type'=>$vet_info->devices->dev_type,
                                'type'=>'video',
                                'datetime'=> Carbon::now()->timestamp,
                                'username'=>$user->first_name.' '.$user->last_name,
                                'user_profile'=>$user->userDetails,
                                'role'=>$is_protect,
                                'app'=>$app->name,
                                'user_id'=>$user->id,
    
                            ];
                            if($staff_info->devices->dev_type == 'ios'){
                                $binding_type = 'apn';
                                $binding_address = $staff_info->devices->device_token;
                            }
                            else{
                                $binding_type = 'fcm';
                                $binding_address = $staff_info->devices->device_token;
                            }
                            $binding = $this->createBindings('staff_'.$staff_id,$binding_address,$binding_type,$data,'IncomingVideoCall.caf','Call incoming');
                            //Busy all the vets when they recieve push try for a video call
                            //$vet_info->update(['is_call'=>true]);
                            //Queue::where('vet_id',$vet_info->id)->update(['status'=>true]);
                        }
    
                       Notification::create([
                            'sid' => $binding['notification_sid'],
                            'user_to_notify' => $staff_info->id,
                            'user_who_fired_event'=>$user->id,
                            'unique_key' =>  $binding['unique_key']
                        ]);
                        // $video = VideoCall::create([
                        //     'room_sid'=>$response->sid,
                        //     'staff_id'=>$staff_info->id,
                        //     'user_id'=>$user->id,
                        //     'app_id'=>$user->app_id,
                        //     'start_time'=>Carbon::now()->timezone('America/Toronto')
                        // ]);
                        $video =$staff_info->video()->create([
                                'room_sid'=>$response->sid,
                                'user_id'=>$user->id,
                                'app_id'=>$user->app_id,
                                'start_time'=>Carbon::now()->timezone('America/Toronto')
                            ]);
                        VideoCallHistory::create([
                            'video_call_id'=>$video->id,
                            'status'=>$type,
                            'type'=>'user',
                        ]);
                        $a++;
                    }
                }
               
                return $this->successResponse($room_data, 'Video call started');
            }
            catch (QueryException $e){
                return $this->errorResponse($e->getMessage(),401);
            }
        catch (RestException $e){
            return $this->errorResponse($e->getMessage(),$e->getStatusCode());
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(),$e->getCode());
        }

    }

    public function callEvents(Request $request)
    {
        $status = $request->status;
        $user_id = $request->user_id;
        $vet_id = $request->vet_id;
        $type = $request->type;
        $room_sid  = $request->room_sid;
        $vet_status = array();
        if($vet_id != 0){
            $vet_status = Vet::find($vet_id);
            $queue_status =  Queue::where('vet_id',$vet_status->id)->first();
        }
        $history = $this->history($room_sid,$vet_id,$user_id);
        $unique_id = $request->unique_key;
        $oldVetNotificationData = Notification::where(['unique_key'=>$unique_id,'seen_by_user'=>0])->first();
        if(isset($history) && !empty($history)){
            $this->addHistory($history->id,$status,$type);
        }
        $heading = 'User connected to another Vet on the call';
        if($type == 'user'){
            switch ($status){
                //case 'accepted':
                case 'declined':
                    $heading = 'Call disconnect by user';
                    break;
                case 'completed':
                    $end_time = Carbon::now();
                    $vet_status->is_call = 0;
                    VideoCall::where('id',$history->id)->update(['end_time'=>$end_time]);
                    $queue_status->update(['status'=>false]);
                    $vet_status->save();
                    break;
                case 'notanswered':
                    return $this->errorResponse('Video not successful.Try again in a moment', 417);
                default:
            }
        }
        elseif($type == 'vet'){
            switch ($status){
                case 'accepted':
                    $vet_status->is_call = 1;
                    $queue_status->update(['status'=>true]);
                    //For webapp users only
                    WebAppUsersExtra::where(['type'=>'video','user_id'=>$user_id])->update(['vet_id'=>$vet_status->id]);
                    break;
                case 'declined':
                    $vet_status->is_call = 0;
                    $queue_status->update(['status'=>false]);
                    break;
                case 'completed':
                    $end_time = Carbon::now();
                    $vet_status->is_call = 0;
                    VideoCall::where('id',$history->id)->update(['start_time'=>$history->start_time,'end_time'=>$end_time]);
                    $queue_status->update(['status'=>false]);
                    break;
                case 'notanswered':
                    return $this->errorResponse('Call disconnected', 417);
                    break;
                default:
                    $vet_status->is_call = 0;
            }
            $vet_status->save();
            //Check participant count
            if($this->getPariticipantList($room_sid) == true){
                return $this->errorResponse('Another vet has already joined the video', 404);
            }
        }
        //Below all logic are for vet only
        //If already call accepted by some other vet
        //Check notification status if unseen
        $notificationData = $this->vetQueueDuringVideoCall(); //Get all queue list where status is false
        foreach ($notificationData as $nData){
            if($status == 'declined' || $status == 'accepted'){
                $tempQueue['vet_id'] = $nData['vet_id'];
                if($nData['vet_id'] == $vet_id && $tempQueue['vet_id'] == $vet_id){
                    unset($nData['vet_id']);
                    unset($oldVetNotificationData->user_to_notify);
                }
                if(isset($nData['vet_id']) && !empty($nData['vet_id'])){
                    //Get vet id from notification data
                    $vetData= Vet::find($nData['vet_id']);
                    if($vetData->devices->dev_type == 'ios'){
                        $binding_type = 'apn';
                        $binding_address = $vetData->devices->device_token;
                    }
                    else{
                        $binding_type = 'fcm';
                        $binding_address = $vetData->devices->device_token;
                    }
                    $data=[
                        'type'=>'endCall',
                        'user_id'=>$user_id
                    ];
                    //Make Vet available for next call
                    //$vetData->is_call = false;
                    //$vetData->update();
                    //Queue::where('vet_id',$vetData->id)->update(['status'=>false]);
                    //Vet notified to end call as some other vet joined the call
                    $this->createBindings('vet_'.$vet_id,$binding_address,$binding_type,$data,'default',$heading);
                }
            }
        }

        return $this->successResponse($vet_status, 'Video call status');
    }

    public function history($room_sid,$vet_id,$user_id){
        //$history = VideoCallHistory::where('video_call_id',$temp->id)->first();
        return VideoCall::where(['room_sid'=>$room_sid,'user_id'=>$user_id,'vet_id'=>$vet_id])->first();
    }

    public function addHistory($video_id,$status,$type){
        $temp = new VideoCallHistory();
        $temp->video_call_id = $video_id;
        $temp->status = $status;
        $temp->type = $type;
        $temp->save();
    }

    public function userFeedback(Request $request){

    }

    /**
     * @param Request $request
     * @return array
     * Twilio video composition
     */
    private function start_composition(Request $request){
        if($request->StatusCallbackEvent == 'composition-available'){
            try {
                $their_url = $request->CompositionSid;
                $room_sid = $request->RoomSid;
                $base_url = 'https://video.twilio.com';
                $full_url = $base_url.''.$their_url;
                $this->getFileS3($their_url,$room_sid);
                $response = ['twilio_url'=>$their_url,'room'=>$room_sid];
            } catch (TwilioException $e) {
                $response = ['message'=>$e->getMessage(),'code'=>$e->getCode()];
            }
            return $response;
        }
    }

    /**
     * @param Request $request
     * @return Response
     * Video Call webhooks for saving video composition
     */
    public function startRoom(Request $request){
        if ($request->StatusCallbackEvent == 'recording-completed') {
            try {
                $twilio = $this->twilio;
                $room_sid = $request->RoomSid;
                $composition = $twilio->video->compositions->create( $room_sid, [
                    'audioSources' => '*',
                    'videoLayout' => array(
                        'grid' => array(
                            'video_sources' => array('*')
                        )
                    ),
                    'statusCallback' => $this->configComposition,
                    'format' => 'mp4'
                ] );
                $composite_id = $composition->sid;
                $composite_url = $composition->url;
                //VideoCall::where('room_sid',$room_sid)->update(['media_url'=>$composite_id]);
                $result = $this->successResponse( $composite_url, 'Composition enqueued' );
            }
            catch (RestException $e){
                $result = $this->errorResponse($e->getMessage(), $e->getCode());
            }
            return $result;
        }
    }
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return Response
     */
    public function uploadComposition(Request $request)
    {
        $client = $this->twilio;
        if ($request->StatusCallbackEvent == 'composition-available') {
            //$mediaUrl = $request->MediaUri;
            $room_sid = $request->RoomSid;
            try{
                $get = VideoCall::where('room_sid',$room_sid)->first();
                $uri = "https://video.twilio.com/v1/Compositions/$request->CompositionSid/Media?Ttl=3600";
                $response = $client->request("GET", $uri);
                $mediaLocation = $response->getContent()["redirect_to"];
                file_put_contents("myFile.mp4", fopen($mediaLocation, 'r'));
                $content = file_get_contents($mediaLocation);
                $name = $room_sid.'.mp4';
                try{
                    $response = $this->uploadFileToLocalToS3(fopen($mediaLocation, 'r'),$name,$room_sid,$get);
                    return $result = $this->successResponse($response, 'success');
                }
                catch (AwsException $e) {
                    return $result = $this->errorResponse($e->getMessage(),$e->getStatusCode());
                }
            }
            catch (TwilioException $e){
                return $result = $this->errorResponse($e->getMessage(),401);
            } catch (\Exception $e) {
                return $result = $this->errorResponse($e->getMessage(),401);
            }
        }
    }

    public function uploadFileToLocalToS3($file,$key,$room_sid,$data){
        // Upload a publicly accessible file. The file size and type are determined by the SDK.
        try {
            $s3 = Storage::disk('s3_extra')->getDriver()->getAdapter()->getClient();
            $resp = Storage::disk('s3_extra')->put($key, $file);
            $cmd = $s3->getCommand('GetObject', [
                'Bucket' => env('AWS_STAG_VIDEO'),
                'Key' =>$key
            ]);
            //Pre Signed URL work
            $request = $s3->createPresignedRequest($cmd, '+30 minutes');
            $presignedUrl = (string)$request->getUri();

            VideoCall::where('id',$data->id)->update([
                'start_time'=>$data->start_time,
                'end_time'=>$data->end_time,
               // 'media_url'=>$presignedUrl
            ]);
            VideoCallMedia::updateOrCreate(['video_call_id'=>$data->id],[
                'media_url' => $presignedUrl,
                'video_call_id'=>$data->id
            ]);
            //VideoCall::where('room_sid',$room_sid)->update(['media_url'=>$presignedUrl]);
            return true;
        } catch (AwsException $e) {
            return false;
            //return $result = $this->errorResponse($e->getMessage(),$e->getStatusCode());
        }
    }

    /**
     * @param Request $request
     * @return Response
     */
    public function checkNotificationStatus(Request $request){
        try{
            $user = Auth::guard('vets')->user();
            $status = Notification::where('unique_key',$request->unique_key)->update(['seen_by_user'=>1]);
            return $this->successResponse($status, 'Notification seen success');
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(),$e->getCode());
        }

    }

    public function myCallHistory(Request $request)
    {
        $type = $request->type;
        $app = $this->find_app($request->api_key);
        try {
            if ($app->app_type == 'whitelabel') {
                $user = auth()->guard('api')->user();
                $user_id = ['user_id' => $user->id,'app_id'=>$app->id];
            }
            elseif ($app->app_type == 'sdk'){
                $user = auth()->guard('guests')->user();
                $user_id = ['user_id' => $user->id,'app_id'=>$app->id];
            }
            else{
                $user = auth()->guard('vets')->user();
                $user_id = ['vet_id' => $user->id];
            }
            $model = VideoCall::select('id','room_sid','user_id','vet_id','start_time','end_time')
                ->with(['history'=>function($q){
                    $q->select('video_call_id','status','id')
                        ->whereRaw('id IN (select MAX(id) from video_call_histories GROUP BY video_call_id)');
                    //->groupBy('video_call_id');
                }, 'user'=>function($q){
                    $q->select('id','first_name','last_name')->with(['userDetails'=>function($q){
                        $q->select('user_id','profile');
                    }]);
                }, 'vet'=>function($q){
                    $q->select('id','first_name','last_name')->with(['vetDetails'=>function($q){
                        $q->select('vet_id','profile');
                 }]);
                },'guest'=>function($q){
                    $q->select('id','first_name','last_name');
                },
                    'webapps'=>function($q){
                        $q->select('id','first_name','last_name');
                    }
                ])
                ->where($user_id)->latest()->groupBy('room_sid');
                $model = $model->paginate($this->noOfRecordPerPage);
                //dd($model);
                $collection = VpmCallCollection::collection($model);
                return $this->successResponse( $collection, 'Call list',true);
            }
            catch (QueryException $e) {
                return $this->errorResponse( $e->getMessage(), 406 );
            }
            catch (\Exception $e) {
                return $this->errorResponse( $e->getMessage(), $e->getCode() );
            }
    }
}
