<?php

namespace App\Http\Controllers\Client;

use App\Coupon;
use Carbon\Carbon;
use App\CouponUsage;
use App\VetCarePackage;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class GuestApiController extends Controller
{
    public function getPackagesList(Request $request)
    {
        $input = $request->only('search_value', 'search_by', 'page', 'pagination', 'perPage', 'api_key');
        try{
            $key = $request->api_key;
            $app = $this->find_app($key);
            $model = VetCarePackage::get();
            $protect = $model->filter(function ($value, $key) {
                return $value->type === 'protect';
            })->values();
            $data['protect'] = $protect->all();

            $simple = $model->filter(function ($value, $key) {
                return $value->type === 'non-protect';
            })->values();
            $data['non-protect'] = $simple->all();

            $non_credit = $model->filter(function ($value, $key) {
                return $value->type === 'non-credit';
            })->values();
            $data['non-credit'] = $non_credit->all();

            return $this->successResponse($data, 'list');
        }
        catch (Exception $e){
            return $this->errorResponse($e->getMessage(),$e->getCode());
        }
    }

    public function redeem(Request $request)
    {
        try{
            $user = auth()->user();
            $code = $request->code;
            $date = Carbon::now()->toDateString();
            $history = null;
            $model = Coupon::search($code)->firstOrFail();
            $json_to_var = json_decode($model);

            if($request->package_id == $model->package_id){
                if($json_to_var->other->expiry >= $date){
                    $get_payment = VetCarePackage::find($model->package_id);
                    // User not created - Signup flow
                    if(isset($user) && $user != null) {
                        $history = CouponUsage::where(['coupon_id'=>$model->id,'user_id'=>$user->id])->first();
                    }
                    if($history){
                        if($json_to_var->other->one_time == 1){
                            return $this->errorResponse('Code one time use only  contact admin',406);
                        }
                        if($history->left_days < 1){
                            return $this->errorResponse('Code expired  contact admin',406);
                        }
                    }
                    //Response to show user
                    $old_price = $get_payment->price;
                    $off  = $json_to_var->other->percent_off;
                    $calculation = ($off/100)*$old_price;
                    $new_price = $old_price - $calculation;
                }
                else{
                    return $this->errorResponse('Code expired',406);
                }
            }
            else{
                return $this->errorResponse('Redeem code does not belong to your selected package',403);
            }

            $resp['message'] = 'Code accepted';
            $resp['coupon_id'] = $model->id;
            $resp['old_price'] = $old_price;
            $resp['new_price'] = round($new_price,2);
            $resp['discount'] = round($calculation,2);
            $resp['package_id'] = $request->package_id;
            $resp['currency'] = $get_payment->currency;
            return $this->successResponse($resp, 'Redeeem Success');
        }
        catch (ModelNotFoundException $e){
            return $this->errorResponse('Incorrect code! Contact Admin');
        }
        catch (QueryException $e){
            return $this->errorResponse($e->getMessage(),404);
        }
        catch (Exception $e){
            return $this->errorResponse('Warning! Contact Admin',400);
        }
    }

}
