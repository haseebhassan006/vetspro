<?php

namespace App\Http\Controllers\Client;

use App\App;
use App\Coupon;
use App\CouponUsage;
use App\Http\Requests\StripeCardRequest;
use App\Package;
use App\PackageUsage;
use App\Payment;
use App\PaymentProtectUser;
use App\Subscriptions;
use App\Traits\FullTextSearch;
use App\Traits\StripePayment;
use App\User;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Database\QueryException;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Mockery\Exception;
use Stripe\Exception\ApiErrorException;
use Stripe\Exception\CardException;

class UserPaymentController extends Controller
{
    //
    private $noOfRecordPerPage = 10;
    private $paginate = false;
    use FullTextSearch;
    use StripePayment;
    protected $userData;

    public function __construct(User $userData)
    {
        if(auth()->check()):
            $this->id = Auth::user()->id;
            $this->userData = $userData;
            $user = $userData->find($this->id);
            $this->init($user->app_id);
        endif;
    }

    public function index(Request $request)
    {
        $input = $request->only('search_value', 'search_by', 'page', 'pagination', 'perPage', 'api_key');
        try{
            $key = $request->api_key;
            $app = $this->find_app($key);
            $model = Package::where('app_id',$app->id)->get();
            $protect = $model->filter(function ($value, $key) {
                return $value->type === 'protect';
            })->values();
            $data['protect'] = $protect->all();

            $simple = $model->filter(function ($value, $key) {
                return $value->type === 'non-protect';
            })->values();
            $data['non-protect'] = $simple->all();

            $non_credit = $model->filter(function ($value, $key) {
                return $value->type === 'non-credit';
            })->values();
            $data['non-credit'] = $non_credit->all();

            return $this->successResponse($data, 'list');
        }
        catch (Exception $e){
            return $this->errorResponse($e->getMessage(),$e->getCode());
        }
    }

    public function add_card(StripeCardRequest $request){
        $validated = $request->validated();
        try{
            $user = auth()->user();
            if($user->stripe_id ){
                $customer = $this->retrieveCustomer($user->stripe_id);
            }
            else{
                $customer = $this->createCustomer($user->email);

            }
            $validated['cus_id'] = $customer->id;
            //$token = $this->createStripeToken($validated);
            $token = $this->createStripeToken($validated);
            $this->createCustomerSetupIntent($customer->id,$token['token']->id);
            if($token['code'] == 200){
                //$customer = $this->createCustomer($user->email);
                $this->createCustomerSetupIntent($customer->id,$token['token']->id);

                $validated['stripe_id'] = $customer->id;
                $validated['card_id'] = $token['token']->id;
                $user->update($validated);
                return $this->successResponse($token, 'Card added');
            }
            else{
                return $this->errorResponse($token['message'],$token['code']);
            }
        }
        catch (CardException $e){
            return $this->errorResponse($e->getMessage(), $e->getHttpStatus());
        }
        catch (QueryException $e){
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\Response
     */
    public function buy_package(Request $request)
    {
        try{
            $user = auth()->user();
            $package_id = $request->package_id;
            $coupon_id = isset($request->coupon_id) ? $request->coupon_id : 1;
            $price = $request->price;//stripe charges in cents
            $package_data = Package::find($package_id);
            $description = 'Payment against '.$package_data->name;
            $is_recurring = $package_data->is_recurring;
            $interval = $package_data->interval;
            $model = Coupon::find($coupon_id);
            $json_to_var = json_decode($model);


            //Make user stripe charge
            //Case only for 0 payments
            if($package_data->is_card == 0){
                $this->addCouponUsageData($coupon_id,$user->id,$json_to_var->other->access_days,$package_data->id,$package_data->is_card);
                //Add payment information for zero
                Payment::create(
                    [
                        'user_id'=>$user->id,
                        'amount'=>$price,
                        'charge_id'=>'',
                        'status'=>'accepted',
                        'date'=>Carbon::now()->toDateTimeString()
                    ]);
                $response = $this->successResponse('null', 'Package bought');
            }
            else{
                if($price == 0 || $price == 0.0){
                    $subscribed = '';
                    if($interval == 'month'){
                        //$trail_end_date = Carbon::now()->addDay(1)->timestamp;
                        $trail_end_date = Carbon::now()->addMinutes(5)->timestamp;
                        $price_data = $this->getPrice($package_data->price_id);
                        if($price == $price_data){
                            $price_id_subscription = $package_data->price_id;
                        }
                        else{
                            $price_id_subscription = $this->createPrice($price_data,$package_data->currency,$package_data->interval,$package_data->product_id);
                        }
                        // $subscribed = $this->addStripePlanUser($user->stripe_id,$price_id_subscription,$trail_end_date);
                        $subscribed = $this->addStripePlanUser($user->stripe_id,$package_data,$trail_end_date);
                   
                    }
                    $this->userPaymentData($user->id,$price,'','accepted',$package_data->id,$coupon_id,$subscribed,'',$interval,$package_data->type);
                    //Add payment data,subscription data and usage history
                    $response = $this->successResponse('null', 'Package bought');
                }
                else{
                    //Except all zero payments
                    $charge = $this->makeCharge($price,$package_data->currency,$user->stripe_id,$description,$user->card_id);
                    $price_data = $this->getPrice($package_data->price_id);
                    if($price == $price_data){
                        $price_id_subscription = $package_data->price_id;
                    }
                    try{
                        if($charge->status == 'succeeded'){
                            $subscribed = [];
                            //For recurring payments only
                            if($interval == 'month'){
    //                        $trail_end_date = Carbon::now()->addDay(1)->timestamp;
                                $trail_end_date = Carbon::now()->addMinutes(5)->timestamp;
                                if($price != $price_data){
                                    $price_id_subscription = $this->createPrice($price,$package_data->currency,$package_data->interval,$package_data->product_id);
                                }
                                // $subscribed = $this->addStripePlanUser($user->stripe_id,$price_id_subscription,$trail_end_date);
                                $subscribed = $this->addStripePlanUser($user->stripe_id,$package_data,$trail_end_date);
                           
                            }
                            //Add payment data,subscription data and usage history
                            $this->userPaymentData($user->id,$price,$price_id_subscription,$charge->status,$package_data->id,$coupon_id,$subscribed,$price_id_subscription,$interval,$package_data->type);
                            $this->addCouponUsageData($coupon_id,$user->id,$json_to_var->other->access_days,$package_data->id,$package_data->is_card);
                            $response = $this->successResponse('null', 'Package bought');
                        }
                        else{
                            $response = $this->errorResponse('Your payment was not succeeded', 401);
                        }
                    }
                    catch (ApiErrorException $exception){
                        $response = $this->errorResponse($exception->getMessage(), $exception->getHttpStatus());
                    }

                }
            }
//            if($package_data->type == 'protect'){
//                $user->removeRole('users');
//                $user->assignRole('protect_users');
//            }
            return $response;
        }
        catch (QueryException $e){
            return $this->errorResponse($e->getMessage(), 407);
        }
        catch (Exception $e){
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    public function userPaymentData($user_id,$price,$charge_id,$charge_status,$package_id,$coupon_id,$subscribed,$charge,$interval,$type){
        //Add payment data and usage history
        if(isset($charge) && !empty($charge)){
            $payment = Payment::updateOrCreate(['user_id'=>$user_id],[
                'amount'=>$price,
                'charge_id'=>$charge_id,
                'status'=>$charge_status,
                'stripe_response'=> json_encode($charge),
                'date'=>Carbon::now()->toDateTimeString()
            ]);
        }
        else{
            $payment = Payment::create(
                ['user_id'=>$user_id,
                'amount'=>$price,
                'charge_id'=>$charge_id,
                'status'=>$charge_status,
                'date'=>Carbon::now()->toDateTimeString()
            ]);
        }
        $data = PackageUsage::create([
            'user_id'=>$user_id,
            'package_id'=>$package_id,
            'coupon_id'=>$coupon_id
        ]);

        //Add User subscription
        if($interval == 'month' && isset($subscribed) && !empty($subscribed)){
            //Add subscription data
            $json = $this->retreiveSubscriptionSchedule($subscribed->id);
            //dd($subscribed,$json);
            //json = json_decode($subscribed->getContent(),true);
            Subscriptions::updateOrCreate(['user_id'=>$user_id],[
                'subscription_id'=>$json['id'],
                'start_date'=>$json['phases'][0]['start_date'],
                'end_date'=>$json['phases'][0]['end_date'],
                'status'=>$json['status']
            ]);
        }
        //Add User subscription if package type is protect
        if($type == 'protect'){
            PaymentProtectUser::create([
                'user_id'=> $user_id,
                'payment_id'=> $payment->id,
                'subscription_timestamp' => Carbon::now('UTC')
            ]);
        }

        return $data;
    }

    public function redeem(Request $request)
    {
        try{
            $user = auth()->user();
            $code = $request->code;
            $date = Carbon::now()->toDateString();

            $model = Coupon::search($code)->firstOrFail();
            $json_to_var = json_decode($model);

            //$expiry = $json_to_var['expiry'];
            //dd($json_to_var->other->expiry,$date);
            if($request->package_id == $model->package_id){
                if($json_to_var->other->expiry >= $date){
                    $get_payment = Package::find($model->package_id);

                    $history = CouponUsage::where(['coupon_id'=>$model->id,'user_id'=>$user->id])->first();
                    if($history){
                        if($json_to_var->other->one_time == 1){
                            return $this->errorResponse('Code one time use only  contact admin',406);
                        }
                        // $used_days = strtotime($history->use_datetime);
                        // $datediff = date_diff($date - $used_days);
                        if($history->left_days < 1){
                            return $this->errorResponse('Code expired  contact admin',406);
                        }

                    }
                    //Response to show user
                    $old_price = $get_payment->price;
                    $off  = $json_to_var->other->percent_off;
                    $calculation = ($off/100)*$old_price;
                    $new_price = $old_price - $calculation;
                }
                else{
                    //$resp['message'] = 'Code expired or invalid code, contact admin';
                    //$resp['coupon_id'] = $model->id;
                    return $this->errorResponse('Code expired',406);
                }
            }
            else{
                //$resp['message'] = 'Code expired or invalid code, contact admin';
                //$resp['coupon_id'] = $model->id;
                return $this->errorResponse('Redeem code does not belong to your selected package',403);
            }

            $resp['message'] = 'Code accepted';
            $resp['coupon_id'] = $model->id;
            $resp['old_price'] = $old_price;
            $resp['new_price'] = round($new_price,2);
            $resp['discount'] = round($calculation,2);
            $resp['package_id'] = $request->package_id;
            $resp['currency'] = $get_payment->currency;
            return $this->successResponse($resp, 'Redeeem Success');
        }
        catch (ModelNotFoundException $e){
            return $this->errorResponse('Incorrect code! Contact Admin');
        }
        catch (QueryException $e){
            return $this->errorResponse($e->getMessage(),404);
        }
        catch (Exception $e){
            return $this->errorResponse('Warning! Contact Admin',401);
        }
    }

    public function addStripePlanUser($cus_id,$price_id,$days){
        return $this->addSubscription($cus_id,$price_id,$days);
//        return $this->successResponse($subscription, 'user subscribed');
//        try{
//            $subscription = $this->addSubscription($cus_id,$price_id,$days);
//            return $this->successResponse($subscription, 'user subscribed');
//        }
//        catch (ApiErrorException $e){
//            return $this->errorResponse($e->getMessage(),$e->getHttpStatus());
//        }

    }

    public function addCouponUsageData($coupon_id,$user_id,$days,$package_id,$is_card){
        $usage = CouponUsage::updateOrCreate(['coupon_id'=>$coupon_id,'user_id'=>$user_id],[
            'use_datetime'=>Carbon::now(),
            'left_days'=>$days - 1,
            //'use_datetime'=>Carbon::now(),
           // 'coupon_id'=>$model->id
        ]);
        if($is_card == 0){
            $data = PackageUsage::create([
                'user_id'=>$user_id,
                'package_id'=>$package_id,
                'coupon_id'=>$coupon_id
            ]);
        }
    }

    public function get_cards(){
        try{
            $user = auth()->user();
            $data = $this->getUserCards($user->stripe_id);
            return $this->successResponse($data, 'My all cards');
        }
        catch (ApiErrorException $e){
            return $this->errorResponse($e->getMessage(),401);
        }

    }

    public function unsubscribeUser(Request $request){
        try{
            $user = auth()->user();
            //Check for recurring payment
            if($user->usage()->count() > 0){
                $check_interval = Package::findOrFail($user->usage[0]->package_id);
                if($check_interval->interval == 'month' || $check_interval->interval == 'day'){
                    $data = Subscriptions::where('user_id',$user->id)->firstOrFail();
                    $this->unsubscribe($data->subscription_id);
                    $data->delete();
                    if($check_interval->type == 'protect'){
                        $user->removeRole('protect_users');
                    }
//                    else{
//                        $user->removeRole('users');
//                    }
                }
                $trash = PackageUsage::where('user_id',$user->id)->delete();

                return $this->successResponse($trash, 'unsubscribe successful');
            }
            else{
                return $this->errorResponse('You are not subscribed to any package',406);
            }
        }
        catch (ModelNotFoundException $e){
            return $this->errorResponse('You are not subscribed to any package',406);
        }
        catch (ApiErrorException $e){
            return $this->errorResponse($e->getMessage(),401);
        }

    }

    public function history(){
        $user = auth()->user();
        try{
            $data = Payment::select('id','user_id','date','amount','status')->with(['user'=>function($q){
               $q->select('id')->with(['usage'=>function($q){
                  $q->select('id','user_id','package_id')->with(['package'=>function($q){
                     $q->select('id','name');
                   }]);
               }]);
            }])
            ->where('user_id',$user->id)->get();
            return $this->successResponse($data, 'payment list');
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(),401);
        }
    }

    public function createHooks()
    {
        return $this->createdHooks();
    }



}
