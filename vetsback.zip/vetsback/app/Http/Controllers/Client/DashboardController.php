<?php

namespace App\Http\Controllers\Client;

use App\VetCareUser;
use App\VetCareUserPayment;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\Http\Resources\ClinicDashboardResource;
use App\UserAppStatus;
use App\VetCarePackageUsage;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{
    protected $user;

    public function __construct()
    {
        $this->middleware('auth:clinic');
        $this->user = $this->guard()->user();
    }

    public function getMyApps(){
        return App::where('model_id', $this->user->id)->get();
    }

    public function index(Request $request){
        $input = $request->only('limit');
        $limit = isset($input['limit'])?$input['limit']:4;
        $res = [];
        try {
            $app = $this->user->app()->first();

            $isHandShake=is_handshake_enabled($app->id );
            $currentDate = Carbon::now();
            $minusMonthsDate=$currentDate->subMonth(12);


            if($isHandShake){
                 /**
                 *  get all subscribers & cancelleres of handshake  users
                 *                 */
                $handShake = UserAppStatus::selectRaw('
                DATE_FORMAT(created_at,"%m-%Y") as date,count(id) as total_count,status')
                ->where('app_id',$app->id);

                /* Count Total Successed and Cancelled */
                $subscribers = $handShake->groupBy('status')->get();

                $totalSubscribed = $subscribers->where('status','subscribed')->first();
                $totalUpgrade = $subscribers->where('status','upgrade')->first();
                $totalCancelled = $subscribers->where('status','cancelled')->first();
                $totalSubscribed = (($totalSubscribed != null)? $totalSubscribed->total_count:0)+ (($totalUpgrade != null)? $totalUpgrade->total_count:0);
                $totalCancelled = (($totalCancelled != null)? $totalCancelled->total_count:0);


                $handShake =$handShake->whereYear('created_at',">=",$minusMonthsDate->year)
                ->whereMonth('created_at','>=',1)
                ->groupBy(['date','status'])
                ->orderBy('date','asc')
                ->get();

                $chartData = [];
                for($i=1;$i<=12;$i++)
                {
                    $monthDate = $minusMonthsDate->addMonth(1);
                    $monthDate = $minusMonthsDate->format('m-Y');
                    $subscribed = $handShake->where('date',$monthDate)->where('status','subscribed')->first();
                    $upgrade = $handShake->where('date',$monthDate)->where('status','upgrade')->first();
                    $cancelled = $handShake->where('date',$monthDate)->where('status','cancelled')->first();
                    $chartData[$i]['subscribed'] = [
                        'total' =>  ($subscribed != null? $subscribed->total_count:0) + ($upgrade != null? $upgrade->total_count:0),
                        'date' => $monthDate
                    ];
                    $chartData[$i]['cancelled'] = [
                        'total' =>  ($cancelled != null? $cancelled->total_count:0) ,
                        'date' => $monthDate
                    ];

                }

            }else{
                /**
                 *  get all subscribers users of normal subscriber
                */

                $subscribers = DB::table('vet_care_package_usages')
                ->join('vet_care_users','vet_care_package_usages.user_id','vet_care_users.id')
                ->selectRaw('COUNT(*) AS total_count, DATE_FORMAT(vet_care_package_usages.created_at,"%m-%Y") AS date')
                ->whereNull('vet_care_package_usages.deleted_at')
                ->where('vet_care_users.app_id',$app->id);

                   /* count total subscribed by app_id  */
                $totalSubscribed =  $subscribers->first();
                $totalSubscribed =  ($totalSubscribed != null)?$totalSubscribed->total_count:0;


                $subscribers = $subscribers->whereYear('vet_care_package_usages.created_at',">=",$minusMonthsDate->year)
                ->whereMonth('vet_care_package_usages.created_at','>=',1)
                ->groupBy('date')
                ->get();

                /**
                 * get all cancellers users of normal subscriber
                */


                 $cancellers = DB::table('vet_care_package_usages')
                ->join('vet_care_users','vet_care_package_usages.user_id','vet_care_users.id')
                ->where('vet_care_users.app_id',$app->id)
                ->selectRaw('COUNT(*) AS total_count, DATE_FORMAT(vet_care_package_usages.deleted_at,"%m-%Y") AS date');
                /* count total cancelled by app_id  */
                $totalCancelled=  $cancellers->first();
                $totalCancelled =  ($totalCancelled != null)?$totalCancelled->total_count:0;

                 $cancellers = $cancellers->whereNotNull('vet_care_package_usages.deleted_at')
                ->whereYear('vet_care_package_usages.deleted_at',">=",$minusMonthsDate->year)
                ->whereMonth('vet_care_package_usages.deleted_at','>=',1)
                ->groupBy('date')
                ->get();



                /**
                 * formatting chart data for last twelve
                  */
                $chartData = [];
                for($i=1;$i<=12;$i++)
                {
                    $monthDate = $minusMonthsDate->addMonth(1);

                    $monthDate = $minusMonthsDate->format('m-Y');
                    $subscribed = $subscribers->where('date',$monthDate)->first();
                    $cancelled = $cancellers->where('date',$monthDate)->first();

                    $chartData[$i]['subscribed'] = [
                        'total' =>  ($subscribed != null? $subscribed->total_count:0),
                        'date' => $monthDate
                    ];
                    $chartData[$i]['cancelled'] = [
                        'total' =>  ($cancelled != null? $cancelled->total_count:0),
                        'date' => $monthDate
                    ];

                }

            }
            // Users
            $users = VetCareUser::where('app_id',$app->id);


            // Total Users
            $res['total_users'] = $users->count();

            // Recently Joined Users
            $users = $users->latest()->limit($limit)->get();
            $res['recent_joined_users'] = $users;

            // User Payments
            $userPayments = VetCareUserPayment::with('user')->whereHas('user' , function($q) use($app){
                $q->where('app_id',$app->id);
            });

            // Recent Payments
            $res['recent_payments'] = $userPayments->latest()->limit($limit)->get();


            $res['totalSubscribed'] = $totalSubscribed;
            $res['totalCancelled'] = $totalCancelled;
            $res['chartData'] = $chartData;

            return $this->successResponse($res, 'Dashboard Data.');

        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    public function guard()
    {
        return Auth::guard('clinic');
    }

}
