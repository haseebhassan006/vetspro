<?php

namespace App\Http\Controllers\Client;

use App\VetCareCoupon;
use App\VetCarePackage;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\CouponRequest;
use App\Traits\CouponGenerateTrait;
use Carbon\Carbon;

class ClinicCouponController extends Controller
{
    use CouponGenerateTrait;

    private $noOfRecordPerPage = 10;

    private $paginate = false;
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $input = $request->only('search_value');
        $value = isset($input['search_value'])?$input['search_value']:'';
        $user = auth()->user();
        $app = $this->findAppByName($user->app);
        try{

            $model = VetCareCoupon::whereHas('vetCarePackage',function($q) use($app){
                $q->where('vet_care_id',$app->id);
            })->withCount('vetCareCouponCodes')->with('vetCarePackage:id,name');

            $model->when($request->has('package_id') , function($q) use($request){
                    $q->where('package_id',$request->package_id);
            });
            $model->when($value, function($q) use($value){
                 $q->whereRaw(" (other) like '%$value%'");
            });
            $this->paginate = true;
            $data = $model->orderBy('id','desc')->paginate($this->noOfRecordPerPage);
            return $this->successResponse($data, 'list', $this->paginate);

        }
        catch (Exception $e){
            return $this->errorResponse('List error');
        }
    }

    /**
     * Store a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function store(CouponRequest $request)
    {
        $validate = $request->validated();
        $user = auth()->user();
        $app = $this->findAppByName($user->app);
        try{
            $chk_vet_pakcage =vetCarePackage::where(['id'=>$request->package_id,'vet_care_id'=>$app->id])->first();
            if(empty($chk_vet_pakcage)){
                return $this->errorResponse('Wrong pakage id please use correct package id',403);
            }
            $model =VetCareCoupon::whereHas('vetCareCouponCodes',function($q) use($request){
                $q->where('code',$request->code);
            })->first();
            if(!$model){
                $package_id = $validate['package_id'];
                if( $validate['has_expiry']==false ){

                    $validate['expiry']="null";
                    $validate['access_days']=0;
                }
                unset($validate['package_id'],$validate['code']);
                $validate['enable_pet_tracking'] = isset($validate['enable_pet_tracking']) ? $validate['enable_pet_tracking'] : 0;
                $data = ['other'=>$validate,'package_id'=>$package_id];
                $data['created_by'] = $user->id;
                $data['created_model'] = get_class($user);
                $data = $user->vetCareCoupon()->create($data);
                 $data->vetCareCouponCodes()->create(['code' => $request->code]);
                 $data->load('vetCareCouponCodes');
                return $this->successResponse($data, 'coupon added');
            }
            else{
                return $this->errorResponse('Coupon with same code already exists',403);
            }
        }
        catch (QueryException $e){
            return $this->errorResponse($e->getMessage(),404);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\VetCareCoupon  $vetCareCoupon
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $user = auth()->user();
        $app = $this->findAppByName($user->app);
        // $vetCareCoupon = VetCareCoupon::where()->findOrFail($id);
        $vetCareCoupon = VetCareCoupon::whereHas('vetCarePackage',function($q) use($app){
            $q->where('vet_care_id',$app->id);
        })->findOrFail($id);
        $vetCareCoupon->load(['vetCareCouponCodes'=>function($q){
            $q->withCount(['vetCareCouponUsages','vetCarePackageUsages'])->orderBy('id','desc');
         }]);
         return $this->successResponse($vetCareCoupon, 'show coupon');
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\VetCareCoupon  $vetCareCoupon
     * @return \Illuminate\Http\Response
     */
    public function update($id,CouponRequest $request)
    {
        $user = auth()->user();
        $app = $this->findAppByName($user->app);
        $validatedData = $request->validated();
        try {
            $package_id = $validatedData['package_id'];
            $chk_vet_pakcage =vetCarePackage::where(['id'=>$request->package_id,'vet_care_id'=>$app->id])->first();

            if(empty($chk_vet_pakcage)){
                return $this->errorResponse('Wrong pakage id ,please use correct package id',403);
            }
            unset($validatedData['package_id'],$validatedData['code']);
            if( $validatedData['has_expiry']==false ){

                $validatedData['expiry']="null";
                $validatedData['access_days']=0;
            }
            // $model =  $user->vetCareCoupon()->findOrFail($id);
            $model =  VetCareCoupon::findOrFail($id);
            if($model->vetCareCouponCodes()->has('vetCareCouponUsages')->count() ||
            $model->vetCareCouponCodes()->has('vetCarePackageUsages')->count()
            ){
                return $this->errorResponse("Coupon codes are in used, unable to update",403);
            }
            $model_enable_pet_tracking=isset($model->other['enable_pet_tracking'])?$model->other['enable_pet_tracking']:0;
            $validatedData['enable_pet_tracking'] = isset($validatedData['enable_pet_tracking']) ? $validatedData['enable_pet_tracking'] : $model_enable_pet_tracking;
            $model->package_id  = $package_id;
            $model->other = $validatedData;
            $model->updated_by = $user->id;
            $model->updated_model = get_class($user);
            $model->save();

            // this codition ensure to update those coupon code which has only one coupon code.
            // if($request->has('code') && $model->vetCareCouponCodes()->withTrashed()->count() == 1)
            // {
            //     $model->vetCareCouponCodes()->update(['code'=>$request->code]);

            // }
            $model->load('vetCareCouponCodes');
            return $this->successResponse($model, 'Successfully Record Updated.');
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

     /**
     * Remove the specified resource from storage.
     *
     * @param  \App\VetCareCoupon  $vetCareCoupon
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $user = auth()->user();
        $app = $this->findAppByName($user->app);
        try {
            $vetCareCoupon = VetCareCoupon::whereHas('vetCarePackage',function($q) use($app){
                $q->where('vet_care_id',$app->id);
            })->findOrFail($id);
            // $vetCareCoupon = $user->vetCareCoupon()->findOrFail($id);
            if( $vetCareCoupon && ($vetCareCoupon->vetCareCouponCodes()->has('vetCareCouponUsages')->count()
            || $vetCareCoupon->vetCareCouponCodes()->has('vetCarePackageUsages')->count()) )
            {
                return $this->errorResponse("Coupon codes are in used, unable to delete",403);
            }
            $vetCareCoupon->deleted_by =  $user->id;
            $vetCareCoupon->deleted_model = get_class($user);
            $vetCareCoupon->vetCareCouponCodes()->delete();
            $vetCareCoupon->deleted_at = Carbon::now();
            $vetCareCoupon->save();

            return $this->successResponse($vetCareCoupon, 'Successfully Deleted.');
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    public function multiCoupon(Request $request)
    {
        $data = $request->validate([
            "name" => "required|string",
            "expiry" => "required",
            "access_days" => "sometimes",
            "percent_off" => "sometimes",
            "price_off" => "sometimes",
            "one_time" => "sometimes",
            "package_id" => "required|exists:vet_care_packages,id",
            "coupon_count" => "required|numeric"
        ]);

        $user = auth()->user();
        $only = $request->only('name','expiry','access_days','off_type','price_off','one_time','enable_pet_tracking','has_expiry');
        $only['enable_pet_tracking'] = isset($only['enable_pet_tracking']) ? $only['enable_pet_tracking'] : 0;

        if( $only['has_expiry']==false ){
            $only['expiry']="null";
            $only['access_days']=0;
        }
        $data = [
            'package_id' => $request->package_id,
            'other' => $only
        ];
        $model = null;
        try{

            $model = $user->vetCareCoupon()->create($data);

            for($i=0; $i<$request->coupon_count;$i++)
            {
                $model->vetCareCouponCodes()->create(['code'=>$this->generateCoupon()]);
            }
            $model->load('vetCareCouponCodes');

        } catch (\Exception $e) {

            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
        return $this->successResponse($model, 'coupon added');
    }


}
