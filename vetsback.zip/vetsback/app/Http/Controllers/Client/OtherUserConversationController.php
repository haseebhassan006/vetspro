<?php

namespace App\Http\Controllers\Client;
use App\Vet;
use App\Chat;
use App\ChatDetail;
use App\ChatEndedBy;
use App\FailedHandshake;
use App\Http\Requests\ChatRequest;
use App\Http\Requests\TwilioApiRequest;
use App\ExtraPet;
use App\Http\Requests\UserStatusRequest;
use App\Http\Resources\UserSubscriptionStatusResource;
use App\Mail\InformClientErrorEmail;
use App\Mail\MailMeProtectUserInfo;
use App\UserAppStatus;
use App\WebappUser;
use App\WebAppUsersExtra;
use Carbon\Carbon;
use http\Exception\BadMessageException;
use Illuminate\Database\QueryException;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Http\Response;
use Illuminate\Log\LogManager;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;
use Mockery\Exception\BadMethodCallException;
use Monolog\Logger;
use Symfony\Component\HttpKernel\Exception\HttpException;
use Twilio\Exceptions\TwilioException;

class OtherUserConversationController extends TwilioApiController
{
    /*
     * This api is for handshake request for all webapp users
     *
     */
    public function handshake(TwilioApiRequest $request)
    {
        $validated = $request->validated();
        $app = $this->find_app($request->api_key);
        if(!isset($app) && empty($app)){
            $path_uri = $request->path();
            switch ($path_uri){
                case str_contains($path_uri,'vidaah');
                    $app = 'vidaah';
                    break;
                case str_contains($path_uri,'onepet');
                    $app = 'onepet';
                    break;

            }
            $this->statusErrorCodes(500,$app,'Invalid Api Key');
            return $this->errorResponse('Invalid Api Key', 500);
        }
        $conversation_request = $request->conversation_request;
        try{
            if($conversation_request == 'chat'){ $vet_id = $this->checkVetChat();}
            elseif($conversation_request == 'video'){ $vet_id = $this->checkVetVideo();}
            if($vet_id == false){
                FailedHandshake::create([
                    'request'=> $request->all(),
                    'response'=>['message'=>'Vets are busy at the moment. Try again later','code'=>406],
                    'app_id'=>$app->id
                ]);
                //Log::error('Vets are busy at the moment. Try again later');
                //\logger('Vets are busy at the moment. Try again later');
                return $this->errorResponse('Vets are busy at the moment. Try again later', 406);
            }
            $channel = isset($request->channel_sid) ? $request->channel_sid : '';
            $room = isset($request->room_sid) ? $request->room_sid : '';
            $type = isset($request->type) ? $request->type : '';
            $status = isset($request->status) ? $request->status : '';
            $oldVetId = isset($request->vet_id)?$request->vet_id:null;
            $is_protect = isset($request->is_protect)?$request->is_protect:'users';
            $dev_type = $request->dev_type;
            $validated['app_id'] = $app->id;
            $pet = $validated['pet'];

            unset($validated['api_key']);
            unset($validated['pet']);
            unset($validated['conversation_request']);
            unset($validated['is_protect']);
            if(!empty($channel)){ unset($validated['channel_sid']); }
            if(!empty($room)){ unset($validated['room_sid']); }
            if(!empty($type)){ unset($validated['type']); }
            if(!empty($status)){ unset($validated['status']); }
            if(!empty($old_vet_id)){ unset($validated['vet_id']); }

            //Step 1 : Create User
            $user = WebappUser::updateOrCreate(['email'=>$request->email],$validated);
            $extra_data = WebAppUsersExtra::create(['type'=>$conversation_request,'protected'=>$is_protect,'user_id'=>$user->id]);
            //Step 2 : Create Pet
            $pet_info = ExtraPet::updateOrCreate(['user_id'=>$user->id,'name'=>$pet['name']],[
                'sex'=>$pet['sex'],'breed'=>$pet['breed'],'weight'=>$pet['weight'],'age'=>$pet['age'],
                'color'=>$pet['color'],'species'=>$pet['species'],'app_id'=>$app->id
            ]);

            //Call the parent method create
            $protect_client = [$is_protect];
            try {
                $res = parent::create($conversation_request, $user, $pet_info, $protect_client, $app, $oldVetId, $room,$vet_id);

                if ($conversation_request == 'chat') {
                    parent::channelUserCreation($res['friendlyName'], $res['userObject'],
                        $res['vetObject'], $pet_info, $app->name, $protect_client);

                    //Update vet information in webapp extra table
                    WebAppUsersExtra::where(['type' => $conversation_request, 'protected' => $is_protect, 'user_id' => $user->id])->update(['vet_id' => $res['vetObject']['vet_id']]);

                    $response['channel'] = parent::fetchMyChannel($res['friendlyName']);

                    //$response['vet'] = $res['vetObject']['vet_id'];
                    $member_vet = 'app-1_vet-' . $res['vetObject']['vet_id'];
                   // $response['vet'] = $member_vet;
                    $response['vet']['id'] = $member_vet;
                    $response['vet']['username'] = $res['vetObject']['vet_name'];
                    //Update user twilio sid
                    $user_sid = parent::fetchUserSid('app-' . $app->id . '_user-' . $user->id);
                    WebappUser::where('email', $request->email)->update(['twilio_user_sid' => $user_sid->sid]);

                } else {
                    $response['room_sid'] = $res;
                }
                $identity = 'app-' . $app->id . '_user-' . $user->id;
                $response['identity'] = $identity;
                $response['twilioToken'] = parent::myToken($identity, $dev_type, $app->id);

                return $this->successResponse($response, 'User handshake successful');
            }
            catch (QueryException | \Exception $e){
                $code = $e->getCode();
                if($code == 0){
                    $code = 500;
                }
                $this->statusErrorCodes($code,$app->name,$e->getMessage());
                return $this->errorResponse($e->getMessage(), $code);
            }
        }
        catch (QueryException | \Exception $e){
            $code = $e->getCode();
            if($code == 0){
                $code = 500;
            }
            $this->statusErrorCodes($code,$app->name,'Invalid Request');
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }

    }
    /*
     * Twilio Chat refresh token
     */
    public function refresh(Request $request){
        $identity = $request->identity;
        $dev_type = $request->dev_type;
        $app = $this->find_app($request->api_key);
        //$token = $request->token;
        $response['twilioToken'] = parent::myToken($identity, $dev_type, $app->id);
        return $this->successResponse($response, 'User token');
    }
    /*
     * When user wants to end chat from thier side
     */
    public function endCoversationByUser(Request $request){
        try {
            $channelSid = $request->channel_sid;

            if($request->has('channel_sid') && $request->channel_sid != ""){
                $vet = Chat::where('channel_sid',$channelSid)->first();
                if(!$vet){
                    return $this->errorResponse('Channel not found.',404);
                }
            }

            $vet = Chat::where('channel_sid',$channelSid)->first();
            if($vet->vet_id){
                $vetStatusupdate = Vet::find($vet->vet_id);
                if(!empty($vetStatusupdate) && $vetStatusupdate->is_chat >= 1){
                    $vetStatusupdate->is_chat = $vetStatusupdate->is_chat - 1;
                    $vetStatusupdate->update();
                }
                ChatEndedBy::create(['chat_id'=>$vet->id,'ended_by'=>'user']);
                $this->chatEndByUser($channelSid,$vet->vet_id);
            }
            return $this->successResponse(true, 'End chat successful');
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }
    /*
     * When user wants to end chat from thier side
     */
    public function endCoversationByUserTestCase(Request $request){
        try {
            $channelSid = $request->channel_sid;
            $vet = Chat::where('channel_sid',$channelSid)->first();
            if($vet->vet_id){
                $this->chatEndByUserTestCase($channelSid,$vet->vet_id);
            }
            return $this->successResponse(true, 'End chat successful');
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    public function channelWebhooks(Request $request){
        try{

            //dd($request->all());
            //$response = $this->postChannelWebhooks($request->channel_sid);
//            $header = ['Content-Type'=> 'application/json'];
//            $url = 'https://api.dogtastic.co/';
//            $uri = 'api/vpm-hooks';
//            $params = array(
//                'channel_sid'=>$channel_sid,
//            );
//            $this->httpRequestWithJson($url,$uri,$request->all(),$username,$password,$header);
            //return $this->successResponse(, 'Webhooks');

        }
        catch (TwilioException $exception){
            throw new \Exception($exception->getMessage());
        }
    }
    /*
     * Inform the clients about the failure during handshake
     * via email
     */
    public function statusErrorCodes($code,$app,$body){
        $date = Carbon::now()->toDateTimeString();
        $app = strtolower($app);
        $emails = array();
        array_push($emails,'ali.raza@invisionsolutions.ca');
        switch ($code){
            case 401:
            case 500:
                switch ($app){
                    case 'vidaah':
                    array_push($emails,'juan_moreno@juansolutions.com');
//                    case 'petacumen':
//                        case 'onepet':
//                    case 'vetsplsumore':
                    Mail::to($emails)->send(new InformClientErrorEmail($date,$app,$body,$code));
                    break;
                }
                break;
        }
    }
    /*
     * Used for user actions such as when user registers
     * when user cancels from clients app
     */
    public function userActions(UserStatusRequest $request){
        $validated = $request->validated();
        try{
            $app = $this->find_app($request->api_key);
            $validated['app_id'] = $app->id;
            $email = $request->email;
            $status = $request->status;
            $date_time = $request->date_time;
            $type = isset($request->type)?$request->type:"monthly";
            if($request->status == 'subscribed'){
                $find_user = WebappUser::updateOrCreate(
                    ['app_id' => $app->id, 'email' => $email],
                    $validated
                );
                //$find_user = WebappUser::create($validated);
            }
            else{
                $find_user = WebappUser::where('email',$email)->first();
            }
            //User Status History
            if($find_user){
                $array = [
                    'user_id'=>$find_user->id,
                    'status'=>$status,
                    'app_id'=>$app->id,
                    'date_time'=>$date_time,
                    'type'=>$type
                ];
                $temp = UserAppStatus::create($array);
//                $data = WebappUser::select('id','email','your_registration_date','app_id')->with(['user_status'=>function ($q){
//                    $q->latest();
//                }])->where('email',$email)->latest()->take(1)->get();
                //$data = WebappUser::select('id','email','your_registration_date','app_id')->where('email',$email)->latest()->take(1)->get();
                $data['email'] = $find_user->email;
                $data['registration'] = $find_user->your_registration_date;
                $data['status'] = $temp->status;
                return $this->successResponse($data,'User action successful');
            }
            else{
                return $this->errorResponse('You need to subscribe first,before cancellation',401);
            }
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(),$e->getCode());
        }
    }
    /*
     * This api is for handshake request for all webapp users
     *
     */
    public function testcases()
    {
        $a=rand(1, 3);
        //$a++;
        $email = "joeytest".$a."@onepet.com";
        $data = [
            "first_name" => "joey",
            "last_name" => "test",
            "email" => $email,
            "conversation_request" => "chat",
            "pet" => [
                "name" => "kitty",
                "sex" => "female",
                "breed" => "british",
                "weight" => "",
                "age" => "",
                "color" => "white",
                "species" => "Cat"
            ],
            "api_key" => "HjM2G1RdYWHeeRQx",
            "is_protect" => "users",
            "your_registration_date" => "2021-02-11 14:00:00",
            "dev_type" => "web"
        ];
        $validated = $data;
        $app = $this->find_app($validated['api_key']);
//        if(!isset($app) && empty($app)){
//            $path_uri = $request->path();
//            switch ($path_uri){
//                case str_contains($path_uri,'vidaah');
//                    $app = 'vidaah';
//                    break;
//                case str_contains($path_uri,'onepet');
//                    $app = 'onepet';
//                    break;
//
//            }
//            $this->statusErrorCodes(500,$app,'Invalid Api Key');
//            return $this->errorResponse('Invalid Api Key', 500);
//        }
        $conversation_request = $validated['conversation_request'];
        try{
            if($conversation_request == 'chat'){ $vet_id = $this->checkVetChat();}
            elseif($conversation_request == 'video'){ $vet_id = $this->checkVetVideo();}
            if($vet_id == false){
//                FailedHandshake::create([
//                    'request'=> $request->all(),
//                    'response'=>['message'=>'Vets are busy at the moment. Try again later','code'=>406],
//                    'app_id'=>$app->id
//                ]);
                //Log::error('Vets are busy at the moment. Try again later');
                //\logger('Vets are busy at the moment. Try again later');
                return $this->errorResponse('Vets are busy at the moment. Try again later', 406);
            }
            $channel = isset($validated['channel_sid']) ? $validated['channel_sid'] : '';
            $room = isset($validated['room_sid']) ?$validated['room_sid'] : '';
            $type = isset($validated['type']) ? $validated['type'] : '';
            $status = isset($validated['status']) ? $validated['status'] : '';
            $oldVetId = isset($validated['vet_id'])?$validated['vet_id']:null;
            $is_protect = isset($validated['is_protect'])?$validated['is_protect']:'users';
            $dev_type = $validated['dev_type'];
            $validated['app_id'] = $app->id;
            $pet = $validated['pet'];

            unset($validated['api_key']);
            unset($validated['pet']);
            unset($validated['conversation_request']);
            unset($validated['is_protect']);
            if(!empty($channel)){ unset($validated['channel_sid']); }
            if(!empty($room)){ unset($validated['room_sid']); }
            if(!empty($type)){ unset($validated['type']); }
            if(!empty($status)){ unset($validated['status']); }
            if(!empty($old_vet_id)){ unset($validated['vet_id']); }

            //Step 1 : Create User
            $user = WebappUser::updateOrCreate(['email'=>$email],$validated);
            $extra_data = WebAppUsersExtra::create(['type'=>$conversation_request,'protected'=>$is_protect,'user_id'=>$user->id]);
            //Step 2 : Create Pet
            $pet_info = ExtraPet::updateOrCreate(['user_id'=>$user->id,'name'=>$pet['name']],[
                'sex'=>$pet['sex'],'breed'=>$pet['breed'],'weight'=>$pet['weight'],'age'=>$pet['age'],
                'color'=>$pet['color'],'species'=>$pet['species'],'app_id'=>$app->id
            ]);

            //Call the parent method create
            $protect_client = [$is_protect];
            try {
                $res = parent::create($conversation_request, $user, $pet_info, $protect_client, $app, $oldVetId, $room,$vet_id);

                if ($conversation_request == 'chat') {
                    parent::channelUserCreation($res['friendlyName'], $res['userObject'],
                        $res['vetObject'], $pet_info, $app->name, $protect_client);

                    //Update vet information in webapp extra table
                    WebAppUsersExtra::where(['type' => $conversation_request, 'protected' => $is_protect, 'user_id' => $user->id])->update(['vet_id' => $res['vetObject']['vet_id']]);

                    $response['channel'] = parent::fetchMyChannel($res['friendlyName']);

                    //$response['vet'] = $res['vetObject']['vet_id'];
                    $member_vet = 'app-1_vet-' . $res['vetObject']['vet_id'];
                    // $response['vet'] = $member_vet;
                    $response['vet']['id'] = $member_vet;
                    $response['vet']['username'] = $res['vetObject']['vet_name'];
                    //Update user twilio sid
                    $user_sid = parent::fetchUserSid('app-' . $app->id . '_user-' . $user->id);
                    WebappUser::where('email', $email)->update(['twilio_user_sid' => $user_sid->sid]);

                } else {
                    $response['room_sid'] = $res;
                }
                $identity = 'app-' . $app->id . '_user-' . $user->id;
                $response['identity'] = $identity;
                $response['twilioToken'] = parent::myToken($identity, $dev_type, $app->id);

                return $this->successResponse($response, 'User handshake successful');
            }
            catch (QueryException | \Exception $e){
                $code = $e->getCode();
                if($code == 0){
                    $code = 500;
                }
                $this->statusErrorCodes($code,$app->name,$e->getMessage());
                return $this->errorResponse($e->getMessage(), $code);
            }
        }
        catch (QueryException | \Exception $e){
            $code = $e->getCode();
            if($code == 0){
                $code = 500;
            }
            //$this->statusErrorCodes($code,$app->name,$request->all());
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }

    }

}
