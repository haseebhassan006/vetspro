<?php


namespace App\Http\Controllers\Client;

use App\User;
use App\Coupon;
use App\Package;
use App\Payment;
use App\VetCare;
use App\Zipcode;
use Carbon\Carbon;
use App\AppSetting;
use App\VetCarePet;
use App\WebappUser;
use App\VetCareUser;
use App\UtmAttribute;
use App\Subscriptions;
use App\UserAppStatus;
use App\VetCareCoupon;
use Illuminate\Database\Eloquent\Model;
use Mockery\Exception;
use App\VetCarePackage;
use App\VetCareCouponUsage;
use App\VetCareUserPayment;
use App\BouncingVetCareUser;
use App\Mail\ContactSupport;
use App\VetCarePackageUsage;
use App\VetCareSubscription;
use Illuminate\Http\Request;
use App\Traits\TwilioSDKTrait;
use App\Http\Requests\UserRequest;
use App\VetCarePaymentProtectUser;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\URL;
use Stripe\Exception\CardException;
use App\Http\Controllers\Controller;
use Illuminate\Contracts\Auth\Guard;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail;
use Twilio\Exceptions\TwilioException;
use App\Traits\VetCareUserPaymentTrait;
use Illuminate\Database\QueryException;
use Stripe\Exception\ApiErrorException;
use App\Http\Requests\StripeCardRequest;
use App\Http\Requests\UserStatusRequest;
use App\Http\Requests\UserContactSupport;
use Illuminate\Support\Facades\Validator;
use Stripe\Exception\BadMethodCallException;
use Stripe\Exception\UnexpectedValueException;
use Stripe\Exception\UnknownApiErrorException;
use App\Http\Requests\VetCareUserSignUpRequest;
use App\Http\Requests\VetCareRegisterUserRequest;
use App\VetCareCouponCode;
use Illuminate\Database\Eloquent\ModelNotFoundException;

class UserAuthController extends Controller
{
    use TwilioSDKTrait;
    use VetCareUserPaymentTrait;

    public function __construct()
    {
        $this->generic();
    }
    /**
     * login API
     *
     * @param Request $request
     * @return \Illuminate\Http\Response
     */
    public function login(Request $request)
    {
        $input = $request->all();
        $validator = Validator::make($input, [
            'email' => 'required|email',
            'password' => 'required',
            'dev_type' => 'required',
            'app_version' => 'required',
        ]);
        if ($validator->fails()) {
            return $this->errorResponse($validator->errors()->all());
        }
        $credentials = $request->only(['email', 'password']);
        try {
            $check_user_app_info = $this->find_app($request->api_key);
            $check_if_user_is_a_app_user = VetCareUser::where('app_id', $check_user_app_info->id)->get();
            if ($check_if_user_is_a_app_user) {

                if ($token = $this->guard()->attempt(['email' => $request->email, 'password' => $request->password, 'app_id' => $check_user_app_info->id])) {

                    $user = $this->guard()->user();
                    if (!$user->hasAnyRole('users', 'protect_users')) {
                        return $this->errorResponse('UnAuthorized. Please contact admin', 401);
                    }

                    if ($token = $this->guard()->attempt($credentials)) {

                        $app_id = $this->find_app($input['api_key']);
                        //Update or create new device
                        $user->devices()->delete();
                        $user->devices()->updateOrCreate(['device_token' => $request->device_token], [
                            'rec_id' => $user->id,
                            'device_token' => $request->device_token,
                            'udid' => $request->udid,
                            'dev_type' => $request->dev_type,
                            'app_version' => $request->app_version
                        ]);
                        //update appid on twilio user resource if new appid
                        if ($app_id->id != $user->app_id) {
                            $identity = 'app-' . $app_id->id . '_user-' . $user->id;
                            $identity = is_local_env() ? 'local-' . $identity : $identity;
                            $this->fetchAndUpdateUser($app_id->id, $identity);
                        }
                        $this->initialize($app_id);

                        $dashboard['paymentIntent'] = '';
                        $dashboard['subscription'] = '';
                        if($user->card_id){
                            $dashboard['paymentIntent'] = $this->getPaymentIntent($user->card_id);
                            $dashboard['subscription'] = VetCareSubscription::where('user_id',$user->id)->get();
                        }


                        $success['token'] = $token;
                        $success['twilioToken'] = $this->init(is_local_env() ? 'local-' . 'app-' . $app_id->id . '_user-' . $user->id : 'app-' . $app_id->id . '_user-' . $user->id , $request->dev_type, $app_id->id);

                        $success['user'] = $user->load(['devices', 'userDetails', 'usage', 'latestPayment', 'defaultPet','packageUsageDetail']);
                        $success['dashboard'] = $dashboard;
                        $isPawpUser = false;
                        $checkingUserIsPawp = WebappUser::where(['email'=>$input['email'],'app_id'=>4])->get();
                        if(!$checkingUserIsPawp->isEmpty()){
                            $user->assignRole("protect_users");
                            $isPawpUser = true;
                        }
                        $success['isPawpUser'] = $isPawpUser;

                        $success['stringify_response'] = json_encode($success);

                        $dateTime = Carbon::now();
                        $user->userAuthenticationHistory()->create([
                            'dateTime' => $dateTime,
                            'type' => 'login',
                        ]);
                        return $this->successResponse($success, 'logged in');
                    }
                }
                else {
                    return $this->errorResponse('Wrong credentials');
                }
            }
        }
        catch (ApiErrorException $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
        catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }
    /**
     * register API
     *
     * @param UserRequest $request
     * @return \Illuminate\Http\Response
     */
    public function create(VetCareUserSignUpRequest $request)
    {
        $validatedData = $request->validated();
        $vetCareCouponCodeId = 0;
        $isPawpUser = false;
        try {
            DB::beginTransaction();
            $app = $this->find_app($validatedData['api_key']);
            $appSettings = AppSetting::where('app_id',$app->id)->first();
            $validatedData['app_id'] = $app->id;
            $pet_tracking_code=isset($validatedData['pet_tracking_code']) && !empty($validatedData['pet_tracking_code'])?$validatedData['pet_tracking_code'] : NULL;
            unset($validatedData['pet_tracking_code']);
            //For specific cases only
            if($request->has('no_payment')){
                $validatedData['password'] = bcrypt('externalUsers#');
                $user = VetCareUser::updateOrCreate(['email'=>$request->email],$validatedData);
                $identity = 'app-' . $app->id . '_user-' . $user->id;
                $identity = is_local_env() ? 'local-' . $identity : $identity;
            }
            else{

                // Check if Package subscription is active
                if($request->has('package_id') && $this->isSubscriptionPriceActive($validatedData['package_id']) == false){
                    return $this->errorResponse('Package is not active. Please Subscribe to another package',406);
                }

                // If vetcare user - not handshake
                $validator = Validator::make($validatedData, [
                    'email' => 'unique:vet_care_users,email,NULL,id,deleted_at,NULL',
                ]);
                if ($validator->fails()) {
                    return $this->errorResponse($validator->errors()->all());
                }
                if (array_key_exists('password', $validatedData)) {
                    $pwd = $validatedData['password'];
                    $validatedData['password'] = bcrypt($validatedData['password']);
                }
                //Creates a user
                $user = VetCareUser::create($validatedData);

                //Add user to twilio account as well
                $attributes = ["app_id" => $app->id, "user_id" => $user->id, "email" => $request->email];
                $identity = 'app-' . $app->id . '_user-' . $user->id;
                $identity = is_local_env() ? 'local-' . $identity : $identity;
                $dataToTwilio = [
                    'attributes' => json_encode($attributes),
                    'friendlyName' => $request->first_name . ' ' . $request->last_name,
                    'identity' => $identity
                ];


                $createUser = $this->createUser($dataToTwilio);
            }

            $other = array();

            // Storing other user details
            if($request->has('other') && !empty($request->other)){
                $other = $request->other;
            }

            //Add User Detail
            if(@$validatedData['zip_code']){
                $other['zip_code'] = $validatedData['zip_code'];

            }
            if(@$validatedData['phone_no']){
                $other['phone_no'] = $validatedData['phone_no'];
            }

            if (count($other) > 0) {
                $user_details = ['user_id' => $user->id, 'other' => $other];
                $user->userDetails()->create($user_details);
            }

            //Add Pet Data
            $validatedData['user_id'] = $user->id;
            $pet = $user->pets()->create($validatedData);
            unset($validatedData['user_id']);

            //Attach Default Pet to User
            if($pet){
                $defaultPet = $user->defaultPet()->sync($pet);
            }

            //Coupon by default or user entered
            if($request->has('code') && $request->code != ''){

                $coupon = VetCareCoupon::with('vetCareCouponCodes')->where('package_id',$request->package_id)->whereHas('vetCareCouponCodes',function($q) use($request){
                    $q->where('code', $request->code);
                })->first();

                if($coupon && $coupon->other['enable_pet_tracking']==1){
                    $user->pet_tracking_code = $pet_tracking_code;
                    $user->save;
                }

                if($coupon && $coupon->vetCareCouponCodes){
                    $vetCareCouponCode = $coupon->vetCareCouponCodes->where('code',$request->code)->first();
                    $vetCareCouponCodeId = $vetCareCouponCode->id;
                }

            }

            //We check if the payment is true or not from middleware
            if(!$request->has('no_payment')){
                //Add Payment Data
                //Now we initialze the stripe configuration
                $this->initialize($app->id);

                $package = VetCarePackage::find($validatedData['package_id']);
                // Skip if package type = non-credit
                if($package->type != "non-credit"){
                    $this->addCard($validatedData,$user);
                }

                $this->buyPackage($validatedData['package_id'],$user,$vetCareCouponCodeId,$validatedData['price']);
                if($request->has('is_addOn')){
                    $this->buyPackage($validatedData['addOn_package_id'],$user,$vetCareCouponCodeId,$validatedData['addOn_price']);
                }

                //Check if package is protect or non protect
                //Check if a user is pawp user
                $checkingUserIsPawp = WebappUser::where(['email'=>$validatedData['email'],'app_id'=>4])->get();

                if(!$checkingUserIsPawp->isEmpty()){
                    $user->assignRole("protect_users");
                    $isPawpUser = true;
                }
                else{
                    if($this->ifVcPackageProtected($validatedData['package_id'])){
                        $user->assignRole("protect_users");
                    }elseif($request->has('no_payment') || (isset($appSettings->is_payment_required) && $appSettings->is_payment_required  == 'false')){
                        $user->assignRole("protect_users");
                    }else{
                        $user->assignRole("users");
                    }
                }
            }

            if($request->has('no_payment')){
                $user->assignRole("protect_users");
            }

            $user->devices()->updateOrCreate([
                'dev_type' => $request->dev_type], [
                'device_token' => $request->device_token,
                'rec_id' => $user->id,
                'udid' => $request->udid,
                'app_version' => $request->app_version
            ]);


            $dashboard['paymentIntent'] = '';
            $dashboard['subscription'] = '';
            if(@$user->card_id){
                $dashboard['paymentIntent'] = $this->getPaymentIntent($user->card_id);
                $dashboard['subscription'] = VetCareSubscription::where('user_id',$user->id)->get();
            }



            $success['token'] = auth()->login($user);
            $success['twilioToken'] = $this->init($identity, $request->dev_type, $request->app_id);
            //$success['user'] = $user->getUserDetails($user->id);
            $success['user'] = $user->load(['devices', 'userDetails', 'usage.couponCode', 'latestPayment','defaultPet','packageUsageDetail']);
            $success['dashboard'] = $dashboard;
            $success['isPawpUser'] = $isPawpUser;

            $success['stringify_response'] = json_encode($success);

            // Delete Record from bouncing user
            $this->deleteVetCareBouncingUser($user->email,$user->app_id);

             DB::commit();

            return $this->successResponse($success, 'signed up');

        } catch (TwilioException $e) {
            DB::rollBack();
            return $this->errorResponse($e->getMessage(), $e->getCode());
        } catch (ApiErrorException $e) {
            DB::rollBack();
            return $this->errorResponse($e->getMessage(), $e->getCode());
        } catch (BadMethodCallException $e) {
            DB::rollBack();
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }catch (UnexpectedValueException $e){
           DB::rollBack();
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }


    }

    /**
     * register API For Handshake App
     * Version 2.0
     *
     * @param UserRequest $request
     * @return \Illuminate\Http\Response
     */
    public function registerUser(VetCareRegisterUserRequest $request)
    {
        $validatedData = $request->validated();
        $status = $request->has('status') && $request->status != '' ? $request->status : 'subscribed';
        $coupon_id = 1;

        try {

            $app = $this->find_app($validatedData['api_key']);
            $appSettings = AppSetting::where('app_id',$app->id)->first();

            $validatedData['app_id'] = $app->id;
                $validatedData['password'] = bcrypt('externalUsers#');

                //Creates a user
                $user = VetCareUser::create($validatedData);

                // Add User Status
                if($user){
                    $array = [
                        'user_id'=>$user->id,
                        'status'=>$status,
                        'app_id'=>$app->id,
                        'date_time'=> Carbon::now(),
                        'type'=> isset($request->type)?$request->type:"monthly"
                    ];
                    $temp = UserAppStatus::create($array);
                }

                //Add user to twilio account as well
                $attributes = ["app_id" => $app->id, "user_id" => $user->id, "email" => $request->email];
                $identity = 'app-' . $app->id . '_user-' . $user->id;
                $identity = is_local_env() ? 'local-' . $identity : $identity;

                $dataToTwilio = [
                    'attributes' => json_encode($attributes),
                    'friendlyName' => $request->first_name . ' ' . $request->last_name,
                    'identity' => $identity
                ];


                $createUser = $this->createUser($dataToTwilio);

            $other = array();

            // Storing other user details
            if($request->has('other') && !empty($request->other)){
                $other = $request->other;
            }

            //Add User Detail
            if(@$validatedData['zip_code']){
                $other['zip_code'] = $validatedData['zip_code'];

            }
            if(@$validatedData['phone_no']){
                $other['phone_no'] = $validatedData['phone_no'];
            }
            if (count($other) > 0) {
                $user_details = ['user_id' => $user->id, 'other' => $other];
                $user->userDetails()->create($user_details);
            }

            //Add Pet Data
            $validatedData['user_id'] = $user->id;
            $pet = $user->pets()->create($validatedData);
            unset($validatedData['user_id']);

            //Attach Default Pet to User
            if($pet){
                $defaultPet = $user->defaultPet()->sync($pet);
            }


            if($request->has('role') && $request->role == 'protect_users'){
                $user->assignRole("protect_users");
            }else{
                $user->assignRole("users");
            }

            $user->devices()->updateOrCreate([
                'dev_type' => $request->dev_type], [
                'device_token' => $request->device_token,
                'rec_id' => $user->id,
                'udid' => $request->udid,
                'app_version' => $request->app_version
            ]);

            $success['token'] = auth()->login($user);
            $success['twilioToken'] = $this->init($identity, $request->dev_type, $request->app_id);
            $success['user'] = $user->load(['devices', 'userDetails','defaultPet','userAppStatuses']);

            // Only Stringify response
            $response['stringify_response'] = json_encode($success);

            // Delete Record from bouncing user
            $this->deleteVetCareBouncingUser($user->email,$user->app_id);

            return $this->successResponse($response, 'User Created Successfully');

        } catch (TwilioException $e) {
            return $this->errorResponse($e->getMessage(), $e->getStatusCode());
        } catch (ApiErrorException $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        } catch (BadMethodCallException $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }catch (UnexpectedValueException $e){
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }

    }
    /**
     * register API For Handshake App
     * Version 2.0
     *
     * @param UserRequest $request
     * @return \Illuminate\Http\Response
     */
    public function talkToVet(VetCareUserSignUpRequest $request)
    {
        $validatedData = $request->validated();
        $coupon_id = 1;

        try {

            $app = $this->find_app($validatedData['api_key']);
            $appSettings = AppSetting::where('app_id',$app->id)->first();

            $validatedData['app_id'] = $app->id;
            $validatedData['password'] = bcrypt('externalUsers#');
            $validator = Validator::make($validatedData, [
                'email' => 'email|exists:vet_care_users,email',
            ]);

            if ($validator->fails()) {
                return $this->errorResponse('User not found. Please register user first.',404);
            }

            //Get Registered user
            $user = VetCareUser::where('email',$request->email)->first();
            // check whethere user has status subscribed
            $userStatus = UserAppStatus::where('user_id',$user->id)->where('app_id',$app->id)->latest()->first();
            if($userStatus){
                $user->status = $userStatus->status;
                if($userStatus->status == 'cancelled'){
                    return $this->errorResponse('User Subscription has been cancelled.',404);
                }
            }else{
                return $this->errorResponse('User not subscribed yet .',404);
            }

            //Add user to twilio account as well
            $attributes = ["app_id" => $app->id, "user_id" => $user->id, "email" => $request->email];
            $identity = 'app-' . $app->id . '_user-' . $user->id;
            $identity = is_local_env() ? 'local-' . $identity : $identity;

            //Attach Default Pet to User
            if($request->has('pet_id') && $request->pet_id != ''){
                $defaultPet = VetCarePet::where('user_id',$user->id)->where('id',$request->pet_id)->first();
                if($defaultPet){
                    $defaultPet = $user->defaultPet()->sync($defaultPet);
                }else{
                    return $this->errorResponse('Pet not found.',404);
                }
            }

            $user->devices()->updateOrCreate([
                'dev_type' => $request->dev_type], [
                'device_token' => $request->device_token,
                'rec_id' => $user->id,
                'udid' => $request->udid,
                'app_version' => $request->app_version
            ]);

            $success['token'] = auth()->login($user);
            $success['twilioToken'] = $this->init($identity, $request->dev_type, $request->app_id);
            $success['user'] = $user->load(['devices', 'userDetails','defaultPet','userAppStatuses']);

            // Only Stringify response
            $response['stringify_response'] = json_encode($success);


            // Delete Record from bouncing user
            $this->deleteVetCareBouncingUser($user->email,$user->app_id);

            return $this->successResponse($response, 'User Found Successfully');

        } catch (TwilioException $e) {
            return $this->errorResponse($e->getMessage(), $e->getStatusCode());
        } catch (ApiErrorException $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        } catch (BadMethodCallException $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }catch (UnexpectedValueException $e){
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }

    }

     /**
     * register API
     *
     * @param UserRequest $request
     * @return \Illuminate\Http\Response
     */
    public function validateEmailVcuser(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'email' => 'required|email',
        ]);
        if ($validator->fails()) {
            return $this->errorResponse($validator->errors()->all());
        }

        $app = $this->find_app($request['api_key']);

        $user = VetCareUser::where('email',$request->email)->first();

        if($user){
            return $this->errorResponse('User already registered with this email.',406);
        }else{
            return $this->successResponse([], 'Email Address is valid');
        }
    }

    /**
     * Logout user (Revoke the token)
     *
     * @param Request $request
     * @return  [string] message
     */
    public function logout(Request $request)
    {
        $user = $request->user();
        //$user->update(['is_online'=>0]);

        $dateTime = Carbon::now();
        $user->devices()->delete();
        $user->userAuthenticationHistory()->create([
            'dateTime' => $dateTime,
            'type' => 'logout'
        ]);

        auth()->logout();
        return $this->successResponse(true, 'Successfully logged out');
    }

    /**
     * Get the authenticated User
     * My profile
     *
     * @return  [json] user object
     */
    public function user()
    {
        try {
            $user = $this->guard()->user();
            $this->initialize($user->app_id);
            $isPawpUser = false;
            $checkingUserIsPawp = WebappUser::where(['email'=>$user->email,'app_id'=>4])->get();
            if(!$checkingUserIsPawp->isEmpty()){
                $user->assignRole("protect_users");
                $isPawpUser = true;
            }
            $data['isPawpUser'] = $isPawpUser;
            $data['paymentIntent'] = null;
            if($user->card_id){
                $data['paymentIntent'] = $this->getPaymentIntent($user->card_id);
            }
            $data['subscription'] = VetCareSubscription::where('user_id',$user->id)->get();

            $data['user'] = $user->load(['userDetails', 'usage', 'latestPayment','packageUsageDetail']);
            return $this->successResponse($data, 'user data');
        }catch (UnexpectedValueException $e) {
            return $this->errorResponse($e->getError(), $e->getHttpStatus());
        }
        catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    /**
     * add_profile user and validating through Request Class
     *
     * @param UserRequest $request
     * @return \Illuminate\Http\Response
     *
     */
    public function update($id, UserRequest $request)
    {
        $data = $request->validated();
        //dd($data['other']);
        $user = auth()->user();
        unset($data['api_key']);
        try {
            $identity = 'app-' . $user->app_id . '_user-' . $id;
            $identity = is_local_env() ? 'local-' . $identity : $identity;

            if ($request->hasFile('profile')) {
                $data['profile'] = $path = $this->uploadFilePublicRepo($request->profile, 's3','users');
                $get_user_channels = $this->fetchUserChannel($identity);
                if ($get_user_channels) {
                    foreach ($get_user_channels as $channelData) {
                        $channel_data = $this->fetchChannel($channelData->channelSid, 'arr');
                        $attributes_data = $channel_data->attributes;
                        $json_data = json_decode($attributes_data, true);
                        //dd($json_data['user']['profile']);
                        //$json_data = json_decode($json_data,true);
                        $json_data['user']['profile'] = $data['profile'];
                        $json_object = json_encode($json_data);
                        $this->updateChannelAttribute($channelData->channelSid, $json_object);
                    }
                }

            }
                $data['other'] = $user->userDetails()->first()->other;
                if($request->has('zip_code') && !empty($data['zip_code'])){
                    $data['other']['zip_code'] = $data['zip_code'];
                    unset($data['zip_code']);

                }
                if($request->has('phone_no') && !empty($data['phone_no'])){
                    $data['other']['phone_no'] = $data['phone_no'];
                    unset($data['phone_no']);

                }
            $user->userDetails()->updateOrCreate(['vet_care_user_id' => $user->id], $data);
            //Update channel attributes data on twilio
            $user->update($data);
            $user = $user->load(['userDetails', 'usage', 'payment']);
            return $this->successResponse($user, 'user data');
        } catch (QueryException $e) {
            switch ($e->getCode()) {
                case 23000:
                    $message = "Record not updated. Try again";
                    break;
                default:
                    $message = "Try again. Query Error";
            }
            return $this->errorResponse($message, 405);
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    /**
     * Updating user and validating through Request Class
     * @param ClientUserUpdateRequest $request
     * @return \Illuminate\Http\Response
     */
    public function update_password(ClientUserUpdateRequest $request)
    {
        $data = $request->validated();
        $user = $request->user();
        try {
            if (array_key_exists('new_password', $data)) {
                if (HashAlias::check($data['old_password'], $user->password) == false) {
                    throw new \Exception('invalid password');
                }
                $data['password'] = bcrypt($data['new_password']);
            }
            unset($data['new_password'], $data['old_password']);
            $id = $user->update($data);
            $user = $user->getUserDetails();
            return $this->successResponse($user, 'user data');
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    /**
     * Get the token array structure.
     *
     * @param string $token
     *
     * @return \Illuminate\Http\Response
     */
    protected function respondWithToken($token)
    {
        $a = [
            'token' => $token,
            'token_type' => 'bearer',
            'expires_in' => auth()->factory()->getTTL() * 60
        ];

        return $this->successResponse($a, 'user data');
    }

    /**
     * Refresh a token.
     *
     * @return \Illuminate\Http\Response
     */
    public function refresh()
    {

        return $this->respondWithToken(auth()->refresh(true, true));
    }

    /**
     * Get the guard to be used during authentication.
     *
     * @return Guard
     */
    public function guard()
    {
        return Auth::guard('vcusers');
    }

    /**
     * Get the authenticated User.
     *
     */
    public function me()
    {
        return response()->json(auth()->user());
    }

    public function upload(Request $request)
    {
        // dd($request->file('file'));
        $file = "";
        if ($files = $request->file('file')) {
            foreach ($request->file('file') as $key => $file) {
                $file = $this->saveImage($file);
            }
        }
        return response()->json($file, 200);
    }

    public function contactSupport(UserContactSupport $request)
    {
        $data = $request->validated();
        $user = auth()->user();
        try {
            $subject = $request->subject;
            $text = $request->text;
            $user_name = $user->first_name . ' ' . $user->last_name;
            $email = $user->email;
            Mail::to(env('MAIL_TO'))->send(new ContactSupport($subject, $text, ucfirst($user_name), $email));

            return $this->successResponse(true, 'Email sent');
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    /**
     * Add User card on stripe
     * @param array $data
     * @param $user
     * @return \Illuminate\Http\JsonResponse|\Illuminate\Http\Response
     */
    protected function addCard($data = array(),$user){
        if($user->stripe_id ){
            $customer = $this->retrieveCustomer($user->stripe_id);
        }
        else{
            $customer = $this->createCustomer($user->email);

        }
        $data['cus_id'] = $customer->id;
        //$token = $this->createStripeToken($validated);
        $token = $this->createStripeToken($data);
        if($token['code'] == 200){
            //$customer = $this->createCustomer($user->email);
            $this->createCustomerSetupIntent($customer->id,$token['token']->id);

            $validated['stripe_id'] = $customer->id;
            $validated['card_id'] = $token['token']->id;
            $user->update($validated);
        }
        return $token ?? $token ;

    }

    /**
     * Buy a package
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse|\Illuminate\Http\Response
     */
    protected function buyPackage($package_id,$user,$vetCareCouponCodeId,$price)
    {
        try{
            $this->initialize($user->app_id);
            $package_data = VetCarePackage::find($package_id);
            $description = 'Payment against '.$package_data->name;
            $is_recurring = $package_data->is_recurring;
            $interval = $package_data->interval;
            $vetCareCouponCode = VetCareCouponCode::with('model')->whereHasMorph('model',[VetCareCoupon::class],function($q) use($package_id){
                $q->where('package_id',$package_id);
            })->find($vetCareCouponCodeId);
            $vetCareCouponCodeId = optional($vetCareCouponCode)->id;

            /* VetCareCoupon */
            $model = optional($vetCareCouponCode)->model;

            $json_to_var = json_decode($model);

            //Make user stripe charge
            //Case only for 0 payments
            if($package_data->is_card == 0){
                if($model){
                    $this->addCouponUsageData($vetCareCouponCodeId,$user->id,$json_to_var->other->access_days,$package_data->id,$package_data->is_card);
                }else{
                    $this->addCouponUsageData(null,$user->id,null,$package_data->id,$package_data->is_card);
                }
                //Add payment information for zero
                VetCareUserPayment::create(
                    [
                        'user_id'=>$user->id,
                        'amount'=>$price,
                        'charge_id'=>'',
                        'status'=>'accepted',
                        'date'=>Carbon::now()->toDateTimeString()
                    ]);

                VetCarePackageUsage::create([
                    'user_id'=>$user->id,
                    'package_id'=>$package_data->id,
                    'vet_care_coupon_code_id'=>$vetCareCouponCodeId
                ]);
                $end_date=$this->createNextDate($package_data->interval,$package_data->interval_count);
                $vet_subscription = new VetCareSubscription;
                $vet_subscription->user_id = $user->id;
                $vet_subscription->subscription_id = $package_data->id;
                $vet_subscription->start_date = Carbon::now();
                // $vet_subscription->end_date = Carbon::now()->addDays(30);
                $vet_subscription->end_date = date('Y-m-d H:i:s',$end_date);
               
                $vet_subscription->status = 'active';
                $vet_subscription->save();

                $response = $this->successResponse('null', 'Package bought');
            }
            else{
                if($price == 0 || $price == 0.0){
                    $subscribed = '';
                        $trail_end_date = Carbon::now()->addMinutes(5)->timestamp;
                        $price_data = $this->getPrice($package_data->price_id);
                        // $subscribed = $this->addSubscription($user->stripe_id,$package_data->price_id,$trail_end_date);
                        $subscribed = $this->addSubscription($user->stripe_id,$package_data,$trail_end_date);
                    
                    $this->addCouponUsageData($vetCareCouponCodeId,$user->id,$json_to_var->other->access_days,$package_data->id,$package_data->is_card);

                    // $this->userPaymentData($user->id,$price,'','accepted',$package_data->id,$vetCareCouponCodeId,$subscribed,'',$interval,$package_data->type);
                    $this->userPaymentData($user->id,$price,'','accepted',$package_data,$vetCareCouponCodeId,$subscribed,'',$interval,$package_data->type);

                    //Add payment data,subscription data and usage history
                    $response = $this->successResponse('null', 'Package bought');
                }
                else{
                    //Except all zero payments
                    $charge = $this->makeCharge($price,$package_data->currency,$user->stripe_id,$description,$user->card_id,$user);

                    try{
                        if($charge->status == 'succeeded'){
                            $subscribed = [];
                            //For recurring payments only
                                $trail_end_date = Carbon::now()->addMinutes(5)->timestamp;

                                // $subscribed = $this->addSubscription($user->stripe_id,$package_data->price_id,$trail_end_date);
                                $subscribed = $this->addSubscription($user->stripe_id,$package_data,$trail_end_date);

                            //Add payment data,subscription data and usage history
                            // $this->userPaymentData($user->id,$price,$package_data->price_id,$charge->status,$package_data->id,$vetCareCouponCodeId,$subscribed,$charge,$interval,$package_data->type);
                            $this->userPaymentData($user->id,$price,$package_data->price_id,$charge->status,$package_data,$vetCareCouponCodeId,$subscribed,$charge,$interval,$package_data->type);
                            
                            
                            if($model)
                            {
                                $this->addCouponUsageData($vetCareCouponCodeId,$user->id,$json_to_var->other->access_days,$package_data->id,$package_data->is_card);
                            }

                            $response = $this->successResponse('null', 'Package bought');
                        }
                        else{
                            $response = $this->errorResponse('Your payment was not succeeded', 401);
                        }
                    }
                    catch (ApiErrorException $exception){
                        $response = $this->errorResponse($exception->getMessage(), $exception->getHttpStatus());
                    }

                }
            }
            return $response;
        }
        catch (QueryException $e){
            return $this->errorResponse($e->getMessage(), 407);
        }
        catch (Exception $e){
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    protected function userPaymentData($user_id,$price,$charge_id,$charge_status,$package,$vetCareCouponCodeId,$subscribed,$charge,$interval,$type){
        //Add payment data and usage history
        // $payment = VetCareUserPayment::updateOrCreate(['user_id'=>$user_id],[
        $payment = VetCareUserPayment::create([
            'user_id'=>$user_id,
            'amount'=>$price,
            'charge_id'=>$charge_id,
            'status'=>$charge_status,
            'stripe_response'=> isset($charge) && !empty($charge) ? json_encode($charge) : null,
            'date'=>Carbon::now()->toDateTimeString()
        ]);

        $data = VetCarePackageUsage::create([
            'user_id'=>$user_id,
            'package_id'=>$package->id,
            'vet_care_coupon_code_id'=>$vetCareCouponCodeId
        ]);


        //Add User subscription
        if(isset($subscribed) && !empty($subscribed)){
            $end_date=$this->createNextDate($package->interval,$package->interval_count);
            //Add subscription data
            $json = $this->retreiveSubscriptionSchedule($subscribed->id);
            //dd($subscribed,$json);
            //json = json_decode($subscribed->getContent(),true);
            $vet_subscription = new VetCareSubscription;
            $vet_subscription->user_id = $user_id;
            $vet_subscription->subscription_id = $json['id'];
            $vet_subscription->start_date = Carbon::now();
            // $vet_subscription->end_date = Carbon::now()->addDays(30);
            $vet_subscription->end_date =  date('Y-m-d H:i:s',$end_date);
            $vet_subscription->status = $json['status'];
            $vet_subscription->save();
        }
        //Add User subscription if package type is protect
        if($type == 'protect'){
            VetCarePaymentProtectUser::create([
                'user_id'=> $user_id,
                'payment_id'=> $payment->id,
                'subscription_timestamp' => Carbon::now('UTC')
            ]);
        }

        return $data;
    }

    protected function addCouponUsageData($vetCareCouponCodeId,$user_id,$days,$package_id,$is_card){
        if($vetCareCouponCodeId){
            $usage = VetCareCouponUsage::updateOrCreate(['vet_care_coupon_code_id'=>$vetCareCouponCodeId,'user_id'=>$user_id],[
                'use_datetime'=>Carbon::now(),
                'left_days'=>$days == "null"?"unlimited":$days - 1,
            ]);
        }
        if($is_card == 0){
            $data = VetCarePackageUsage::create([
                'user_id'=>$user_id,
                'package_id'=>$package_id,
                'vet_care_coupon_code_id'=>$vetCareCouponCodeId
            ]);
        }
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\Response
     */


    public function updateCard(Request $request)
    {
        try{
            $user = $this->guard()->user();

            $this->initialize($user->app_id);

            $res = $this->addCard($request->all(),$user);

            if($res['code'] != 200){
                return $this->errorResponse($res['message'], $res['code']);
            }

            $response = $this->getPaymentIntent($user->card_id);

            return $this->successResponse($response, 'card updated');
        }
        catch (\Exception $exception){
            return $this->errorResponse($exception->getMessage(), $exception->getCode());
        }


    }

    public function validateCard(Request $request)
    {
        $appId = $this->find_app($request->api_key)->id;
        $this->initialize($appId);

        try{
            $token = $this->stripe->paymentMethods->create([
                'type' => 'card',
                'card' => [
                    'number' => $request['number'],
                    'exp_month' => $request['exp_month'],
                    'exp_year' => $request['exp_year'],
                    'cvc' => $request['cvc'],
                ],
            ]);
            return $this->successResponse([], 'Card Validated Succesfully');
        }catch (\Exception $exception){
            return $this->errorResponse($exception->getMessage(), 402);
        }
    }

    public function unsubscribeUser(Request $request){
        try{
            $user = auth()->user();
            $data = array ();
            //Check for recurring payment
            if($user->usage()->count() > 0){

                $this->initialize($user->app_id);
                $check_interval = VetCarePackage::findOrFail($user->usage[0]->package_id);
//                if($check_interval->interval == 'month' || $check_interval->interval == 'day'){
                    $data = VetCareSubscription::where('user_id',$user->id)->orderBy('id','desc')->first();
                    if($data->status == 'canceled'){
                        return $this->errorResponse('Your Package is already in canceled state or you are not subscribed to any package',406);
                    }
                    $stripeResponse = $this->unsubscribe($data->subscription_id);

                    if($stripeResponse){
//                        $data->update(['status' => $stripeResponse['status']]);
                        $data->status = $stripeResponse['status'];
                    }
                    if($check_interval->is_recurring == 0){
                        $data->status = 'canceled';
                    }

                    // Saving reasons of package cancellation
                    if($request->has('others') && $request->others != null)
                    {
                        $data->others = $request->others;
//                        $data->update(['others' => $request->others]);
                    }
                    $data->save();
                    if($check_interval->type == 'protect'){
                        $user->removeRole('protect_users');
                        $user->assignRole('users');
                    }
//                }
                $trash = VetCarePackageUsage::where('user_id',$user->id)->delete();

                return $this->successResponse($data, 'Unsubscribed Successful');
            }
            else{
                return $this->errorResponse('You are not subscribed to any package',406);
            }
        }
        catch (ModelNotFoundException $e){
            return $this->errorResponse('You are not subscribed to any package',406);
        }
        catch (ApiErrorException $e){
            return $this->errorResponse($e->getMessage(),401);
        }

    }

    public function subscribeUser(Request $request){
        try{
            $user = auth()->user();
            $userRole = $user->getRoleNames()->first();
            $user->pet_tracking_code = isset($request->pet_tracking_code) && !empty($request->pet_tracking_code) ?  $request->pet_tracking_code :$user->pet_tracking_code;
            $user->update();
            $price = @$request->price;
            $package_id = @$request->package_id;
            $vetCareCouponCodeId = 0;
            if($request->has('code') && $request->code != ''){
                $coupon = VetCareCoupon::with("vetCareCouponCodes")->whereHas('vetCareCouponCodes',function($q) use($request){
                    $q->where('code',$request->code);
                })->first();
                if($coupon->vetCareCouponCodes){
                    $vetCareCouponCode = $coupon->vetCareCouponCodes->where('code',$request->code)->first();
                    $vetCareCouponCodeId =  $vetCareCouponCode->id;
                }
            }

            // Check if Package subscription is active
            if($this->isSubscriptionPriceActive($package_id) == false){
                return $this->errorResponse('Package is not active. Please Subscribe to another package',406);
            }

            $this->buyPackage($package_id,$user,$vetCareCouponCodeId,$price);

            if($this->ifVcPackageProtected($package_id)){
                $user->syncRoles('protect_users');
            }

            $data['subscription'] = VetCareSubscription::where('user_id',$user->id)->get();


            return $this->successResponse($data, 'Subscription successful');
        }
        catch (ModelNotFoundException $e){
            return $this->errorResponse('You are not subscribed to any package',406);
        }
        catch (ApiErrorException $e){
            return $this->errorResponse($e->getMessage(),401);
        }
    }

    public function updateSubscriptionRequest(Request $request){
        try{
            $user = auth()->user();
            $this->initialize($user->app_id);

            $new_package_id = @$request->new_package_id;
            $old_package_id = @$request->old_package_id;
            $oldData = VetCareSubscription::where('user_id',$user->id)->latest()->first();
            $package_data_new = VetCarePackage::find($new_package_id);
            $package_data_old = VetCarePackage::find($old_package_id);
            // Check if Package subscription is active
            if($this->isSubscriptionPriceActive($new_package_id) == false){
                return $this->errorResponse('Package is not active. Please Subscribe to another package',406);
            }

            // temporary handling exceptional case
            if($package_data_old->is_recurring == 1 && $package_data_new->is_recurring == 0){
                return $this->errorResponse("You can't upgrade your package to non-recurring from recurring",406);
            }
            if($package_data_old->is_recurring == 0){
                $updatedData = $this->updateSubscriptionWithNoRecurring($package_data_new,$user->stripe_id);

            }else{
                $updatedData = $this->updateSubscription($package_data_new,$user->stripe_id,$oldData->subscription_id);
            }
            if($updatedData || $package_data_old->is_recurring == 0){
                // Update old subscription
                if ($oldData->status != 'canceled') {

                    $oldData->update(['status' => 'canceled']);

                    if($package_data_old->type == 'protect'){
                        $user->removeRole('protect_users');
                        $user->assignRole('users');
                    }

                }

                // Create new subscription
                $end_date=$this->createNextDate($package_data_new->interval,$package_data_new->interval_count);
                $data['subscription'] = VetCareSubscription::create([
                    'user_id'=>$user->id,
                    'subscription_id'=>$updatedData['id']??1,
                    'start_date'=>Carbon::now(),
                    // 'end_date'=>Carbon::now()->addDays(30),
                    'end_date'=> date('Y-m-d H:i:s',$end_date),
                   
                    'status'=>'upgraded'
                ]);

                if($this->ifVcPackageProtected($new_package_id)){
                    $user->syncRoles('protect_users');
                }

                // Delete old package usage
                $trash = VetCarePackageUsage::where('user_id',$user->id)->delete();

                // Create new package usage
                $data['package_usage'] = VetCarePackageUsage::create([
                    'user_id'=>$user->id,
                    'package_id'=>$new_package_id,
                    'vet_care_coupon_code_id'=>0
                ]);
                return $this->successResponse($data, 'Subscription update successful');

            }
            else{
                return $this->errorResponse('Error in package upgrade',401);
            }

        }
        catch (UnknownApiErrorException $e){
            return $this->errorResponse($e->getMessage(),406);
        }
        catch (ApiErrorException $e){
            return $this->errorResponse($e->getMessage(),401);
        }
    }

    /*
     * Twilio refresh token
     */
    public function refreshTwilioApiToken(Request $request){

        $identity = $request->identity;
        $dev_type = $request->dev_type;
        $app_id = ($request->has('api_key')  && $request->api_key !== null && $request->api_key != '') ? $this->find_app($request->api_key)->id : null;
        $response['twilioToken'] = $this->init($identity, $dev_type, $app_id);
        //$response['pawpTwilioToken'] = $this->accessToken($identity, $dev_type, $app_id);
        return $this->successResponse($response, 'User token');
    }

    public function validatePasswordRequest(Request $request){
        //You can add validation login here
        $user = VetCareUser::where('email', '=', $request->email)->first();
        //Check if the user exists
        if (!@$user) {
            return $this->errorResponse('User does not exists', 401);
        }

        //Create Password Reset Token
        DB::table('password_resets')->insert([
            'email' => $request->email,
            'token' => str_random(60),
            'created_at' => Carbon::now()
        ]);
        //Get the token just created above
        $tokenData = DB::table('password_resets')
            ->where('email', $request->email)->first();

        if ($this->sendResetEmail($request->email, $tokenData->token)) {
            return $this->successResponse(true, 'Resent Email sent');
        } else {
            return $this->errorResponse('A Network Error occurred. Please try again.', 401);
        }
    }

    private function sendResetEmail($email, $token)
    {
    //Retrieve the user from the database
        $user = VetCareUser::where('email', $email)->select('first_name', 'email')->first();
    //Generate, the password reset link. The token generated is embedded in the link
        $link = URL::to('/').'/password/reset/' . $token . '?email=' . urlencode($user->email);

        try {
            //Here send the link with CURL with an external email API
            Mail::send('emails.forgetPassword', ['link' => $link], function($message) use($email){
                $message->to($email);
                $message->subject('Reset Password Request');
            });
            return true;
        } catch (\Exception $e) {
            return false;
        }
    }

    public function resetPassword(Request $request)
    {
        //Validate input
//        dd($request->all());
        $validator = Validator::make($request->all(), [
            'email' => 'required|email|exists:users,email',
            'password' => 'required|confirmed',
            'token' => 'required'
        ]);

        //check if payload is valid before moving on
        if ($validator->fails()) {
            return redirect()->back()->withErrors(['email' => 'Complete form']);
        }

        $password = $request->password;
        // Validate the token
        $tokenData = DB::table('password_resets')
            ->where('token', $request->token)->first();
        // Redirect the user back to the password reset request form if the token is invalid
        if (!$tokenData) return view('auth.passwords.email');

            $user = VetCareUser::where('email', $tokenData->email)->first();
        // Redirect the user back if the email is invalid
        if (!$user) return redirect()->back()->withErrors(['email' => 'Email not found']);
        //Hash and update the new password
        $user->password = \Hash::make($password);
        $user->update(); //or $user->save();

        //login the user immediately they change password successfully
        //Auth::login($user);

        //Delete the token
        DB::table('password_resets')->where('email', $user->email)
            ->delete();

        //Send Email Reset Success Email
        if ($this->sendSuccessEmail($tokenData->email)) {
            return view('index');
        } else {
            return redirect()->back()->withErrors(['email' => trans('A Network Error occurred. Please try again.')]);
        }

    }

    public function showResetPasswordForm($token) {
        return view('auth.passwords.email', ['token' => $token]);
    }

    protected function findPackage($id){
        return VetCarePackage::find($id);
    }

    public function getPackage(Request $request){

        try{
            $data = new VetCarePackage;
            $find_app = $this->find_app($request->api_key);
            if($request->has('id') && !empty($request->id))
            {
                $data = $data->where('id',$request->id);
            }
            $data = $data->with(['benefit','metadata'])->where('vet_care_id',$find_app->id)->latest()->get();

            return $this->successResponse($data, 'Vet Care Package');
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(),$e->getCode());
        }

    }

    /*
    * Used for user actions such as when user registers
    * when user cancels from clients app
    */
    public function userActions(UserStatusRequest $request){
        $validated = $request->validated();
        try{
            $app = $this->find_app($request->api_key);
            $validated['app_id'] = $app->id;
            $email = $request->email;
            $status = $request->status;
            $date_time = $request->date_time;
            $type = isset($request->type)?$request->type:"monthly";
            if($request->status == 'subscribed'){
                $find_user = VetCareUser::updateOrCreate(
                    ['app_id' => $app->id, 'email' => $email],
                    $validated
                );
            }
            else{
                $find_user = VetCareUser::where('email',$email)->first();
            }
            //User Status History
            if($find_user){
                $array = [
                    'user_id'=>$find_user->id,
                    'status'=>$status,
                    'app_id'=>$app->id,
                    'date_time'=>$date_time,
                    'type'=>$type
                ];
                $temp = UserAppStatus::create($array);
                $data['email'] = $find_user->email;
                $data['registration'] = $find_user->created_at;
                $data['status'] = $temp->status;
                return $this->successResponse($data,'User action successful');
            }
            else{
                return $this->errorResponse('You need to subscribe first,before cancellation',401);
            }
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(),$e->getCode());
        }
    }

    /*
    * Used for user actions such as when user registers
    * when user cancels from clients app
    */
    public function userActionsV2(UserStatusRequest $request){
        $validated = $request->validated();
        try{
            $app = $this->find_app($request->api_key);
            $validated['app_id'] = $app->id;
            $email = $request->email;
            $status = $request->status;
            $date_time = isset($request->date_time)?$request->date_time:date('Y-m-d h:i:s');
            $type = isset($request->type)?$request->type:"monthly";

            $is_protect = $request->role;

            if ($is_protect != 'protect_users' && $is_protect != 'users') {
                return $this->errorResponse('role not found', 404);
            }
            if ($status != 'cancelled' && $status != 'subscribed' && $status != 'upgrade') {
                return $this->errorResponse('status not found', 404);
            }

            if($request->status == 'subscribed'){
                $find_user = VetCareUser::updateOrCreate(
                    ['app_id' => $app->id, 'email' => $email],
                    $validated
                );
            }
            else{
                $find_user = VetCareUser::where('email',$email)->first();
            }
            //User Status History
            if($find_user){
                $array = [
                    'user_id'=>$find_user->id,
                    'status'=>$status,
                    'app_id'=>$app->id,
                    'date_time'=>$date_time,
                    'type'=>$type
                ];
                $temp = UserAppStatus::create($array);
                $data['email'] = $find_user->email;
                $data['registration'] = $find_user->created_at;
                $data['status'] = $temp->status;
                $data['role'] = $request->role;


                if($request->has('role') && $request->role == 'protect_users'){
                    $find_user->syncRoles('protect_users');
                }else{
                    if($find_user->hasRole('protect_users')){
                        return $this->errorResponse("Error: Can't degrade User from protected.",401);
                    }
                    $find_user->syncRoles("users");
                }
//                $data['user'] = $find_user;


                return $this->successResponse($data,'User action successful');
            }
            else{
                return $this->errorResponse('You need to subscribe first,before cancellation',401);
            }
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(),$e->getCode());
        }
    }

    /**
     * Use for ZipCodes
     **/
    public function validateZipCodes(Request $request)
    {
        if(Zipcode::where('code',$request->code)->first()){
            $appId = $this->find_app($request->api_key)->id;
            $package = VetCarePackage::where('vet_care_id',$appId)->where('is_default',1)->first();
            if($package){
                return $this->successResponse($package,'Zipcode Verified');
            }else{
                return $this->errorResponse('No default package is assigned to this app.',404);
            }
        }else{
            return $this->errorResponse('Invalid ZipCode',404);
        }
    }

    /**
     * saving data of vet care bouncing users
     *
     **/
    public function saveBouncingUsers(Request $request)
    {
        $data = $request->only('id','email','first_name','last_name','pets','others','phone_number','zip_code');
        try{
            $app = $this->find_app($request->api_key);
            $data['app_id'] = $app->id;
            $user = BouncingVetCareUser::create($data);
            return $this->successResponse($user,'Data Saved');
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(),$e->getCode());
        }
    }

    /**
     * saving other data of vet care  users
     *
     **/
    public function saveOtherDataOfUser(Request $request)
    {
        $data = $request->except('user_id','api_key');
        try{
            $app = $this->find_app($request->api_key);
            $user = auth()->user();
            if($user){
                $user = $user->update([
                    'extra' => $data
                ]);
                return $this->successResponse($data,'Extra Data Saved');
            }else{
                return $this->successResponse('User not found - Extra Data Not Saved',203);
            }
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(),$e->getCode());
        }
    }

    // Saving UTM attributes in new table
    public function utmSave(Request $request){
        $app = $this->find_app($request->api_key);
        try{
            $data = $request['attributes'];
            if(!empty($data)){
                $data = UtmAttribute::create(['app_id' => $app->id, 'attributes' => $data]);
                return $this->successResponse($data,'UTM Data Saved');
            }else{
                return $this->successResponse('UTM Data Not Saved',203);
            }
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(),$e->getCode());
        }
    }

    public function deleteVetCareBouncingUser($email,$app_id){
        $users = BouncingVetCareUser::where('email',$email)
                ->where('app_id',$app_id)
                ->get();

        if($users){
            foreach ($users as $user) {
                $user->delete();
            }
        }
        return true;
    }

    /**
     * check if subscription price is active or not
     */

     public function isSubscriptionPriceActive($packageId){
        try {
            $status = true;
            $package = VetcarePackage::findOrFail($packageId);
            if($package->is_recurring == 1 && $package->price != 0){
                $this->initialize($package->vet_care_id);
                $packagePriceStripe = $this->retrievePricePlan($package->price_id);
                if($packagePriceStripe->active == false){
                    $status = false;
                }
            }
            return $status;

        } catch (\Throwable $th) {
            return false;
        }
     }

      /**
     * External login API
     *
     * @param Request $request
     * @return \Illuminate\Http\Response
     */
    public function externalLogin(Request $request)
    {
        $input = $request->all();
        $validator = Validator::make($input, [
            'email' => 'required|email',
            'password' => 'required',
        ]);
        if ($validator->fails()) {
            return $this->errorResponse($validator->errors()->all());
        }
        $credentials = $request->only(['email', 'password']);
        try {
            $check_user_app_info = $this->find_app($input['api_key']);

            $check_if_user_is_a_app_user = VetCareUser::where('app_id', $check_user_app_info->id)->get();
            if ($check_if_user_is_a_app_user) {

                if ($token = $this->guard()->attempt(['email' => $request->email, 'password' => $request->password, 'app_id' => $check_user_app_info->id])) {

                    $user = $this->guard()->user();
                    if (!$user->hasAnyRole('users', 'protect_users')) {
                        return $this->errorResponse('UnAuthorized. Please contact admin', 401);
                    }

                    if ($token = $this->guard()->attempt($credentials)) {

                        // $app_id = $this->find_app($input['api_key']);
                        //Update or create new device
                        if(isset($request->device_token) && !empty($request->device_token)){
                            $user->devices()->delete();
                            $user->devices()->updateOrCreate(['device_token' => $request->device_token], [
                                'rec_id' => $user->id,
                                'device_token' => $request->device_token,
                                'udid' => $request->udid,
                                'dev_type' => $request->dev_type,
                                'app_version' => $request->app_version
                            ]);
                        }
                            // update appid on twilio user resource if new appid
                            if ($check_user_app_info->id != $user->app_id) {
                                $identity = 'app-' . $check_user_app_info->id . '_user-' . $user->id;
                                $identity = is_local_env() ? 'local-' . $identity : $identity;
                                $this->fetchAndUpdateUser($check_user_app_info->id, $identity);
                            }
                            $this->initialize($check_user_app_info);

                        $dashboard['paymentIntent'] = '';
                        $dashboard['subscription'] = '';
                        if($user->card_id){
                            $dashboard['paymentIntent'] = $this->getPaymentIntent($user->card_id);
                            $dashboard['subscription'] = VetCareSubscription::where('user_id',$user->id)->get();
                        }


                        $success['token'] = $token;
                        // $success['user'] = $user->load(['devices', 'userDetails', 'usage', 'latestPayment', 'defaultPet','packageUsageDetail']);
                        $success['user'] = $user->load([ 'userDetails','defaultPet','packageUsageDetail']);

                        $success['dashboard'] = $dashboard;
                        $isPawpUser = false;
                        $checkingUserIsPawp = WebappUser::where(['email'=>$input['email'],'app_id'=>4])->get();
                        if(!$checkingUserIsPawp->isEmpty()){
                            $user->assignRole("protect_users");
                            $isPawpUser = true;
                        }

                        $dateTime = Carbon::now();
                        $user->userAuthenticationHistory()->create([
                            'dateTime' => $dateTime,
                            'type' => 'login',
                        ]);
                        return $this->successResponse($success, 'logged in');
                    }
                }
                else {
                    return $this->errorResponse('Wrong credentials');
                }
            }
        }
        catch (ApiErrorException $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
        catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }
}
