<?php

namespace App\Http\Controllers\Client;

use App\App;
use App\Exports\SendFeedback;
use App\Feedback;
use App\Http\Requests\VetEmailFeedbacksRequest;
use App\Http\Resources\ClinicPaymentResource;
use App\Http\Resources\VetCareUserPaymentResource;
use App\Mail\EmailFeedbacks;
use App\VetCareCouponCode;
use App\VetCareUser;
use App\VetCareUserPayment;
use App\BouncingVetCareUser;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\Http\Resources\VetFeedbackResource;
use App\Http\Resources\VetCareUserListResource;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Storage;


class ReportController extends Controller
{

    private $noOfRecordPerPage = 10;
    private $paginate = false;
    private $user;

    public function __construct()
    {
        $this->middleware('auth:clinic');
        $this->user = $this->guard()->user();
    }

    public function guard()
    {
        return Auth::guard('clinic');
    }

    public function user(Request $request){
        $input = $request->only('search_value', 'search_by', 'page', 'pagination', 'perPage', 'app_id','export','date_from','date_to','user_id','package_id','ef_status','user_type','subscription_status');
            try {
            $app = $this->user->app()->first();
            $request['key'] = $app->api_key;
            if(!$app)
            {
                return $this->errorResponse('No App is linked with this Clinic.', 404);
            }

            $value = isset($input['search_value'])?$input['search_value']:'';

            $model = VetCareUser::latest()->search($value);
            $model = $model->with(['user_status','emergencyLatest.notesEmergencyLatest','emergencyLatestFilter.notesEmergencyLatest','defaultPet','usage.package','usageLatest.package','payment','userDetails','vetCareUserFeedbacks.vet','pets']);

            if (isset($input['pagination']) && $input['pagination'] != "") {
                $this->paginate = true;
                //Use case when there is a date filter
                if ($request->has('date_from') && $request->has('date_to')) {
                    $model = $model->whereBetween('created_at',
                        [$input['date_from'] . " 00:00:00", $input['date_to'] . " 23:59:00"]
                    );
                }
                if(@$request->has('package_id')){
                    $package_id = @$input['package_id'];
                    $eagerloading = $model->whereHas('usageLatest',function($q) use($package_id){
                        $q = $q->where('package_id',$package_id);
                    });
                }
                else{
                    $eagerloading = $model->with(['usageWithThrashed.package','usageSubscription'=>function($q){
                        $q->with('subscriptonsData');
                    }]);
                }


                if($request->has('user_type') && !empty($input['user_type']) ){ // membership type status filter
                    //protected or normal user
                        $role_name= $input['user_type'];
                        $model = $model->whereHas('roles',function ($q) use ($role_name){
                            $q->where('name',$role_name);
                        });
                }

                if($request->has('subscription_status') && !empty($input['subscription_status'])){ // subscrption status
                    $is_handshake = is_handshake_enabled($app->id);
                    if($is_handshake){
                        //check in user app statuses
                        $model = $model->whereHas('user_status');
                    }else{
                            // $model = $model->whereHas('usage');
                            $model = $model->whereHas('usageSubscription');
                            // $model = $model->doesnthave('usage');
                    }
                }

                // if($request->has('ef_status') && !empty($input['ef_status'])){ // emergecny fund status filter
                //     $ef_status= $input['ef_status']; //true ,false , denied
                //     $app_id = $app->id;
                //     if($ef_status!='false'){

                //         $eagerloading = $model->whereHas('emergencyLatestFilter',function ($q) use ($ef_status,$app_id){
                //             $q->where(function ($query)  use ($ef_status)  {
                //                 $query->whereHas('notesEmergencyLatest');
                //             });
                //         });

                //     } else{
                //         $eagerloading = $model->whereHas('emergencyLatestFilter',function ($q) use ($ef_status,$app_id){
                //             $q->whereHas('notesEmergencyLatest');
                //             $q->ordoesnthave('notesEmergencyLatest');
                //         });
                //     }

                // }

                if($request->has('ef_status') && !empty($input['ef_status'])){ // emergecny fund status filter
                    $ef_status= $input['ef_status']; //true ,false , denied
                    $app_id = $app->id;

                    $eagerloading = $model->whereHas('emergencyLatestFilter',function ($q) use ($ef_status,$app_id){
                        $q->where('status',$ef_status);
                    });
            }

                if($input['export'] === 'true' || $input['export'] === true){
                    $this->paginate = false;
                    $users =  $eagerloading->where('app_id',$app->id)->latest()->get();
                }
                else{
                    $users =  $eagerloading->where('app_id',$app->id)->latest()->paginate($this->noOfRecordPerPage);

                }
            }
            else{
                $users =  $model->where('app_id',$app->id)->where('id',$request->user_id)->get();
            }
            $users = VetCareUserListResource::collection($users);

            return $this->successResponse($users, 'Record Fetched Successfully .', $this->paginate);
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }

    }

    public function handShakeAppuserList(Request $request){
        $input = $request->only('search_value', 'search_by', 'page', 'pagination', 'perPage', 'app_id','export','date_from','date_to','user_id','package_id');
        try {
            $app = $this->user->app()->first();

            if(!$app)
            {
                return $this->errorResponse('No App is linked with this Clinic.', 404);
            }

            $value = isset($input['search_value'])?$input['search_value']:'';

            $model = VetCareUser::latest()->search($value);
            $model = $model->with(['defaultPet','userDetails','vetCareUserFeedbacks.vet','pets','user_status' => function($q) {
                // Sort by descending order
                $q->orderBy('id', 'desc');
            }]);

            if (isset($input['pagination']) && $input['pagination'] != "") {
                $this->paginate = true;
                //Use case when there is a date filter
                if ($request->has('date_from') && $request->has('date_to')) {
                    $model = $model->whereBetween('created_at',
                        [$input['date_from'] . " 00:00:00", $input['date_to'] . " 23:59:00"]
                    );
                }

                if($input['export'] === 'true' || $input['export'] === true){
                    $this->paginate = false;
                    $users =  $model->where('app_id',$app->id)->latest()->get();
                }
                else{
                    $users =  $model->where('app_id',$app->id)->latest()->paginate($this->noOfRecordPerPage);

                }
            }
            else{
                $users =  $model->where('app_id',$app->id)->where('id',$request->user_id)->get();
            }

            return $this->successResponse($users, 'Record Fetched Successfully .', $this->paginate);
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }

    }

    public function bouncingUser(Request $request){
        $input = $request->only('search_value','page', 'pagination', 'perPage', 'app_id','export','date_from','date_to');
        try {
            $app = $this->user->app()->first();

            if(!$app)
            {
                return $this->errorResponse('No App is linked with this Clinic.', 404);
            }

            $value = isset($input['search_value'])?$input['search_value']:'';

            $model = BouncingVetCareUser::where('app_id',$app->id);

            if(!empty($value)){
                $model = $model->where('email','Like','%'.$value.'%')
                ->orWhere(function ($query) use ($value) {
                    $query->where('email','Like','%'.$value.'%')->orWhere('first_name','Like','%'.$value.'%')
                    ->orWhere('last_name','Like','%'.$value.'%');
                });
            }


            if (isset($input['pagination']) && $input['pagination'] != "") {
                $this->paginate = true;
                //Use case when there is a date filter
                if ($request->has('date_from') && $request->has('date_to')) {
                    $model = $model->whereBetween('created_at',
                        [$input['date_from'] . " 00:00:00", $input['date_to'] . " 23:59:00"]
                    );
                }

                $model = $model->where('app_id',$app->id);

                if($input['export'] === 'true' || $input['export'] === true){
                    $this->paginate = false;
                    $model =  $model->latest()->get();
                }
                else{
                    $model =  $model->latest()->paginate($this->noOfRecordPerPage);

                }
            }
            else{
                $model =  $model->where('id',$request->user_id)->get();
            }

            return $this->successResponse($model, 'Record Fetched Successfully .', $this->paginate);
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }

    }

    public function payment(Request $request){
        $input = $request->only('search_value', 'search_by', 'page', 'pagination', 'perPage', 'app_id','export','date_from','date_to','user_id','status');
        try {
            $app = $this->user->app()->first();
            $value = isset($input['search_value'])?$input['search_value']:'';
            $search_by = isset($input['search_by'])?$input['search_by']:'';

            if(!$app)
            {
                return $this->errorResponse('No App is linked with this Clinic.', 404);
            }

            $model = new VetCareUser();
            $model = $model->where('app_id', $app->id);

            //This model is only used when there is search by coupon checked from admin
            if ($search_by == 'coupon') {
                $upper_case = ucfirst($value);
                $lower_case = strtolower($value);
                $full_case = strtoupper($value);
                $temp_str_case = $upper_case.' '.$lower_case.' '.$full_case;
                $find_coupon_code = VetCareCouponCode::where('code','like',"%$value%")->with("vetCareCouponUsages")->withTrashed()->get();
                $temp_coupon_usage = array();
                if($find_coupon_code){
                    foreach ($find_coupon_code as $coupon_code){
                        $usage_arr = $coupon_code->vetCareCouponUsages;
                        foreach ($usage_arr as $usage) {
                            $temp_coupon_usage[] = $usage->user_id;
                        }
                    }
                }
                if ($request->has('date_from') && $request->has('date_to')) {
                    $model = $model->whereHas('latestPaymentHasMany',function($q) use ($input){
                        $q->whereBetween('date', [$input['date_from'] . " 00:00:00", $input['date_to'] . " 23:59:00"]
                        );
                    });
                }
                else{
                    $model = $model->with(['latestPaymentHasMany', 'payProtectUser', 'emergency' => function ($q) {
                        $q->latest();
                    }])->whereHas('coupon_usage');
                }
                $model =  $model->where('app_id', $app->id)->whereIn('id', $temp_coupon_usage);
            }
            else{
                $model = $model->where('app_id', $app->id)->when($value, function ($q) use ($value) {
                    $q->where(function ($q) use ($value) {
                        $q = $q->where('email', 'LIKE', '%' .$value.'%')
                            ->orWhere('first_name','Like','%'.$value.'%')
                            ->orWhere('last_name','Like','%'.$value.'%');
                    });
                });
            }

            $model = $model
                ->has('latestPaymentHasMany')
                ->with(['latestPaymentHasMany', 'payProtectUser', 'userDetails' , 'emergency' => function ($q) {
                },
                    'coupon_usage' => function ($q) use ($value) {
                        $q->with(['couponCode' => function($q) {
                            $q->select('id','code');
                        } ]);

                    },
                    'usage' => function($q){
                        $q->with(['couponCode' => function($q) {
                            $q->select('id','code');
                        } ]);
                    }
                ])
                ->orderByRaw('(Select max(created_at) from vet_care_user_payments p where p.user_id = vet_care_users.id ) desc');

            $model = $model->where('app_id', $app->id);

            if (isset($input['pagination']) && $input['pagination'] != "") {
                $this->paginate = true;
                $model = $model->paginate($this->noOfRecordPerPage);
            } else {
                $model = $model->get();
            }

            //call to a resource collection
            // $model = UserPaymentResource::collection($model);

            $model = VetCareUserPaymentResource::collection($model);

            /*
            $model = VetCareUserPayment::whereHas('user',function($q) use($app,$value){
                $q->where('app_id',$app->id);
                $q->where(function($q) use($app,$value){
                    $q->where('email','Like','%'.$value.'%')
                    ->orWhere(function($q) use($app,$value){
                        $q->where('email','Like','%'.$value.'%')->orWhere('first_name','Like','%'.$value.'%')
                        ->orWhere('last_name','Like','%'.$value.'%');
                    });
                });
            });

            $model = $model->with(['user'=> function($q) use ($value){
//
//                $q->with(['usage'=>function($q){
//                    $q->with('couponCode.model:id,other','package');
//                },'coupon_usage.couponCode.model:id,other']);
                $q->with(['coupon_usage' => function ($q) use ($value) {
                    $q->with(['couponCode' => function($q) {
                        $q->select('id','code');
                    } ]);

                },
                    'usage' => function($q){
                    $q->with(['couponCode' => function($q) {
                        $q->select('id','code');
                    } ]);
                }]);
            }]);

            if (isset($input['pagination']) && $input['pagination'] != "") {
                $this->paginate = true;
                //Use case when there is a date filter
                if ($request->has('date_from') && $request->has('date_to')) {
                    $model = $model->whereBetween('created_at',
                        [$input['date_from'] . " 00:00:00", $input['date_to'] . " 23:59:00"]
                    );
                }
                if(@$request->has('status')){
                    $status = @$input['status'];
                    $model = $model->where('status',$status);
                }

                if($input['export'] === 'true' || $input['export'] === true){
                    $this->paginate = false;
                    $users =  $model->get();
                }
                else{
                    $users =  $model->paginate($this->noOfRecordPerPage);

                }

//                dd($users);
                $users = ClinicPaymentResource::collection($users);
            }
            */


            return $this->successResponse($model, 'Successfully Record Fetched.', $this->paginate);
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }

    }

    public function userFeedbacks(Request $request){
        $input = $request->only('search_value', 'search_by', 'page', 'pagination', 'perPage', 'app_id','export','date_from','date_to','user_id','package_id');
        try {
            $app = $this->user->app()->first();

            if(!$app)
            {
                return $this->errorResponse('No App is linked with this Clinic.', 404);
            }

            $value = isset($input['search_value'])?$input['search_value']:'';

            $model = VetCareUserFeedback::latest();
            $model = $model->with(['defaultPet','usage.package','usageLatest.package','payment','userDetails','vetCareUserFeedbacks.vet','pets']);

            if (isset($input['pagination']) && $input['pagination'] != "") {
                $this->paginate = true;
                //Use case when there is a date filter
                if ($request->has('date_from') && $request->has('date_to')) {
                    $model = $model->whereBetween('created_at',
                        [$input['date_from'] . " 00:00:00", $input['date_to'] . " 23:59:00"]
                    );
                }
                if(@$request->has('package_id')){
                    $package_id = @$input['package_id'];
                    $eagerloading = $model->whereHas('usageLatest',function($q) use($package_id){
                        $q = $q->where('package_id',$package_id);
                    });
                }
                else{
                    $eagerloading = $model->with(['usageWithThrashed.package','usageSubscription'=>function($q){
                        $q->with('subscriptonsData');
                    }]);
                }
                if($input['export'] === 'true' || $input['export'] === true){
                    $this->paginate = false;
                    $users =  $eagerloading->where('app_id',$app->id)->latest()->get();
                }
                else{
                    $users =  $eagerloading->where('app_id',$app->id)->latest()->paginate($this->noOfRecordPerPage);

                }
            }
            else{
                $users =  $model->where('app_id',$app->id)->where('id',$request->user_id)->get();
            }

            return $this->successResponse($users, 'Record Fetched Successfully .', $this->paginate);
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }

    }

    public function vetFeedbacks(Request $request){
        $input = $request->only('search_value', 'search_by', 'page', 'pagination', 'perPage', 'app_id','export','date_from','date_to','user_id','package_id');
        try {
            $app = $this->user->app()->first();

            if(!$app)
            {
                return $this->errorResponse('No App is linked with this Clinic.', 404);
            }

            $value = isset($input['search_value'])?$input['search_value']:'';
            $model = Feedback::latest();
            $model = $model->where('app_id',$app->id);
            $model = $model->with(['video','chat','reason','recommendation']);
            if($value != ''){
                $model = $model->whereHas('video.vcUser',function($q) use($value){
                    $q->where('email','Like','%'.$value.'%')
                    ->orWhere(function($q) use($value){
                        $q->where('email','Like','%'.$value.'%')->orWhere('first_name','Like','%'.$value.'%')
                        ->orWhere('last_name','Like','%'.$value.'%');
                    });
                });

                $model = $model->where('app_id',$app->id);
                $model = $model->orWhereHas('video.vet',function($q) use($value){
                    $q->where('email','Like','%'.$value.'%')
                    ->orWhere(function($q) use($value){
                        $q->where('email','Like','%'.$value.'%')->orWhere('first_name','Like','%'.$value.'%')
                        ->orWhere('last_name','Like','%'.$value.'%');
                    });
                });

                $model = $model->where('app_id',$app->id);
                $model = $model->orWhereHas('chat.vcUser',function($q) use($value){
                    $q->where('email','Like','%'.$value.'%')
                    ->orWhere(function($q) use($value){
                        $q->where('email','Like','%'.$value.'%')->orWhere('first_name','Like','%'.$value.'%')
                        ->orWhere('last_name','Like','%'.$value.'%');
                    });
                });

                $model = $model->where('app_id',$app->id);
                $model = $model->orWhereHas('chat.vet',function($q) use($value){
                    $q->where('email','Like','%'.$value.'%')
                    ->orWhere(function($q) use($value){
                        $q->where('email','Like','%'.$value.'%')->orWhere('first_name','Like','%'.$value.'%')
                        ->orWhere('last_name','Like','%'.$value.'%');
                    });
                });
            }

            $model = $model->where('app_id',$app->id);
            // if ($request->has('date_from') && $request->has('date_to')) {
            //     $model = $model->whereBetween('created_at',
            //         [$input['date_from'] . " 00:00:00", $input['date_to'] . " 23:59:00"]
            //     );
            // }
            $model = $model->where('app_id',$app->id);

            // return $this->successResponse($model, 'Record Fetched Successfully .', $this->paginate);

            if (isset($input['pagination']) && $input['pagination'] != "") {
                $this->paginate = true;

                if($request->has('export') && $request->export === 'true' || $request->export === true){
                    $this->paginate = false;
                    $model =  $model->where('app_id',$app->id)->latest()->get();
                }
                else{
                    $model =  $model->where('app_id',$app->id)->latest()->paginate($this->noOfRecordPerPage);
                }
            }
            else{
                $model =  $model->where('app_id',$app->id)->latest()->get();
            }

            $model = VetFeedbackResource::collection($model);


            return $this->successResponse($model, 'Record Fetched Successfully .', $this->paginate);
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }

    }

    public function vetEmailFeedbacks(VetEmailFeedbacksRequest $request){
//        $input = $request->only('email','app_id','export','date_from','date_to');
        try {
            $app = $this->user->app()->first();
            $email = isset($request->email) ? str_replace(' ','',$request->email) : '';
            $export = isset($request->export) ? $request->export : 'pdf';
            $export = strtolower($export);
            if ($export != 'pdf' && $export != 'excel') {
                return $this->errorResponse('The export field is required, should be "pdf" or "excel".', 404);
            }

            if (!$email) {
                return $this->errorResponse('The email field is required', 404);
            }

            if(!$app)
            {
                return $this->errorResponse('No App is linked with this Clinic.', 404);
            }

            $model = Feedback::latest();
            $model = $model->where('app_id',$app->id);
            $model = $model->with(['video','chat','reason','recommendation']);

             if ($request->has('date_from') && $request->has('date_to')) {
                 $model = $model->whereBetween('created_at',
                     [$request->date_from . " 00:00:00", $request->date_to . " 23:59:59"]
                 );
             }

             $data = VetFeedbackResource::collection($model->get());
             $response['export_type'] = $export;
             $response['data'] = $data;
                if ($export == 'pdf') {
                    $filename = date('d-m-Y'). '_' . time() . '_VetFeedbacks.pdf';
                    $pdf = \PDF::loadView('emailFeedbackPdfView', $response)->setPaper('a4', 'landscape');
                    $attachment = $pdf->output();
                    $uploaded_file = $this->uploadFilePublicRepoV2($attachment,'s3','feedbacks', $filename);
                } else {
                    $filename = date('d-m-Y'). '_' . time() . '_VetFeedbacks.xlsx';
                    $attachment = \Excel::store(new SendFeedback($response), 'feedbacks/'.$filename, 's3');
                    $chk_file = Storage::disk('s3')->url('feedbacks/'.$filename.'');
                    $uploaded_file = $chk_file;
                }

            $from_address = '';
            $email_response['data'] = '';
            if ($model->get()->count() > 0) {
                 $subject = 'Vet Feedbacks';
                 if (str_contains($email, ',') || str_contains($email, ';')) {
                     if (str_contains($email, ',')) {
                         $email_to = explode(',', $email);
                     } elseif (str_contains($email, ';')) {
                         $email_to = explode(';', $email);
                     }
                     foreach ($email_to as $email) {
                        Mail::to($email)->send(new EmailFeedbacks($email_response, $from_address, $email, $subject, $uploaded_file));
                     }
                 } else {
                        Mail::to($email)->send(new EmailFeedbacks($email_response, $from_address, $email, $subject, $uploaded_file));
                 }
                 return $this->successResponse($model, '' . $model->get()->count() . ' Record Fetched Successfully and emailed.');
             } else {
                 return $this->successResponse($model, '' . $model->get()->count() . ' Record Fetched Successfully.');
             }

            return $this->successResponse($model, 'Record Fetched Successfully .', $this->paginate);
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }

    }

//    public function pdfview(Request $request,$id)
//    {
//        view()->share('items',$request->all());
//        if($request->has('download')){
//            $pdf = (new \Barryvdh\DomPDF\PDF)->loadView('pdfview');
//            return $pdf->download('pdfview.pdf');
//        }
//
//        return view('protectClientPdfView');
//    }

}
