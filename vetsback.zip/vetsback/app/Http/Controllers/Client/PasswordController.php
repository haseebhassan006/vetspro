<?php

namespace App\Http\Controllers\Client;

use App\Rules\MatchOldPassword;
use App\VetCare;
use App\VetCareUser;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;

class PasswordController extends Controller
{
    //
    public function __construct()
    {
        $this->middleware('auth:vcusers');
    }

    public function store(Request $request)
    {
        try {
            $request->validate([
                'current_password' => ['required', new MatchOldPassword],
                'new_password' => ['required'],
                'new_confirm_password' => ['same:new_password'],
            ]);

            $user = VetCareUser::find(auth('vcusers')->user()->id)->update(['password' => Hash::make($request->new_password)]);

            return $this->successResponse($user, 'Password change successfully');
        }
        catch (\Exception $e){
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }
}
