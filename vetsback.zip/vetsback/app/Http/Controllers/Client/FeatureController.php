<?php

namespace App\Http\Controllers\Client;

use App\VetCareUser;
use App\VetCarePackage;
use App\VetCarePackageUsage;
use App\VetCareSubscription;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\Traits\VetCareUserPaymentTrait;
use Stripe\Exception\ApiErrorException;
use Illuminate\Database\Eloquent\ModelNotFoundException;

class FeatureController extends Controller
{

    use VetCareUserPaymentTrait;

    private $noOfRecordPerPage = 10;
    private $paginate = false;
    private $user;

    public function __construct()
    {
        $this->middleware('auth:clinic');
        $this->user = $this->guard()->user();
    ///    $this->app = auth()->check()?$this->user->app()->first():null;
        $this->app = $this->user?$this->user->app()->first():null;

    }

    public function guard()
    {
        return Auth::guard('clinic');
    }

    // Delete User
    public function deleteUser($id,Request $request)
    {
        try {
            $user = VetCareUser::findOrfail($id);
            // Check if user belongs to this clinic
            if ($this->app->id != $user->app_id) {
                return $this->errorResponse('User does not belong to this clinic', 422);
            }

            if($user){
                if(!empty($user->stripe_id)){
                    $this->initialize($user->app_id);
                    try {
                        $this->deleteCustomer($user->stripe_id);
                    } catch (ApiErrorException $e){
                        return $this->errorResponse('Error from stripe while removing user from stripe. Error Details : '.$e->getMessage(), 406);
                    }
                }
            }
            $user->update(['is_deleted_by'=>'clinic']);
            $user->delete();
            $data = array(
                "user" => $user
            );
            return $this->successResponse($data, 'Successfully Record Deleted.');
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), 402);
        }
    }

    // Unsubscribe User
    public function unsubscribeUser($id,Request $request)
    {
        try{
            $user = VetCareUser::findOrfail($id);
            // Check if user belongs to this clinic
            if ($this->app->id != $user->app_id) {
                return $this->errorResponse('User does not belong to this clinic', 422);
            }
            //Check for recurring payment
            if($user->usage()->count() > 0){
                $check_interval = VetCarePackage::where('id',$user->usage[0]->package_id)->first();
                if($check_interval && ($check_interval->interval == 'month' || $check_interval->interval == 'day')){
                    $data = VetCareSubscription::where('user_id',$user->id)->where('status','<>','canceled')->firstOrFail();
                    $this->initialize($user->app_id);
                    $stripeResponse = $this->unsubscribe($data->subscription_id);
                    if($stripeResponse){
                        $data->update(['status' => $stripeResponse['status']]);
                    }
                    $data->delete();
                    if($check_interval->type == 'protect'){
                        $user->removeRole('protect_users');
                        $user->assignRole("users");
                    }
                }else{
                    $data = VetCareSubscription::where('user_id',$user->id)->first();
                    if($data){
                        $data->delete();
                    }
                    $user->assignRole("users");
                }
                $trash = VetCarePackageUsage::where('user_id',$user->id)->delete();

                return $this->successResponse($trash, 'User has been unsubscribed successfully.');
            }
            else{
                return $this->errorResponse('This user is not subscribed to any package',406);
            }
        }
        catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), 402);
        }
        catch (ApiErrorException $e){
            return $this->errorResponse('Error from stripe while removing user from stripe. Error Details : '.$e->getMessage(), 406);
        }
    }
}
