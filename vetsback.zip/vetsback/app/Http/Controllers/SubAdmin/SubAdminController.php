<?php

namespace App\Http\Controllers\SubAdmin;

use JWTAuth;
use Validator;
use App\SubAdmin;
use Carbon\Carbon;
use Illuminate\Http\Request;
use App\AdminNotificableUser;
use App\Traits\TwilioSDKTrait;
use Illuminate\Support\Facades\DB;
use App\Traits\OtherTwilioSDKTrait;
use Illuminate\Support\Facades\App;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\Http\Requests\AdminUserRequest;
use Illuminate\Database\QueryException;
use App\Http\Requests\SubAdminLoginRequest;
use App\Http\Requests\subAdminUpdateRequest;
use Carbon\Exceptions\UnknownGetterException;
use App\Http\Requests\SubAdminRegisterRequest;
use stdClass;


class SubAdminController extends Controller
{
    protected $user;
    use TwilioSDKTrait;
    use OtherTwilioSDKTrait;
    private $noOfRecordPerPage = 10;
    private $paginate = false;

    public function __construct()
    {
        $this->generic();
        $this->construct();
    }

    /**
    * Get the guard to be used during authentication.
    *
    * @return \Illuminate\Contracts\Auth\Guard
    */
    public function guard()
    {
        return Auth::guard('staff');
    }

    /**
     * login API
     *
     * @return \Illuminate\Http\Response
     */
    public function login(SubAdminLoginRequest $request)
    {
        $data = $request->validated();

        try {
            $credentials = $request->only(['email', 'password']);
            if ($token = $this->guard()->attempt($credentials)) {
                $this->user = $this->guard()->user();
                if ($this->user->hasRole(['staff'])) {
                    $this->user->update(['is_online'=>1]);
                    $identity = 'staff-'.$this->user->id;
                    $success['token'] = $token;
                    $success['staffTwilioToken'] = $this->init($identity);
                    // $success['pawpTwilioToken'] = $this->accessToken();
                    $dateTime =  Carbon::now();
                    $this->user->AuthenticationHistory()->create([
                        'dateTime' => $dateTime,
                        'type' => 'login'
                    ]);
                    return $this->successResponse($success, 'logged in');
                } else {
                    return $this->errorResponse('Wrong credentials or missing access rights to application.');
                }
            } else {
                return $this->errorResponse('Wrong credentials or missing access rights to application.');
            }
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    /**
     * register API
     *
     * @param SubAdminRegisterRequest $request
     * @return \Illuminate\Http\Response
     */
    public function create(SubAdminRegisterRequest $request)
    {
        $validatedData = $request->validated();
        try{
            $staff = new SubAdmin;
            if(array_key_exists('password',$validatedData)){
                $pwd = $validatedData['password'];
                $validatedData['password'] = bcrypt($validatedData['password']);
            }
            $data = $staff->create($validatedData);
            $data->assignRole($request->role);
            //Add user to twilio account as well
            $attributes = ["user_id"=>$data->id,"role"=>$data->role,"email"=>$data->email];
            $identity = 'staff-'.$data->id;
            $dataToTwilio = [
                'attributes' => json_encode($attributes),
                'friendlyName' => $data->first_name.' '.$data->last_name,
                'identity'=> $identity
            ];
            $createUser = $this->createUser($dataToTwilio);
            $success['token'] = auth()->login($data);
            $success['staffTwilioToken'] = $this->init($identity);
            $success['staff'] = $data;

            $dateTime =  Carbon::now();
            $data->AuthenticationHistory()->create([
                'dateTime' => $dateTime,
                'type' => 'login'
            ]);
            return $this->successResponse($success, 'Successfully Created Staff.');
        }catch (RestException $e) {
            return $this->errorResponse($e->getMessage(),$e->getCode());
        }
        catch (QueryException $e) {
            switch ($e->getCode()) {
                case 23000:
                    $message = "Email already exists";
                break;
                default:
                    $message = "Try again. Query Error";
            }
            return $this->errorResponse($message,405);
        }
        catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(),$e->getCode());
        }
    }

    /**
     * add_profile user and validating through Request Class
     * @param subAdminUpdateRequest $request
     * @return \Illuminate\Http\Response
     */
    public function update($id,subAdminUpdateRequest $request)
    {
        $data = $request->validated();
       
        try{
            $user = SubAdmin::findOrfail($id);
            if(($user->is_active != 1) && $request->has('is_active') && $request->is_active == 1){
                // Only allow 7 staff active at a time
                $checkStaffActiveCount = SubAdmin::where('is_active' , 1)->where('id', '!=' , $id)->count();
                if($checkStaffActiveCount >= 7){
                    return $this->errorResponse('Can not activate more than 7 staff members at a time.',422);
                }
              }
            if(array_key_exists('password',$data)){
                $pwd = $data['password'];
                $data['password'] = bcrypt($data['password']);
            }
        $user->update($data);
            return $this->successResponse($user, 'Successfully Record Updated.');
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }
    /**
     * Delete
     * @param id $id
     * @return \Illuminate\Http\Response
     */
    public function deleted($id)
    {
        try {
            $user = SubAdmin::findOrfail($id);

            // Inactive sub-admin on soft delete
            $user->update(['is_active' => 0]);

            $user->delete();
            $data = array(
                "user" => $user
            );
            return $this->successResponse($data, 'Successfully Record Deleted.');
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }
    
    public function list(Request $request)
    {
        try {
            $user = new SubAdmin;
            if (isset($request['pagination']) && $request['pagination'] != "") {
                $this->paginate = true;
                $user = $user->paginate($this->noOfRecordPerPage);
            } else {
                $user_id = $request['user_id'];
                $user = $user->find($user_id);
            }
            $data = array(
                "user" => $user
            );
            return $this->successResponse($data, 'Successfully Fetch Staff List.');
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }

    /**
     * Logout user (Revoke the token)
     *
     * @return [string] message
     */
    public function logout()
    {
        if($this->guard()->user())
        {   
            $this->user = $this->guard()->user();
            $data = array(
                'is_online'=>0,
            );
            $this->user->update($data);

            $dateTime =  Carbon::now();
            $this->user->AuthenticationHistory()->create([
                'dateTime' => $dateTime,
                'type' => 'logout'
            ]);

            auth()->logout();
            return $this->successResponse(true, 'Successfully logged out');
        }
    }
}
