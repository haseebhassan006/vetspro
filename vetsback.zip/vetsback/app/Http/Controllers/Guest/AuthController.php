<?php

namespace App\Http\Controllers\Guest;

use App\App;
use App\Guest;
use App\Http\Requests\GuestAuthRequest;
use App\Http\Requests\UserRequest;
use App\Traits\TwilioSDKTrait;
use App\User;
use Carbon\Carbon;
use Illuminate\Database\QueryException;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;


use App\WebappUser;
use App\UserAppStatus;

class AuthController extends Controller
{
    use TwilioSDKTrait;

    public function __construct()
    {
        $this->generic();
    }
    /**
     * login and Register API
     *
     * @param UserRequest $request
     * @return \Illuminate\Http\Response
     */
    public function registerToLogin(GuestAuthRequest $request)
    {
        $validated = $request->validated();
        $guard_name = '';
        try {
            $validated['password'] = bcrypt($validated['email']);

            $app_id = $this->find_app($request->api_key);
            $validated['app_id'] = $app_id->id;
            //unset( $validated['api_key']);
            if($app_id->app_type == 'whitelabel'){
                $user = User::where(['email'=>$request->email])->first();
                $user->updateAppId($app_id->id);
                if(!$user){
                    $user = User::create($validated);
                }
                $guard_name = 'api';
            }
            elseif($app_id->app_type == 'sdk'){
                $user = Guest::where(['app_id'=>$app_id->id,'email'=>$request->email])->first();
                if(!$user){
                    $user = Guest::create($validated);
                }
                $guard_name = 'guests';
            }
                //Update or create new device
                $device = $user->devices->where('udid', $request->udid)->first();
                if (isset($device)) {
                    $user->devices()->where('udid', $request->udid)->update([
                        'device_token'=>$request->device_token,
                        'dev_type'=>$request->dev_type,
                        'app_version'=>$request->app_version,
                    ]);
                } else {
                    $user->devices()->create([
                        'rec_id'=>$user->id,
                        'device_token'=>$request->device_token,
                        'udid'=>$request->udid,
                        'dev_type'=>$request->dev_type,
                        'app_version'=>$request->app_version,
                    ]);
                }
                //dd(auth()->guard(''));
                $success['token'] = auth()->guard($guard_name)->login($user);
                $success['twilioToken'] = $this->init('app-'.$app_id->id.'_user-'.$user->id, $request->dev_type, $app_id->id);
                $success['user'] = auth()->guard($guard_name)->user();

                return $this->successResponse($success, 'logged in');

        }
        catch (QueryException | \Exception $e) {
            return $this->errorResponse($e->getMessage(), 401);
        }
    }

    public function logout(Request $request){
        try{
            $user = $request->user();
            if(@$user){
                $user->devices()->delete();
                //$user = auth()->user();
                auth()->logout();
                //$user = $this->guard()->logout();
            }


            return $this->successResponse($user, 'logged out');
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), $e->getCode());
            }
    }
    /**
     * Get the guard to be used during authentication.
     *
     * @return \Illuminate\Contracts\Auth\Guard
     */
    public function guard()
    {
        return Auth::guard('guests');
    }

}
