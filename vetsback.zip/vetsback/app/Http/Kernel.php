<?php

namespace App\Http;

use App\Http\Middleware\Cors;
use App\Http\Middleware\PawpAuth;
use App\Http\Middleware\PetHotline;
use App\Http\Middleware\IpMiddleware;
use App\Http\Middleware\goodCharlieMiddleware;
use App\Http\Middleware\handshakeAppsMiddleware;
use Illuminate\Foundation\Http\Kernel as HttpKernel;
use App\Http\Middleware\petvethotlineClientMiddleware;
use App\Http\Middleware\NoPaymentVetCareUserMiddleware;

class Kernel extends HttpKernel
{
    /**
     * The application's global HTTP middleware stack.
     *
     * These middleware are run during every request to your application.
     *
     * @var array
     */
    protected $middleware = [
       // \Fruitcake\Cors\HandleCors::class,
//       \App\Http\Middleware\PreflightResponse::class,
        \App\Http\Middleware\TrustProxies::class,
        \App\Http\Middleware\CheckForMaintenanceMode::class,
        \Illuminate\Foundation\Http\Middleware\ValidatePostSize::class,
        \App\Http\Middleware\TrimStrings::class,
        \Illuminate\Foundation\Http\Middleware\ConvertEmptyStringsToNull::class,
        //\Fruitcake\Cors\HandleCors::class,
        \App\Http\Middleware\Cors::class

    ];

    /**
     * The application's route middleware groups.
     *
     * @var array
     */
    protected $middlewareGroups = [
        'web' => [
            \App\Http\Middleware\EncryptCookies::class,
            \Illuminate\Cookie\Middleware\AddQueuedCookiesToResponse::class,
            \Illuminate\Session\Middleware\StartSession::class,
            // \Illuminate\Session\Middleware\AuthenticateSession::class,
            \Illuminate\View\Middleware\ShareErrorsFromSession::class,
            \App\Http\Middleware\VerifyCsrfToken::class,
            \Illuminate\Routing\Middleware\SubstituteBindings::class,
            \App\Http\Middleware\IpMiddleware::class,

        ],

        'api' => [
            'throttle:200,1',
            'bindings',
        ],

        'client' => [
            'throttle:200,1',
            'bindings',
            \App\Http\Middleware\ClientRouting::class,
        ],

        'clinic' => [
            'throttle:200,1',
            'bindings',
        ],
    ];

    /**
     * The application's route middleware.
     *
     * These middleware may be assigned to groups or used individually.
     *
     * @var array
     */
    protected $routeMiddleware = [
        'auth' => \App\Http\Middleware\Authenticate::class,
        'auth.basic' => \Illuminate\Auth\Middleware\AuthenticateWithBasicAuth::class,
        'bindings' => \Illuminate\Routing\Middleware\SubstituteBindings::class,
        'cache.headers' => \Illuminate\Http\Middleware\SetCacheHeaders::class,
        'can' => \Illuminate\Auth\Middleware\Authorize::class,
        'guest' => \App\Http\Middleware\RedirectIfAuthenticated::class,
        'signed' => \Illuminate\Routing\Middleware\ValidateSignature::class,
        'throttle' => \Illuminate\Routing\Middleware\ThrottleRequests::class,
        'verified' => \Illuminate\Auth\Middleware\EnsureEmailIsVerified::class,
        'assign.guard' => \App\Http\Middleware\AssignGuard::class,
        'jwt.auth' => \Tymon\JWTAuth\Http\Middleware\Authenticate::class,
        'role' => \Spatie\Permission\Middlewares\RoleMiddleware::class,
        'permission' => \Spatie\Permission\Middlewares\PermissionMiddleware::class,
        'role_or_permission' => \Spatie\Permission\Middlewares\RoleOrPermissionMiddleware::class,
        'pawpAuth'=> \App\Http\Middleware\PawpAuth::class,
        'petCube'=> \App\Http\Middleware\PetCube::class,
        'vidaahAuth'=> \App\Http\Middleware\VidaahAuth::class,
        'GoodCharlieAuth'=> \App\Http\Middleware\GoodCharlieAuth::class,
        'petHeavenAuth'=> \App\Http\Middleware\PetHeavenAuth::class,
        'onePetAuth'=> \App\Http\Middleware\OnePetAuth::class,
        'nimbleAuth'=> \App\Http\Middleware\NimbleAuth::class,
        'petAcumen'=> \App\Http\Middleware\PetAcumen::class,
        'petHotline'=>\App\Http\Middleware\PetHotline::class,
        'cors'=>\App\Http\Middleware\Cors::class,
        'petstablished'=>\App\Http\Middleware\Petstablished::class,
        'adminOnly'=>\App\Http\Middleware\CheckIfAdmin::class,
        'staffOnly'=>\App\Http\Middleware\Staff::class,
//        'PreflightResponse' => \App\Http\Middleware\PreflightResponse::class
        'clientApp'=>\App\Http\Middleware\ClientRouting::class,
        'noPaymentVCAuth'=>\App\Http\Middleware\NoPaymentVetCareUserMiddleware::class,
        'goodCharlieMiddleware'=>\App\Http\Middleware\goodCharlieMiddleware::class,
        'handshakeAppsMiddleware' => \App\Http\Middleware\handshakeAppsMiddleware::class,
        'handshakeAppsV2Middleware' => \App\Http\Middleware\handshakeAppsV2Middleware::class,
        'petvethotlineClientMiddleware'=>\App\Http\Middleware\petvethotlineClientMiddleware::class,

        'trainerverified'=>\App\Http\Middleware\TrainerVerified::class,
        'petcubeUserRegistraionDateUpdate'=>\App\Http\Middleware\PetcubeUserRegistraionDateUpdate::class,
        'griffin'=> \App\Http\Middleware\Griffin::class,

    ];

    /**
     * The priority-sorted list of middleware.
     *
     * This forces non-global middleware to always be in the given order.
     *
     * @var array
     */
    protected $middlewarePriority = [
        \Illuminate\Session\Middleware\StartSession::class,
        \Illuminate\View\Middleware\ShareErrorsFromSession::class,
        \App\Http\Middleware\Authenticate::class,
        \Illuminate\Session\Middleware\AuthenticateSession::class,
        \Illuminate\Routing\Middleware\SubstituteBindings::class,
        \Illuminate\Auth\Middleware\Authorize::class,
    ];
}
