<?php

namespace App\Listeners;

use App\Events\EndChatEmailEvent;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Support\Facades\Mail;
use App\Mail\SendChatOnEmail;

class SendEndChatEmail
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  EndChatEmailEvent  $event
     * @return void
     */
    public function handle(EndChatEmailEvent $event)
    {
        //
        try{ // need to add queue jobs here as it will take alot to send email on end chat
            Mail::to($event->chatDetail['send_email_on'])->send(new SendChatOnEmail($event->chatDetail['vetname'],ucfirst($event->chatDetail['username']),ucfirst($event->chatDetail['app_name']),$event->chatDetail['chatdetails']));
        } catch (\Exception $e){
            return $this->errorResponse($e->getMessage(), $e->getCode());
        }
    }
}
