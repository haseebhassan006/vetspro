<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable;
use Tymon\JWTAuth\Contracts\JWTSubject;
use Spatie\Permission\Traits\HasRoles;
use JWTAuth;
use App\Traits\CustomSearch;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Contracts\Auth\MustVerifyEmail;



class SubAdmin extends Authenticatable implements JWTSubject
{
    use HasRoles;
    use SoftDeletes;
    use CustomSearch;

    protected $fillable = ['first_name','last_name','is_online','country','email','password','is_active','is_call'];
    protected $guard_name = 'staff';

    protected $hidden = [
        'password'
    ];
    protected $appends = ['role_names','queue'];
    /** Get the identifier that will be stored in the subject claim of the JWT.
    *
    * @return mixed
    */
   public function getJWTIdentifier()
   {
       return $this->getKey();
   }

   /**
    * Return a key value array, containing any custom claims to be added to the JWT.
    *
    * @return array
    */
   public function getJWTCustomClaims()
   {
       return [];
   }

   public function attachments()
    {
        return $this->morphMany(TemplateAttachment::class, 'attachmentable');
    }

    public function notable()
    {
        return $this->morphMany(StaffNote::class, 'notable');
    }

    public function AuthenticationHistory()
    {
        return $this->morphMany(AuthenticationHistory::class, 'model');
    }

    public function queue(){
        return $this->hasMany(StaffQueue::class ,'staff_id','id');
    }
    public function getQueueAttribute()
    {
        return count($this->queue()->where('status',0)->get()) > 0 ? true : false ; 
    }

    public function devices(){
        return $this->morphOne(Device::class, 'model');
    }

    public function video(){
        return $this->morphMany(VideoCall::class, 'model');
    }

    public function getRoleNamesAttribute()
    {
        return $this->getRoleNames();
    }

    public function notification(){
        return $this->belongsTo(Notification::class,'id','user_to_notify');
    }

    public function userFeedback(){
        return $this->morphMany(VetCareUserFeedback::class, 'model');
    }
}
