<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CouponUsage extends Model
{
    //
    protected $guarded = [];
    public function model()
    {
        return $this->morphTo();
    }

    public function coupon(){
        return $this->hasOne(Coupon::class,'id','coupon_id');
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function payment()
    {
        return $this->hasOne(Payment::class, 'created_at', 'use_datetime');
    }
}
