<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AdminNotificableUser extends Model
{
    //
    protected $fillable = ['status'];
    public $timestamps = false;
}
