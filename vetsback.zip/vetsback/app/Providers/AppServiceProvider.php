<?php

namespace App\Providers;

use App\Observers\TrainerReviewObserver;
use App\Observers\UserObserver;
use App\TrainerReview;
use App\User;
use Illuminate\Support\ServiceProvider;
use Laravel\Telescope\IncomingEntry;
use Laravel\Telescope\Telescope;
use Illuminate\Support\Facades\Schema;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
        Telescope::ignoreMigrations();
//        if ($this->app->isLocal()) {
//            $this->app->register(TelescopeServiceProvider::class);
//        }
//        Telescope::filter(function (IncomingEntry $entry) {
//            if (env('TELESCOPE_KEY', false) || $this->app->isLocal()) {
//                return true;
//            }
//        });
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        //
        Schema::defaultStringLength(191);

        User::observe(UserObserver::class);
        TrainerReview::observe(TrainerReviewObserver::class);
    }
}
