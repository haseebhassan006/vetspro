<?php

namespace App\Providers;

use Illuminate\Support\Facades\Gate;
use Laravel\Telescope\EntryType;
use Laravel\Telescope\IncomingEntry;
use Laravel\Telescope\Telescope;
use Laravel\Telescope\TelescopeApplicationServiceProvider;

class TelescopeServiceProvider extends TelescopeApplicationServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
//         Telescope::night();

        $this->hideSensitiveRequestDetails();
        // Add Telescope tag status
//        Telescope::tag(function (IncomingEntry $entry) {
//            $response = array();
//
//            if ($entry->type === 'request') {
//                $response['status'] = $entry->content['response_status'];
//                //['status:'.$entry->content['response_status']];
//            }
//            if ($entry->type === 'request' && str_contains($entry->content['uri'], '/api/one-pet')) {
//                $response['app'] = 'one-pet';
//                //return ['status:'.$entry->content['response_status'],'app:one-pet'];
//            }
//            if ($entry->type === 'request' && str_contains($entry->content['uri'], '/api/vidaah')) {
//                $response['app'] = 'vidaah';
////                return ['status:'.$entry->content['response_status'],'app:vidaah'];
//            }
//            if ($entry->type === 'request' && str_contains($entry->content['uri'], '/api/pawp')) {
//                $response['app'] = 'pawp';
////                return ['status:'.$entry->content['response_status'],'app:pawp'];
//            }
//            if ($entry->type === 'request' && str_contains($entry->content['uri'], '/api/pet-acumen')) {
//                $response['app'] = 'pet-acumen';
////                return ['status:'.$entry->content['response_status'],'app:pet-acumen'];
//            }
//            if ($entry->type === 'request' && str_contains($entry->content['uri'], '/api/petHotline')) {
//                $response['app'] = 'petHotline';
////                return ['status:'.$entry->content['response_status'],'app:petHotline'];
//            }
//            if ($entry->type === 'request' && str_contains($entry->content['uri'], '/api/pet-cube')) {
//                $response['app'] = 'pet-cube';
////                return ['status:'.$entry->content['response_status'],'app:pet-cube'];
//            }
//            return $response;
////            return [];
//        });
        Telescope::tag(function (IncomingEntry $entry) {
            if ($entry->type === 'request') {
                return ['status:'.$entry->content['response_status']];
            }
            return [];
        });

        Telescope::filter(function (IncomingEntry $entry) {
//            if ($this->app->environment('local')) {
//                return true;
//            }
            if ($entry->type === EntryType::REQUEST) {
                $entry->tags([
                    $entry->content['uri'],
                    $entry->content['method'],
                    $entry->content['response_status'],
                    $entry->content['controller_action'],
                ]);
            }
//            if ($entry->type === EntryType::REQUEST
//                && isset($entry->content['uri'])) {
//                return false;
//            }
//            if ($entry->type === EntryType::REQUEST
//                && isset($entry->content['uri'])
//                && $entry->content['middleware'] == 'web') {
//                return false;
//            }

            if(isset($entry->content['middleware']) && !empty($entry->content['middleware'])){
                if ($entry->type === EntryType::REQUEST
                    //&& isset($entry->content['uri'])
                    && $entry->content['uri'] === '/success' && $entry->content['middleware'][0] == 'web' && $entry->content['method'] == 'GET') {
                    return true;
                }
                if ($entry->type === EntryType::REQUEST
                    && isset($entry->content['uri'])
                    && str_contains($entry->content['uri'], '/') && $entry->content['middleware'][0] == 'web' && $entry->content['method'] == 'GET') {
                    return false;
                }
            }

            if (env('TELESCOPE_KEY', false) || $this->app->isLocal() ||  $this->app->isProduction()) {
                return true;
            }
            return $entry->isReportableException() ||
                   $entry->isFailedRequest() ||
                   $entry->isFailedJob() ||
                   $entry->isScheduledTask() ||
                   $entry->hasMonitoredTag();
        });
    }

    /**
     * Prevent sensitive request details from being logged by Telescope.
     *
     * @return void
     */
    protected function hideSensitiveRequestDetails()
    {
        if ($this->app->environment('local')) {
            return;
        }
        Telescope::hideRequestParameters(['_token','number','cvc']);

        Telescope::hideRequestHeaders([
            'cookie',
            'x-csrf-token',
            'x-xsrf-token',
        ]);
    }

    /**
     * Register the Telescope gate.
     *
     * This gate determines who can access Telescope in non-local environments.
     *
     * @return void
     */
    protected function gate()
    {
        Gate::define('viewTelescope', function ($user) {
            return in_array($user->email, [
                //
                'adnan@inv.com'
            ]);
        });
    }
}
