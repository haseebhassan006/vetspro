<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class VideoGalleryCategory extends Model
{
    //
    use SoftDeletes;
    protected $fillable = ['category_name','status'];

    public function video(){
        return $this->hasMany(VideoGallery::class,'category_id','id');
    }
}
