<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PaymentProtectUser extends Model
{
    //
    protected $dateFormat = 'Y-m-d H:i:s';
    protected $fillable = ['payment_id','subscription_timestamp','user_id'];
    public $timestamps = false;

}
