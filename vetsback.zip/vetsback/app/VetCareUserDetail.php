<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class VetCareUserDetail extends Model
{
    //
    //protected $guarded = [];
    protected $fillable = ['profile','other'];
    //protected $appends = ['profile_url'];
    protected $casts = ['other'=>'array'];


    public function user(){
        return $this->belongsTo(VetCareUser::class);
    }
    //define accessor
    public function getProfileUrlAttribute()
    {
        $s3 = env('AWS_URL', '');
        return $s3.$this->profile;
    }
}
