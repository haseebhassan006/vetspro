<?php

namespace App;

use App\Http\Controllers\VideoController;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Subscriptions extends Model
{
    //
    use SoftDeletes;
    protected $guarded = [];

}
