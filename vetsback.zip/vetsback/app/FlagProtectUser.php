<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FlagProtectUser extends Model
{
    //
    public $timestamps = false;

    protected $fillable = ['user_id','emergency_id','flag','notes','app_id'];

//    public function webappUser(){
//        return $this->belongsTo(WebappUser::class);
//    }
//
//    public function user(){
//        return $this->belongsTo(User::class);
//    }

}
