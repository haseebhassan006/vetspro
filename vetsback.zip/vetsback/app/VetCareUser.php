<?php

namespace App;

use App\Traits\CustomSearch;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Spatie\Permission\Traits\HasRoles;
use Tymon\JWTAuth\Contracts\JWTSubject;

class VetCareUser extends Authenticatable implements JWTSubject
{
    //
    use Notifiable;
    use SoftDeletes;
    use HasRoles;
    use CustomSearch;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $guard_name = 'vcusers';

    protected $appends = ['role_names','app','notesEmergency','emergency'];

    protected $fillable = [
        'first_name', 'last_name', 'email', 'password', 'app_id', 'is_online', 'status', 'stripe_id', 'card_id', 'trail_ends_at','next_emergency_activation_date','extra','is_deleted_by','pet_tracking_code'
    ];

    protected $searchable = ['first_name', 'last_name', 'email'];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token'
    ];
    //protected $guarded = [];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
        'extra' => 'json',
    ];
    //protected $appends = ['user_details'];

    // Rest omitted for brevity

    /**
     * Get the identifier that will be stored in the subject claim of the JWT.
     *
     * @return mixed
     */
    public function getJWTIdentifier()
    {
        return $this->getKey();
    }

    /**
     * Return a key value array, containing any custom claims to be added to the JWT.
     *
     * @return array
     */
    public function getJWTCustomClaims()
    {
        return [];
    }

    public function getRoleNamesAttribute(){
        return $this->getRoleNames();
    }

    public function getAppNameAttribute(){
        return $this->getAppAttribute();
    }

    public function userDetails(){
        return $this->hasOne(VetCareUserDetail::class,'vet_care_user_id','id')->latest();
    }

    public function apps(){
        return $this->hasMany(App::class,'id','app_id');
    }

    public function pets(){
        return $this->morphMany(VetCarePet::class, 'model');
    }

    public function devices(){
        return $this->morphMany(Device::class, 'model');
    }

    public function latestDevices(){
        return $this->morphOne(Device::class, 'model')->latest();
    }

    public function chats(){
        return $this->belongsTo(Chat::class);
    }

    public function getAppAttribute(){
        return $this->apps()->pluck('name');
    }

    public function getUserDetails($id){
        return User::find($id);
    }

    public function updateAppId($value){
        return $this->load('apps')->update(['app_id'=>$value]);
    }

    public function userDetailData(){
        return $this->load('user_details');
    }

    public function userAuthenticationHistory(){
        return $this->morphMany(AuthenticationHistory::class, 'model');
    }

    public function videoCall(){
        return $this->belongsTo(VideoCall::class,'id','user_id');
    }

    public function couponRedeem(){
        return $this->morphMany(CouponUsage::class, 'model');
    }

    public function coupon(){
        return $this->morphMany(Coupon::class, 'model');
    }

    public function usage(){
        return $this->hasMany(VetCarePackageUsage::class,'user_id','id');
    }

    public function trashUsage(){
        return $this->hasMany(VetCarePackageUsage::class,'user_id','id')->withTrashed();
    }

    public function usageLatest(){
        return $this->hasOne(VetCarePackageUsage::class,'user_id','id');
    }

    public function packages(){
        return $this->hasMany(VetCarePackage::class,'user_id','id');
    }

    public function payment(){
        return $this->hasMany(VetCareUserPayment::class,'user_id','id');
    }

    public function latestPayment(){
        return $this->hasOne(VetCareUserPayment::class,'user_id','id')->latest();
    }

    public function emergency(){
        $model = $this->hasMany(EmergencyVetClient::class,'user_id','id')->where('app_id',$this->app_id);
        // If app id is null
        if($this->app_id == null && request()->key != null && appId_by_key(request()->key)){
            $model = $this->hasMany(EmergencyVetClient::class,'user_id','id')
            ->where('app_id',appId_by_key(request()->key));
        }
       return $model;
    }

    public function emergencyLatest(){
        $model = $this->hasMany(EmergencyVetClient::class,'user_id','id')->where('app_id',$this->app_id)->latest();
        // If app id is null
        if($this->app_id == null && request()->key != null && appId_by_key(request()->key)){
            $model = $this->hasMany(EmergencyVetClient::class,'user_id','id')
            ->where('app_id',appId_by_key(request()->key))->latest();
        }
       return $model;
    }

    public function emergencyLatestFilter(){
        $model = $this->hasOne(EmergencyVetClient::class,'user_id','id')->where('app_id',$this->app_id)->latest();
        // If app id is null
        if($this->app_id == null && request()->key != null && appId_by_key(request()->key)){
            $model = $this->hasOne(EmergencyVetClient::class,'user_id','id')
            ->where('app_id',appId_by_key(request()->key))
            ->where('is_latest', 1)
            ->latest();
        }
       return $model;
    }

    public function emergencyFilter(){
        // return $this->hasMany(EmergencyVetClient::class,'user_id','id');

        $model = $this->hasMany(EmergencyVetClient::class,'user_id','id')->where('app_id',$this->app_id)->latest();
        // If app id is null
        if($this->app_id == null && request()->key != null && appId_by_key(request()->key)){
            $model = $this->hasMany(EmergencyVetClient::class,'user_id','id')
            ->where('app_id',appId_by_key(request()->key))->latest();
        }
       return $model;
     }

    public function getEmergencyAttribute(){
        return $this->emergency()->latest()->first();
    }

    public function coupon_usage(){
        return $this->hasOne(VetCareCouponUsage::class,'user_id','id');
    }

    public function payProtectUser(){
        return $this->hasOne(VetCarePaymentProtectUser::class,'user_id','id');
    }

    public function notesEmergency(){
        return $this->hasOne(NoteProectUser::class,'user_id','id');
    }

    public function getNotesEmergencyAttribute(){
        if($this->emergency()->first()){
            return $this->emergency()->latest()->first()->notesEmergency()->latest()->first();
        }
    }

    public function flagsEmergency(){
        return $this->hasOne(FlagProtectUser::class,'user_id','id');
    }

    public function defaultPet()
    {
        return $this->belongsToMany(VetCarePet::class, 'pet_vet_care_user_pivot', 'vet_care_user_id' , 'pet_id');
    }

    public function packageUsageDetail(){
        return $this->hasMany(VetCarePackageUsage::class,'user_id','id')->with('package');
    }

    public function latestPaymentHasMany(){
        if (request()->has('date_from') && request()->has('date_to')) {
            $input = request()->only('date_from','date_to');
            return
            $this->hasMany(VetCareUserPayment::class,'user_id','id')
                ->whereBetween('date', [$input['date_from'] . " 00:00:00", $input['date_to'] . " 23:59:00"])
                ->latest();
        }
        return $this->hasMany(VetCareUserPayment::class,'user_id','id')->latest();
    }

    public function appointmentBooking(){
        return $this->morphMany(AppointmentBooking::class, 'model');
    }

    public function appointmentPet(){
        return $this->morphMany(AppointmentPet::class, 'model');
    }

    public function appointmentPayment(){
        return $this->morphMany(AppointmentPayment::class, 'model');
    }

    public function usageWithThrashed(){
        return $this->hasMany(VetCarePackageUsage::class,'user_id','id')->withTrashed();
    }

    public function usageSubscription(){

        $model=$this->hasMany(VetCareSubscription::class,'user_id','id')->withTrashed();
        if(request()->has('subscription_status') && !empty(request()->subscription_status)){
            $status = request()->subscription_status == 'subscribed' ? 'active':request()->subscription_status;
            $model = $model->where('status',$status);
        }
        return $model;

        // return $this->hasMany(VetCareSubscription::class,'user_id','id')->withTrashed();

    }

    public function usageSubscriptionlates(){
        $model=$this->hasMany(VetCareSubscription::class,'user_id','id')->orderBy('created_at','DESC');
        // $status = request()->subscription_status == 'subscribed' ? 'active':request()->subscription_status;
        // if(request()->has('subscription_status') && !empty(request()->subscription_status)){
        //     $model = $model->where('status',$status);
        // }
        return $model;
    }

    public function vetCareUserFeedbacks()
    {
        return $this->hasMany(VetCareUserFeedback::class, 'user_id', 'id');
    }

    public function user_status(){
        // return $this->hasMany(UserAppStatus::class,'user_id','id');
        $model= $this->hasMany(UserAppStatus::class,'user_id','id');
        if(request()->has('subscription_status') && !empty(request()->subscription_status)){
            $status = request()->subscription_status;
            if ($status == 'upgraded') {
                $model = $model->where('status','upgrade');
            } elseif ($status == 'canceled') {
                $model = $model->where('status','cancelled');
            } else {
                $model = $model->where('status',$status);
            }
        }
        return $model;
    }

    public function user_status_latest(){
        // return $this->hasMany(UserAppStatus::class,'user_id','id');
        $model= $this->hasMany(UserAppStatus::class,'user_id','id');
        if(request()->has('subscription_status') && !empty(request()->subscription_status)){
            $status = request()->subscription_status;
            if ($status == 'upgraded') {
                $status = 'upgrade';
            } elseif ($status == 'canceled') {
                $status = 'cancelled';
            }
            $model = $model->where('status',$status)->latest();
        } else {
            $model = $model->latest();
        }
        return $model;
    }

    public function userAppStatuses(){
        return $this->hasOne(UserAppStatus::class,'user_id','id');
    }
}
