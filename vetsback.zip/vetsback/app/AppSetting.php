<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AppSetting extends Model
{
    
    protected $fillable = ['logo','secondary_color','primary_color','app_id','clinic_id','faqs','fav_icon','title','emergency_fund','is_payment_required','zipcode_validation','extra_image','other','background_image'];

    protected $casts = [
        'other' => 'object'
    ];


    //public $timestamps = false;

//    public function app(){
//        return $this->belongsTo(App::class,'app_id','id');
//    }
}
