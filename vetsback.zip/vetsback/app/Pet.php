<?php

namespace App;

use App\Traits\CustomSearch;
use App\Traits\FullTextSearch;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use \Askedio\SoftCascade\Traits\SoftCascadeTrait;

class Pet extends Model
{
    //
    use SoftDeletes;
    use SoftCascadeTrait;
    //use FullTextSearch;
    use CustomSearch;


    protected $fillable = ['user_id','name','species','age','breed','color','weight','sex','sex_type','profile'];

    protected $softCascade = ['petVeterians','petMedicals','petInsurnaces'];

    protected $appends = ['veterians','medicals','insurnaces'];

    protected $searchable = [
        'name','species','age','breed','color','sex','weight','sex_type'
    ];

    public function users(){
        return $this->belongsTo(User::class);
    }
    public function guests(){
        return $this->belongsTo(Guest::class);
    }
    public function petVeterians(){
        return $this->hasMany(PetVeterinarian::class,'pet_id');
    }
    public function getVeteriansAttribute()
    {
        $this->load('petVeterians');
    }
    public function petMedicals(){
        return $this->hasMany(PetMedical::class,'pet_id');
    }
    public function getMedicalsAttribute()
    {
        $this->load('petMedicals');
    }
    public function petInsurnaces(){
        return $this->hasMany(PetInsurance::class,'pet_id');
    }
    public function getInsurnacesAttribute()
    {
        $this->load('petInsurnaces');
    }
    public function getProfileUrlAttribute()
    {
        $s3 = env('AWS_URL', '');
        return $s3.$this->profile;
    }
    public function model(){
        return $this->morphTo();
    }
}
