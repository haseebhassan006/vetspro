<?php

namespace App;

use App\Traits\CustomSearch;
use Illuminate\Database\Eloquent\Model;

class App extends Model
{
    use CustomSearch;
    protected $fillable = ['name','api_key','fcm_server_key','android_link','ios_link','app_type','is_suspended','trial_period','send_chat_on_email','send_email_on'];

    protected $searchable = ['name'];

    protected $appends = ['app_setting'];

    public function getAppSettingAttribute(){
        return $this->belongsTo(AppSetting::class,'id','app_id')->first();
    }

    public function appSettings(){
        return $this->belongsTo(AppSetting::class,'id','app_id');
    }

    public function users(){
        return $this->belongsTo(User::class);
    }

    public function webapps(){
        return $this->belongsTo(WebappUser::class);
    }

    public function videocall(){
        return $this->belongsTo(VideoCall::class,'id','app_id');
    }

    public function settings(){
        return $this->belongsTo(AppSetting::class,'id','app_id');
    }

    public function vetCareUsers(){
        //return $this->belongsTo(VetCareUser::class,'app_id','id');
        return $this->hasMany(VetCareUser::class,'app_id','id');
    }

    public function clinic()
    {
        return $this->hasOne(VetCare::class , 'id','model_id');
    }

    public function chat(){
        return $this->hasMany(Chat::class,'app_id','id');
    }

    public function model(){
        return $this->morphTo();
    }
}
