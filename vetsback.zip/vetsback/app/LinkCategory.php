<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class LinkCategory extends Model
{
    use SoftDeletes;
    protected $guarded = [];

    public function link(){
        return $this->hasMany(Link::class,'category_id','id');
    }
}
