<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class VetCareApp extends Model
{
    //
    protected $fillable = ['name','api_key','fcm_server_key','android_link','ios_link','app_type','clinic_id'];

}
