<?php

namespace App\Observers;

use App\Vet;

class VetObserver
{
    /**
     * Handle the vet "created" event.
     *
     * @param  \App\Vet  $vet
     * @return void
     */
    public function created(Vet $vet)
    {
        //
    }

    /**
     * Handle the vet "updated" event.
     *
     * @param  \App\Vet  $vet
     * @return void
     */
    public function updated(Vet $vet)
    {
        //

    }

    /**
     * Handle the vet "deleted" event.
     *
     * @param  \App\Vet  $vet
     * @return void
     */
    public function deleted(Vet $vet)
    {
        //
    }

    /**
     * Handle the vet "restored" event.
     *
     * @param  \App\Vet  $vet
     * @return void
     */
    public function restored(Vet $vet)
    {
        //
    }

    /**
     * Handle the vet "force deleted" event.
     *
     * @param  \App\Vet  $vet
     * @return void
     */
    public function forceDeleted(Vet $vet)
    {
        //
    }
}
