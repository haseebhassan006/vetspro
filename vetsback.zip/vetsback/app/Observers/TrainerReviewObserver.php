<?php

namespace App\Observers;

use App\ReviewNameTrainerReview;
use App\Trainer;
use App\TrainerReview;

class TrainerReviewObserver
{
    /**
     * Handle the trainer review "created" event.
     *
     * @param  \App\TrainerReview  $trainerReview
     * @return void
     */
    public function created(TrainerReview $trainerReview)
    {

        $trainer = Trainer::find($trainerReview->trainer_id);

        $trainerReview = TrainerReview::find($trainerReview->id);

        $ratings = request()->get('ratings');
        $ratings= array_column($ratings, 'rate');

        if( $ratings != null){
            $previousAvgRate = $trainer->avg_rate;
            $previousCount = $trainer->count_rate;



            /**  sum previous rate with new rate  */
            $previousAvgRate+= array_sum($ratings);

            /**  increment by 1 in previous count because of new rate */
            $previousCount+=1;
            $trainer->avg_rate = $previousAvgRate;
            $trainer->count_rate = $previousCount;
            $trainer->save();


        }
    }

    /**
     * Handle the trainer review "updated" event.
     *
     * @param  \App\TrainerReview  $trainerReview
     * @return void
     */


    public function updating(TrainerReview $trainerReview)
    {

        $trainer = Trainer::find($trainerReview->trainer_id);


        $ratings = request()->get('ratings');
        $ratings= array_column($ratings, 'rate');
        if( $ratings != null){
            $previousAvgRate = $trainer->avg_rate;
            $previousCount = $trainer->count_rate;

            $oldRate = $trainerReview->ratings->sum('pivot.rate');
            $newRate = array_sum($ratings);

            /**  sum previous rate with new rate  */
            $previousAvgRate+= ($newRate-$oldRate);
            $previousCount-=1;

            /**  increment by 1 in previous count because of new rate */
            $trainer->avg_rate = $previousAvgRate;
            $trainer->count_rate = $previousCount;
            $trainer->save();


        }
    }

    /**
     * Handle the trainer review "deleted" event.
     *
     * @param  \App\TrainerReview  $trainerReview
     * @return void
     */
    public function deleted(TrainerReview $trainerReview)
    {
        $trainer = Trainer::find($trainerReview->trainer_id);


        $ratings = request()->get('ratings');
        if( $ratings != null){
            $previousAvgRate = $trainer->avg_rate;
            $previousCount = $trainer->count_rate;

            $oldRate = $trainerReview->ratings->sum('pivot.rate');


            /**  sum previous rate with new rate  */
            $previousAvgRate-= $oldRate;

            /**  increment by 1 in previous count because of new rate */
            $trainer->avg_rate = $previousAvgRate;
            $trainer->count_rate = $previousCount;
            $trainer->save();


        }
    }

    /**
     * Handle the trainer review "restored" event.
     *
     * @param  \App\TrainerReview  $trainerReview
     * @return void
     */
    public function restored(TrainerReview $trainerReview)
    {
        //
    }

    /**
     * Handle the trainer review "force deleted" event.
     *
     * @param  \App\TrainerReview  $trainerReview
     * @return void
     */
    public function forceDeleted(TrainerReview $trainerReview)
    {
        //
    }
}
