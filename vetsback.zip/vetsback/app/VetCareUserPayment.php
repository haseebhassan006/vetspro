<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class VetCareUserPayment extends Model
{
    //
    protected $fillable = ['user_id','charge_id','date','amount','status','stripe_response'];

    protected $casts = ['stripe_response'=>'json'];


    public function user(){
        return $this->hasOne(VetCareUser::class,'id','user_id');
    }

    public function paymentProtectUser(){
        return $this->hasOne(VetCarePaymentProtectUser::class,'id','payment_id');
    }
}
