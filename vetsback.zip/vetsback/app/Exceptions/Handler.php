<?php

namespace App\Exceptions;

use App\UnauthenticatedUsers;
use Exception;
use Illuminate\Auth\AuthenticationException;
use Illuminate\Foundation\Exceptions\Handler as ExceptionHandler;
use Illuminate\Support\Facades\DB;
use stdClass;
use Symfony\Component\HttpKernel\Exception\UnauthorizedHttpException;
use Illuminate\Support\Facades\Log;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\HttpKernel\Exception\MethodNotAllowedHttpException;
use Symfony\Component\HttpKernel\Exception\HttpException;

class Handler extends ExceptionHandler
{
    /**
     * A list of the exception types that are not reported.
     *
     * @var array
     */
    protected $dontReport = [
        //
    ];

    /**
     * A list of the inputs that are never flashed for validation exceptions.
     *
     * @var array
     */
    protected $dontFlash = [
        'password',
        'password_confirmation',
    ];

    /**
     * Report or log an exception.
     *
     * @param  \Exception  $exception
     * @return void
     */
    public function report(Exception $exception)
    {
        parent::report($exception);
    }

    /**
     * Render an exception into an HTTP response.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Exception  $exception
     */
    public function render($request, Exception $exception)
    {
        $resp = parent::render($request, $exception);
        Log::error(($exception->getMessage()));
        try{
            $errors = $exception->validator->errors()->all();
        }catch(Exception $e){
            $errors = [$exception->getMessage()];
        }
        if($exception->getMessage() == 'Unauthenticated.'){
            return $this->errorResponse('You are not authorized to view this page.','401');
        }
        if($exception->getMessage() == 'Route [login] not defined.'){
            return $this->errorResponse('Unauthorized or invalid token. Please login again.','401');
        }
//        else{
//            return $this->errorResponse($errors,$resp->getStatusCode());
//        }
        //For all unwanted http requests
        if ($this->isHttpException($exception)) {
            if ($exception->getStatusCode() == 404 && in_array('.env',request()->segments()) || in_array('boaform',request()->segments())){
                //Save all blocked ips in table

                //$ip = DB::connection()->getPdo()->quote($request->ip()); // the escaping part
                $ip = DB::connection()->getPdo()->quote($this->getIp());

                UnauthenticatedUsers::create([
                    'ip'=>DB::raw("inet_aton($ip)"),
                    'url'=>$request->url()
                ]);
                //return $this->errorResponse('Your ip is blocked.',511);
            }

            if ($exception->getStatusCode() == 404){
                return $this->errorResponse('Route not found',400);

            }

            if ($exception->getStatusCode() == 500){
                return $this->errorResponse('Server Error. Contact admin',500);

            }
            if ($exception->getStatusCode() == 413){
                return $this->errorResponse('Payload to large.',413);

            }

        }
        else{
            return $this->errorResponse($exception->getMessage(),502);

        }
    }
    /**
     * Convert an authentication exception into an unauthenticated response.
     *

     * @param  \Illuminate\Http\Request  $request
     * @param  \Illuminate\Auth\AuthenticationException  $exception
    */

    protected function unauthenticated($request, AuthenticationException $exception)

    {
        if ($request->expectsJson()) {
            /** return response()->json(['error' => 'Unauthenticated.'], 401); */
            $response = ['success' => 'false','message' => 'You pass invalid token'];
            return $this->errorResponse($exception->getMessage(), $exception->getCode());
            //return response()->json($response,401);
        }

        return redirect()->guest('login');

    }

    public function errorResponse($error, $code = 401,$errorMessages = []){

        $statusCode = $code == 0 ? 401 : $code;
        $response = [
            'success' => false,
            'status_code' =>$statusCode,
            'message' => is_array($error) == TRUE ? $error : [$error],
            //'message' => $error,
            //'data'    => $errorMessages
            'data'    => []
        ];

        return response()->json($response, $statusCode);
    }

    public function handleException($request, Exception $exception)
    {

        if ($exception instanceof MethodNotAllowedHttpException) {
            return $this->errorResponse('The specified method for the request is invalid', 405);
        }

        if ($exception instanceof NotFoundHttpException) {
            return $this->errorResponse('The specified URL cannot be found', 404);
        }

        if ($exception instanceof HttpException) {
            return $this->errorResponse($exception->getMessage(), $exception->getStatusCode());
        }

        if (config('app.debug')) {
            return parent::render($request, $exception);
        }

        return $this->errorResponse('Unexpected Exception. Try later', 500);

    }

    public function getIp(){
        foreach (array('HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_FORWARDED', 'HTTP_X_CLUSTER_CLIENT_IP', 'HTTP_FORWARDED_FOR', 'HTTP_FORWARDED', 'REMOTE_ADDR') as $key){
            if (array_key_exists($key, $_SERVER) === true){
                foreach (explode(',', $_SERVER[$key]) as $ip){
                    $ip = trim($ip); // just to be safe
                    if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false){
                        return $ip;
                    }
                }
            }
        }
        //return request()->ip(); // it will return server ip when no client ip found
    }
}
