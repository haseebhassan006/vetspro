<?php
namespace App\Logging;

// Include the SDK using the Composer autoloader
use Aws\CloudWatchLogs\CloudWatchLogsClient;

$options = [
    'region'            => 'us-west-2',
    'version'           => 'latest',
    'credentials' => [
        'key'    => env('CLOUDWATCH_ACCESS_ID'),
        'secret' => env('ClOUDWATCH_ACCESS_KEY')
    ]
];

$client = new CloudWatchLogsClient($options);
date_default_timezone_set('UTC');
$result = '';

$logGroupName = '/logtest';
try {
    $result = $client->createLogGroup([
        'logGroupName' => $logGroupName,
    ]);
} catch (\Aws\CloudWatchLogs\Exception\CloudWatchLogsException $e) {
    echo $e->getAwsErrorCode() . "\n";
    echo $e->getMessage() . "\n";
}
var_dump($result);

$logStreamName = date("Y.m.d") . ' [LOGTEST] ' . date("H.i.s");
try {
    $result = $client->createLogStream([
        'logGroupName' => $logGroupName,
        'logStreamName' => $logStreamName
    ]);
} catch (\Aws\CloudWatchLogs\Exception\CloudWatchLogsException $e) {
    echo $e->getAwsErrorCode() . "\n";
    echo $e->getMessage() . "\n";
}

var_dump($result);

try {
    $result = $client->putLogEvents([
        'logGroupName' => $logGroupName,
        'logStreamName' => $logStreamName,
        'logEvents' => [
            [
                'message' => 'This is a test 1',
                'timestamp' => round(microtime(true) * 1000),
            ]
        ]
    ]);
} catch (\Aws\CloudWatchLogs\Exception\CloudWatchLogsException $e) {
    echo $e->getAwsErrorCode() . "\n";
    echo $e->getMessage() . "\n";
}

var_dump($result);
$nextSequenceToken = ($result['nextSequenceToken']);

try {
    $result = $client->putLogEvents([
        'logGroupName' => $logGroupName,
        'logStreamName' => $logStreamName,
        'logEvents' => [
            [
                'message' => 'This is a test 2',
                'timestamp' => round(microtime(true) * 1000),
            ]
        ],
        'sequenceToken' => $nextSequenceToken,
    ]);
} catch (\Aws\CloudWatchLogs\Exception\CloudWatchLogsException $e) {
    echo $e->getAwsErrorCode() . "\n";
    echo $e->getMessage() . "\n";
}

var_dump($result);
