<?php

namespace App;

use App\Traits\CustomSearch;
use App\Traits\FullTextSearch;
use Illuminate\Database\Eloquent\Model;

class FailedHandshake extends Model
{
    use CustomSearch;
    protected $guarded = [];
    protected $casts = ['request'=>'json','response'=>'json'];
    protected $searchable = ['request','response'];
    public function apps(){
        return $this->hasMany(App::class,'id','app_id');
    }
}
