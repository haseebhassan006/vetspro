<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserAppStatus extends Model
{
    //
    protected $fillable = ['app_id','user_id','status','date_time','type','created_at'];

    public function user(){
        return $this->belongsTo(WebappUser::class,'user_id','id');
    }
}
