<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PivotVideoCall extends Model
{
    //
    protected $guarded = [];
}
