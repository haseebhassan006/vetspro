<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Device extends Model
{
    //
    use SoftDeletes;
    protected $guarded = [];

    public function model(){
       // return $this->belongsTo(User::class);
        //return $this->morphedByMany(User::class, 'id');
        return $this->morphTo();

    }
}
