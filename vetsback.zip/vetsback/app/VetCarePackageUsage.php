<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class VetCarePackageUsage extends Model
{
    use SoftDeletes;

    protected $fillable = ['user_id','package_id','coupon_id','vet_care_coupon_code_id'];

    public function package(){
        return $this->belongsTo(VetCarePackage::class);
    }

    public function coupon(){
        return $this->belongsTo(VetCareCoupon::class);
    }

    public function couponCode(){
        return $this->belongsTo(VetCareCouponCode::class,'vet_care_coupon_code_id')->withTrashed();
    }


}
