<?php

namespace App;

use App\Traits\CustomSearch;
use App\Traits\FullTextSearch;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use \Askedio\SoftCascade\Traits\SoftCascadeTrait;


class TrainerReview extends Model
{
    //
    use SoftDeletes;
    use SoftCascadeTrait;
    //use FullTextSearch;
    use CustomSearch;

    protected $guarded = [];

    public function users(){
        return $this->belongsTo(User::class,'user_id','id');
    }

    public function trainers(){
        return $this->belongsTo(Trainer::class,'trainer_id','id');
    }

    public function bookings(){
        return $this->belongsTo(AppointmentBooking::class,'booking_id','id');
    }

    public function appointmentPet()
    {
        return $this->belongsTo(AppointmentPet::class,'appointment_pet_id','id');
    }

    public function reviewable()
    {
        return $this->morphTo();
    }

    public function ratings()
    {
        return $this->belongsToMany(ReviewName::class,'review_name_trainer_review')->withPivot('rate');
    }

    public function raviewRatings()
    {
        return $this->hasMany(ReviewNameTrainerReview::class);
    }

}

