<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Payment extends Model
{
    //
    protected $guarded = [];

    protected $casts = ['stripe_response'=>'json'];


    public function user(){
        return $this->hasOne(User::class,'id','user_id');
    }
    public function paymentUser(){
        return $this->belongsTo(User::class,'user_id','id');
    }
    public function paymentProtectUser(){
        return $this->hasOne(PaymentProtectUser::class,'id','payment_id');
    }
    public function couponData(){
        return $this->hasOne(CouponUsage::class,'created_at','use_datetime');
    }
//    public function packageData(){
//        return $this->hasOne(PackageUsage::class,'created_at','updated_at');
//    }



}
