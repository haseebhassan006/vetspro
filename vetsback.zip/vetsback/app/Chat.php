<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Chat extends Model
{
    //
    protected $guarded = [];

    public function chat_details(){
        return $this->belongsTo(ChatDetail::class,'id','chat_id');
    }
    public function vet(){
        return $this->belongsTo(Vet::class);
    }
    public function whitelabelUser(){
        return $this->belongsTo(User::class,'user_id','id');
    }
    public function webappUser(){
        return $this->belongsTo(WebappUser::class,'user_id','id');
    }
    public function sdkUser(){
        return $this->belongsTo(Guest::class,'user_id','id');
    }

    public function app(){
        return $this->belongsTo(App::class);
    }

    
    public function ended_chat(){
        return $this->hasOne(ChatEndedBy::class,'chat_id','id');
    }
    public function vcUser()
    {
        return $this->hasOne(VetCareUser::class, 'id', 'user_id');
    }
    

}
