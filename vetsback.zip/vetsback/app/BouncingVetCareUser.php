<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BouncingVetCareUser extends Model
{
    protected $guarded = [];

    protected $casts = [
        'pets' => 'object',
        'others' => 'object'
    ];

    protected $appends = ['app_name'];

    public function app()
    {
        return $this->belongsTo(App::class);
    }

    public function getAppNameAttribute(){
        return $this->app()->first()->name;
    }
}
