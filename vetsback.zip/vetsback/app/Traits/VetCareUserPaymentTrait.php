<?php
namespace App\Traits;

use App\App;
use App\User;
use Carbon\Carbon;
use App\VetCareSubscription;
use Exception;
use Illuminate\Http\Request;
use Stripe\Exception\CardException;
use Stripe\Exception\ApiErrorException;

trait VetCareUserPaymentTrait{

    protected $stripeConfig;
    protected $stripe;

    public function initialize($app=null){
        $this->stripeConfig   = config('services.stripe.vetcare');
        if(($app != null)){
            if(!is_int($app)){
                $app = $app->id;
            }
            $appInstance = App::where('id',$app)->whereNotNull('stripe_key')->first();
            if($appInstance){
                $this->stripeConfig   = $appInstance->stripe_key;
            }
        }
        $this->stripe = new \Stripe\StripeClient($this->stripeConfig);
    }

    /**
     * @param $name
     * @param $metadata
     * @param $type
     * @return array
     */
    public function createStripeProduct($name, $metadata, $type){
        //$json = json_encode($metadata);
        try{
            $product = $this->stripe->products->create([
                'name' => $name,
                'metadata'=> $metadata
            ]);
            $price = [
                'product' => $product->id,
                'unit_amount' => 100 * $metadata['price'],
                'currency' => $metadata['currency'],
            ];
            if($type == 'recurring'){
                $price['recurring'] = [
                    'interval' => $metadata['interval'],
                    'interval_count' => $metadata['interval_count'],
                ];
            }
            $price_res = $this->stripe->prices->create([
                $price
            ]);
            //$this->createPlan($product->id,$metadata['currency'],$metadata['interval'],$metadata['price']);
            $product['code'] = 200;
            $product['price_id'] = $price_res->id;
            $product['product_id'] = $product->id;
        }
        catch (ApiErrorException $exception){
            $product['code'] = $exception->getHttpStatus();
            $product['message'] = $exception->getMessage();
        }
        return $product;
    }

    /**
     * @param array $data
     * @return array
     */
    public function createStripeToken($data = array()): array
    {
        try{
            $token = $this->stripe->paymentMethods->create([
                'type' => 'card',
                'card' => [
                    'number' => $data['number'],
                    'exp_month' => $data['exp_month'],
                    'exp_year' => $data['exp_year'],
                    'cvc' => $data['cvc'],
                ],
            ]);

            $this->stripe->paymentMethods->attach(
                $token->id,
                ['customer' => $data['cus_id']]
            );
            $this->stripe->customers->update(
                $data['cus_id'],
                ['invoice_settings' => ['default_payment_method' => $token->id]]
            );
            $response['token'] = $token;
            $response['code'] = 200;
        }
        catch (ApiErrorException $e){
            $response['code'] = $e->getHttpStatus();
            $response['message'] = $e->getMessage();
        }

        return $response;
    }

    public function createCustomer($email){
        $customer = $this->stripe->customers->create([
            'email' => $email,
        ]);

        return $customer;
    }

    public function createCustomerSetupIntent($cus_id,$card_id){
        return $this->stripe->setupIntents->create([
            'customer' => $cus_id,
            'payment_method_types' => ['card'],
            'confirm'=>true,
            'payment_method'=>$card_id

        ]);
    }

    public function retrieveCustomer($cus_id){
        $customer = $this->stripe->customers->retrieve(
            $cus_id
        );
        return $customer;
    }

    public function createCard(){
        $this->stripe->customers->createSource(
            'cus_FSRQ8XSryfj6Ma',
            ['source' => 'tok_mastercard']
        );
    }

    public function getPrice($price){
        $data = $this->stripe->prices->retrieve($price);
        return $data->unit_amount/100;
    }

    public function createPrice($amount,$currency,$interval,$product_id){
        $data = $this->stripe->prices->create([
            'unit_amount' => 100 * $amount,
            'currency' => $currency,
            'recurring' => ['interval' => $interval],
            'product' => $product_id,
        ]);
        return $data->id;
    }

    // public function addSubscription($cus_id,$price_id,$days){
    public function addSubscription($cus_id,$package_data,$days){

        // $trail_end_date = Carbon::now()->addDays(30)->timestamp;

        $createNextTrailDate = $this->createNextDate($package_data->interval,$package_data->interval_count);
        $trail_end_date = $createNextTrailDate;

        try{
            return $this->stripe->subscriptionSchedules->create([
                'customer' => $cus_id,
                // 'start_date' => $days,
                'start_date'=>'now',
                'end_behavior' => 'release',
                'phases' => [
                    [
                        'items' => [
                            [
                                // 'price' => $price_id,
                                'price' => $package_data->price_id,
                                
                                'quantity' => 1,
                            ],
                        ],
                        'iterations' => 12,
                        'trial_end' =>$trail_end_date //check for duplicate payment occur after this
                    ],
                ],
                // 'billing_cycle_anchor' => 'automatic',
            ]);
        }catch(Exception $e){

            return null;
        }
    }

    public function updateSubscription($new_package,$cus_id,$oldSubscriptionId){

        $price_id = $new_package->price_id;
        // First Cancel the old subscription
        $unsubscribe = $this->unsubscribe($oldSubscriptionId);
        $createNextTrailDate = $this->createNextDate($new_package->interval);
        $trail_end_date = (isset($unsubscribe->phases[0]) && $unsubscribe->phases[0] && $unsubscribe->phases[0]->trial_end) ? $unsubscribe->phases[0]->trial_end : $createNextTrailDate;
        $startDate = isset($unsubscribe->created) ? $unsubscribe->created : 'now';

        // Create a new subscription
        if($unsubscribe){
            return $this->stripe->subscriptionSchedules->create([
                'customer' => $cus_id,
                'start_date'=> $startDate,
                'phases' => [
                    [
                        'items' => [
                            [
                                'price' => $price_id,
                                'quantity' => 1,
                            ],
                        ],
                        'iterations' => 12,
                        'trial_end' =>$trail_end_date
                    ],
                ],
            ]);
        }
    }

    public function updateSubscriptionOld($sub_id,$price_id,$old_price_id,$cus_id){
        $date = Carbon::now()->timestamp;
        $endDate = Carbon::now()->addMinute(1)->timestamp;

        $trail_end_date = Carbon::now()->addDays(30)->timestamp;
        return $this->stripe->subscriptionSchedules->create(
            [
                'customer' => $cus_id,
                'start_date' => 'now',
                'metadata' => ['extra_information' => 'User updated its subscription schedule'],
                'end_behavior' => 'release',
                'phases' => [
                    [
                        'items' => [
                            [
                                'price' => $old_price_id,
                                'quantity' => 1,
                            ],
                        ],
                        'end_date' => $endDate
                    ],
                    [
                        'items' => [
                            [
                                'price' => $price_id,
                                'quantity' => 1,
                            ],
                        ],
                        'iterations' => 12,
                        'trial_end' =>$trail_end_date,
                    ],
                ],
            ]
        );
    }

    public function updateSubscriptionWithNoRecurring($new_package,$cus_id){
        $price_id = $new_package->price_id;
        $trail_end_date = $this->createNextDate($new_package->interval,$new_package->interval_count);
        try{
            return $this->stripe->subscriptionSchedules->create(
                [
                    'customer' => $cus_id,
                    'start_date' => 'now',
                    'metadata' => ['extra_information' => 'User updated its subscription schedule'],
                    'end_behavior' => 'release',
                    'phases' => [
                        [
                            'items' => [
                                [
                                    'price' => $price_id,
                                    'quantity' => 1,
                                ],
                            ],
                            'iterations' => 12,
                            'trial_end' =>$trail_end_date,
                        ],
                    ],
                ]
            );
        }catch(Exception $e){

        }

    }

    /**
     * @param $amount
     * @param $currency
     * @param $source
     * @param $description
     * @param $payment_id
     * @return \stdClass
     */
    public function makeCharge($amount, $currency, $source, $description, $payment_id,$user = null)
    {
        $charge = new \stdClass();
        try{
            $charge = $this->createPaymentIntent($amount,$currency,$source,$description,$payment_id);
            $charge->code = 200;
        }
        catch (ApiErrorException $exception){
            $charge->code  = $exception->getHttpStatus();
            $charge->message  = $exception->getMessage();
            $charge->status = $exception->getStripeCode();
            if($charge->code == 400){
                $charge->message = 'inssuficient funds or card declined';
            }
            // Delete User from DB
            if($user && last(request()->segments()) == 'signup'){
                $user->delete();
            }

            throw new \Exception('Something went wrong while processing your card. System returned : '.$charge->message . '. Status : '.$charge->status, $exception->getCode());
        }
        return $charge;
    }

    public function createPaymentIntent($amount,$currency,$source,$description,$payment_id){
        return $charge = $this->stripe->paymentIntents->create([
            'amount' => 100 * $amount,
            'currency' => $currency,
            'customer'=> $source,
            'description' => $description,
            'payment_method'=>$payment_id,
            'off_session' => true,
            'confirm' => true,
            //'confirmation_method' => 'manual',
            //'confirm'=> true,
            //'off_session' => true,
            //'setup_future_usage'=>'off_session',
            //'payment_method_types' => ['card'],

        ]);
    }

    public function generateResponse($intent)
    {
        # Note that if your API version is before 2019-02-11, 'requires_action'
        # appears as 'requires_source_action'.
        if ($intent->status == 'requires_action' &&
            $intent->next_action->type == 'use_stripe_sdk') {
            # Tell the client to handle the action
            echo json_encode( [
                'requires_action' => true,
                'payment_intent_client_secret' => $intent->client_secret
            ] );
        } else if ($intent->status == 'succeeded') {
            # The payment didn’t need any additional actions and completed!
            # Handle post-payment fulfillment
            echo json_encode( [
                "success" => true
            ] );
        } else {
            # Invalid status
            http_response_code( 500 );
            echo json_encode( ['error' => 'Invalid PaymentIntent status'] );
        }
    }

    public function unsubscribe($sub_id){
        try{
            return $this->stripe->subscriptionSchedules->cancel(
                $sub_id
            );
        }catch(Exception $e){
            return false;
        }

    }

    public function createdHooks(){
        return $this->stripe->webhookEndpoints->create([
            'url' => url("/payment/stripe/hooks/create"),
            'enabled_events' => [
                'charge.failed',
                'charge.succeeded',
                'payment_intent.payment_failed',
                'payment_intent.requires_action',
                'payment_intent.succeeded'
            ],
        ]);
    }

    public function editProduct($prod_id,$metadata){
        $this->stripe->products->update(
            $prod_id,
            ['metadata' => ['is_recurring' => $metadata]]
        );
    }

    public function deleteCustomer($cus_id){
        $this->stripe->customers->delete(
            $cus_id,
            []
        );
    }

    public function retreiveSubscriptionSchedule($subscip_id){
        return $this->stripe->subscriptionSchedules->retrieve(
            $subscip_id,
            []
        );
    }

    public function getPaymentIntent($paymentIntent_id){
        return $this->stripe->paymentMethods->retrieve(
            $paymentIntent_id,
            []
        );

    }

    public function retrievePricePlan($price_id){
        return $this->stripe->plans->retrieve(
            $price_id,
            []
        );
    }

    public function createNextDate($interval,$interval_count=NULL)
    {
        $currentDate = Carbon::now();
        $interval =  preg_replace('/\d+/u', '', $interval);
        switch ($interval) {
            case "day":
                $currentDate = $currentDate->addDay($interval_count);
              break;
            case "week":
                $currentDate = $currentDate->addWeek($interval_count);
              break;
            case "month":
                $currentDate = $currentDate->addMonth($interval_count);
              break;
            case "year":
                $currentDate = $currentDate->addYear();
              break;
            default:
              $currentDate = $currentDate->addMinute(5);
          }
          return $currentDate->timestamp;
    }

}
