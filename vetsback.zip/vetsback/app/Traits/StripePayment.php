<?php
namespace App\Traits;

use App\App;
use App\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Stripe\Exception\ApiErrorException;
use Stripe\Exception\CardException;

trait StripePayment{

    protected $stripeConfig;
    protected $stripe;
    public function init($id){
        $app = App::find($id);
            switch ($app->name){
                case 'vetsPlusMore':
                    $this->stripeConfig   = config('services.stripe.vetsplusmore');
                    break;
                case 'vetCareHotline':
                    $this->stripeConfig   = config('services.stripe.vetpethotline');
                    break;
                case 'linkVet':
                    $this->stripeConfig   = config('services.stripe.linkvet');
                    break;
                default:
                    $this->stripeConfig   = config('services.stripe.vetsplusmore');
            }
        $this->stripe = new \Stripe\StripeClient($this->stripeConfig);

    }

    /**
     * @param $name
     * @param $metadata
     * @param $type
     * @return array
     */
    public function createStripeProduct($name, $metadata, $type){
        //$json = json_encode($metadata);
        try{
            $product = $this->stripe->products->create([
                'name' => $name,
                'metadata'=> $metadata
            ]);
            $price = [
                'product' => $product->id,
                'unit_amount' => 100 * $metadata['price'],
                'currency' => $metadata['currency'],
            ];
            if($type == 'recurring'){
                $price['recurring'] = [
                    'interval' => $metadata['interval'],
                ];
            }
                $price_res = $this->stripe->prices->create([
                    $price
                ]);
            //$this->createPlan($product->id,$metadata['currency'],$metadata['interval'],$metadata['price']);
            $product['code'] = 200;
            $product['price_id'] = $price_res->id;
            $product['product_id'] = $product->id;
        }
        catch (ApiErrorException $exception){
            $product['code'] = $exception->getHttpStatus();
            $product['message'] = $exception->getMessage();
        }
        return $product;
    }

    /**
     * @param array $data
     * @return array
     */
    public function createStripeToken($data = array()): array
    {
        try{
            $token = $this->stripe->paymentMethods->create([
                'type' => 'card',
                'card' => [
                    'number' => $data['number'],
                    'exp_month' => $data['exp_month'],
                    'exp_year' => $data['exp_year'],
                    'cvc' => $data['cvc'],
                ],
            ]);

            $this->stripe->paymentMethods->attach(
                $token->id,
                ['customer' => $data['cus_id']]
            );
            $this->stripe->customers->update(
                $data['cus_id'],
                ['invoice_settings' => ['default_payment_method' => $token->id]]
            );
            $response['token'] = $token;
            $response['code'] = 200;
        }
        catch (ApiErrorException $e){
            $response['code'] = $e->getHttpStatus();
            $response['message'] = $e->getMessage();
        }

        return $response;
    }

    public function createCustomer($email){
        $customer = $this->stripe->customers->create([
            'email' => $email,
        ]);

        return $customer;
    }

    public function createCustomerSetupIntent($cus_id,$card_id){
        return $this->stripe->setupIntents->create([
            'customer' => $cus_id,
            'payment_method_types' => ['card'],
            'confirm'=>true,
            'payment_method'=>$card_id

        ]);
    }

    public function retrieveCustomer($cus_id){
        $customer = $this->stripe->customers->retrieve(
            $cus_id
        );
        return $customer;
    }

    public function createCard(){
        $this->stripe->customers->createSource(
            'cus_FSRQ8XSryfj6Ma',
            ['source' => 'tok_mastercard']
        );
    }

    public function getPrice($price){
        $data = $this->stripe->prices->retrieve($price);
        return $data->unit_amount/100;
    }

    public function createPrice($amount,$currency,$interval,$product_id){
        $data = $this->stripe->prices->create([
            'unit_amount' => 100 * $amount,
            'currency' => $currency,
            'recurring' => ['interval' => $interval],
            'product' => $product_id,
        ]);
        return $data->id;
    }

    // public function addSubscription($cus_id,$price_id,$days){
        
        // $trail_end_date = Carbon::now()->addDays(30)->timestamp;
        public function addSubscription($cus_id,$package_data,$days){
            $createNextTrailDate = $this->createNextDate($package_data->interval,$package_data->interval_count);
            $trail_end_date = $createNextTrailDate;
            try{
            return $this->stripe->subscriptionSchedules->create([
                'customer' => $cus_id,
                //'start_date' => $days,
                'start_date'=>'now',
                'end_behavior' => 'release',
                'phases' => [
                    [
                        'items' => [
                            [
                                // 'price' => $price_id,
                                'price' => $package_data->price_id,
                                'quantity' => 1,
                            ],
                        ],
                        'iterations' => 12,
                        'trial_end' =>$trail_end_date
                    ],
                ],
                // 'billing_cycle_anchor' => 'automatic',
            ]);
        }catch(Exception $e){
            dd($e);
            return null;
        }
    }

    /**
     * @param $amount
     * @param $currency
     * @param $source
     * @param $description
     * @param $payment_id
     * @return \stdClass
     */
    public function makeCharge($amount, $currency, $source, $description, $payment_id)
    {
        $charge = new \stdClass();
        try{
            $charge = $this->createPaymentIntent($amount,$currency,$source,$description,$payment_id);
            // if (isset($charge->id)) {
            //     $charge = $this->stripe->paymentIntents->retrieve(
            //         $charge->id
            //     );
            //               dd($charge);
            //    $charge->confirm();
            // }
                    }
        catch (ApiErrorException $exception){
            $charge->code  = $exception->getHttpStatus();
            $charge->message  = $exception->getMessage();
            $charge->status = $exception->getStripeCode();
        }
        return $charge;
    }

    public function createPaymentIntent($amount,$currency,$source,$description,$payment_id){
        return $charge = $this->stripe->paymentIntents->create([
            'amount' => 100 * $amount,
            'currency' => $currency,
            'customer'=> $source,
            'description' => $description,
            'payment_method'=>$payment_id,
            'off_session' => true,
            'confirm' => true,
            //'confirmation_method' => 'manual',
            //'confirm'=> true,
            //'off_session' => true,
            //'setup_future_usage'=>'off_session',
            //'payment_method_types' => ['card'],

        ]);
    }

    public function generateResponse($intent)
    {
        # Note that if your API version is before 2019-02-11, 'requires_action'
        # appears as 'requires_source_action'.
        if ($intent->status == 'requires_action' &&
            $intent->next_action->type == 'use_stripe_sdk') {
            # Tell the client to handle the action
            echo json_encode( [
                'requires_action' => true,
                'payment_intent_client_secret' => $intent->client_secret
            ] );
        } else if ($intent->status == 'succeeded') {
            # The payment didn’t need any additional actions and completed!
            # Handle post-payment fulfillment
            echo json_encode( [
                "success" => true
            ] );
        } else {
            # Invalid status
            http_response_code( 500 );
            echo json_encode( ['error' => 'Invalid PaymentIntent status'] );
        }
    }

    public function unsubscribe($sub_id){
        return $this->stripe->subscriptionSchedules->cancel(
            $sub_id
        );
    }

    public function createdHooks(){
        return $this->stripe->webhookEndpoints->create([
            'url' => url("/payment/stripe/hooks/create"),
            'enabled_events' => [
                'charge.failed',
                'charge.succeeded',
                'payment_intent.payment_failed',
                'payment_intent.requires_action',
                'payment_intent.succeeded'
            ],
        ]);
    }

    public function editProduct($prod_id,$metadata){
        $this->stripe->products->update(
            $prod_id,
            ['metadata' => ['is_recurring' => $metadata]]
        );
    }

    public function deleteCustomer($cus_id){
        $this->stripe->customers->delete(
            $cus_id,
            []
        );
    }

    public function retreiveSubscriptionSchedule($subscip_id){
        return $this->stripe->subscriptionSchedules->retrieve(
            $subscip_id,
            []
        );
    }

    public function retrievePricePlan($price_id){
        return $this->stripe->plans->retrieve(
            $price_id,
            []
        );
    }

    public function createNextDate($interval,$interval_count=NULL)
    {
        $currentDate = Carbon::now();
        $interval =  preg_replace('/\d+/u', '', $interval);
        switch ($interval) {
            case "day":
                $currentDate = $currentDate->addDay($interval_count);
              break;
            case "week":
                $currentDate = $currentDate->addWeek($interval_count);
              break;
            case "month":
                $currentDate = $currentDate->addMonth($interval_count);
              break;
            case "year":
                $currentDate = $currentDate->addYear();
              break;
            default:
              $currentDate = $currentDate->addMinute(5);
          }
          return $currentDate->timestamp;
    }


}
