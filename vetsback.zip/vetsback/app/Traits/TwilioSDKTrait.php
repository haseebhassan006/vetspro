<?php

namespace App\Traits;

use App\Vet;
use App\Chat;
use App\User;
use App\Queue;
use App\StaffQueue;
use App\SubAdmin;
use App\TChatInfo;
use Carbon\Carbon;
use App\ChatDetail;
use App\WebappUser;
use App\ChatEndedBy;
use App\VetCareUser;
use Aws\S3\S3Client;
use App\TChatMessage;
use function foo\func;
use Mockery\Exception;
use Twilio\Rest\Client;
use App\FailedHandshake;
use Twilio\Jwt\AccessToken;
use Illuminate\Http\Request;
use Twilio\Http\GuzzleClient;
use Aws\Exception\AwsException;
use Aws\Credentials\Credentials;
use Twilio\Jwt\Grants\ChatGrant;
use Twilio\Jwt\Grants\VideoGrant;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Log;
use App\Mail\InformClientErrorEmail;
use GuzzleHttp\Client as HttpClient;
use Illuminate\Support\Facades\Mail;
use Twilio\Exceptions\RestException;
use Twilio\Exceptions\TwilioException;
use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\Storage;
use GuzzleHttp\Exception\ClientException;
use GuzzleHttp\Exception\GuzzleException;
use GuzzleHttp\Exception\RequestException;
use Twilio\Exceptions\ConfigurationException;
use App\Mail\SendChatOnEmail;
use App\Events\EndChatEmailEvent;

trait TwilioSDKTrait{
    private $appName;
    private $sid;
    private $token;
    private $serviceSid;
    private $twilioApiKey;
    private $twilioApiSecret;
    private $twilioCredentialSid;
    private $doctor_api_key;
    private $user_api_key;
    private $channel_name;
    private $configChat;
    private $serviceRoleSid;
    private $channelRoleUserSid;
    private $channelRoleVetSid;
    private $twilioCredentialSidAndroidVetsPlusMore;
    private $twilioCredentialSidIOSVetsPlusMore;
    private $twilio;
    private $channelRoleAdminSid;
    private $channelNoRoleSid;
    private $configRoom;
    private $credentials;
    private $twilioCredentialSidAndroidVetApp;
    private $twilioCredentialSidIOSVetApp;
    private $configComposition;
    private $notify;
    private $user_notify_sid;
    private $admin_user_sid;
    private $twilioCredentialSidIOSVetCareHotline;
    private $twilioCredentialSidAndroidVetCareHotline;
    private $twilioOnePetCredentailsAndroid;
    private $twilioOnePetCredentailsIOs;
    private $twilioPetCubeCredentialFCM;


    public function generic(){
        if (App::environment('local', 'staging')) {
            $this->appName = config('services.vpm-chats-local.app_name');
            $this->sid = config('services.vpm-chats-local.account_sid');
            $this->token = config('services.vpm-chats-local.auth_token');
            $this->serviceSid = config('services.vpm-chats-local.service_sid');
            $this->twilioApiKey = config('services.vpm-chats-local.api_key');
            $this->twilioApiSecret = config('services.vpm-chats-local.api_secret');
            $this->twilioCredentialSidAndroidVetsPlusMore = config('services.vpm-chats-local.push_android_user_vpm');
            $this->twilioCredentialSidIOSVetsPlusMore = config('services.vpm-chats-local.push_ios_user_vpm');
            $this->twilioCredentialSidAndroidVetApp = config('services.vpm-chats-local.doctor_app_stag_android');
            $this->twilioCredentialSidIOSVetApp = config('services.vpm-chats-local.doctor_app_stag_ios');
            $this->serviceRoleSid = config('services.vpm-chats-local.service_role_sid');
            $this->channelRoleUserSid = config('services.vpm-chats-local.channel_role_sid');
            $this->channelRoleVetSid = config('services.vpm-chats-local.channel_vet_sid');
            $this->channelRoleAdminSid = config('services.vpm-chats-local.channel_admin_sid');
            $this->configChat = 'https://dev.itmedicalvetsolutions.com/api/user/chat/hooks';
            $this->twilio = new Client($this->twilioApiKey, $this->twilioApiSecret);
            $this->credentials = base64_encode($this->twilioApiKey . ':' . $this->twilioApiSecret);
            $this->configRoom = 'https://dev.itmedicalvetsolutions.com/api/video/start/room';
            $this->configComposition = 'https://dev.itmedicalvetsolutions.com/api/video/start/composition';
            $this->notify = config('services.vpm-chats-local.notify_sid');
            $this->vet_to_inform_user_sid = config('services.vpm-chats-local.vet_to_inform_user_sid');
            $this->user_notify_sid = config('services.vpm-chats-local.user_notify_sid');
            $this->admin_user_sid = config('services.vpm-chats-local.admin_user_sid');
            $this->twilioCredentialSidIOSVetCareHotline = config('services.vpm-chats-local.credential_sid_ios_vetcarehotline');
            $this->twilioCredentialSidAndroidVetCareHotline = config('services.vpm-chats-local.credential_sid_android_vetcarehotline');
            $this->twilioOnePetCredentailsAndroid = config('services.vpm-chats-local.twilio_one_pet_credential_android');
            $this->twilioOnePetCredentailsIOs = config('services.vpm-chats-local.twilio_one_pet_credential_ios');
            $this->twilioPetCubeCredentialFCM = config('services.vpm-chats-prod.twilio_pet_cube_credential_android');
            $this->twilioPetCubeCredentialIOS = config('services.vpm-chats-local.twilio_pet_cube_credential_ios');
            if(request()->api_key != null && appId_by_key(request()->api_key) == 71 && request()->conversation_request != null && request()->conversation_request == 'video'){
                // $this->serviceSid = 'ISe7bd6e01d8d163ef97cada13f10a7c98';
            }

        }
        if (App::environment(['production'])) {
            $this->appName = config('services.vpm-chats-prod.app_name');
            $this->sid = config('services.vpm-chats-prod.account_sid');
            $this->token = config('services.vpm-chats-prod.auth_token');
            $this->serviceSid = config('services.vpm-chats-prod.service_sid');
            $this->twilioApiKey = config('services.vpm-chats-prod.api_key');
            $this->twilioApiSecret = config('services.vpm-chats-prod.api_secret');
            $this->twilioCredentialSidAndroidVetsPlusMore = config('services.vpm-chats-prod.credential_sid_android_vetsplusmore');
            $this->twilioCredentialSidIOSVetsPlusMore = config('services.vpm-chats-prod.credential_sid_ios_vetsplusmore');
            $this->twilioCredentialSidAndroidVetApp = config('services.vpm-chats-prod.vetsapp-prod-fcm');
            $this->twilioCredentialSidIOSVetApp = config('services.vpm-chats-prod.vetsapp-prod-apn');
            $this->serviceRoleSid = config('services.vpm-chats-prod.service_role_sid');
            $this->channelRoleUserSid = config('services.vpm-chats-prod.channel_role_sid');
            $this->channelRoleVetSid = config('services.vpm-chats-prod.channel_vet_sid');
            $this->channelRoleAdminSid = config('services.vpm-chats-prod.channel_admin_sid');
            $this->configChat = 'https://itmedicalvetsolutions.com/api/user/chat/hooks';
            $this->twilio = new Client($this->twilioApiKey, $this->twilioApiSecret);
            $this->credentials = base64_encode($this->twilioApiKey . ':' . $this->twilioApiSecret);
            $this->configRoom = 'https://itmedicalvetsolutions.com/api/video/start/room';
            $this->configComposition = 'https://itmedicalvetsolutions.com/api/video/start/composition';
            $this->notify = config('services.vpm-chats-prod.notify_sid');
            $this->user_notify_sid = config('services.vpm-chats-prod.user_notify_sid');
            $this->vet_to_inform_user_sid = config('services.vpm-chats-local.vet_to_inform_user_sid');
            $this->admin_user_sid = config('services.vpm-chats-prod.admin_user_sid');
            $this->twilioCredentialSidIOSVetCareHotline = config('services.vpm-chats-prod.credential_sid_ios_vetcarehotline');
            $this->twilioCredentialSidAndroidVetCareHotline = config('services.vpm-chats-prod.credential_sid_android_vetcarehotline');
            $this->twilioOnePetCredentailsAndroid = config('services.vpm-chats-local.twilio_one_pet_credential_android');
            $this->twilioOnePetCredentailsIOs = config('services.vpm-chats-local.twilio_one_pet_credential_ios');
            $this->twilioPetCubeCredentialFCM = config('services.vpm-chats-prod.twilio_pet_cube_credential_android');
            $this->twilioPetCubeCredentialIOS = config('services.vpm-chats-prod.twilio_pet_cube_credential_ios');
        }

    }

    /**
     * @param $identity
     * @param null $dev_type
     * @param null $app_id
     * @param string $room_name
     * @return string
     */
    private function init($identity, $dev_type=NULL, $app_id=NULL, $room_name='null'){
        $twilioToken = new AccessToken(
            $this->sid,
            $this->twilioApiKey,
            $this->twilioApiSecret,
            86000,
            $identity
        );
        $serviceSid = $this->serviceSid;
        $this->fetchBindings($serviceSid,$identity);
        //For Chat use this text block
        // Create Chat grant
        $chatGrant = new ChatGrant();
        $chatGrant->setServiceSid($serviceSid);
        if(@$app_id){
            $findapp = \App\App::find($app_id);
            //Vet Care
            if ($dev_type == 'web' && $findapp->app_type == 'whitelabel-webapp') {
                $chatGrant->setPushCredentialSid($this->twilioCredentialSidAndroidVetsPlusMore);
            }

        }
        //Vet Doctor App
        if (($dev_type == 'android' || $dev_type == 'web') && $app_id == 1) {
            $chatGrant->setPushCredentialSid($this->twilioCredentialSidAndroidVetApp);
        }
        if ($dev_type == 'ios' && $app_id == 1) {
            $chatGrant->setPushCredentialSid($this->twilioCredentialSidIOSVetApp);
        }
        //VetsPlusmore
        if ($dev_type == 'ios' && $app_id == 2) {
            $chatGrant->setPushCredentialSid($this->twilioCredentialSidIOSVetsPlusMore);
        }
        if ($dev_type == 'android' && $app_id == 2) {
            $chatGrant->setPushCredentialSid($this->twilioCredentialSidAndroidVetsPlusMore);
        }
        //VetCareHotline
        if ($dev_type == 'ios' && $app_id == 13) {
            $chatGrant->setPushCredentialSid($this->twilioCredentialSidIOSVetCareHotline);
        }
        if ($dev_type == 'android' && $app_id == 13) {
            $chatGrant->setPushCredentialSid($this->twilioCredentialSidAndroidVetCareHotline);
        }
        //Linkmyvet
        if ($dev_type == 'ios' && $app_id == 14) {
            $chatGrant->setPushCredentialSid($this->twilioCredentialSidIOSVetCareHotline);
        }
        if ($dev_type == 'android' && $app_id == 14) {
            $chatGrant->setPushCredentialSid($this->twilioCredentialSidAndroidVetCareHotline);
        }
        //OnePet
        if ($dev_type == 'ios' && $app_id == 8) {
            $chatGrant->setPushCredentialSid($this->twilioCredentialSidIOSVetCareHotline);
        }
        if ($dev_type == 'android' && $app_id == 8) {
            $chatGrant->setPushCredentialSid($this->twilioCredentialSidAndroidVetCareHotline);
        }
        //PetCube
        if (($dev_type == 'android' || $dev_type == 'web') && $app_id == 5) {
            $chatGrant->setPushCredentialSid($this->twilioPetCubeCredentialFCM);
        }
        if (($dev_type == 'ios') && $app_id == 5) {
            $chatGrant->setPushCredentialSid($this->twilioPetCubeCredentialIOS);
        }
        //Good Charlie
        if (($dev_type == 'android' || $dev_type == 'web') && $app_id == 71) {
            $chatGrant->setPushCredentialSid('CRd02b890897b615a3fe237e7454295751');
        }



        //$chatGrant->setEndpointId($endpointId);
        // Add grant to token
        $twilioToken->addGrant($chatGrant);

        // Create Video grant
        $videoGrant = new VideoGrant();
        //$videoGrant->setRoom($room_name);
        $twilioToken->addGrant($videoGrant);

        return $twilioToken->toJWT();
    }

    /** Chat access methods start
     * @param $channelName
     * @param $userId
     * @param $vetId
     * @param $appId
     * @param $vet_full_name
     * @param $user_full_name
     * @param $pet_info
     * @param null $user_profile
     * @param null $vet_profile
     * @param $app_name
     * @param $is_protect
     * @return mixed
     * @throws TwilioException
     */
    private function createChannel($channelName,$userId,$vetId,$appId,$vet_full_name,$user_full_name,$pet_info,$user_profile=NULL,$vet_profile=NULL,$app_name,$is_protect){
        $serviceSid = $this->serviceSid;
        // Get Activated Staff
        $subAdmin = $this->subAdmin();
        $twilio = $this->twilio;
        $already_a_channel = $this->fetchChannelInitial($channelName);
        try{
            ## Step 1
            //$already_a_channel = $this->fetchChannelInitial($channelName);
            $updated_name = $vet_full_name.'-'.$user_full_name;
            $attributes = [
                    "user" => [
                            "user_id"=>$userId,
                            "user_name"=>$user_full_name,
                            "profile"=>$user_profile,
                            "role"=>$is_protect
                    ],
                    "vet" => [
                        "vet_id"=>$vetId,
                        "vet_name"=>$vet_full_name,
                        "profile"=>$vet_profile,
                    ],
                    "pet" => [
                        $pet_info
                    ],
                    "app"=>[$app_name],
                ];
            if($already_a_channel == 'false'){
                $channel = $twilio->chat->v2->services($serviceSid)
                    ->channels
                    ->create([
                        'friendlyName'=>$updated_name,
                        'uniqueName' => $channelName,
                        'type' => 'private',
                        'attributes'=>json_encode($attributes),
                        //'attributes'=>$attributes,
                    ]);
                $this->insertChannelWebhooksToTwilio($channel->sid);
                ## Step 2
                //$this->insertChannelWebhooksToTwilio($channelName);
                //Save in our database
                Chat::updateOrCreate(['channel_sid'=>$channel->sid],[
                    'vet_id'=>$vetId, 'user_id'=>$userId, 'app_id'=>$appId ,'pet_id'=>$pet_info->id,'status'=>'false'
                ]);
                ## Step 3 ,4, 5
                return $response = $this->createMemberAndSendMessage($channelName,$userId,$vetId,$appId,$subAdmin,$pet_info,$user_full_name);
            }
            else{

                $channelSid = $this->fetchChannel($channelName);
                Chat::updateOrCreate(['channel_sid'=>$channelSid],[
                    'vet_id'=>$vetId, 'user_id'=>$userId, 'app_id'=>$appId
                ]);
                return $response = $this->createMemberAndSendMessage($channelName,$userId,$vetId,$appId,$subAdmin,$pet_info,$user_full_name);
                //return $channelSid;
            }
        }
        catch (TwilioException $exception){
            throw new TwilioException($exception->getMessage());
            //return $response = $this->errorResponse($exception->getMessage(),$exception->getCode());
        }

    }

    private function createMemberAndSendMessage($channelName,$userId,$vetId,$appId,$subAdmin=null,$pet_info,$user_full_name){

        $serviceSid = $this->serviceSid;

        $twilio = $this->twilio;

        $member_vet = 'app-1_vet-'.$vetId;
        $member_user = 'app-'.$appId.'_user-'.$userId;
        $member_admin = 'admin-2';

        $this->createMember($channelName,$member_user,$this->channelRoleUserSid);
        $this->sendAutoMessage($channelName,$member_vet,$pet_info,$user_full_name);
        $this->createMember($channelName,$member_vet,$this->channelRoleVetSid);
        $this->createMember($channelName,$member_admin,$this->channelRoleAdminSid);
        // Adding Activated Staff to Chat
        if($subAdmin != null){
            foreach($subAdmin as $staff)
            {
                $member_subAdmin = ($subAdmin != null) ? 'staff-'.$staff->id : '' ;
                $this->createMember($channelName,$member_subAdmin,$this->channelRoleAdminSid);
            }
        }
        $channelSid = $this->fetchChannel($channelName);

        return $channelSid;
    }

    private function updateChannelAttribute($channel_sid,$attributes){
        $serviceSid = $this->serviceSid;
        $twilio = $this->twilio;
        $channel = $twilio->chat->v2->services($serviceSid)
            ->channels($channel_sid)
            ->update(["attributes" => $attributes]);
    }

    private function createMember($channelName,$id,$role_sid){

        $serviceSid = $this->serviceSid;
        $twilio = $this->twilio;

        try {
            $member = $twilio->chat->v2->services($serviceSid)
                ->channels($channelName)
                ->members
                ->create($id,['roleSid' =>$role_sid]);
        } catch (TwilioException $exception) {
            throw new TwilioException($exception->getMessage());
            //$member = $e->getMessage();
        }

        return $member;
    }

    private function sendAutoMessage($channelsid,$member_vet,$pet_info,$user_full_name){
        $serviceSid = $this->serviceSid;
        $twilio = $this->twilio;
        $message = $twilio->chat->v2->services($serviceSid)
            ->channels($channelsid)
            ->messages
            ->create(["body"=>"Hi, ". strtok($user_full_name,' ') . " How may I assist you and ".$pet_info->name." today?",'from'=>$member_vet]);
        $channel_name = $this->fetchChannelName($channelsid);
        $fetch_channel_sid = $this->fetchChannel($channelsid);
        $this->saveLastMessageIndexDB($fetch_channel_sid,$message->sid,$message->body,$channel_name);
        return $message->sid;
    }

    private function fetchMember($serviceSid,$channelsid){
        $serviceSid = $this->serviceSid;
        $twilio = $this->twilio;
        $member = $twilio->chat->v2->services($serviceSid)
            ->channels($channelsid)
            ->members
            ->read([],3);

        return $member;
    }

    /**
     * @param $user_sid
     * @return string
     */
    private function fetchUserChannel($user_sid){
        $serviceSid = $this->serviceSid;
        $twilio = $this->twilio;
        $flag = 'false';
        try{
            $userChannels = $twilio->chat->v2->services($serviceSid)
                ->users($user_sid)
                ->userChannels
                ->read(20);
            foreach ($userChannels as $record) {
                $flag = 'true';
                $data = $record->channelSid;
            }
            return $userChannels;
        }
        catch (\Exception $e){
            return $flag;
            //return 'No Channels Found.Please start a chat';
        }


    }

    /**
     * @param $channelsid
     * @return array
     * @throws \Exception
     */
    private function fetchAllMembers($channelsid){
        $serviceSid = $this->serviceSid;
        $twilio = $this->twilio;
        try {
            $members = $twilio->chat->v2->services($serviceSid)
                ->channels($channelsid)
                ->members
                ->read([], 20);

            $res = array();
            $i = 0;
            foreach ($members as $record) {
                $res[$i]['member_id'] = $record->sid;
                $res[$i]['identity'] = $record->identity;
                $res[$i]['role_sid'] = $record->roleSid;
                $i ++;
            }
        }
        catch (TwilioException $exception){
            throw new \Exception($exception->getMessage());
        }
        return $res;
    }

    private function fetchWebhooks($channelsid){
        $serviceSid = $this->serviceSid;
        $twilio = $this->twilio;

        $webhooksData = $twilio->chat->v2->services($serviceSid)
            ->channels($channelsid)
            ->webhooks
            ->read(20);

        foreach ($webhooksData as $record) {
            return $record->sid;
        }
    }

    private function insertChannelWebhooksToTwilio($channelSid){
        $configurationUrl = $this->configChat;
        $twilio = $this->twilio;
        $serviceSid = $this->serviceSid;
        try{
            $webhook = $twilio->chat->v2->services($serviceSid)
                ->channels($channelSid)
                ->webhooks
                ->create(
                    "webhook",
                    ["configurationUrl" => $configurationUrl, "configurationMethod" => "POST", "configurationFilters" => ["onMessageSent","onMediaMessageSent","onMemberRemoved"], "configurationRetryCount" => 2]
                );

        }
        catch (TwilioException $exception){

        }
    }

    private function getChannelWebhooks($channel){
        $twilio = $this->twilio;
        $serviceSid = $this->serviceSid;
        try{
            return $twilio->chat->v2->services($serviceSid)
                ->channels($channel)
                ->webhooks
                ->read(20);
        }
        catch (TwilioException $exception){
            throw new \Exception($exception->getMessage());
        }
    }

    private function insertChannelWebhooksToDatabase($channelSid){

    }

    private function saveLastMessageIndexDB($channelsid,$msid,$body,$channel_name){
        try{
            $t_chat_message = TChatMessage::firstOrCreate([
                'msg_sid' => $msid,
                'channel_sid'=> $channelsid,
                'c_friendly_name'=> $channel_name,
                'last_message'=>$body
            ]);
        }
        catch (QueryException $e){
            throw new \Exception($e->getMessage());
        }
    }

    private function createUser($data){
        $twilio = $this->twilio;
        $serviceSid = $this->serviceSid;
        $user = $twilio->chat->v2->services($serviceSid)
            ->users
            ->create($data['identity'],['friendlyName'=> $data['friendlyName'],'attributes'=> $data['attributes']]);
        return $user;
    }

    private function fetchAndUpdateUser($app_id,$identity){
        $twilio = $this->twilio;
        $serviceSid = $this->serviceSid;
        $user = $twilio->chat->v2->services($serviceSid)
            ->users($identity)
            ->update(['attributes'=>json_encode(["app_id"=>$app_id])]);
        return $user;
    }

    private function fetchBindings($serviceSid,$identity){
        $twilio = $this->twilio;
        //Fetch and delete old bindings
        $bindings = $twilio->chat->v2->services($serviceSid)
            ->bindings
            ->read([], 50);
        foreach ($bindings as $record) {
            if ($record->identity == $identity) {
                $twilio->chat->v2->services($serviceSid)
                    ->bindings($record->sid)
                    ->delete();
            }
        }
    }

    private function fetchChannel($channelName,$type='str'){
        $twilio = $this->twilio;
        $serviceSid = $this->serviceSid;
        $type_cast = $type?$type:'str';
        try{
            $channel = $twilio->chat->v2->services($serviceSid)
                ->channels($channelName)
                ->fetch();
            if($type_cast == 'arr'){
                return $channel;
            }
            else{
                return $channel->sid;
            }
        }
        catch (TwilioException $e){
            throw new TwilioException($e->getMessage());
        }
    }

    private function fetchChannelName($channelName){
        $twilio = $this->twilio;
        $serviceSid = $this->serviceSid;
        try{
            $channel = $twilio->chat->v2->services($serviceSid)
                ->channels($channelName)
                ->fetch();
        }
        catch (TwilioException $e){
            $channel = $e->getMessage();
        }
        return $channel->friendlyName;
    }

    private function fetchChannelInitial($channelName){
        $twilio = $this->twilio;
        $serviceSid = $this->serviceSid;
        try{
            $channel = $twilio->chat->v2->services($serviceSid)
                ->channels($channelName)
                ->fetch();
            $flag = 'true';
        }
        catch (TwilioException $e){
            $channel = $e->getMessage();
            $flag = 'false';
        }
        return $flag;
    }

    private function fetchMyUserSid($identity){
        $twilio = $this->twilio;
        $serviceSid = $this->serviceSid;
        return $twilio->chat->v2->services($serviceSid)
            ->users($identity)
            ->fetch();
    }

    private function createChannelWebhook($channelSid){
        $twilio = $this->twilio;
        $serviceSid = $this->serviceSid;
        $configurationUrl = $this->configurationUrl;
        //Create new webhooks
        $webhook = $twilio->chat->v2->services($serviceSid)
            ->channels($channelSid)
            ->webhooks
            ->create(
                "webhook",
                ["configurationUrl" => $configurationUrl, "configurationMethod" => "POST", "configurationFilters" => ["onMessageSent","onMediaMessageSent","onMemberRemoved"], "configurationRetryCount" => 2]
            );


    }

    private function fetchSingleMessage($channel_sid,$msg_sid){
        $twilio = $this->twilio;
        $serviceSid = $this->serviceSid;

        return $get_this_message = $twilio->chat->v2->services($serviceSid)
            ->channels($channel_sid)
            ->messages($msg_sid)
            ->fetch();

    }

    private function fetchMediaMessage($media_sid){
        $serviceSid = $this->serviceSid;
        $apiKey = $this->sid;
        $apiToken = $this->token;
        try{
            $uploadURL = 'https://mcs.us1.twilio.com/v1/Services/'.$serviceSid.'/Media/'.$media_sid;
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $uploadURL);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_USERPWD, "$apiKey:$apiToken");
            curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
            $output = curl_exec($ch);
            $info = curl_getinfo($ch);
            curl_close($ch);
            $json = json_decode($output);
            return $json->links->content_direct_temporary;
        }
        catch (RequestException $e){
            throw new RequestException($e->getResponse(),$e->getCode());
        }
    }

    private function storeInitialChat($user_id,$vet_id,$pet_id,$channel_sid){
        $chat = Chat::create([
            'rec_id'=>$vet_id,
            'sender_id'=> $user_id,
            't_chat_type_id'=>1,
            'pet_id'=>$pet_id
        ]);

        $webhook_id = $this->fetchWebhooks($channel_sid);

        $member_data = $this->fetchAllMembers($channel_sid);

        $t_chat_info = TChatInfo::create([
            'chat_id' => $chat->id,
            'member' => json_encode($member_data),
            'channel_sid'  => $channel_sid,
            'webhook_id'   => $webhook_id
        ]);

        return $chat->id;
    }

    private function updateChannelUniqueName($channel_sid,$user_id=null,$app_id=null,$appName='null',$emergency=null,$reason=null,$recommendation=null,$user_like_twilio=null,$source = null){
        $twilio = $this->twilio;
        $serviceSid = $this->serviceSid;
        $before = $twilio->chat->v2->services($serviceSid)
            ->channels($channel_sid)
            ->fetch();
        if (str_contains($before->uniqueName,'chatEnded')) {
            $before_arr = explode('-chatEnded',$before->uniqueName);
            $before->uniqueName = $before_arr[0];
        }
        $uniqueName = $before->uniqueName.'-chatEnded-'.Carbon::now();
        $after = $twilio->chat->v2->services($serviceSid)
            ->channels($channel_sid)
            ->update(["uniqueName" => $uniqueName]);
        $this->saveMessagesToChat($channel_sid);
        $members = $this->fetchAllMembers($channel_sid);
        Chat::where('channel_sid',$channel_sid)->update(['status'=>'true']);
        $is_sent = 0;
        foreach ($members as $member){
           if($member['role_sid'] == $this->channelRoleVetSid ){
               if($user_id && $app_id && $source != 'webApp' && $is_sent == 0){
                $is_sent = 1;
                $chatDetails = $this->getDetailsOfUserAndApp($user_id,$app_id);
                $twilio->chat->v2->services($serviceSid)
                   ->channels($channel_sid)
                   ->messages
                   ->create(["body"=>$chatDetails['userName'] . ", if you need further assistance, please don't hesitate to reconnect with us at any time. On behalf of ". ucfirst($chatDetails['appName']) . ", we want to thank you for reaching out to us.",'from'=>$member['identity']]);
               }
            //    Commenting for now as we are not sending message on chat end from backend side
            //    else{
            //         $twilio->chat->v2->services($serviceSid)
            //         ->channels($channel_sid)
            //         ->messages
            //         ->create(["body"=>"Chat has been ended",'from'=>$member['identity']]);
            //    }
           }

            //Remove Admin & Vet from channel
            if($member['role_sid'] == $this->channelRoleVetSid || $member['role_sid'] == $this->channelRoleAdminSid){
                try {
                    $this->removeMember($channel_sid,$member['identity']);
                } catch (TwilioException $e) {}
            }

        }

        if($appName == 'petacumen'){
            //Make HTTP Request to pawp
            if (App::environment('production')){
                $url = 'https://api.dogtastic.co/';
                $uri = 'api/vpm-hooks';
                $username = config('services.vpm-chats-prod.petacumen_user_key');
                $password = config('services.vpm-chats-prod.petacumen_user_secret');
            }
            if (App::environment('local', 'staging')) {
                $url = 'https://api.dogtastic.co/';
                $uri = 'api/vpm-hooks';
                $username = config('services.vpm-chats-local.petacumen_user_key');
                $password = config('services.vpm-chats-local.petacumen_user_secret');
            }
            $params = array(
                'event'=>'chat_ended',
                'channel_sid'=>$channel_sid,
                'ended_at'=>Carbon::now()
            );
            $header = ['Content-Type'=> 'application/json'];
            $this->httpRequestWithJson($url,$uri,$params,$username,$password,$header);
        }
        if($appName == 'petcube'){
            //Make HTTP Request to pawp
            if (App::environment('local', 'staging')) {
                $url = 'https://qa.petcube.com';
                $uri = '/api/vpm/chat/'.$channel_sid.'/end/';
                $username = config('services.vpm-chats-local.petcube_user_key');
                $password = config('services.vpm-chats-local.petcube_user_secret');
            }
            if (App::environment('production')) {
                $url = 'https://petcube.com';
                $uri = '/api/vpm/chat/'.$channel_sid.'/end/';
                $username = config('services.vpm-chats-prod.petcube_user_key');
                $password = config('services.vpm-chats-prod.petcube_user_secret');
            }
            $params = array(
                'emergency'=>$emergency
            );
            $header = ['Content-Type'=> 'application/json'];
            $this->httpRequestWithJson($url,$uri,$params,$username,$password,$header);
        }
        if($appName == 'vidaah'){
            //Make HTTP Request to pawp
            if (App::environment('local', 'staging')) {
                $url = 'https://vidaah-staging.web.app';
                $uri = '/api/recommendation';
                $username = config('services.vpm-chats-local.vidaah_user_key');
                $password = config('services.vpm-chats-local.vidaah_user_secret');
            }
//            if (App::environment('production')) {
//                $url = 'https://petcube.com';
//                $uri = '/api/vpm/chat/'.$channel_sid.'/end/';
//                $username = config('services.vpm-chats-prod.petcube_user_key');
//                $password = config('services.vpm-chats-prod.petcube_user_secret');
//            }
            $params = array(
                'reason'=>$reason,
                'channel_sid'=>$channel_sid,
                'recommendation'=>$recommendation
            );
            $header = ['Content-Type'=> 'application/json'];
            $this->httpRequestWithJson($url,$uri,$params,$username,$password,$header);
        }
        if($appName == 'Nimble'){
            //Make HTTP Request to pawp
            if (App::environment('local', 'staging')) {
                $url = 'http://staging-api.nimblepetapp.com';
                $uri = '/v3.0/updatevpmtransaction';
                $username = config('services.vpm-chats-local.nimble_user_key');
                $password = config('services.vpm-chats-local.nimbler_user_secret');
            }
            if (App::environment('production')) {
                $url = 'https://api.nimblepetapp.com';
                $uri = '/v3.0/updatevpmtransaction';
                $username = config('services.vpm-chats-prod.nimble_user_key');
                $password = config('services.vpm-chats-prod.nimbler_user_secret');
            }
            $params = array(
                'vpmdata'=> array(
                    'vpmuserid'=>$user_like_twilio,
                    'apikey'=>config('services.vpm-chats-prod.nimble_user_api_key'),
                    'channel_sid'=>$channel_sid,
                )
            );
            $header = ['Content-Type'=> 'application/json'];
            $this->httpRequestWithJson($url,$uri,$params,$username,$password,$header);
        }
    }

    private function saveMessagesToChat($channelName){
        $serviceSid = $this->serviceSid;
        $twilio = $this->twilio;
        try {
            $data = $twilio->chat->v2->services($serviceSid)
                ->channels($channelName);
            $channel_data =$data->fetch();
            $messages_data = $data->messages->read([], 50);
//
            // $get_chat_id = Chat::where('channel_sid',$channelName)->first();
            $get_chat_id = Chat::with('app')->where('channel_sid',$channelName)->first();
            $res = array();
            $attributes = $channel_data->attributes;
            foreach ($messages_data as $key=>$message){
                $res['body'][$key]['index'] = $message->index;
                $res['body'][$key]['type'] = $message->type;
                if($message->type == 'media'){
                    $res['body'][$key]['body'] = json_encode($message->media);
                }
                else{
                    $res['body'][$key]['body'] = $message->body;
                }
                $res['body'][$key]['date_created'] = $message->dateCreated;
                $res['body'][$key]['from'] = $message->from;

            }
            $res['chat_id'] = $get_chat_id->id;
            $res['attributes'] = $attributes;

            ChatDetail::create($res);
            
            if(!empty($get_chat_id->app['send_email_on'])){
                $chat_attrb=json_decode($attributes);
                $event_data = [];
                $event_data['send_email_on'] =$get_chat_id->app['send_email_on'];
                $event_data['app_name'] =$get_chat_id->app['name'];
                $event_data['vetname'] = $chat_attrb->vet->vet_name;
                $event_data['username'] = $chat_attrb->user->user_name;
                $event_data['chatdetails']=($res['body']);
                event(new EndChatEmailEvent($event_data));
            }
            
            $vetStatusupdate = Vet::find($get_chat_id->vet_id);
                    if(!empty($vetStatusupdate) && $vetStatusupdate->is_chat >= 1){
                        $vetStatusupdate->is_chat = $vetStatusupdate->is_chat - 1;
                        $vetStatusupdate->update();
                    }
            ChatEndedBy::create(['chat_id'=>$get_chat_id->id,'ended_by'=>'system']);


        } catch (TwilioException $exception) {
            throw new TwilioException($exception->getMessage());
        }
    }

    private function removeMember($channelName,$identity){
        $serviceSid = $this->serviceSid;
        $twilio = $this->twilio;
        try {
            $member = $twilio->chat->v2->services($serviceSid)
                ->channels($channelName)
                ->members($identity)
                ->delete();
        } catch (TwilioException $exception) {
            throw new TwilioException($exception->getMessage());
        }
    }

    private function deleteOLdChannels(){
        $serviceSid = $this->serviceSid;
        $twilio = $this->twilio;
        $userChannels = $twilio->chat->v2->services($serviceSid)
            ->users($this->admin_user_sid)
            ->userChannels
            ->read(50);
        foreach ($userChannels as $record) {
            $this->removeMember($record->channelSid);
        }
    }


    private function fetchAllChannels($url){
        $twilio = $this->twilio;
        $serviceSid = $this->serviceSid;
        $credentials = $this->credentials;
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CUSTOMREQUEST => 'GET',
            CURLOPT_HTTPHEADER => array(
                'Authorization: Basic '.$credentials,
                'Content-Type: application/json',
            ),
        ));
        $response = curl_exec($curl);
        curl_close($curl);
        return json_decode($response, true);
//        $channels = $twilio->chat->v2->services($serviceSid)
//            ->channels
//            ->read(['type'=>'private'], 1);
//
//        return $channels;
    }
    /** following methods are for Pawp App
     * @param $room_name
     * @return array
     */
    private function updateChannelFriendlyName($twilio_user_sid,$table_user_id){
        $twilio = $this->twilio;
        $serviceSid = $this->serviceSid;
        return $twilio->chat->v2->services($serviceSid)
            ->users($twilio_user_sid)
            ->update(["friendlyName" => "user-" . $table_user_id]);

    }
    /** Pawp methods end */
    /** Chat access methods end */

    /** Video access methods start
     * @param $room_name
     * @return
     * @throws TwilioException
     */
    private function createRoom($room_name){
        $twilio = $this->twilio;
        try{
            $room = $twilio->video->v1->rooms
                ->create([
                        "recordParticipantsOnConnect" => True,
                        "statusCallback" => $this->configRoom,
                        "type" => "group-small",
                        "uniqueName" => $room_name,
                        "maxParticipants"=>2,
                        //"enableTurn"=>false
                    ]);
        }
        catch (TwilioException $e){
            $room = [
                'message'=>$e->getMessage(),
                'status'=>'false'
            ];
        }

        return $room;
    }

    private function getPariticipant($url){
            $credentials = $this->credentials;
            $curl = curl_init();
            curl_setopt_array($curl, array(
                CURLOPT_URL => $url,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_CUSTOMREQUEST => 'GET',
                CURLOPT_HTTPHEADER => array(
                    'Authorization: Basic '.$credentials,
                    'Content-Type: application/json',
                ),
            ));
            $response = curl_exec($curl);
            curl_close($curl);
            return json_decode($response, true);
        }

    private function getPariticipantList($roomSid): bool
    {
        $twilio = $this->twilio;
        //usleep(180);
        $participants = $twilio->video->rooms($roomSid)
            ->participants->read(array("status" => "connected"));
        if(count($participants) === 2){
           $data = true;
            $keys = array_keys($participants);
            $found = false;
//            foreach ($keys as $key) {
//                //If the key is found in your string, set $found to true
//                $temp = explode('-', $key->identity);
////                if (false !== strpos("vet", $key)) {
////                    $data = true;
////                }
//                if (false !== preg_match_all('/vet/', $temp[1])) {
//                    $data = true;
//                }
//
////                if (in_array('user',$temp[1])) {
////                    $data = true;
////                }
//
//            }
        }
        else{
            $data =  false;
        }
        return $data;

    }

    private function createBindings($identity,$device_token,$binding_type,$data,$sound,$heading)
    {
        if(!isset($data['user_profile']['user_id']) && isset($data['user_profile']['vet_care_user_id']) && !empty(isset($data['user_profile']['vet_care_user_id'])))
        {
            $data['user_profile']['user_id'] = $data['user_profile']['vet_care_user_id'];
        }
        Log::alert('message '.$identity);
        Log::alert('device_token '.$device_token);
        Log::alert('binding_type '.$binding_type);
        Log::alert($data);

        $twilio = $this->twilio;
        // Create a notification
        $tobinding = json_encode([
            'binding_type'=>$binding_type,
            'address'=>$device_token
            ]);
        $rand = rand();
        $data['unique_key'] = $rand;
         $notification_sid = $twilio
            ->notify->services($this->notify)
            ->notifications->create([
                 "toBinding" => [
                     $tobinding
                ],
                "body" => $heading,
                "data" => $data,
                "category"=>'AcceptOrReject',
                "sound" => $sound
            ]);
        $response['notification_sid'] = $notification_sid->sid;
        $response['unique_key'] = $rand;
        Log::alert($response);
        return $response;
    }

    private function deleteBindings($binding_id){
        $twilio = $this->twilio;
        $twilio->notify->v1->services($this->notify)
            ->bindings($binding_id)
            ->delete();
    }
    /**
     * @param $device_token
     * @param $binding_type
     * @param $data
     * @param $body
     * @return array
     */
    private function pushNotify($device_token, $binding_type, $data , $body): array
    {
        $twilio = $this->twilio;
        // Create a notification
        $tobinding = json_encode([
            'binding_type'=>$binding_type,
            'address'=>$device_token
        ]);
        $notification_sid = $twilio
            ->notify->services($this->user_notify_sid)
            ->notifications->create([
                //"tag" => [$binding->sid],
                "toBinding" => [
                    $tobinding
                ],
                // "identity" => $identity,
                "body" => $body,
                "data" => $data,
               // "category"=>'AcceptOrReject',
                "sound" => "default"
            ]);
        $response['notification_sid'] = $notification_sid->sid;
        return $response;
    }

    private function fetchRoom($room){
        $twilio = $this->twilio;
        $room = $twilio->video->v1->rooms($room)->fetch();
        return $room;
    }
    /** Video access methods end  */

    private function getFigoUser($email){
        return ClientUsers::where(['email'=>$email])->first();
    }

    private function findIdentity($sid){
        return PetAssistantUser::where(['sid'=>$sid])->first();
    }
    //For video
    private function checkVetOnlineStatus($vet_id=null){
        if($vet_id != null){
            $vet = Vet::role('vets')->where('is_online',1)->where('id','!=',$vet_id)->where('is_call',0)->inRandomOrder()->first();
        }
        else{
            $vet = Vet::role('vets')->where('is_online',1)->where('is_call',0)->inRandomOrder()->first();
        }
        //$vet = Vet::role('vets')->where('is_online',1)->inRandomOrder()->first();
        return isset($vet->id) ? $vet->id:false;
    }

    private function vetQueue(){
        return Queue::with(['queue'=>function($q){
            $q->where('is_call',false);
        }])->where('status',false)->get();
    }

    private function vetQueueDuringVideoCall(){
        return Queue::with(['queue'=>function($q){
            $q->where('is_call',0);
        }])->where('status',0)->get();
    }

    private function staffQueue(){
        return StaffQueue::with(['queue'=>function($q){
            $q->where('is_call',false);
        }])->where('status',false)->get();
    }

    private function staffQueueDuringVideoCall(){
        return StaffQueue::with(['queue'=>function($q){
            $q->where('is_call',0);
        }])->where('status',0)->get();
    }

    //For chat
    private function checkOnlineVet(){

        $vets = Vet::role('vets')->where('is_online',1)->where('is_chat',0)->inRandomOrder()->get();
        if(sizeof($vets) < 1){

            $vets = Vet::role('vets')
            ->where('is_online',1)
            ->where('is_chat','<>',0)
            ->orderBy('is_chat', 'DESC')
            ->orderBy('updated_at', 'DESC')
            ->get();
        }
        $i = 0;
        foreach ($vets as $a_vet) {
            $temp_vets[$i] = $a_vet->id;
            $i++;
        }

            // if(count($temp_vets) > 1){
            //    $find_user_last_chat_time = Chat::whereIn('vet_id',$temp_vets)->where(['status','!=','false'])->get();
                // $find_user_last_chat_time = Chat::whereHas('ended_chat')->whereIn('vet_id',$temp_vets)->where('status','!=','false')->groupBy(['vet_id'])->inRandomOrder()->first();
                // $find_user_last_chat_time = Chat::whereHas('ended_chat')->whereIn('vet_id',$temp_vets)->where('status','!=','false')->groupBy(['vet_id'])->get();

                // $vet =$find_user_last_chat_time->vet_id;
                // if(count($find_user_last_chat_time) > 1){
//                    foreach ($find_user_last_chat_time as $item){
//                        $chat_temp_user_last_chat_time[] = $item->vet_id;
//                        $chat_temp_user_last_chat_time=array_unique($chat_temp_user_last_chat_time); // fetching the unique values only from array
//                         $vet = array_shift($chat_temp_user_last_chat_time); //removing the first element from array and return the removed element
// //                        foreach ($vet as $available_vet){
// //                            $vet = $available_vet->id;
// //                        }
//                    }

            //    }
            // }else{
                //    $vet = $a_vet->id;
            //    }
            if(@$temp_vets){
                $vet = array_pop($temp_vets); //deleting the last element of array
            }

            return isset($vet) ? $vet : false;

    }

    private function findPetAssistantID($id){
        return PetAssistantUser::where(['user_id'=>$id])->first();
    }

    private function setCallStatus($id,$status){
         Vet::where('id',$id)->update(['is_call'=>$status]);
    }

    private function notifyWebappConversationRequest($params=array()){
        if(App::environment('production')){
            //Make HTTP Request to pawp
            $url = 'https://vet-dev.one.pet/';
            $uri = 'v1/emergency-fund';
            //$username = config('services.pawp-clinic-stag.pawp_end_user_key');
            //$password = config('services.pawp-clinic-stag.pawp_end_user_pwd');
        }
        if (App::environment(['local', 'staging'])) {
            //Make HTTP Request to pawp
            $url = 'https://api.vet-dev.one.pet/';
            $uri = 'v1/emergency-fund';
            //$username = config('services.pawp-clinic-stag.pawp_end_user_key');
            //$password = config('services.pawp-clinic-stag.pawp_end_user_pwd');
        }
        $header = ['Content-Type'=> 'application/json'];
        $this->httpRequestWithJson($url,$uri,$params,$username,$password,$header);
    }

    private function chatEndedByUserApp($channel_sid,$vet_id,$user_id,$app_id){
        $twilio = $this->twilio;
        $serviceSid = $this->serviceSid;
        $before = $twilio->chat->v2->services($serviceSid)
            ->channels($channel_sid)
            ->fetch();
        $uniqueName = $before->friendlyName.'-chatEnded-'.Carbon::now();
        $after = $twilio->chat->v2->services($serviceSid)
            ->channels($channel_sid)
            ->update(["uniqueName" => $uniqueName]);
        //Notify doctor about end chat by user
        $this->informToVet($vet_id,$channel_sid,$user_id,$app_id);
        Chat::where('channel_sid',$channel_sid)->update(['status'=>'true']);

        $chatDetails = $this->getDetailsOfUserAndApp($user_id,$app_id);

        try {
            $twilio->chat->v2->services($serviceSid)
                    ->channels($channel_sid)
                    ->messages
                    ->create(["body"=>$chatDetails['userName'] . ", if you need further assistance, please don't hesitate to reconnect with us at any time. On behalf of ". ucfirst($chatDetails['appName']) . ", we want to thank you for reaching out to us.",'from'=>'app-1_vet-'.$vet_id]);

            $members = $this->fetchAllMembers($channel_sid);
            foreach ($members as $member){
                if($member['role_sid'] == $this->channelRoleVetSid || $member['role_sid'] == $this->channelRoleAdminSid){
                    try {
                        $this->removeMember($channel_sid,$member['identity']);
                    } catch (TwilioException $e) {}
                }
            }
            //$this->removeMemberForcefully($channel_sid,'admin-2');
            //$this->removeMemberForcefully($channel_sid,'app-1_vet-'.$vet_id);

        } catch (TwilioException $e) {
        }
        $this->saveToDB($channel_sid);
    }

    private function getDetailsOfUserAndApp($user_id,$app_id){
        $user = User::where('id', $user_id)->where('app_id',$app_id)->first();
        if(!$user){
            $user = VetCareUser::where('id', $user_id)->where('app_id',$app_id)->first();
        }
        if(!$user){
            $user = WebappUser::where('id', $user_id)->where('app_id',$app_id)->first();
        }

        $app = \App\App::where('id', $app_id)->first();

        $appName = $app->name;
        if($app->app_type == 'whitelabel-webapp'){
            if(!empty($app->appSettings->title)){
                $appName = $app->appSettings->title;
            }
        }

        $userName = '';
        if($user){
            $userName = $user->first_name;
        }

        return array(
            'appName'=>$appName,
            'userName'=>$userName,
            );
    }


    private function chatEndedByUserAppTestCase($channel_sid,$vet_id){
        $twilio = $this->twilio;
        $serviceSid = $this->serviceSid;
        $before = $twilio->chat->v2->services($serviceSid)
            ->channels($channel_sid)
            ->fetch();
        $uniqueName = $before->friendlyName.'-chatEnded-'.Carbon::now();
        $after = $twilio->chat->v2->services($serviceSid)
            ->channels($channel_sid)
            ->update(["uniqueName" => $uniqueName]);
        //Notify doctor about end chat by user
        try {
            $this->removeMemberForcefully($channel_sid,'admin-2');
            $this->removeMemberForcefully($channel_sid,'app-1_vet-'.$vet_id);

        } catch (TwilioException $e) {
        }
        $this->saveToDB($channel_sid);
    }

    protected function informToVet($vet_id,$channel_sid,$user_id,$app_id){
        $vetData = Vet::find($vet_id);
        $app = $this->findAppById($app_id);
        if(isset($vetData->devices) && !empty($vetData->devices)){
            if ($vetData->devices->dev_type == 'ios') {
                $binding_type = 'apn';
                $binding_address = $vetData->devices->device_token;
            } else {
                $binding_type = 'fcm';
                $binding_address = $vetData->devices->device_token;
            }
            $data = [
                'type' => 'showFeedback',
                'channel_sid'=>$channel_sid,
                'user_id'=>$user_id,
                'app_id'=>$app->name
            ];
            $this->userEndCallbindingsFromApps('vet_' . $vetData->id, $binding_address, $binding_type, $data, 'default', 'Chat ended by client');

            //$this->userEndCallbindings('vet_' . $vetData->id, $binding_address, $binding_type, $data, 'default', 'Chat ended by client');
        }
    }

    protected function informToUser($vet_id,$channel_sid,$user_id,$app_id,$type='showFeedback'){
        $userData = VetCareUser::find($user_id);
        $app = $this->findAppById($app_id);
        if(isset($userData->latestDevices) && !empty($userData->latestDevices) && $userData->latestDevices->device_token != null ){
            if ($userData->latestDevices->dev_type == 'ios') {
                $binding_type = 'apn';
                $binding_address = $userData->latestDevices->device_token;
            } else {
                $binding_type = 'fcm';
                $binding_address = $userData->latestDevices->device_token;
            }
            $data = [
                'type' => $type,
                'channel_sid'=>$channel_sid,
                'vet_id'=>$vet_id,
                'user_id'=>$user_id,
                'app_id'=>$app->name
            ];
            $this->userEndCallbindingsFromApps('app-' . $app_id . '_user-' . $user_id, $binding_address, $binding_type, $data, 'default', 'Chat ended by vet');
        }
    }

    private function saveToDB($channelName){
        $serviceSid = $this->serviceSid;
        $twilio = $this->twilio;
        try {
            $data = $twilio->chat->v2->services($serviceSid)
                ->channels($channelName);
            $channel_data =$data->fetch();
            // $messages_data = $data->messages->read([], 50);
            $messages_data = $data->messages->read([]);//save all twilio chats on db
            // $get_chat_id = Chat::where('channel_sid',$channelName)->first();
            $get_chat_id = Chat::with('app')->where('channel_sid',$channelName)->first();
            $res = array();
            $attributes = $channel_data->attributes;
            foreach ($messages_data as $key=>$message){
                $res['body'][$key]['index'] = $message->index;
                $res['body'][$key]['type'] = $message->type;
                if($message->type == 'media'){
                    $res['body'][$key]['body'] = json_encode($message->media);
                }
                else{
                    $res['body'][$key]['body'] = $message->body;
                }
                $res['body'][$key]['date_created'] = $message->dateCreated;
                $res['body'][$key]['date_updated'] = $message->dateUpdated;
                $res['body'][$key]['from'] = $message->from;

            }
            $res['chat_id'] = $get_chat_id->id;
            $res['attributes'] = $attributes;

            ChatDetail::create($res);
            if(!empty($get_chat_id->app['send_email_on'])){
                $chat_attrb=json_decode($attributes);
                $event_data = [];
                $event_data['send_email_on'] =$get_chat_id->app['send_email_on'];
                $event_data['app_name'] =$get_chat_id->app['name'];
                $event_data['vetname'] = $chat_attrb->vet->vet_name;
                $event_data['username'] = $chat_attrb->user->user_name;
                $event_data['chatdetails']=($res['body']);
                event(new EndChatEmailEvent($event_data));
            }

        } catch (TwilioException $exception) {
            throw new TwilioException($exception->getMessage());
        }
    }

    private function removeMemberForcefully($channelName,$identity){
        $serviceSid = $this->serviceSid;
        $twilio = $this->twilio;
        try {
            $member = $twilio->chat->v2->services($serviceSid)
                ->channels($channelName)
                ->members($identity)
                ->delete();
        } catch (TwilioException $exception) {
            throw new TwilioException($exception->getMessage());
            //$member = $e->getMessage();
        }

        return $member;
    }

    private function removeChannel($channelName){
        $serviceSid = $this->serviceSid;
        $twilio = $this->twilio;
        try {
            $twilio->chat->v2->services($serviceSid)
                ->channels($channelName)
                ->delete();
        } catch (TwilioException $exception) {
            throw new TwilioException($exception->getMessage());
        }
    }

    private function guzzleHttpRequestWithJson($url,$uri,$params,$username,$pwd,$header,$app){
        try {
            $httpclient = new \GuzzleHttp\Client(['base_uri' => $url]);
            $request = $httpclient->request('POST', $uri, [
                'json' => $params,
                'headers' => $header,
                'auth' => [$username, $pwd]
            ]);
            return $request->getBody();
        }
        catch (\Exception $exception){
            $code = $exception->getCode();
            if($code == 0){
                $code = 500;
            }
            $this->statusErrorCodes($code,$app,$exception->getMessage());
        }
    }

    public function statusErrorCodes($code,$app,$body){
        $date = Carbon::now()->toDateTimeString();
        $app = strtolower($app);
        switch ($code){
            case 401:
            case 406:
            case 500:
                switch ($app){
                    case 'vidaah':
                    case 'petacumen':
                    case 'onepet':
                    case 'petcube':
                        Mail::to('ali.raza@invisionsolutions.ca')->send(new InformClientErrorEmail($date,$app,$body,$code));
                        break;
                }
                break;

        }

    }

    // Activated Staff
    private function subAdmin(){
        return
        SubAdmin::where('is_active', 1)
         ->get();
    }

    public function userEndCallbindingsFromApps($identity,$device_token,$binding_type,$data,$sound,$heading)
    {
        $twilio = $this->twilio;
        // Create a notification
        // dd($notification);
        $tobinding = json_encode([
            'binding_type'=>$binding_type,
            'address'=>$device_token
        ]);
        $rand = rand();
        $data['unique_key'] = $rand;
        $notification_sid = $twilio
            ->notify->services($this->vet_to_inform_user_sid)
            ->notifications->create([
                "toBinding" => [
                    $tobinding
                ],
                "body" => $heading,
                "data" => $data,
                "category"=>'AcceptOrReject',
                "sound" => $sound
            ]);
        $response['notification_sid'] = $notification_sid->sid;
        $response['unique_key'] = $rand;
        return $response;
    }

    private function createStaffChannel($channelName, $fromUserObject, $toUserObject, $fromUserRole, $toUserRole){
        $serviceSid = $this->serviceSid;
        $twilio = $this->twilio;
        $already_a_channel = $this->fetchChannelInitial($channelName);
        try{
            $updated_name = $channelName . '_' . $fromUserObject->first_name . '_' . $toUserObject->first_name;
            $attributes = [
                    "from" => [
                            "user_id"=>$fromUserObject->id,
                            "user_name"=>$fromUserObject->first_name,
                            "role"=>$fromUserRole
                    ],
                    "to" => [
                            "user_id"=>$toUserObject->id,
                            "user_name"=>$toUserObject->first_name,
                            "role"=>$toUserRole
                    ],
                ];
            if($already_a_channel == 'false'){
                $channel = $twilio->chat->v2->services($serviceSid)
                    ->channels
                    ->create([
                        'friendlyName'=>$updated_name,
                        'uniqueName' => $channelName,
                        'type' => 'private',
                        'attributes'=>json_encode($attributes),
                    ]);
                return $response = $this->createStaffMemberAndSendMessage($channelName, $fromUserObject, $toUserObject, $fromUserRole, $toUserRole);
            }
            else{

                $channelSid = $this->fetchChannel($channelName);
                return $response = $this->createStaffMemberAndSendMessage($channelName, $fromUserObject, $toUserObject, $fromUserRole, $toUserRole);
            }
        }
        catch (TwilioException $exception){
            throw new TwilioException($exception->getMessage());
        }

    }

    private function createStaffMemberAndSendMessage($channelName, $fromUserObject, $toUserObject, $fromUserRole, $toUserRole){

        $serviceSid = $this->serviceSid;

        $twilio = $this->twilio;

        $member_from = $fromUserRole == 'admin' ? 'admin-2' : 'staff-'.$fromUserObject->id;
        $member_to = $toUserRole == 'admin' ? 'admin-2' : 'staff-'.$toUserObject->id;

        $this->createMember($channelName,$member_from,$this->channelRoleUserSid);
        $this->createMember($channelName,$member_to,$this->channelRoleAdminSid);
       
        $channelSid = $this->fetchChannel($channelName);

        return $channelSid;
    }


}
