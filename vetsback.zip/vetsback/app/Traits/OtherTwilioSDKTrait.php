<?php
namespace App\Traits;

use App\Vet;
use App\Chat;
use App\Queue;
use App\SubAdmin;
use App\VideoCall;
use Carbon\Carbon;
use App\ChatDetail;
use App\ChatEndedBy;
use App\VideoCallMedia;
use Twilio\Rest\Client;
use Twilio\Jwt\AccessToken;
use Illuminate\Http\Request;
use Aws\Exception\AwsException;
use Twilio\Jwt\Grants\ChatGrant;
use Twilio\Jwt\Grants\VideoGrant;
use Illuminate\Support\Facades\App;
use GuzzleHttp\Client as HttpClient;
use Twilio\Exceptions\TwilioException;
use Illuminate\Support\Facades\Storage;
use GuzzleHttp\Exception\GuzzleException;
use GuzzleHttp\Exception\RequestException;


trait OtherTwilioSDKTrait{
    private $tAppName;
    private $tSid;
    private $tToken;
    private $tServiceSid;
    private $tApiKey;
    private $tApiSecret;
    private $tCredentialSidAndroidVetApp;
    private $tCredentialSidIOSVetApp;
    private $tServiceRoleSid;
    private $tChannelRoleUserSid;
    protected $tChannelRoleVetSid;
    protected $tChannelRoleAdminSid;
    private $tConfigChat;
    private $auth;
    private $tCredentials;
    private $channelRoleAdminSid;
    private $channelNoRoleSid;
    private $configRoom;
    private $credentials;
    private $notification_ios_vets_app;
    private $notification_android_vets_app;
    private $configComposition;
    private $pawpnotify;
    private $pawpNotifyUser;

    public function construct(){
        if (App::environment('local', 'staging')) {
            $this->tSid 			     = config('services.pawp-clinic-stag.account_sid');
            $this->tToken 			 = config('services.vpawp-clinic-stag.auth_token');
            $this->tServiceSid 	     = config('services.pawp-clinic-stag.service_sid');
            $this->tApiKey 	 = config('services.pawp-clinic-stag.api_key');
            $this->tApiSecret   = config('services.pawp-clinic-stag.api_secret');
            $this->tServiceRoleSid = config('services.pawp-clinic-stag.service_role_sid');
            $this->tChannelRoleUserSid = config('services.pawp-clinic-stag.channel_role_sid');
            $this->tChannelRoleVetSid = config('services.pawp-clinic-stag.channel_vet_sid');
            $this->tChannelRoleAdminSid = config('services.pawp-clinic-stag.channel_admin_sid');
            $this->tConfigChat = 'http://dev.itmedicalvetsolutions.com/api/chat/store';
            $this->auth = new Client($this->tApiKey, $this->tApiSecret);
            $this->tCredentials = base64_encode($this->tApiKey.':'.$this->tApiSecret);
            $this->notification_ios_vets_app  = config('services.pawp-clinic-stag.notification_vets_app_ios');
            $this->notification_android_vets_app  = config('services.pawp-clinic-stag.notification_vets_app_android');
            $this->configRoom = 'http://dev.itmedicalvetsolutions.com/api/pawp/room/hooks';
            $this->pawpnotify = config('services.pawp-clinic-stag.pawpNotify');
            $this->pawpNotifyUser = config('services.pawp-clinic-stag.pawpNotifyUser');
        }
        if (App::environment(['production'])) {
            $this->tSid 			     = config('services.pawp-clinic-prod.account_sid');
            $this->tToken 			 = config('services.pawp-clinic-prod.auth_token');
            $this->tServiceSid 	     = config('services.pawp-clinic-prod.service_sid');
            $this->tApiKey 	 = config('services.pawp-clinic-prod.api_key');
            $this->tApiSecret   = config('services.pawp-clinic-prod.api_secret');
            $this->tServiceRoleSid = config('services.pawp-clinic-prod.service_role_sid');
            $this->tChannelRoleUserSid = config('services.pawp-clinic-prod.channel_role_sid');
            $this->tChannelRoleVetSid = config('services.pawp-clinic-prod.channel_vet_sid');
            $this->tChannelRoleAdminSid = config('services.pawp-clinic-prod.channel_admin_sid');
            $this->tConfigChat = 'http://itmedicalvetsolutions.com/api/chat/store';
            $this->auth = new Client($this->tApiKey, $this->tApiSecret);
            $this->tCredentials = base64_encode($this->tApiKey.':'.$this->tApiSecret);
            $this->notification_ios_vets_app  = config('services.pawp-clinic-prod.notification_vets_app_ios');
            $this->notification_android_vets_app  = config('services.pawp-clinic-prod.notification_vets_app_android');
            $this->configRoom = 'http://itmedicalvetsolutions.com/api/pawp/room/hooks';
            $this->pawpnotify = config('services.pawp-clinic-prod.pawpNotify');
            $this->pawpNotifyUser = config('services.pawp-clinic-prod.pawpNotifyUser');
        }
    }

    private function accessToken($identity,$dev_type=NULL,$app_id=NULL,$roomName='null'){
        $twilioToken = new AccessToken(
            $this->tSid,
            $this->tApiKey,
            $this->tApiSecret,
            86000,
            $identity
        );
        $serviceSid = $this->tServiceSid;
        $this->fetchBindingsOnPawp($serviceSid,$identity);
        //For Chat use this text block
        // Create Chat grant
        $chatGrant = new ChatGrant();
        $chatGrant->setServiceSid($serviceSid);
        if (($dev_type == 'android' || $dev_type == 'web') && $app_id == 1) {
            $chatGrant->setPushCredentialSid($this->notification_android_vets_app);
        }
        if ($dev_type == 'ios' && $app_id == 1) {
            $chatGrant->setPushCredentialSid($this->notification_ios_vets_app);
        }
        //$chatGrant->setEndpointId($endpointId);
        // Add grant to token
        $twilioToken->addGrant($chatGrant);
        // Create Video grant
        $videoGrant = new VideoGrant();
        //$videoGrant->setRoom($roomName);
        $twilioToken->addGrant($videoGrant);
        return $twilioToken->toJWT();
    }

    private function fetchBindingsOnPawp($serviceSid,$identity){
        $twilio = $this->auth;
        //Fetch and delete old bindings
        $bindings = $twilio->chat->v2->services($serviceSid)
            ->bindings
            ->read([], 20);
        foreach ($bindings as $record) {
            if ($record->identity == $identity) {
                $twilio->chat->v2->services($serviceSid)
                    ->bindings($record->sid)
                    ->delete();
            }
        }
    }

    public function createPawpChannel(Request $request){
        $serviceSid = $this->tServiceSid;
        $twilio = $this->auth;
        $name = $request->name;
        try{
            $channel = $twilio->chat->v2->services($serviceSid)
                ->channels
                ->create([
                    'friendlyName'=>$name,
                    'uniqueName' =>$name,
                    'type' => 'private',
                ]);
            $member_user = 'app-4'.'_user-6';
            self::addMember($channel->sid,$member_user,$this->tChannelRoleUserSid);
            return $channel;
        }
        catch (TwilioException $e){
            throw new TwilioException($e->getMessage());
        }
    }

    protected function updateChannelName($channel_sid,$channel_name,$attributes){
        $serviceSid = $this->tServiceSid;
        $twilio = $this->auth;
        $channel = $twilio->chat->v2->services($serviceSid)
            ->channels($channel_sid)
            ->update(["friendlyName" => $channel_name,"attributes" => json_encode($attributes)]);
    }

    protected function addMember($channelName,$id,$role_sid){
        //header('X-Twilio-Webhook-Enabled: true');
        $serviceSid = $this->tServiceSid;
        $twilio = $this->auth;
        try {
            //$URL = 'https://chat.twilio.com/v2/Services/' . $serviceSid . '/Channels/' . $channelName . '/Members';
            $URL = 'https://chat.twilio.com/v2/Services/';
            $URI = $serviceSid . '/Channels/' . $channelName . '/Members';
            $addData = array(
                'Identity' => $id,
                'RoleSid' => $role_sid,
            );
            $header = ['X-Twilio-Webhook-Enabled'=>'true'];
            //Make a guzzle http request to add member
            //To add custom header
            $member = $this->httpRequest($URL,$URI,$addData,$this->tApiKey,$this->tApiSecret,$header);
//
        } catch (TwilioException $exception) {
            //throw new TwilioException($exception->getMessage());
            $member = $twilio->chat->v2->services($serviceSid)
                ->channels($channelName)
                ->members($id)
                ->fetch();
            //$member = $e->getMessage();
        }
        return $member;
    }

    protected function updateMemberIdentity($user_sid,$identity){
        $serviceSid = $this->tServiceSid;
        $twilio = $this->auth;
        try {
            $user = $twilio->chat->v2->services($serviceSid)
                ->users($user_sid)
                ->update([
                        "identity" => $identity
                    ]
                );
        } catch (TwilioException $exception) {
            throw new TwilioException($exception->getMessage());
            //$member = $e->getMessage();
        }
        return $user;
    }

    private function httpRequest($url,$uri,$params,$username,$pwd,$header){
        $httpclient = new \GuzzleHttp\Client(['base_uri' => $url]);
        $request = $httpclient->request('POST',$uri,[
            'form_params'=> $params,
            'headers'=> $header,
            'auth'=> [$username,$pwd]
        ]);
        //$member = $request->send();
        return $request->getBody();
    }

    private function httpRequestWithJson($url,$uri,$params,$username,$pwd,$header){
        try {
            $httpclient = new \GuzzleHttp\Client(['base_uri' => $url]);
            $request = $httpclient->request('POST', $uri, [
                'json' => $params,
                'headers' => $header,
                'auth' => [$username, $pwd]
            ]);

            return $request->getBody();
        }
        catch (GuzzleException $exception){

        }
    }

    public function vetsInQueue(){
        return Queue::with(['queue'=>function($q){
            $q->where('is_call',false);
        }])->where('status',false)->get();
    }
    //For Chat
//    private function vetChatOnline($vet_id=null){
//        if($vet_id != null){
//            $vet = Vet::role('vets')->where('is_online',1)->where('id','!=',$vet_id)->where('is_call',0)->inRandomOrder()->first();
//        }
//        else{
//            $vet = Vet::role('vets')->where('is_online',1)->where('is_call',0)->inRandomOrder()->first();
//        }
//        //$vet = Vet::role('vets')->where('is_online',1)->inRandomOrder()->first();
//        return isset($vet->id) ? $vet->id:false;
//    }

    private function vetChatOnline(){

        $vets = Vet::role('vets')->where('is_online',1)->inRandomOrder()->get();
        $i = 0;
        foreach ($vets as $a_vet) {
            $temp_vets[$i] = $a_vet->id;
            $i++;
        }

        $vet = array_pop($temp_vets);

        return isset($vet) ? $vet : false;

    }
    //For Video
    private function vetVideoOnline($vet_id=null){
        if($vet_id != null){
            $vet = Vet::role('vets')->where('is_online',1)->where('id','!=',$vet_id)->where('is_call',0)->inRandomOrder()->first();
        }
        else{
            $vet = Vet::role('vets')->where('is_online',1)->where('is_call',0)->inRandomOrder()->first();
        }
        return isset($vet->id) ? $vet->id:false;
    }

    protected function autoMessage($channelsid,$member_vet){
        $serviceSid = $this->tServiceSid;
        $twilio = $this->auth;
        $message = $twilio->chat->v2->services($serviceSid)
            ->channels($channelsid)
            ->messages
            ->create(["body"=>"Hi, How may I assist you?",'from'=>$member_vet]);
//        $channel_name = $this->fetchChannelName($channelsid);
//        $fetch_channel_sid = $this->fetchChannel($channelsid);
//        $this->saveLastMessageIndexDB($fetch_channel_sid,$message->sid,$message->body,$channel_name);
        return $message->sid;
    }

    private function updateChannelEndChat($channel_sid,$appName='null'){
        $twilio = $this->auth;
        $serviceSid = $this->tServiceSid;
        $before = $twilio->chat->v2->services($serviceSid)
            ->channels($channel_sid)
            ->fetch();
        $uniqueName = $before->friendlyName.'-chatEnded-'.Carbon::now();
        $after = $twilio->chat->v2->services($serviceSid)
            ->channels($channel_sid)
            ->update(["uniqueName" => $uniqueName]);
        //Dump to DB
        //Remove admin
        $members = $this->fetchAllMembersFromPawp($channel_sid);
        Chat::where('channel_sid',$channel_sid)->update(['status'=>'true']);

        foreach ($members as $member){
//            if($member['role_sid'] == $this->channelRoleVetSid ){
//                $twilio->chat->v2->services($serviceSid)
//                    ->channels($channel_sid)
//                    ->messages
//                    ->create(["body"=>"Chat has been ended",'from'=>$member['identity']]);
//            }
            //Remove Admin & Vet from channel
            if($member['role_sid'] == $this->tChannelRoleVetSid || $member['role_sid'] == $this->tChannelRoleAdminSid){
                try {
                    $this->removeMemberFromPawp($channel_sid,$member['identity']);
                } catch (TwilioException $e) {}
            }

        }
        try {
            $this->removeAdminMemmber($channel_sid);
        } catch (TwilioException $e) {
        }
        $this->dumpToDB($channel_sid,'system');

        if($appName == 'pawp'){
            //Make HTTP Request to pawp
            if (App::environment('production')){
                $url = 'https://api.pawp.com/';
                $uri = 'v1/telemedicine/vpm/';
                $username = config('services.pawp-clinic-prod.pawp_end_user_key');
                $password = config('services.pawp-clinic-prod.pawp_end_user_pwd');
            }
            if (App::environment('local', 'staging')) {
                $url = 'https://stg-api.pawp.com/';
                $uri = 'v1/telemedicine/vpm/';
                $username = config('services.pawp-clinic-stag.pawp_end_user_key');
                $password = config('services.pawp-clinic-stag.pawp_end_user_pwd');
            }
            $params = array(
                'event'=>'chat_ended',
                'channel_sid'=>$channel_sid,
                'ended_at'=>Carbon::now()
            );
            $header = ['Content-Type'=> 'application/json'];
            $this->httpRequestWithJson($url,$uri,$params,$username,$password,$header);
        }
    }

    private function notifyPawpConversationRequest($params,$type){
        if(App::environment('production')){
            //Make HTTP Request to pawp
            $url = 'https:/api.pawp.com/';
            $uri = 'v1/telemedicine/emergency/';
            $username = config('services.pawp-clinic-prod.pawp_end_user_key');
            $password = config('services.pawp-clinic-prod.pawp_end_user_pwd');
        }
        if (App::environment(['local', 'staging'])) {
            //Make HTTP Request to pawp
            $url = 'https://stg-api.pawp.com/';
            if($type == 'chat'){
                $uri = 'v1/telemedicine/emergency/';
            }
            else{
                $uri = 'v1/telemedicine/emergency/';
            }

            $username = config('services.pawp-clinic-stag.pawp_end_user_key');
            $password = config('services.pawp-clinic-stag.pawp_end_user_pwd');
        }
        $header = ['Content-Type'=> 'application/json'];
        $this->httpRequestWithJson($url,$uri,$params,$username,$password,$header);
    }

    private function updateChannelEndChatByPawp($channel_sid,$vet_id,$value){
        $twilio = $this->auth;
        $serviceSid = $this->tServiceSid;
        $before = $twilio->chat->v2->services($serviceSid)
            ->channels($channel_sid)
            ->fetch();
        $uniqueName = $before->friendlyName.'-chatEnded-'.Carbon::now();
        $after = $twilio->chat->v2->services($serviceSid)
            ->channels($channel_sid)
            ->update(["uniqueName" => $uniqueName]);
        //Notify doctor about end chat by pawp user
        $this->sendPushToVet($vet_id);
        $members = $this->fetchAllMembersFromPawp($channel_sid);
        Chat::where('channel_sid',$channel_sid)->update(['status'=>'true']);

        foreach ($members as $member){
            if($member['role_sid'] == $this->tChannelRoleUserSid){
                $twilio->chat->v2->services($serviceSid)
                    ->channels($channel_sid)
                    ->messages
                    ->create(["body"=>"Chat has been ended",'from'=>$member['identity']]);
            }
            //Remove Admin & Vet from channel
            if($member['role_sid'] == $this->tChannelRoleVetSid || $member['role_sid'] == $this->tChannelRoleAdminSid){
                try {
                    $this->removeMemberFromPawp($channel_sid,$member['identity']);
                } catch (TwilioException $e) {}
            }

        }
        $this->dumpToDB($channel_sid,$value);
    }

    protected function sendPushToVet($vet_id){
        $vetData = Vet::find($vet_id);
        if(isset($vetData->devices) && !empty($vetData->devices)){
            if ($vetData->devices->dev_type == 'ios') {
                $binding_type = 'apn';
                $binding_address = $vetData->devices->device_token;
            } else {
                $binding_type = 'fcm';
                $binding_address = $vetData->devices->device_token;
            }
            $data = [
                'type' => 'showFeedback',
            ];
            $this->userEndCallbindings('vet_' . $vetData->id, $binding_address, $binding_type, $data, 'default', 'Chat ended by pawp client user');
        }
    }

    private function dumpToDB($channelName,$value='null'){
        $serviceSid = $this->tServiceSid;
        $twilio = $this->auth;
        $ended_by = $value ?: 'system';

        try {
            $data = $twilio->chat->v2->services($serviceSid)
                ->channels($channelName);
            $channel_data =$data->fetch();
            // $messages_data = $data->messages->read([], 50);
            $messages_data = $data->messages->read([]); //save all twilio chats on db
            // $get_chat_id = Chat::where('channel_sid',$channelName)->first();
            $get_chat_id = Chat::with('app')->where('channel_sid',$channelName)->first();

            $res = array();
            $attributes = $channel_data->attributes;
            foreach ($messages_data as $key=>$message){
                $res['body'][$key]['index'] = $message->index;
                $res['body'][$key]['type'] = $message->type;
                if($message->type == 'media'){
                    $res['body'][$key]['body'] = json_encode($message->media);
                }
                else{
                    $res['body'][$key]['body'] = $message->body;
                }
                $res['body'][$key]['date_created'] = $message->dateCreated;
                $res['body'][$key]['date_updated'] = $message->dateUpdated;
                $res['body'][$key]['from'] = $message->from;

            }
            $res['chat_id'] = $get_chat_id->id;
            $res['attributes'] = $attributes;

            ChatDetail::create($res);
            if(!empty($get_chat_id->app['send_email_on'])){
                $chat_attrb=json_decode($attributes);
                $event_data = [];
                $event_data['send_email_on'] =$get_chat_id->app['send_email_on'];
                $event_data['app_name'] =$get_chat_id->app['name'];
                $event_data['vetname'] = $chat_attrb->vet->vet_name;
                $event_data['username'] = $chat_attrb->user->user_name;
                $event_data['chatdetails']=($res['body']);
                event(new EndChatEmailEvent($event_data));
            }
            $vetStatusupdate = Vet::find($get_chat_id->vet_id);
                    if(!empty($vetStatusupdate) && $vetStatusupdate->is_chat >= 1){
                        $vetStatusupdate->is_chat = $vetStatusupdate->is_chat - 1;
                        $vetStatusupdate->update();
                    }
            ChatEndedBy::create(['chat_id'=>$get_chat_id->id,'ended_by'=>$ended_by]);


        } catch (TwilioException $exception) {
            throw new TwilioException($exception->getMessage());
        }
    }

    private function removeAdminMemmber($channelName){
        $serviceSid = $this->tServiceSid;
        $twilio = $this->auth;
        try {
            $member = $twilio->chat->v2->services($serviceSid)
                ->channels($channelName)
                ->members('admin-2')
                ->delete();
        } catch (TwilioException $exception) {
            throw new TwilioException($exception->getMessage());
            //$member = $e->getMessage();
        }

        return $member;
    }

    protected function getRoom($room){
        $twilio = $this->auth;
        $room = $twilio->video->v1->rooms($room)->fetch();
        return $room;
    }

    protected function pRoomEvents($room,$status): array
    {
        $twilio = $this->auth;
        $data = $twilio->video->rooms($room,$status)
            ->participants->read(array("status" => $status));
        $response = (array) null;
        $durationvet = '';
        $durationuser = '';
        foreach ($data as $key => $participant){
            $participantConnected = explode('-', $participant->identity);
            $response[] = $participantConnected[1];
           //$durationvet = $participant->duration;
            //$participant2 = explode('-', $participant->identity);
            if($participantConnected[0] == 'vet'){
               // $response['vet_id'] = $participantConnected[1];
                $response['type']='vet';
                $response['vet_id' ]= $participantConnected[1];
                $durationvet = $participant->duration;
            }
            if($participantConnected[0] == 'user'){
                // $response['vet_id'] = $participantConnected[1];
                $response['type']='user';
                $response['user_id' ]= $participantConnected[1];
                $durationvet = $participant->duration;
            }
//            else{
//                $response[] = $participantConnected[1];
//                //$durationuser = $participant->duration;
//            }

        }
        if($durationvet > $durationuser){
            $type = 'vet';
        }
        else{
            $type = 'user';
        }
        $response['type'] = $type;
        return $response;
    }

    private function makeRoom($room_name){
        $twilio = $this->twilio;
        try{
            $room = $twilio->video->v1->rooms
                ->create([
                    "recordParticipantsOnConnect" => True,
                    "statusCallback" => $this->configRoom,
                    "type" => "group-small",
                    "uniqueName" => $room_name,
                    "maxParticipants"=>2,
                ]);
        }
        catch (TwilioException $e){
            $room = [
                'message'=>$e->getMessage(),
                'status'=>'false'
            ];
        }

        return $room;
    }

    private function userBindings($identity,$device_token,$binding_type,$data,$sound,$heading){
        $twilio = $this->auth;
        // Create a notification
        $tobinding = json_encode([
            'binding_type'=>$binding_type,
            'address'=>$device_token
        ]);
        $rand = rand();
        $data['unique_key'] = $rand;
        $notification_sid = $twilio
            ->notify->services($this->pawpnotify)
            ->notifications->create([
                "toBinding" => [
                    $tobinding
                ],
                "body" => $heading,
                "data" => $data,
                "category"=>'AcceptOrReject',
                "sound" => $sound
            ]);
        $response['notification_sid'] = $notification_sid->sid;
        $response['unique_key'] = $rand;
        return $response;
    }

    public function userEndCallbindings($identity,$device_token,$binding_type,$data,$sound,$heading)
    {
        $twilio = $this->auth;
        // Create a notification
        // dd($notification);
        $tobinding = json_encode([
            'binding_type'=>$binding_type,
            'address'=>$device_token
        ]);
        $rand = rand();
        $data['unique_key'] = $rand;
        $notification_sid = $twilio
            ->notify->services($this->pawpNotifyUser)
            ->notifications->create([
                "toBinding" => [
                    $tobinding
                ],
                "body" => $heading,
                "data" => $data,
                "category"=>'AcceptOrReject',
                "sound" => $sound
            ]);
        $response['notification_sid'] = $notification_sid->sid;
        $response['unique_key'] = $rand;
        return $response;
    }

    public function addComposition($room,$composition_id,$event)
    {
        $client = $this->auth;
        if ($event == 'composition-available') {
            //$mediaUrl = $request->MediaUri;
            try{
                $get = VideoCall::where('room_sid',$room)->latest()->first();
                $uri = "https://video.twilio.com/v1/Compositions/$composition_id/Media?Ttl=3600";
                $response = $client->request("GET", $uri);
                $mediaLocation = $response->getContent()["redirect_to"];
                file_put_contents("myFile.mp4", fopen($mediaLocation, 'r'));
                $content = file_get_contents($mediaLocation);
                $name = $room.'.mp4';
                try{
                    $response = $this->toS3(fopen($mediaLocation, 'r'),$name,$room,$get);
                    return $result = $this->successResponse($response, 'success');
                }
                catch (AwsException $e) {
                    return $result = $this->errorResponse($e->getMessage(),$e->getStatusCode());
                }

            }
            catch (TwilioException | \Exception $e){
                return $result = $this->errorResponse($e->getMessage(),401);
            }
        }
    }

    public function toS3($file,$key,$room_sid,$data){

        // Upload a publicly accessible file. The file size and type are determined by the SDK.
        try {
            $s3 = Storage::disk('s3_extra')->getDriver()->getAdapter()->getClient();
            $resp = Storage::disk('s3_extra')->put($key, $file);
            $cmd = $s3->getCommand('GetObject', [
                'Bucket' => env('AWS_STAG_VIDEO'),
                'Key' =>$key
            ]);
            //Pre Signed URL work
            $request = $s3->createPresignedRequest($cmd, '+30 minutes');
            $presignedUrl = (string)$request->getUri();
            VideoCall::where('id',$data->id)->update([
                'start_time'=>$data->start_time,
                'end_time'=>$data->end_time,
              //  'media_url'=>$presignedUrl
            ]);
            VideoCallMedia::updateOrCreate(['video_call_id'=>$data->id],[
                'media_url' => $presignedUrl,
                'video_call_id'=>$data->id
            ]);
//            VideoCall::where('room_sid',$room_sid)->update(['media_url'=>$presignedUrl]);
            return true;
        } catch (AwsException $e) {
            return false;
            //return $result = $this->errorResponse($e->getMessage(),$e->getStatusCode());
        }
    }

    public function history($room_sid,$vet_id,$user_id){
        //$history = VideoCallHistory::where('video_call_id',$temp->id)->first();
        return VideoCall::where(['room_sid'=>$room_sid,'user_id'=>$user_id,'vet_id'=>$vet_id])->first();
    }

    private function fetchPMediaMessage($media_sid){
        $twilio = $this->auth;
        $serviceSid = $this->tServiceSid;
        $apiKey = $this->tApiKey;
        $apiToken = $this->tApiSecret;
        try{
            $uploadURL = 'https://mcs.us1.twilio.com/v1/Services/'.$serviceSid.'/Media/'.$media_sid;
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $uploadURL);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_USERPWD, "$apiKey:$apiToken");
            curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
            $output = curl_exec($ch);
            $info = curl_getinfo($ch);
            curl_close($ch);
            $json = json_decode($output);
            if(@$json){
                $response = $json->links->content_direct_temporary;
            }
            else{
                $response = 'false';
            }
            return $response;
        }
        catch (RequestException $e){
            throw new RequestException($e->getResponse(),$e->getCode());
        }
    }

    private function fetchAllMembersFromPawp($channelsid){
        $serviceSid = $this->tServiceSid;
        $twilio = $this->auth;
        try {
            $members = $twilio->chat->v2->services($serviceSid)
                ->channels($channelsid)
                ->members
                ->read([], 20);

            $res = array();
            $i = 0;
            foreach ($members as $record) {
                $res[$i]['member_id'] = $record->sid;
                $res[$i]['identity'] = $record->identity;
                $res[$i]['role_sid'] = $record->roleSid;
                $i ++;
            }
        }
        catch (TwilioException $exception){
            throw new TwilioException($exception->getMessage());
        }
        return $res;
    }

    private function removeMemberFromPawp($channelName,$identity){
        $serviceSid = $this->tServiceSid;
        $twilio = $this->auth;
        try {
            $member = $twilio->chat->v2->services($serviceSid)
                ->channels($channelName)
                ->members($identity)
                ->delete();
        } catch (TwilioException $exception) {
            throw new TwilioException($exception->getMessage());
        }
    }

    private function removePawpChannel($channelName){
        $serviceSid = $this->tServiceSid;
        $twilio = $this->auth;
        try {
            $twilio->chat->v2->services($serviceSid)
                ->channels($channelName)
                ->delete();
        } catch (TwilioException $exception) {
            throw new TwilioException($exception->getMessage());
        }
    }

    // Activated Staff
    private function pawpSubAdmin(){
        return
        SubAdmin::where('is_active', 1)
         ->get();
    }
}
