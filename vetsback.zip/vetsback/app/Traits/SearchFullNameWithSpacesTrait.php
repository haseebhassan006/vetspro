<?php


namespace App\Traits;

use Illuminate\Support\Facades\DB;

trait SearchFullNameWithSpacesTrait
{
    protected function fullTextWildcardsSearch($term)
    {
        // removing symbols used by MySQL
        $reservedSymbols = ['-', '+', '<', '>', '@', '(', ')', '~'];
        $term = str_replace($reservedSymbols, '', $term);

        $words = explode(' ', $term);

        foreach ($words as $key => $word) {
            /*
             * applying + operator (required word) only big words
             * because smaller ones are not indexed by mysql
             */
            if (strlen($word) >= 3) {
                $words[$key] = '+' . $word . '*';
            }
        }

        $searchTerm = implode(' ', $words);

        return $searchTerm;
    }
    /**
     * Search on full name ( first and last name) when space exists
     *
     * @param \Illuminate\Database\Eloquent\Builder $query
     * @param string $value
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function SearchFullNameWithSpaces($query,$value,$type = ''){
        if ($type == 'where') {
            $query->Where(DB::raw(
                "REPLACE(CONCAT(COALESCE(first_name,''),' ',COALESCE(last_name,'')),' ',' ')"
            ),
                'like', '%' . $value . '%');
        }
        else{
            $query->orwhere('last_name', 'LIKE', $value . '%')
                        ->orwhere('first_name', 'LIKE', '%' . $value)
                        ->orwhere('email', 'LIKE', '%' . $value)
                        // Concat the name columns and then apply search query on full name
                        ->orWhere(
                            DB::raw(
                            // REPLACE will remove the double white space with single (As defined)
                            "REPLACE(
                                    /* CONCAT will concat the columns with defined separator */
                                    CONCAT(
                                        /* COALESCE operator will handle NUll values as defined value. */
                                        COALESCE(first_name,''),' ',
                                        COALESCE(last_name,'')
                                    ),
                                ' ',' ')"
                        ),
                            'like',
                            '%' . $value . '%'
                        );
        }
        
        return $query;
    }

}
