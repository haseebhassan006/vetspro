<?php
namespace App\Traits;

trait TwilioVideoSDKTait{

}