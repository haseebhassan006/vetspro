<?php


namespace App\Traits;

use LaravelFCM\Facades\FCM;
use LaravelFCM\Message\OptionsBuilder;
use LaravelFCM\Message\PayloadDataBuilder;
use LaravelFCM\Message\PayloadNotificationBuilder;

trait PushNotification
{
    public function pushNotification($notification = [])
    {
        //dd($notification['data']);
        $success = false;

        $optionBuilder = new OptionsBuilder();
        $optionBuilder->setTimeToLive(60 * 20);
//$notification['title']
        $notificationBuilder = new PayloadNotificationBuilder($notification['title']);
        $notificationBuilder->setTitle($notification['title'])
            //->setBody($notification['body'])
            ->setBody($notification['body'])
            ->setSound($notification['sound']);

        $dataBuilder = new PayloadDataBuilder();
        $dataBuilder->addData($notification['data']);

        $option = $optionBuilder->build();
        $notification_data = $notificationBuilder->build();
        $data = $dataBuilder->build();

        $token = $notification['device_token'];

        $downstreamResponse = FCM::sendTo($token, $option, $notification_data, $data);

        $success = $downstreamResponse->numberSuccess();
        if ($success) {
            return true;
        } else {
            return false;
        }
        // $downstreamResponse->numberFailure();
    }
}
