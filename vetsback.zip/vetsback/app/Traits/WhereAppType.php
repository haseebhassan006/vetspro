<?php


namespace App\Traits;

use App\App;
use Illuminate\Support\Facades\DB;

trait WhereAppType
{
    /**
     * Return App Ids as Array
     *
     */
    public function whereAppIdArray($appType){
        $app = new App;
        $res = $app->whereIn('app_type',$appType)->pluck('id');
        return $res;
    }

}
