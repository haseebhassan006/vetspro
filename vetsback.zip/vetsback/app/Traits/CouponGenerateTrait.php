<?php
namespace App\Traits;

use App\VetCareCouponCode;

trait CouponGenerateTrait {
    private function generateCoupon(int $size=10)
    {

        $chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        $couponCode = "";
        for ($i = 0; $i < $size; $i++) {
            $couponCode .= $chars[mt_rand(0, strlen($chars)-1)];
        }
        $code = VetCareCouponCode::withTrashed()->where("code",$couponCode)->first();
        if($code != null)
        {
            $this->generateCoupon();
        }

        return $couponCode;
    }

}


