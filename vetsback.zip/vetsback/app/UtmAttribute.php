<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UtmAttribute extends Model
{
    protected $table = 'utm_attributes';
    protected $fillable = ['app_id', 'attributes'];
    protected $casts = [
        'attributes' => 'object'
    ];
}
