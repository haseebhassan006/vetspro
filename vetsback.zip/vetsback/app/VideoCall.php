<?php

namespace App;

use App\Traits\CustomSearch;
use App\Traits\WhereAppType;
use App\Traits\ExactWordSearch;
use Illuminate\Database\Eloquent\Model;

class VideoCall extends Model
{
    //
    use CustomSearch;
    use WhereAppType;
//    protected $guarded = [];
    // protected $fillable = ['room_sid','user_id','vet_id','start_time','end_time','media_url','app_id','staff_id'];
    protected $fillable = ['room_sid','user_id','vet_id','start_time','end_time','media_url','app_id','staff_id'];
    protected $searchable = ['room_sid'];
    public function user(){
        return $this->hasMany(User::class,'id','user_id');
    }
    public function history(){
        return $this->hasMany(VideoCallHistory::class,'video_call_id','id');
    }
    public function user_history(){
        return $this->hasMany(VideoCallHistory::class,'video_call_id','id')->latest();
    }
    public function vet(){
        return $this->hasMany(Vet::class,'id','vet_id');
    }
    public function app(){
        return $this->hasOne(App::class,'id','app_id');
    }
    public function guest(){
        return $this->hasMany(Guest::class,'id','user_id');
    }
    public function webapps(){
        return $this->hasMany(WebappUser::class,'id','user_id');
    }
    public function mediaUrl(){
        return $this->hasOne(VideoCallMedia::class,'video_call_id','id');
    }

    public function videoUser()
    {
        return $this->hasOne(ReportUserTypeStatus::class,'user_id','user_id');
    }

    public function vcUser()
    {
        return $this->hasOne(VetCareUser::class, 'id', 'user_id');
    }
    
    public function whitelabelUser(){
        return $this->belongsTo(User::class,'user_id','id');
    }

    public function staff(){
        return $this->hasMany(SubAdmin::class,'id','staff_id');
    }

    public function model()
    {
        return $this->morphTo();
    }

}
