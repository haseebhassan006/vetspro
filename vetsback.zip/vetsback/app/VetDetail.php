<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class VetDetail extends Model
{
    protected $fillable = ['profile'];
    protected $appends = ['profile_url'];


    public function vet(){
        return $this->belongsTo(Vet::class);
    }
    
    public function getProfileUrlAttribute()
    {
        $s3 = env('AWS_URL', '');
        return $s3.$this->profile;
    }
}
