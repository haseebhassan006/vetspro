<?php

namespace App;

use App\Traits\FullTextSearch;
use Illuminate\Database\Eloquent\Model;

class Coupon extends Model
{

//    protected $guarded = [];
    use FullTextSearch;

    protected $fillable = ['other','model_id','model_type','package_id'];

    protected $casts = ['other'=>'json'];

    protected $searchable = ['other'];

    public function model()
    {
        return $this->morphTo();
    }

    public function package(){
        return $this->hasOne(Package::class,'id','package_id');
    }


}
