<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TChatInfo extends Model
{
    //
    protected $guarded = [];
}
