<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class VideoCallMedia extends Model
{
    //
    protected $guarded = [];
    public $timestamps = false;
//    public function media()
//    {
//        return $this->belongsTo(VideoCall::class,'id','video_call_id');
//    }
}
