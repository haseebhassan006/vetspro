<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ChatEndedBy extends Model
{
    //
    protected $table = 'chat_ended_by';
    protected $fillable = ['chat_id','ended_by'];
    public $timestamps = false;

}
