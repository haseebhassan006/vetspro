<?php

namespace App;

use App\Traits\CustomSearch;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;


class EmergencyVetClient extends Model
{
    //
    use CustomSearch;
    use SoftDeletes;
    protected $table = 'user_protect_users';
    protected $guarded = [];
    protected $searchable = ['type','is_protect'];
    protected $appends = ['emergencyFund'];

//    public function users(){
//        return $this->belongsTo(User::class);
//    }
    public function userData(){
        return $this->hasMany(User::class,'id','user_id');
    }

    public function userDataWithTrashed(){
        return $this->hasMany(User::class,'id','user_id')->withTrashed();
    }

    public function vetData(){
        return $this->hasMany(Vet::class,'id','vet_id');
    }

    public function vetDataWithTrashed(){
        return $this->hasMany(Vet::class,'id','vet_id')->withTrashed();
    }

    public function webappData(){
        return $this->hasMany(WebappUser::class,'id','user_id');
    }

    public function webappDataWithThrashed(){
        return $this->hasMany(WebappUser::class,'id','user_id')->withTrashed();
    }

    public function vetCareUserData(){
        return $this->hasMany(VetCareUser::class,'id','user_id');
    }

    public function vetCareUserDataWithThrashed(){
        return $this->hasMany(VetCareUser::class,'id','user_id')->withTrashed();
    }

    public function appData(){
        return $this->hasMany(App::class,'id','app_id');
    }

    public function flagsEmergency(){
        return $this->hasOne(FlagProtectUser::class,'emergency_id','id');
    }

    public function notesEmergency(){
        return $this->hasOne(NoteProectUser::class,'emergency_id','id');
    }

    public function notesEmergencyLatest(){
        $model = $this->hasOne(NoteProectUser::class,'emergency_id','id')->latest();
        return $model;
    }
    public function usageLatest(){
        return $this->hasOne(VetCarePackageUsage::class,'user_id','user_id')->latest();
    }

    public function getEmergencyFundAttribute(){
        $fund = ( $this->usageLatest()->first() && $this->usageLatest()->first()->package()->first()  )
        ? $this->usageLatest()->first()->package()->first()->emergency_fund
        : null;

        if($fund == null && $this->appData()->first() && $this->appData()->first()->app_setting){
          if(
            json_decode($this->appData()->first()->app_setting->other)->enable_handshake
            &&
            json_decode($this->appData()->first()->app_setting->other)->enable_handshake == 1
            ){
            $fund = $this->appData()->first()->app_setting->emergency_fund;
          }
        }

        return $fund;
    }

}
