<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class VetCareUserFeedback extends Model
{
    
    protected $guarded = [];

    // All vetcare users
    public function user()
    {
        return $this->belongsTo(VetCareUser::class, 'user_id', 'id');
    }

    public function vet()
    {
        return $this->belongsTo(Vet::class, 'vet_id', 'id');
    }

    public function app()
    {
        return $this->belongsTo(App::class, 'app_id', 'id');
    }
    public function model()
    {
        return $this->morphTo();
    }
    
}
