<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UnauthenticatedUsers extends Model
{
    //
    protected $fillable = ['ip','url'];
}
