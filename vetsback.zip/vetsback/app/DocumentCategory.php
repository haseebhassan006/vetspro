<?php

namespace App;

use App\DocumentResource;
use Illuminate\Database\Eloquent\Model;

class DocumentCategory extends Model
{
    protected $guarded = [];


    public function documents(){
        return $this->hasMany(Document::class,'category_id','id');
    }
}
