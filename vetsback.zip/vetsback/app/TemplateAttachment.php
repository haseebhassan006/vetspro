<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TemplateAttachment extends Model
{
    protected $fillable = ['body','image_url','attachmentable_type','attachmentable_id','title'];

    public function attachmentable()
    {
        return $this->morphTo();
    }
}

