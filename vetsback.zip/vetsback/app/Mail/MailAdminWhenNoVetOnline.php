<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;

class MailAdminWhenNoVetOnline extends Mailable
{
    use Queueable, SerializesModels;
    public $date;

    /**
     * Create a new message instance.
     *
     * @param $date
     */
    public function __construct($date)
    {
        //
        $this->date = $date;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this->from(env('MAIL_FROM_ADDRESS'))
            ->bcc(env('MAIL_BCC'))
            ->subject('Vets are unavailable')
            ->view('emails.informative');
    }
}
