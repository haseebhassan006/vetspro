<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;

class SendChatOnEmail extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * @var
     */
    public $vetname;
    public $username;
    public $chatdetails;
    public $appname;

    /**
     * Create a new message instance.
     *
     * @param $vetname
     * @param $username
     * @param $chatdetails
     */
    public function __construct($vetname,$username,$appname,$chatdetails)
    {
        $this->vetname = $vetname;
        $this->username = $username;
        $this->appname = $appname;
        $this->chatdetails = $chatdetails;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this->from('leon@vetsplusmore.com')
            // ->cc(env('MAIL_CC'))
            //  ->bcc(env('MAIL_BCC'))
            ->subject('EndChat Details')
            ->view('emails.sendChatonEmail');
    }
}
