<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;

class InformClientErrorEmail extends Mailable
{
    use Queueable, SerializesModels;

    public $date;
    public $app;
    public $body;
    public $code;
    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($date,$appname,$body,$code)
    {
        $this->date = $date;
        $this->app = $appname;
        $this->body = $body;
        $this->code = $code;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this->from('leon@vetsplusmore.com')
            ->bcc(env('MAIL_BCC'))
            ->subject('Error Integration VPM')
            ->view('emails.customErrorClient');
    }
}
