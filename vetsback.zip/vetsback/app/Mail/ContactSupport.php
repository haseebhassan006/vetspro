<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;

class ContactSupport extends Mailable
{
    use Queueable, SerializesModels;

    public $heading;
    public $text;
    public $user;
    public $email;

    /**
     * Create a new message instance.
     *
     * @param $heading
     * @param $text
     * @param $user
     * @param $email
     */
    public function __construct($heading,$text,$user,$email)
    {
        $this->heading = $heading;
        $this->text = $text;
        $this->user = $user;
        $this->email = $email;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this->from(env('MAIL_FROM_ADDRESS'))
            ->bcc(env('MAIL_BCC'))
            ->subject('Contact Support - VPM')
            ->view('emails.contactSupport');
    }
}
