<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;

class EmailFeedbacks extends Mailable
{
    use Queueable, SerializesModels;

    public $data;
    public $from_address;
    public $email;
    public $subject;
    public $attachment;

    /**
     * Create a new message instance.
     *
     * @param $data
     * @param $from_address
     * @param $email
     * @param $subject
     * @param $attachment
     */
    public function __construct($data, $from_address, $email, $subject, $attachment)
    {
        $this->data = $data;
        $this->from_address = $from_address;
        $this->email = $email;
        $this->subject = $subject;
        $this->attachment = $attachment;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this->from(env('MAIL_FROM_ADDRESS'))
            ->bcc(env('MAIL_BCC'))
            ->subject($this->subject)
            ->view('emails.sendFeedbacks', $this->data)
            ->attach($this->attachment);
    }
}
