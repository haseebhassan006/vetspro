<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Link extends Model
{
    use SoftDeletes;

    protected $guarded = [];
    
    public function LinkCategory()
    {
        return $this->belongsTo(LinkCategory::class,'category_id','id');
    }
}
