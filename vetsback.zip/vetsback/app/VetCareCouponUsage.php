<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class VetCareCouponUsage extends Model
{
    protected $guarded = [];
    public function model()
    {
        return $this->morphTo();
    }

    public function coupon(){
        return $this->hasOne(VetCareCoupon::class,'id','coupon_id')->withTrashed();
    }

    public function couponCode(){
        return $this->belongsTo(VetCareCouponCode::class,'vet_care_coupon_code_id')->withTrashed();
    }
}

