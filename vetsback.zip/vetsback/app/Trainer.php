<?php

namespace App;

use JWTAuth;
use Spatie\Permission\Traits\HasRoles;
use Illuminate\Database\Eloquent\Model;
use Tymon\JWTAuth\Contracts\JWTSubject;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Foundation\Auth\User as Authenticatable;

class Trainer extends Authenticatable implements JWTSubject
{
    use HasRoles;
    use SoftDeletes;
    // use CustomSearch;

    protected $guarded = [];
    protected $guard_name = 'trainer';

    protected $hidden = [
        'password'
    ];

    /** Get the identifier that will be stored in the subject claim of the JWT.
    *
    * @return mixed
    */
   public function getJWTIdentifier()
   {
       return $this->getKey();
   }

   /**
    * Return a key value array, containing any custom claims to be added to the JWT.
    *
    * @return array
    */
   public function getJWTCustomClaims()
   {
       return [];
   }

   /**
    * Get all of the devices for the Trainer
    *
    * @return \Illuminate\Database\Eloquent\Relations\MorphOne
    */
    public function devices(){
        return $this->morphOne(Device::class, 'model');
    }

    /**
     * Get all of the schedules for the Trainer
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function schedules()
    {
        return $this->hasMany(TrainerSchedule::class, 'trainer_id', 'id');
    }

    /**
     * Get all of the appointments for the Trainer
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function appointments()
    {
        return $this->hasMany(AppointmentBooking::class, 'trainer_id', 'id');
    }

    public function AuthenticationHistory()
    {
        return $this->morphMany(AuthenticationHistory::class, 'model');
    }

    /**
     * Get all of the review for the Trainer
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function reviews()
    {
        return $this->hasMany(TrainerReview::class);
    }

    public function getSpecialtiesAttribute($value) {
        return json_decode($value);
    }

}
