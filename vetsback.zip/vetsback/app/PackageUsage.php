<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class PackageUsage extends Model
{
    //
    use SoftDeletes;
    protected $guarded = [];

    public function user(){
        return $this->belongsTo(User::class);
    }

    public function package(){
        return $this->belongsTo(Package::class);
        //return $this->hasMany(PackageUsage::class,'id','package_id');
    }

    public function payment(){
        return $this->hasOne(Payment::class,'id','payment_id');
    }

    public function coupon(){
        return $this->hasOne(Coupon::class,'id','coupon_id');
    }

}
