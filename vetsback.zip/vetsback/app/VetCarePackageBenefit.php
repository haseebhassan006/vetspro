<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class VetCarePackageBenefit extends Model
{
    protected $fillable = ['benefit_title','features'];

    /**
     * The Package that belong to the Benifit.
     */
    public function package()
    {
        return $this->belongsToMany(VetCarePackage::class, 'package_benefit_pivot', 'vet_care_benefit_id' , 'vet_care_package_id');
    }
}
