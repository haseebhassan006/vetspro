<?php

namespace App;

use App\Traits\CustomSearch;
use App\Traits\FullTextSearch;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class PetVeterinarian extends Model
{
    //
    //use FullTextSearch;
    use CustomSearch;
    use SoftDeletes;

    protected $guarded = [];
    protected $searchable = [
        'name','phone_no'
    ];
    public function petData(){
        return $this->belongsTo(Pet::class);
    }
}
