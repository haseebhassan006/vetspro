<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AuthenticationHistory extends Model
{
    protected $guarded = [];

    // protected $hidden = ['model_type','model_id'];

    /**
     * Morph to All models
     * @return \Illuminate\Database\Eloquent\Relations\MorphTo
     */
    public function model()
    {
        return $this->morphTo();
    }

    public function vet()
    {
        return $this->belongsTo(Vet::class,'model_id','id');
    }

    public function staff()
    {
        return $this->belongsTo(SubAdmin::class,'model_id','id');
    }
}
