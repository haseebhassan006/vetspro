<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Third Party Services
    |--------------------------------------------------------------------------
    |
    | This file is for storing the credentials for third party services such
    | as Mailgun, SparkPost and others. This file provides a sane default
    | location for this type of information, allowing packages to have
    | a conventional file to locate the various service credentials.
    |
    */

    'mailgun' => [
        'domain' => env('MAILGUN_DOMAIN'),
        'secret' => env('MAILGUN_SECRET'),
        'endpoint' => env('MAILGUN_ENDPOINT', 'api.mailgun.net'),
    ],

    'postmark' => [
        'token' => env('POSTMARK_TOKEN'),
    ],

    'ses' => [
        'key' => env('SES_KEY'),
        'secret' => env('SES_KEY_SECRET'),
        'region' => env('SES_REGION', 'us-east-1'),
    ],

    'sparkpost' => [
        'secret' => env('SPARKPOST_SECRET'),
    ],
    'stripe' => [
        'vetsplusmore' => env('STRIPE_VETSPLUSMORE','sk_test_732F2dDpMu6Czdv0T6kfXmr1'),
        'vetcare' => env('STRIPE_VETSPLUSMORE','sk_test_732F2dDpMu6Czdv0T6kfXmr1'),
        'petvethotline' => env('STRIPE_PETVETHOTLINE','sk_test_51GyfNuCUS39ZEZ7t3l808bs7bLTGdnt0bltHc5QTugyWvaCq6ZcxsU66UZP1yy5p9qSXM7LZ5mByvRxgKwqFg8pk00WlvWsxaC'),
        'linkvet'=>env('STRIPE_LINKVET')
    ],
    'vpm-chats-local'=>[
        //Authentication
        'auth_token' => 'c43480c98bf99ce34e2764d1f8bb14dd',
        'account_sid'=> 'AC1fb1ee89018a3d86fbe5db65afd96460',
        'api_key' =>'SKf0ff01ec1bdc927fdfebb29591ff02f6',
        'api_secret' =>'MH3UU0xG14b0XHnY1FlgA05iwNtoNr3j',
        'service_sid' =>'ISbaa48843bb7544519d587e5e92182993',
        //Roles
        'service_role_sid'=>'RLa995d1772b8c4b3693ef8c0885450906',
        'channel_role_sid'=>'RLd113f8d75c3e4588ba8000eced9d9bc1',
        'channel_vet_sid'=> 'RL90196796ada54123b61e65d7fc37accd',
        'channel_admin_sid'=>'RLfb8296f483694bef8c8346ead740e742',
        'channel_no_role_sid'=>'RLdf9883ab72e14f8aa2326ec056ed1cee',
        'admin_user_sid'=>'USf8b32c47b093485c89e0394b55587f98',
        //Push Credentials
        'push_android_user_vpm'=>'CRd02b890897b615a3fe237e7454295751',
        'doctor_app_stag_ios' => 'CR6e8141f5ffc36ad1932d1104cf16f689',
        'doctor_app_stag_android' =>'CR08d9d2a061a4c6f1bb16af02de05af67',
        'push_ios_user_vpm'=>'CRc83a839f83fc1785bf414cf34e176687',
        'credential_sid_ios_vetcarehotline'=>'CRb3ba2e49e4bcf2253193560335a4dfda',
        'credential_sid_android_vetcarehotline' =>'CRd02b890897b615a3fe237e7454295751',
        'credential_sid_android_linkmyvet' =>'CRd02b890897b615a3fe237e7454295751',
        'credential_sid_ios_linkmyvet'=>'CR7a1badb8de9216e0a751cba470966300',
        //Notify service
        //Vet video call
        'notify_sid'=>'IS2e2ce468196825aaa63a631e37c78043',
        // User Push to Vet
        'vet_to_inform_user_sid' => 'IS2f50883f4c2b4a8b3311dba02257e0f3',
        //User stripe
        'user_notify_sid'=>'ISe7bd6e01d8d163ef97cada13f10a7c98',
        //One pet creds
        'onepet_user_key'=>'onepet',
        'onepet_user_secret'=>'BO0kGe5FV22w0iHnNMVft4yFA1LBDKVJ',
        //Petcube user creds
        'petcube_user_key'=>'vpm',
        'petcube_user_secret'=>'$A$pbA1Lq6Tk%oe',
        //PetAcumen User creds
        'petacumen_user_key'=>'VpmHook',
        'petacumen_user_secret'=>'vpm4dogtastic!',
        //Vidaah User creds
        'vidaah_user_key'=>'vpmvidaah',
        'vidaah_user_secret'=>'u7MoiF8jpOALMj',
         //One Pet Twilio Creds
        'twilio_one_pet_credential_android'=>'CR773396fac6502c4eaf854a9cf56f7d78',
        'twilio_one_pet_credential_ios'=>'CR506e6756d62fb23548af8bbec4073230',
        //Nimble User Creds
        'nimble_user_key'=>'vetpm',
        'nimbler_user_secret'=>'s8AuKsaB',
        'nimble_user_api_key'=>'SC97ssGC',
        //Pet cube Twilio Creds
        'twilio_pet_cube_credential_android'=>'CR116e0e212ae682d7612ab9b2aeacc45d',
        'twilio_pet_cube_credential_ios'=>'CR1ff79cc576326491f7c22c1000badd30'


    ],
    'vpm-chats-prod'=>[
        //Authentication
        'auth_token' => 'c43480c98bf99ce34e2764d1f8bb14dd',
        'account_sid'=> 'AC1fb1ee89018a3d86fbe5db65afd96460',
        'api_key' =>'SKf0ff01ec1bdc927fdfebb29591ff02f6',
        'api_secret' =>'MH3UU0xG14b0XHnY1FlgA05iwNtoNr3j',
        'service_sid' =>'IS64db9b84071845d3b3b132a161cf1fd7',
        //Roles
        'service_role_sid'=>'RLe1e22de5946a40d9acb19f0e94813d9b',
        'channel_role_sid'=>'RL1b849b6dd6e74312a90357c94a18f70a',
        'channel_vet_sid'=> 'RL98702ce007874517aa3a2701d1ecc9d9',
        'channel_admin_sid'=>'RL0810e38b0c7c41fdb5ca04376864c145',
        'channel_no_role_sid'=>'RLdf9883ab72e14f8aa2326ec056ed1cee',
        'admin_user_sid'=>'USedef909180304af18d6f1f645c456b05',
        //Push Credentials
        'credential_sid_ios_vetsplusmore' => 'CR70763612778ee5e6e679cdb967bf2d14',
        'credential_sid_android_vetsplusmore' =>'CRd02b890897b615a3fe237e7454295751',
        'vetsapp-prod-fcm'=>'CRe75698c323ba4bec4dfe6fefdc40cb7c',
        'vetsapp-prod-apn'=>'CR96181b1b59adb88d995922256103d922',
        'credential_sid_ios_vetcarehotline'=>'CRc0f4e82bfd1fd3516c4ea0bc391dbb29',
        'credential_sid_android_vetcarehotline' =>'CRd02b890897b615a3fe237e7454295751',
        'credential_sid_android_linkmyvet' =>'CRd02b890897b615a3fe237e7454295751',
        'credential_sid_ios_linkmyvet'=>'CRedf57753cd08a4447b9553bbe809ca47',
        //Notify service
        'notify_sid'=>'IS13b078f086c9936dc16450b2bfa975b4',
        'user_notify_sid'=>'IS119a251b7d3558677c97635b43f7f8bb',
        // User Push to Vet
        'vet_to_inform_user_sid' => 'IS0a40918d9b1c9f2e7bf4604981705e9f',
        //Vidaah User creds
        'vidaah_user_key'=>'vpmvidaah',
        'vidaah_user_secret'=>'u7MoiF8jpOALMj',
        //PetAcumen User creds
        'petacumen_user_key'=>'VpmHook',
        'petacumen_user_secret'=>'vpm4dogtastic!',
        //One pet creds
        'onepet_user_key'=>'onepet',
        'onepet_user_secret'=>'3jhhrRUTVe0aM9eD0BUea0id2p4Zxj6G',
        //Petcube user creds
        'petcube_user_key'=>'vpm',
        'petcube_user_secret'=>'$A$pbA1Lq6Tk%oe',
        //One Pet Twilio Creds
        'twilio_one_pet_credential_android'=>'CRfbd4c60df04f280f8fdcd0b24a999cd7',
        'twilio_one_pet_credential_ios'=>'CR66325437e3c05bf2becddadad1e5b964',
        //Pet cube Twilio Creds
        'twilio_pet_cube_credential_android'=>'CR116e0e212ae682d7612ab9b2aeacc45d',
        'twilio_pet_cube_credential_ios'=>'CRc54d458afabe5b14c5f2402fa53d41db',
        //Nimble User Creds
        'nimble_user_key'=>'vetpm',
        'nimbler_user_secret'=>'cJMq3QoD',
        'nimble_user_api_key'=>'kr8DvdYn',
    ],
    'vpm-chats-test'=>[
        'auth_token' => 'c43480c98bf99ce34e2764d1f8bb14dd',
        'account_sid'=> 'AC1fb1ee89018a3d86fbe5db65afd96460',
        'api_key' =>'SKf0ff01ec1bdc927fdfebb29591ff02f6',
        'api_secret' =>'MH3UU0xG14b0XHnY1FlgA05iwNtoNr3j',
        'service_sid' =>'IS0429c455a67f465199e309b18c6df883',
        'credential_sid_ios_vetsplusmore' => 'CR6e8141f5ffc36ad1932d1104cf16f689',
        'credential_sid_android_vetsplusmore' =>'CR08d9d2a061a4c6f1bb16af02de05af67',
        'service_role_sid'=>' RL291346326b0340c9842e74be1e6b180b',
        'channel_role_sid'=>'RLad4a5aa991f84811a83b4be2c3c96361',
        'channel_vet_sid'=> 'RL66bd683b74424ab4b33ee2580b4ae735',
        'channel_admin_sid'=>'RL10d1d133984c4378a69c9ecb9152b2ca',
        'channel_no_role_sid'=>'RLdf9883ab72e14f8aa2326ec056ed1cee',
        'notify_sid'=>'IS2e2ce468196825aaa63a631e37c78043',
        'push_android_user_vpm'=>'CR79a27d91b230274d7a89d9f4ab7d8c5e',
        'push_ios_user_vpm'=>'CRc83a839f83fc1785bf414cf34e176687',
        'notify_push_service_sid'=>'IS13b078f086c9936dc16450b2bfa975b4'


    ],
    'pawp-clinic-stag'=>[
        'auth_token' => '242b2319872f5b1a78665333497f542c',
        'account_sid'=> 'ACba2194786acc09049805371364fbd7b1',
        'api_key' =>'SK72b8078bed5a5cae4a66748c580879a2',
        'api_secret' =>'13dquwG934u7H4JKWsq6cFXFHUW4k3Pn',
        'service_sid' =>'ISa2b536e57b034ed1ad04be2894b73920',
        'service_role_sid'=>' RL291346326b0340c9842e74be1e6b180b',
        'channel_role_sid'=>'RL27222c0584b54b00b54f714581fe72b9',
        'channel_vet_sid'=> 'RLefa610b6c2e74bdf90272f744e482fff',
        'channel_admin_sid'=>'RL7e65eeef78ac40f597fa5adfc6dff070',
        'channel_no_role_sid'=>'RL7031b6cebaa543fbac6fe5db5fc05cc0',
        'push_android_user_vpm'=>'CR79a27d91b230274d7a89d9f4ab7d8c5e',
        'push_ios_user_vpm'=>'CRc83a839f83fc1785bf414cf34e176687',
        'notify_push_service_sid'=>'IS13b078f086c9936dc16450b2bfa975b4',
        'notification_vets_app_ios'=>'CR9c0d134ef8eb12ea0f755b0c64e8009b',
        'notification_vets_app_android'=>'CR01db1f9bedf077214c9f8a62a5b66b23',
        'pawp_end_user_key'=>'vpm-admin',
        'pawp_end_user_pwd'=>'zsiqMYfhI8N9VKu8Is3UUg8RwNY5GmP35AbjCIAoqjjNssSx42XSVi3L5rnzRUyg',
        'pawpNotify'=>'IS5cb0cec06548db6beafc604f3eede84e',
        'pawpNotifyUser'=>'ISdceee1d85c1aef117d2cf6a9624d1ea3',
        'vpm-pawp_user'=>'pawp_admin',
        'vpm_pawp_user_pwd'=>'visiOn20**',
        'admin_user_sid'=>'USca157482455c4b14b204a9dff5b6e25f',

    ],
    'pawp-clinic-prod'=>[
        //Auth
        'auth_token' => '242b2319872f5b1a78665333497f542c',
        'account_sid'=> 'ACba2194786acc09049805371364fbd7b1',
        'api_key' =>'SKed078a70dc1d8d12c5568acffbb319bf',
        'api_secret' =>'qQeTBgErykfqSghsyS3mzxiTYL3iOnff',
        'service_sid' =>'IS596bede569884b268527be6b25f9315f',
        //Roles
        'service_role_sid'=>' RL291346326b0340c9842e74be1e6b180b',
        'channel_role_sid'=>'RLe591f822b7f74a77bbb4cb8fe443e527',
        'channel_vet_sid'=> 'RLf359ca30557e49958674f307aea0094d',
        'channel_admin_sid'=>'RL2dbae394a4c5424ea6970ef141bd3034',
        'channel_no_role_sid'=>'RL7031b6cebaa543fbac6fe5db5fc05cc0',
        'admin_user_sid'=>'USbac18d8553ea445090806be5c635b9f8',
        //Notification
        'notify_push_service_sid'=>'IS13b078f086c9936dc16450b2bfa975b4',
        'notification_vets_app_ios'=>'CR70763612778ee5e6e679cdb967bf2d14',
        'notification_vets_app_android'=>'CR3c860da1da7df92001f90367caadefd7',
        'pawpNotify'=>'IS76cc658b7914b0178b63403cab93b460',
        'pawpNotifyUser'=>'IS3ac1bd0a4114fa9c4f927d4049322ae6',
        //Pawp api authentication
        'pawp_end_user_key'=>'vpm-admin',
        'pawp_end_user_pwd'=>'7awGttx36ZHoNPmcCQDorWvtEQQAxYUXACfh4rhvHrPN84K8xTJma4zMn6Ger8EJ',
        //Pawp vpm auth
        'vpm-pawp_user'=>'pawp_admin',
        'vpm_pawp_user_pwd'=>'VeauL9Mn78XGEHvE2'
    ],
    'hand-shake-app-creds' => [
        // 'goodcharlie' => [
        //     'good_charlie' => 'zeG2wkcrhzI9E7fB'
        // ],
        'GoodCharlieVPM' => [
            'goodcharlievpm' => 'zeG2wkcrhzI9E7fB'
        ],
        'groomit' => [
            'groomit' => 'groomit##',
        ],
        'petvethotline' => [
            'petvethotline' => 'b7K3Sui6xge9E7jx'
        ],
    ],

    //Staging
    'vpm-app-creds' => [
        'Vidaah' => [
            'vidaah_admin' => 'visiOn21***'
        ],
        // 'goodcharlie' => [
        //     'good_charlie' => 'good_charlie_staging_access'
        // ],
        'GoodCharlieVPM' => [
            'goodcharlievpm' => 'good_charlie_staging_access'
        ],
        'petcube' => [
            'petcube_admin' => 'visiOn21**'
        ],
        'heaven' => [
            'petheaven_admin' => 'visiOn21**'
        ],
        'petacumen' => [
            'petacumen' => 'petacumen##'
        ],
        'petvethotline' => [
            'pethotline_admin' => 'vision##'
        ],
        'petstablished' => [
            'petstablished_admin' => 'petstablished##'
        ],
        'tailjoy' => [
            'tailjoy_admin' => 'visiOn21***tailjoy_admin'
        ],
        'europ' => [
            'europ_admin' => 'visiOn21##**europe_admin'
        ],
    ],

    //Production
    'vpm-app-creds-production' => [
        'Vidaah' => [
            'vidaah_admin' => 'ekE7Z8Kntsu3tRSdW'
        ],
        // 'goodcharlie' => [
        //     'good_charlie' => 'PfQx37YgCzwiKbXW'
        // ],
        'GoodCharlieVPM' => [
            'goodcharlievpm' => 'PfQx37YgCzwiKbXW'
        ],
        'petcube' => [
            'petcube_admin' => 'k6a9zxQZ3D2WAuJQ'
        ],
        'heaven' => [
            'petheaven_admin' => 'visiOn21**'
        ],
        'petacumen' => [
            'petacumen' => '93Enc76BbUzD9GdH'
        ],
        'petvethotline' => [
            'pethotline_admin' => '8twmTWpAmDKFRMk8'
        ],
        'petstablished' => [
            'petstablished_admin' => 'b6&dcXUbh58!HLZ6'
        ],
        'tailjoy' => [
            'tailjoy_admin' => 'B$&@)17WxL1XqlJ['
        ],
        'europ' => [
            'europ_admin' => '&Cf$mPFokL@PcE$x'
        ],
    ],

];
