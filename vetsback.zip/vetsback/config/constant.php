<?php
   
return [

    'stripe_msg' => 'Something went wrong while processing your card. System returned : insufficient funds or card declined. Status : parameter_invalid_empty',
]
  
?>