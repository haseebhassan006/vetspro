<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddCloumnTrainersEmailVerifcation extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        //
        Schema::table('trainers', function (Blueprint $table) {
            //
            $table->string('verification_token',200)->nullable()->after('is_active');
            $table->timestamp('email_verified_at')->nullable()->after('verification_token');

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
