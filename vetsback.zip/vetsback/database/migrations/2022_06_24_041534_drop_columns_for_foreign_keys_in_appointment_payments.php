<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class DropColumnsForForeignKeysInAppointmentPayments extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('appointment_payments', function (Blueprint $table) {
            //
            if (Schema::hasColumn('appointment_bookings','trainer_id')){
                $table->dropColumn(['trainer_id']);
            }
            if (Schema::hasColumn('appointment_bookings','app_id')){
                $table->dropColumn(['app_id']);
            }
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('appointment_payments', function (Blueprint $table) {
            //
        });
    }
}
