<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class ScriptToUpdateCreatedAtOfAppId25InUserStatuses extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        DB::beginTransaction();
        try {
                $webapp_users=App\WebappUser::where('app_id',25)->get();
                foreach($webapp_users as  $webapp_user){
                    $userAppStatus=App\UserAppStatus::where(['app_id'=>25,'user_id'=>$webapp_user->id])->whereDate('created_at', '=', '2022-09-19')->first();
                    if($userAppStatus && ($userAppStatus->created_at != $webapp_user->created_at)){
                        $userAppStatus->created_at =$webapp_user->created_at;
                        $userAppStatus->update();
                        DB::commit();
                        $data[] = array('id'=>$userAppStatus->id);
                    }
                }
                print_r($data); 
                echo "script executed !";
            } catch (\Exception $e) {
                DB::rollback();
                echo $e;
            }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
       
    }
}
