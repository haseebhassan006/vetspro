<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddColumnInNotesProtectUsers extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('notes_protect_users', function (Blueprint $table) {
            $table->char('is_last_created',1)->default(0);
            
        });

        $EmergencyVetClients=App\EmergencyVetClient::select('id')->get();
        foreach($EmergencyVetClients as $EmergencyVetClient){
            $NoteProectUser=App\NoteProectUser::where('emergency_id',$EmergencyVetClient->id)->get();
            if(sizeof($NoteProectUser)>0){
                $toUpdate=$NoteProectUser->last();
                $toUpdate->is_last_created =1;
                $toUpdate->update();
            }else{
                continue;
            }
        }

    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('notes_protect_users', function (Blueprint $table) {
            //
            $table->dropColumn('is_last_created');

        });
    }
}
