<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class DropColummnsInAppointmentBookings extends Migration
{

    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('appointment_bookings', function (Blueprint $table) {
            //
            if (Schema::hasColumn('appointment_bookings','trainer_id')){
                $table->dropColumn(['trainer_id']);
            }
            if (Schema::hasColumn('appointment_bookings','app_id')){
                $table->dropColumn(['app_id']);
            }
            if (Schema::hasColumn('appointment_bookings','schedule_id')){
                $table->dropColumn(['schedule_id']);
            }
            if (Schema::hasColumn('appointment_bookings','appointment_payment_id')){
                $table->dropColumn(['appointment_payment_id']);
            }
        });

      
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('appointment_bookings', function (Blueprint $table) {
            //
        });
    }
}
