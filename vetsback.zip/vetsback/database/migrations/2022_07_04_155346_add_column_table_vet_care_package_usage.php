<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddColumnTableVetCarePackageUsage extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('vet_care_package_usages', function (Blueprint $table) {
            if(!Schema::hasColumn('vet_care_package_usages',"vet_care_coupon_code_id")){
                $table->bigInteger('vet_care_coupon_code_id')->unsigned()->after('coupon_id');
            }
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('vet_care_package_usages', function (Blueprint $table) {
            if(Schema::hasColumn('vet_care_package_usages',"vet_care_coupon_code_id")){
                $table->dropColumn(['vet_care_coupon_code_id']);
            }
        });
    }
}
