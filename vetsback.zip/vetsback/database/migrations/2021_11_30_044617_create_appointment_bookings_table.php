<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateAppointmentBookingsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('appointment_bookings', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->integer('trainer_id')->unsigned();
            $table->integer('app_id')->unsigned()->nullable();
            $table->morphs('model');
            $table->integer('schedule_id')->unsigned();
            $table->integer('appointment_pet_id')->unsigned()->nullable();
            $table->integer('appointment_payment_id')->unsigned()->nullable();
            $table->text('booking_note')->nullable();
            $table->string('contact_no')->nullable();
            $table->enum('status', ['Pending','Accepted','Cancelled','Rejected','PaymentDue'])->default('Pending');
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('appointment_bookings');
    }
}
