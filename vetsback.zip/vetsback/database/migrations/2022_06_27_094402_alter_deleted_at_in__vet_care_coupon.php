<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AlterDeletedAtInVetCareCoupon extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('vet_care_coupons', function (Blueprint $table) {
            \DB::statement("ALTER TABLE `vet_care_coupons` CHANGE `deleted_at` `deleted_at` TIMESTAMP NULL");
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('vet_care_coupons', function (Blueprint $table) {
            //
        });
    }
}
