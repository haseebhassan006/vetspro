<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class MakeForeignKeysInAppointmentBookings extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('appointment_bookings', function (Blueprint $table) {
            //
            $table->unsignedBigInteger('trainer_id')->nullable()->after('id');
            $table->bigInteger('app_id')->nullable()->after('trainer_id');
            $table->unsignedBigInteger('schedule_id')->nullable()->after('app_id');
            $table->unsignedBigInteger('appointment_payment_id')->nullable()->after('schedule_id');
           
            
            $table->index('schedule_id');
            $table->index('trainer_id');
            $table->index('app_id');
            $table->index('appointment_payment_id');

            $table->foreign('schedule_id')->references('id')->on('trainer_schedules')->onDelete('cascade');
            $table->foreign('appointment_payment_id')->references('id')->on('appointment_payments')->onDelete('cascade');
            $table->foreign('trainer_id')->references('id')->on('trainers')->onDelete('cascade');
            $table->foreign('app_id')->references('id')->on('apps')->onDelete('cascade');

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('appointment_bookings', function (Blueprint $table) {
            //
        });
    }
}
