<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class DropForeignKeyBookingPetIdFromTrainerReviews extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {

        Schema::table('trainer_reviews', function (Blueprint $table) {
            if (Schema::hasColumn('trainer_reviews','booking_pet_id')){
                $table->dropColumn(['booking_pet_id']);
                // $table->dropForeign(['booking_pet_id']);
            }
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
