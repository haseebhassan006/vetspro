<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateAppointmentPetsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('appointment_pets', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->integer('trainer_id')->unsigned();
            $table->integer('app_id')->unsigned()->nullable();
            $table->morphs('model');
            $table->string('name');
            $table->string('species');
            $table->string('age')->nullable()->default(null);
            $table->string('breed');
            $table->string('color');
            $table->string('weight')->nullable()->default(null);
            $table->enum('sex', ['Male','Female']);
            $table->enum('sex_type', ['Spayed','Neutered']);
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('appointment_pets');
    }
}
