<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AlterVetCareCouponsOthersColumnDataScript extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
         //script starts here
         DB::beginTransaction();
         try {
             $vetCareCoupons=App\VetCareCoupon::withTrashed()->get();
             foreach($vetCareCoupons as $key=>$vetCareCoupon){

                 if(isset($vetCareCoupon->other['percent_off']) && $vetCareCoupon->other['percent_off'] > 0){
                     $off_type = 'percent_off';
                     $price_off = $vetCareCoupon->other['percent_off'];
                 }elseif(isset($vetCareCoupon->other['price_off']) && $vetCareCoupon->other['price_off'] > 0){
                     $off_type = 'price_off';
                     $price_off = $vetCareCoupon->other['price_off'];
                 }else{
                     $off_type = 'none';
                     $price_off = 0;
                 }

                 $vetCareCoupon->other = [
                     "name" => isset($vetCareCoupon->other['name'])?$vetCareCoupon->other['name']:null,
                     "code" => isset($vetCareCoupon->other['code'])?$vetCareCoupon->other['code']:null,
                     "expiry" =>isset($vetCareCoupon->other['expiry'])?$vetCareCoupon->other['expiry']:null,
                     "access_days" =>isset($vetCareCoupon->other['access_days'])?$vetCareCoupon->other['access_days']:null,
                     "off_type" =>$off_type,
                     "price_off" =>$price_off,
                     "one_time" => isset($vetCareCoupon->other['one_time'])?$vetCareCoupon->other['one_time']:null,
                     "enable_pet_tracking"=>isset($vetCareCoupon->other['enable_pet_tracking'])?$vetCareCoupon->other['enable_pet_tracking']:0
                 ];
                 $vetCareCoupon->update();
                 DB::commit();
             }
             echo "script executed !";
            //  dd('script executed !');
         } catch (\Exception $e) {
             DB::rollback();
             echo $e;
             // something went wrong
         }
         //script ends here
    }
    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
