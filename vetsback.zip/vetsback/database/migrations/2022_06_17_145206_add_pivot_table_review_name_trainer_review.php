<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddPivotTableReviewNameTrainerReview extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('review_name_trainer_review', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedBigInteger('review_name_id');
            $table->unsignedBigInteger('trainer_review_id');
            $table->float('rate')->default(0.0);

            $table->foreign('review_name_id')->references('id')->on('review_names')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('trainer_review_id')->references('id')->on('trainer_reviews')->onDelete('cascade')->onUpdate('cascade');

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('review_name_trainer_review');
    }
}
