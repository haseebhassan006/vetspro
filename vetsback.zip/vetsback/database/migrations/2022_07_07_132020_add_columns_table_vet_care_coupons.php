<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddColumnsTableVetCareCoupons extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('vet_care_coupons', function (Blueprint $table) {

            if (!Schema::hasColumn('vet_care_coupons', 'created_by')) {
                $table->unsignedBigInteger('created_by')->after('package_id');
            }
            if (!Schema::hasColumn('vet_care_coupons', 'created_model')) {
                $table->string('created_model')->after('created_by');
            }

            if (!Schema::hasColumn('vet_care_coupons', 'updated_by')) {
                $table->unsignedBigInteger('updated_by')->after('created_model');
            }
            if (!Schema::hasColumn('vet_care_coupons', 'updated_model')) {
                $table->string('updated_model')->after('updated_by');
            }

            if (!Schema::hasColumn('vet_care_coupons', 'deleted_by')) {
                $table->unsignedBigInteger('deleted_by')->after('updated_model');
            }
            if (!Schema::hasColumn('vet_care_coupons', 'deleted_model')) {
                $table->string('deleted_model')->after('deleted_by');
            }



        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('vet_care_coupons', function (Blueprint $table) {
            if (Schema::hasColumn('vet_care_coupons', 'created_by')) {
                $table->dropColumn(['created_by']);
            }
            if (Schema::hasColumn('vet_care_coupons', 'created_model')) {
                $table->dropColumn(['created_model']);
            }

            if (Schema::hasColumn('vet_care_coupons', 'updated_by')) {
                $table->dropColumn(['updated_by']);
            }
            if (Schema::hasColumn('vet_care_coupons', 'updated_model')) {
                $table->dropColumn(['updated_model']);
            }
            if (Schema::hasColumn('vet_care_coupons', 'deleted_by')) {
                $table->dropColumn(['deleted_by']);
            }
            if (Schema::hasColumn('vet_care_coupons', 'deleted_model')) {
                $table->dropColumn(['deleted_model']);
            }
        });
    }
}
