<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddColumnsSendChatOnEmailAndSendEmailOnInApps extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('apps', function (Blueprint $table) {
            //
            $table->boolean('send_chat_on_email')->after('trial_period')->nullable();
            $table->string('send_email_on')->after('send_chat_on_email')->nullable();

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('apps', function (Blueprint $table) {
            $table->dropColumn(['send_chat_on_email']);
            $table->dropColumn(['send_email_on']);
        });
    }
}
