<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddColumnStatusInUserProtectUsers extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('user_protect_users', function (Blueprint $table) {
            //
            $table->enum('status', ['true', 'false','denied'])->default('false');

        });
        $EmergencyVetClients=App\EmergencyVetClient::where('is_protect','true')->get();
        foreach($EmergencyVetClients as $EmergencyVetClient){

            $NoteProectUser=App\NoteProectUser::where('emergency_id',$EmergencyVetClient->id)->get();

            if(sizeof($NoteProectUser)>0){
                $toUpdate=$NoteProectUser->last();
                App\EmergencyVetClient::where('id',$EmergencyVetClient->id)->update([
                    'status'=>$toUpdate->paid
                ]);
            }
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('user_protect_users', function (Blueprint $table) {
            //
            $table->dropColumn('status');

        });
    }
}
