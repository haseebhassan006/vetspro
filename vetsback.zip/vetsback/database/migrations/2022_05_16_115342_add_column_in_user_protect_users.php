<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddColumnInUserProtectUsers extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('user_protect_users', function (Blueprint $table) {
            //
            $table->char('is_latest',1)->default(0);

        });

        $VetCareUsers= App\VetCareUser::withTrashed()->with(['roles'])->whereHas('roles',function($q){
            $q->where('name','protect_users');
        })->latest()->get();

        foreach($VetCareUsers as $VetCareUser){
            $EmergencyVetClient=App\EmergencyVetClient::where('user_id',$VetCareUser->id)->latest()->first();
            if(!empty($EmergencyVetClient)){
                $EmergencyVetClient->is_latest = 1;
                $EmergencyVetClient->update();
            }
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('user_protect_users', function (Blueprint $table) {
            //
            $table->dropColumn('is_latest');

        });
    }
}
