<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class ScriptForHasExpiryCheckInVetCareCoupons extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        DB::beginTransaction();
        try {
        $vetCareCoupons=App\VetCareCoupon::withTrashed()->get();

        foreach($vetCareCoupons as $key=>$vetCareCoupon){
            $vetCareCoupon->other = [
                "name" => isset($vetCareCoupon->other['name'])?$vetCareCoupon->other['name']:null,
                "code" => isset($vetCareCoupon->other['code'])?$vetCareCoupon->other['code']:null,
                "expiry" =>isset($vetCareCoupon->other['expiry'])?$vetCareCoupon->other['expiry']:null,
                "access_days" =>isset($vetCareCoupon->other['access_days'])?$vetCareCoupon->other['access_days']:null,
                "off_type" =>isset($vetCareCoupon->other['off_type'])?$vetCareCoupon->other['off_type']:'none',
                "price_off" =>isset($vetCareCoupon->other['price_off'])?$vetCareCoupon->other['price_off']:0,
                "one_time" => isset($vetCareCoupon->other['one_time'])?$vetCareCoupon->other['one_time']:null,
                "enable_pet_tracking"=>isset($vetCareCoupon->other['enable_pet_tracking'])?$vetCareCoupon->other['enable_pet_tracking']:0,
                "has_expiry" =>isset($vetCareCoupon->other['expiry']) && !empty($vetCareCoupon->other['expiry']) ?true:false,

            ];
            $vetCareCoupon->update();
            DB::commit();

        }
            echo "script executed !";
        } catch (\Exception $e) {
            DB::rollback();
            echo $e;
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {

    }
}
