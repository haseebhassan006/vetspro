<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddPetTrackingCodeInVetCareUsers extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('vet_care_users', function (Blueprint $table) {
            //
            $table->string('pet_tracking_code')->after('next_emergency_activation_date')->nullable();

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('vet_care_users', function (Blueprint $table) {
            //
        });
    }
}
