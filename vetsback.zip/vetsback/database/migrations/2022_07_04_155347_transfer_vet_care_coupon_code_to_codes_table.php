<?php

use App\VetCareCoupon;
use App\VetCareCouponUsage;
use App\VetCarePackageUsage;
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class TransferVetCareCouponCodeToCodesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        VetCareCoupon::doesntHave('vetCareCouponCodes')->whereNotNull('other->code')->withTrashed()->chunk(100, function ($coupons) {
            foreach ($coupons as $coupon) {
                $other = $coupon->other;
                $code = $other['code']??'';
                unset($other['code']);
                $coupon->other = $other;

                $coupon->save();
                if($code)
                {
                    $couponCode= $coupon->vetCareCouponCodes()->create(['code'=>$code,"deleted_at" => $coupon->deleted_at]);
                     VetCareCouponUsage::where('coupon_id',$coupon->id)->update(['vet_care_coupon_code_id'=>$couponCode->id]);
                     VetCarePackageUsage::withTrashed()->where('coupon_id',$coupon->id)->update(['vet_care_coupon_code_id'=>$couponCode->id]);

                }

            }
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {

    }
}
