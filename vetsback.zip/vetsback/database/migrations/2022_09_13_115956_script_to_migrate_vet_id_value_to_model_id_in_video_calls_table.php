<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class ScriptToMigrateVetIdValueToModelIdInVideoCallsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
       
        $videoCalls=App\VideoCall::get();
        foreach($videoCalls as $key=>$videoCall){
            if(!empty($videoCall->vet_id)){
                $videoCall->model_id =$videoCall->vet_id ;
                $videoCall->model_type='App\Vet';
            }
            $videoCall->update();
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
      
    }
}
