<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddStatusEnumValuesInAppointmentBookings extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('appointment_bookings', function (Blueprint $table) {
            //
            \DB::statement("ALTER TABLE `appointment_bookings` CHANGE `status` `status` ENUM('pending','completed','cancelled', 'request cancellation') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Pending';");
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('appointment_bookings', function (Blueprint $table) {
            //
            $table->dropColumn('status');

        });
    }
}
