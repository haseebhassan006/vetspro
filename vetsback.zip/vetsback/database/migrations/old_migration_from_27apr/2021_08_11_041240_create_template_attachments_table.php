<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTemplateAttachmentsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('template_attachments', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->longText('title');
            $table->longText('body');
            $table->text('image_url')->nullable()->default('NULL');
            $table->morphs('attachmentable');
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('template_attachments');
    }
}
