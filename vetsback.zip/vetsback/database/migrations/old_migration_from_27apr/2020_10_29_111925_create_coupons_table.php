<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCouponsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('coupons', function (Blueprint $table) {
            $table->engine = 'InnoDB';
            $table->bigIncrements('id');
            $table->bigInteger('user_id');
            $table->string('name');
            $table->string('code')->unique();
            $table->date('expiry');
            $table->string('access_days');
            $table->string('percent_off')->nullable()->default(null);
            $table->string('price_off')->nullable()->default(null);
            $table->tinyInteger('one_time')->nullable()->default(null);
            $table->tinyInteger('card_detail_required')->nullable()->default(null);
            $table->enum('type', ['simple', 'protect']);
            $table->tinyInteger('is_expiry')->nullable()->default(0);
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('coupons');
    }
}
