<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateDevicesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('devices', function (Blueprint $table) {
            $table->engine = 'InnoDB';
            $table->bigIncrements('id');
            $table->bigInteger('rec_id')->nullable()->default(null);
            $table->string('device_token')->nullable()->default(null);
            $table->string('udid')->nullable()->default(null);
            $table->string('dev_type')->nullable()->default(null);
            $table->integer('model_id')->nullable()->default(null);
            $table->string('model_type')->nullable()->default(null);
            $table->string('app_version')->nullable()->default(null);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('devices');
    }
}
