<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateVetCareCouponsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('vet_care_coupons', function (Blueprint $table) {
        $table->bigIncrements('id')->unsigned();
		$table->bigInteger('package_id')->length(20)->unsigned();
		$table->longText('other')->nullable();
		$table->integer('model_id')->length(11)->nullable();
		$table->string('model_type')->nullable()->default('NULL');
		$table->timestamp('deleted_at');
		$table->timestamp('created_at');
		$table->timestamp('updated_at');
		$table->foreign('package_id')->references('id')->on('vet_care_packages');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('vet_care_coupons');
    }
}
