<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTrainerSchedulesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('trainer_schedules', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->integer('trainer_id');
            $table->timestamp('slot_from_time');
            $table->timestamp('slot_to_time');
            $table->date('date')->nullable();
            $table->enum('day', ['MON','TUE','WED','THU','FRI','SAT','SUN','ALL','NON'])->default('NON');
            $table->double('charges', 8, 2)->nullable()->default(0.00);
            $table->enum('booking_status', ['Available','Booked'])->default('Available');
            $table->timestamps();
            $table->softDeletes();
        });
    }

    

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('trainer_schedules');
    }
}
