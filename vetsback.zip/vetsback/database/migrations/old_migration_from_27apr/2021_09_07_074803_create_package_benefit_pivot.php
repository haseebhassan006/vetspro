<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePackageBenefitPivot extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('package_benefit_pivot', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->bigInteger('vet_care_package_id');
            $table->bigInteger('vet_care_benefit_id');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('package_benifit_pivot', function (Blueprint $table) {
            //
        });
    }
}
