<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTelescopeEntriesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('telescope_entries', function (Blueprint $table) {
            $table->engine = 'InnoDB';
            $table->bigIncrements('sequence');
            $table->char('uuid', 36);
            $table->char('batch_id', 36);
            $table->string('family_hash')->nullable()->default(null);
            $table->tinyInteger('should_display_on_index')->nullable()->default(1);
            $table->string('type', 20);
            $table->longText('content');
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('telescope_entries');
    }
}
