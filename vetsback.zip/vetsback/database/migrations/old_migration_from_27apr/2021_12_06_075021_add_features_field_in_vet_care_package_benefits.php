<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddFeaturesFieldInVetCarePackageBenefits extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('vet_care_package_benefits', function (Blueprint $table) {
            $table->text('features')->nullable()->after('benefit_title');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('vet_care_package_benefits', function (Blueprint $table) {
            //
        });
    }
}
