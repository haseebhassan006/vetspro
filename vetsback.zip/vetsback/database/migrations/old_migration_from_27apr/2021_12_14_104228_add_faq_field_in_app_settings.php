<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddFaqFieldInAppSettings extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('app_settings', function (Blueprint $table) {
            $table->string('title')->nullable()->after('secondary_color')->nullable();
            $table->text('fav_icon')->nullable()->after('secondary_color')->nullable();
            $table->longText('faqs')->nullable()->after('secondary_color')->nullable();
            $table->longText('other')->nullable()->after('zipcode_validation')->nullable();
            $table->double('emergency_fund', 8, 2)->nullable()->after('secondary_color');
            $table->enum('is_payment_required',['true','false'])->default('true')->after('secondary_color');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('app_settings', function (Blueprint $table) {
            //
        });
    }
}
