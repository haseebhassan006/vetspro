<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

class AlterTableVetCarePackageUsages extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('vet_care_package_usages', function (Blueprint $table) {

            if(Schema::hasColumn('vet_care_package_usages','coupon_id'))
            {
                DB::statement('ALTER TABLE `vet_care_package_usages` MODIFY `coupon_id` BIGINT UNSIGNED NULL;');
            }

            if(Schema::hasColumn('vet_care_package_usages','vet_care_coupon_code_id'))
            {
                DB::statement('ALTER TABLE `vet_care_package_usages` MODIFY `vet_care_coupon_code_id` BIGINT UNSIGNED NULL;');
            }

            if(Schema::hasColumn('vet_care_coupon_usages','coupon_id'))
            {
                DB::statement('ALTER TABLE `vet_care_coupon_usages` MODIFY `coupon_id` BIGINT UNSIGNED NULL;');
            }

            if(Schema::hasColumn('vet_care_coupon_usages','vet_care_coupon_code_id'))
            {
                DB::statement('ALTER TABLE `vet_care_coupon_usages` MODIFY `vet_care_coupon_code_id` BIGINT UNSIGNED NULL;');
            }
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('vet_care_package_usages', function (Blueprint $table) {
            //
        });
    }
}
