<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\SubAdmin;
use Faker\Generator as Faker;

$factory->define(SubAdmin::class, function (Faker $faker) {
    return [
        //
    ];
});
